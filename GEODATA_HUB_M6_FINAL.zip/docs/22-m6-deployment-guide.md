# GEODATA HUB — Production Deployment Guide

**Version**: M6 (post-M5.4)
**Date**: 2026-11-21
**Status**: Production-ready (with documented risks — see completion report)

---

## 1. Hosting Requirements

### 1.1 Runtime

- **Node.js / Bun**: the app is built and tested on Node.js 20+ and Bun 1.3+. Production should run the Next.js standalone server (`.next/standalone/server.js`).
- **Memory**: 512 MB minimum, 1 GB recommended (the PDF generator loads full documents into memory; the calculation engine is light).
- **CPU**: 1 vCPU minimum; 2 vCPU recommended for concurrent PDF generation.

### 1.2 Database

- **Development**: SQLite (`db/custom.db`, file-based). NOT recommended for production multi-instance deployments (single-writer contention under load).
- **Production**: PostgreSQL 14+ (the Prisma schema is portable — switch the `datasource db.provider` to `"postgresql"` and run `prisma migrate deploy`). The `prisma/postgresql/0001_init.sql` migration is provided as a starting point.
- **Connection**: `DATABASE_URL=postgresql://USER:PASSWORD@HOST:5432/DBNAME?schema=public`

### 1.3 Reverse proxy

- A reverse proxy is REQUIRED for TLS termination and production-grade rate limiting. A `Caddyfile` is included (HTTP-only on :81 for the dev preview — production must enable HTTPS).
- **Recommended**: Caddy v2 (auto-HTTPS via Let's Encrypt), nginx, or a cloud load balancer (AWS ALB, Cloudflare, etc.).
- **Headers to forward**: `Host`, `X-Forwarded-For`, `X-Forwarded-Proto`, `X-Real-IP` (the Caddyfile shows the pattern).
- **NEXTAUTH_URL** must be set to the public HTTPS URL (NextAuth validates redirect targets against it).

### 1.4 Storage

- **`storage/uploads/`**: lab documents (PDFs, photos, drawings). Must be persistent across deployments.
- **`storage/reports/`**: generated report PDFs. Must be persistent across deployments.
- **Production**: mount a persistent volume at `storage/`. For multi-instance deployments, use shared storage (NFS, S3-compatible object storage with a custom driver — not currently implemented).

### 1.5 External dependencies

- **`pdfkit`** (v0.21.0): pure-JS PDF generation, no native dependencies.
- **`bcryptjs`**: pure-JS bcrypt (no native build). For high-throughput production, consider switching to `bcrypt` (native) for ~3× faster hashing.
- **`sharp`** (v0.34.3): image processing (Next.js image optimization). Has prebuilt binaries for common platforms.
- **No external API dependencies** (no third-party services called at runtime).

---

## 2. Environment Variables

See `.env.example` for the template. **Required for production**:

| Variable | Description | Example |
|----------|-------------|---------|
| `DATABASE_URL` | Database connection string | `postgresql://user:pass@host:5432/geodata?schema=public` |
| `NEXTAUTH_SECRET` | Random string ≥32 chars (signs session JWTs) | `openssl rand -base64 32` |
| `NEXTAUTH_URL` | Public HTTPS URL of the deployment | `https://geodata.example.com` |

**Rotate `NEXTAUTH_SECRET` if any prior commit containing a real secret was pushed to a shared repository** — see the M6 security audit.

### Secrets hygiene

- `.env` is gitignored (M6 fix). NEVER commit a real `.env`.
- `.env.example` is committed and contains placeholder values only.
- For production secret management, use your platform's secret store (AWS Secrets Manager, GCP Secret Manager, Docker secrets, Kubernetes secrets).

---

## 3. Build & Deploy

### 3.1 Build

```bash
# Install dependencies
bun install  # or: npm ci

# Generate the Prisma client
bunx prisma generate

# Apply DB migrations (PRODUCTION — never reset)
bunx prisma migrate deploy  # PostgreSQL
# OR for SQLite dev: bunx prisma db push --accept-data-loss

# Build the Next.js standalone server
bun run build
# Output: .next/standalone/ (server.js) + .next/static/ + public/
```

### 3.2 Run

```bash
# Start the standalone server
NODE_ENV=production node .next/standalone/server.js
# OR with Bun:
NODE_ENV=production bun .next/standalone/server.js

# The server listens on $PORT (default 3000).
```

### 3.3 Health check

```bash
curl -sf https://your-deployment/api/health
# {"success":true,"data":{"status":"ok","service":"geodata-hub","db":"reachable","auth":"nextauth-v4","api":"v1"}}
```

Use this endpoint for Kubernetes liveness/readiness probes or load balancer health checks.

### 3.4 Seed initial data (first deployment only)

```bash
# WARNING: this RESETS the database — only run on a fresh deployment.
bun run db:seed
# Demo password for all seeded users: Demo1234!
# Rotate immediately after first login.
```

---

## 4. Database Deployment Procedure

### 4.1 Initial deployment

1. Provision a PostgreSQL 14+ database.
2. Set `DATABASE_URL` in the production environment.
3. Switch `prisma/schema.prisma` `datasource db.provider` to `"postgresql"` (already supported — the schema is provider-portable).
4. Run `bunx prisma migrate deploy` to create the schema.
5. Run `bun run db:seed` to populate demo data (optional — for production, create real organizations and users via the API or direct SQL).

### 4.2 Schema updates (subsequent deployments)

1. **Backup first**: `pg_dump geodata > backup-$(date +%F).sql` (or use your managed-DB snapshot feature).
2. Review the migration in `prisma/migrations/` (when present).
3. Run `bunx prisma migrate deploy` (applies pending migrations non-destructively).
4. **NEVER run `prisma migrate reset` in production** — it drops all data.

### 4.3 SQLite → PostgreSQL migration

If migrating from the dev SQLite to production PostgreSQL:

1. Export the SQLite data: `sqlite3 db/custom.db .dump > data.sql` (or use Prisma's `prisma db pull` to introspect).
2. Manually transform the SQL (SQLite uses `TEXT` for DateTime; PostgreSQL uses `TIMESTAMP` — Prisma handles this transparently if you re-seed).
3. For production, prefer seeding fresh data over migrating dev data.

---

## 5. Backup & Recovery

### 5.1 Backup procedure

**PostgreSQL**:
```bash
# Logical backup (daily):
pg_dump --format=custom --file=geodata-$(date +%F).dump geodata

# Or with pg_dumpall for cluster-wide:
pg_dumpall --file=cluster-$(date +%F).sql
```

**File storage**: backup `storage/uploads/` and `storage/reports/` directories (these contain user documents and generated PDFs not stored in the DB).

### 5.2 Recovery procedure

**PostgreSQL**:
```bash
# Restore from a custom-format dump:
pg_restore --clean --if-exists --dbname=geodata geodata-YYYY-MM-DD.dump

# Or from a plain SQL dump:
psql -d geodata -f cluster-YYYY-MM-DD.sql
```

**File storage**: restore the `storage/` directory from your backup target.

### 5.3 Backup integrity verification

A backup is only useful if it can be restored. Use `scripts/m6-verify-backup.ts` to verify backup integrity:

```bash
bun run scripts/m6-verify-backup.ts /path/to/backup.db
```

The script verifies:
- All 13 tables are present.
- Row counts are non-zero (sanity check).
- `PRAGMA integrity_check` returns `ok`.
- No foreign-key violations.

### 5.4 Backup frequency

- **Database**: daily (managed-DB automated backups recommended) + weekly off-site.
- **File storage**: daily (rsync to backup volume or S3 sync).
- **Retention**: 30 days minimum; 90 days recommended for audit purposes.

---

## 6. Rollback Instructions

### 6.1 Application rollback

1. Keep the previous deployment's build artifact (`.next/standalone/` directory) for one release.
2. On rollback: stop the current server, restore the previous build, restart.
3. The database schema is forward-compatible within a minor version — rolling back the app one version typically does NOT require a DB rollback.

### 6.2 Database rollback

**ONLY if a migration caused data loss** (rare — Prisma migrations are additive by design in this project):

1. Stop the application.
2. Restore the most recent pre-migration backup: `pg_restore --clean --dbname=geodata backup-YYYY-MM-DD.dump`.
3. Roll back the application to the matching build.
4. Investigate the migration issue before re-attempting.

### 6.3 Prisma migration rollback

Prisma does not auto-generate down-migrations. To roll back a specific migration:

1. Create a NEW migration that reverses the schema change (e.g. `DROP TABLE` for an added table, `ALTER TABLE ... DROP COLUMN` for an added column).
2. Apply with `bunx prisma migrate deploy`.
3. NEVER use `prisma migrate reset` in production.

---

## 7. Monitoring & Logging

### 7.1 Application logs

- **Format**: structured plaintext via `console.log` (Next.js dev mode) — wrap with a JSON logger (pino, winston) for production.
- **API access log**: every request is logged as `[api] METHOD /path → STATUS` (see `src/lib/api/api-utils.ts`).
- **Error log**: thrown `AppError` instances are caught by `withApi` and returned as the uniform error envelope — they do NOT leak stack traces.
- **Activity log**: every significant operation is recorded in the `ActivityLog` table (visible in the `/activity` UI page and the `/api/activity` endpoint).

### 7.2 Sensitive data handling

- Passwords: hashed with bcrypt (10 rounds) — never logged, never returned in API responses.
- `NEXTAUTH_SECRET`: never logged.
- File paths: `filePath` (documents) and `pdfStoragePath` (reports) are server-controlled and never returned in API responses (only the download URL).
- The health endpoint returns only structural metadata (status, service, db reachability) — no secrets, no environment values.

### 7.3 Recommended monitoring

- **Uptime**: `/api/health` (HTTP 200 = healthy, 503 = degraded DB).
- **Error rate**: count HTTP 5xx responses in the access log.
- **DB connection pool**: monitor Prisma connection pool usage (PostgreSQL `pg_stat_activity`).
- **Disk usage**: `storage/` grows with uploaded documents and generated PDFs — monitor and alert at 80% capacity.

---

## 8. Security Hardening Checklist

Before going live, verify:

- [ ] `NEXTAUTH_SECRET` is a fresh random value (rotated if any prior commit leaked a secret).
- [ ] `NEXTAUTH_URL` is set to the public HTTPS URL.
- [ ] HTTPS is enforced at the reverse proxy (Caddy/nginx auto-redirect from HTTP).
- [ ] `DATABASE_URL` uses a dedicated least-privilege PostgreSQL role (not the superuser).
- [ ] Rate limiting is configured at the reverse proxy (the app does not ship with a rate limiter).
- [ ] `storage/uploads/` and `storage/reports/` are NOT served directly by the reverse proxy (only through the app's authenticated download endpoints).
- [ ] The demo seed (`bun run db:seed`) was NOT run in production, OR all demo users were deleted/rotated after first login.
- [ ] `Demo1234!` passwords are NOT used in production.
- [ ] The first ORG_ADMIN password is strong and unique.
- [ ] CORS is restricted (the app uses same-origin + SameSite=Lax cookies by default; no CORS headers are emitted).
- [ ] The `X-Content-Type-Options: nosniff` header is set on all responses (verified in `src/lib/api/api-response.ts`).
- [ ] The `Cache-Control: private, no-store` header is set on all API responses (verified in `src/lib/api/api-response.ts`).

---

## 9. Pre-deployment Verification

Run the full regression suite before every production deployment:

```bash
# 1. Static checks
npx tsc --noEmit           # must pass with 0 errors
npx eslint .               # must pass with 0 errors/warnings

# 2. Engine + service + API regression (M5.2)
bash scripts/m5.2-int-run-all.sh all

# 3. Frontend regression (M5.3)
bash scripts/m5.3-run-all.sh all

# 4. M5.4 classification + reports
bun test ./scripts/m5.4-test-classification.ts
bash scripts/m5.4-run-integration.sh

# 5. M6 E2E + role matrix + cross-org isolation
bash scripts/m6-run-e2e.sh

# 6. Production build
bun run build

# 7. Backup integrity
bun run scripts/m6-verify-backup.ts /path/to/latest-backup.db
```

All checks must pass before promoting to production.

---

## 10. Known Limitations

1. **No built-in rate limiting**: the app relies on the reverse proxy for rate limiting. Add Caddy/nginx rate limit directives in production.
2. **Single-instance SQLite**: the dev DB is SQLite — production must use PostgreSQL for multi-instance horizontal scaling.
3. **No CSRF token rotation**: the app uses SameSite=Lax cookies + same-origin checks (the NextAuth security model). For stricter CSRF protection, add a double-submit CSRF token (not currently needed).
4. **No 2FA / SSO**: authentication is username/password only. Add NextAuth providers (SAML, OIDC) for enterprise SSO if required.
5. **No audit log retention policy**: the `ActivityLog` table grows indefinitely. Add a retention job (e.g. delete entries older than 1 year) for long-running deployments.
6. **PDF generation is in-process**: each PDF generation request runs in the Next.js server process. For high-volume deployments, offload PDF generation to a queue + worker (BullMQ, SQS) — currently synchronous.
7. **File storage is local**: `storage/` is a local directory. For multi-instance deployments, use shared storage or implement an S3-compatible storage driver.

See the M6 completion report (`docs/22-m6-completion-report.md`) for the full risk register.
