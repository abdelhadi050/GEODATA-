# GEODATA HUB — Phase 1: Phased Implementation Plan

**Status:** Proposed — awaiting approval. Maps 1:1 to the requested Phases 2–8. Each phase ends with a **verification gate**; errors are fixed before the next phase starts. Nothing after Phase 1 begins until the architecture is approved.

---

## Phase 2 — Foundation (after approval)

**Tasks**

1. Environment variables: generate `NEXTAUTH_SECRET` (never printed), set `NEXTAUTH_URL`, keep `DATABASE_URL`; create `.env.example` with SQLite + PostgreSQL templates.
2. Install new dependencies: `leaflet`, `react-leaflet@^5`, `@types/leaflet`, `bcryptjs`, `@types/bcryptjs`.
3. Design-system foundations: `globals.css` tokens (emerald/teal primary, status colors), `PageHeader`, `StatusBadge`, `StatCard`, `EmptyState`, `ConfirmDialog`, `DataToolbar`; root layout with ThemeProvider + Toaster + QueryProvider.
4. App shell: `(app)` layout with server-side session guard, sidebar, topbar, breadcrumbs, user menu, mobile drawer; `/login` page with demo-credentials panel; root redirect logic.
5. `lib/constants.ts` (value sets, labels, colors) and `lib/rbac.ts` (role matrix).

**Gate 2 (browser-verified):** lint clean; `tsc --noEmit` clean; `/` redirects correctly in both session states; login page renders with theme; shell navigation works; logout returns to `/login`.

## Phase 3 — Database & Backend

**Tasks**

1. Replace scaffold demo models with the approved 11-model schema; `db:push`; create migration history (`prisma migrate dev`) for the PostgreSQL path.
2. `prisma/seed.ts`: 2 organizations, 6 users, 5 projects, ~30 boreholes, layers, samples, ~60 lab tests with realistic results, documents, sharing requests, activity entries.
3. Authentication: NextAuth credentials provider + bcryptjs; JWT session callbacks (`role`, `organizationId`); R1 smoke test on Next 16.
4. `lib/api-utils.ts` handler wrapper (session → RBAC → Zod parse → service → uniform error envelope) and `lib/services/*` with tenant scoping; `lib/validation/*` Zod schemas (client+server shared) incl. lab-test result registry.
5. All API route handlers from architecture §7; `/api/health`.
6. Activity logging on every mutation.

**Gate 3 (runtime-tested):** seed runs cleanly; login works via API for all 6 accounts; scripted CRUD curl/bun tests for every entity pass; **tenant isolation test** — Org B user denied Org A resources (403/404) unless covered by the approved share; RBAC violations rejected server-side.

## Phase 4 — Core Application

**Tasks**

1. Dashboard: KPIs, status distribution chart, recent activity.
2. Projects: list (search/filter/sort/paginate), create/edit forms, detail (boreholes, documents, sharing, reports tabs), delete (admin, confirm dialog), boundary viewer.
3. Boreholes: list, create/edit (coordinate input with mini-map picker), detail page with stratigraphy log column, samples table, tests table, documents.
4. Geological layers: inline CRUD on the borehole detail (depth-validated).
5. Samples: list with lab-status workflow actions, CRUD forms.
6. Lab tests: list, create on sample, result entry forms per test type, status workflow.

**Gate 4 (browser-verified):** full CRUD flows per role; validation errors display inline; toasts confirm mutations; empty/loading states present; `manager` can create a project end-to-end; `viewer` sees no mutation controls.

## Phase 5 — GIS

**Tasks**

1. Map page with client-only Leaflet integration; OSM basemap + satellite toggle; scale bar; zoom/fit controls.
2. Borehole markers (status-colored divIcons) + project boundary polygons via `/api/map/data`.
3. Marker selection: popup + info side panel with links (borehole detail, samples, tests).
4. Map filters: project, status, type; boundary visibility toggle.

**Gate 5 (browser-verified):** map renders with seeded data; markers selectable; filters reduce markers live; boundaries toggle; fit-to-project works; mobile layout usable; no SSR/hydration errors in `dev.log`.

## Phase 6 — Collaboration & Documents

**Tasks**

1. Sharing workflow UI: create request, inbox (approve/reject), sent list (revoke), statuses and expiry; shared projects read-only in partner org with badge.
2. Team page: members, role changes, deactivation, add user (simulated invite with one-time password reveal).
3. Documents: upload with metadata, filtered list, streaming download, delete; project + borehole attachment scopes.
4. Reports: borehole log and test summary print views (`/print/...`), report records with history.

**Gate 6 (browser-verified):** Org A manager shares → Org B admin approves → Org B users see the project read-only; revoked share disappears; upload/download/delete work per role; print view produces a clean borehole log.

## Phase 7 — Testing & Quality

**Tasks**

1. `tsc --noEmit` (strict) — zero errors.
2. `bun run lint` — zero errors/warnings.
3. Database validation: schema sync, integrity spot-checks, unique-constraint behavior.
4. Scripted test suite (`scripts/`): CRUD for every entity, auth flows, RBAC matrix per role, tenant isolation matrix, sharing lifecycle.
5. Browser workflow regression (agent-browser): login → dashboard → project → borehole → sample → test → map → share → document → report; logout.
6. Fix everything found; re-run until green.

**Gate 7:** all checks green; no console/runtime errors in `dev.log` during the regression.

## Phase 8 — Finalization

**Tasks**

1. UI polish pass: spacing, alignment, card consistency, dark-mode audit.
2. Responsiveness audit (mobile breakpoints on every screen).
3. Loading skeletons and empty states verified everywhere; toast feedback on every mutation.
4. Demo credentials panel on login; README with installation, demo script (a 5-minute guided tour), architecture summary, functional-vs-simulated list, PostgreSQL/deployment guide (env vars, migrate, seed, S3/email evolution paths).
5. Final end-to-end regression + preview handoff.

**Gate 8 (definition of done):** every functional requirement from the specification demonstrably works in the browser; every simulated feature is labeled; README complete; the prototype runs from the preview panel.

---

## Effort & sequencing notes

- Phases 2–3 are the critical path (auth + tenancy correctness); Phases 4–6 are feature builds on proven foundations; Phases 7–8 harden and package.
- Each phase produces a working, verifiable increment — the app is never left in a broken intermediate state.
- Any deviation from this plan (scope, substitutions) will be announced and justified before it is made, per the execution rules.
