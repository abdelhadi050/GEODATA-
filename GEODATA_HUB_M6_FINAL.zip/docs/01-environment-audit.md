# GEODATA HUB — Phase 1: Environment Audit

**Date:** 2026-11-20 · **Status:** Complete · **Purpose:** factual inventory of the development environment before any application code is written.

---

## 1. Project directory inspection

| Item | Finding |
|---|---|
| Working directory | `/home/z/my-project` (Next.js project root) |
| Pre-existing user work | **None.** Only a platform note `download/README.md` and sandbox scaffold boilerplate (demo `User`/`Post` Prisma models, demo `page.tsx`). Nothing was deleted or overwritten. |
| Action on boilerplate | The demo `User`/`Post` models and demo page will be **replaced in Phase 3 with the real GEODATA HUB schema**. Reason: they are sandbox placeholders, not user work. This is the only destructive change, and it is announced here first. |

## 2. Runtime & tooling

| Tool | Version | Notes |
|---|---|---|
| bun | 1.3.14 | Package manager + dev runtime (platform mandate) |
| Node.js | v24.22.3 | Available for auxiliary tooling |
| npm | 11.19.1 | Available |
| TypeScript | 5.x (strict) | Configured by scaffold |
| git | 2.47.3 | Available |
| Mermaid CLI (mmdc) | available | Used to render the ERD |
| RAM | 4 GB | Constrained; favors lightweight dev DB |

## 3. Framework & libraries already installed (from `package.json`)

| Category | Package (version) | Status for GEODATA HUB |
|---|---|---|
| Framework | next ^16.1.1 (App Router, Turbopack) | Use as-is (running 16.1.3) |
| UI runtime | react / react-dom ^19.0.0 | Use as-is |
| Styling | tailwindcss ^4, @tailwindcss/postcss ^4, tw-animate-css | Use as-is |
| Component library | shadcn/ui (New York) — ~50 components in `src/components/ui` | Use as-is |
| Icons | lucide-react ^0.525.0 | Use as-is |
| ORM | prisma ^6.11.1 + @prisma/client (client generated v6.19.2) | Use as-is |
| Auth | next-auth ^4.24.11 | Installed, **not configured** — to be configured in Phase 3 |
| Forms | react-hook-form ^7.60, @hookform/resolvers ^5.1 | Use as-is |
| Validation | zod ^4.0.2 | Use as-is (client + server) |
| Tables | @tanstack/react-table ^8.21.3 | Use as-is (search/filter/sort/pagination) |
| Server state | @tanstack/react-query ^5.82 | Use as-is |
| Client state | zustand ^5.0.6 | Use as-is (map/UI state) |
| Charts | recharts ^2.15.4 | Use as-is (lab test visualization) |
| Misc | sonner (toasts), next-themes (dark mode), framer-motion, date-fns, uuid, sharp | Use as-is |
| Backend SDK | z-ai-web-dev-sdk ^0.0.18 | Backend-only use if AI features are ever added; not needed for MVP |

**Must be installed (not present):** `leaflet`, `react-leaflet` (v5 for React 19), `@types/leaflet`, `bcryptjs`, `@types/bcryptjs`.

## 4. Database environment

| Check | Result |
|---|---|
| PostgreSQL server (`pg_isready`, `psql`) | **Not available in this sandbox** (no client, no server) |
| Prisma datasource configured | SQLite, file at `/home/z/my-project/db/custom.db` (platform mandate for the sandbox) |
| Prisma scripts | `db:push`, `db:generate`, `db:migrate`, `db:reset` (already defined) |
| **Probe: `Json` field on SQLite** | **VERIFIED WORKING** — DDL accepted and a GeoJSON Polygon round-trip (write → read → delete) succeeded with Prisma 6.19.2 client. See `scripts/probe-json.ts`. |

**Conclusion (decision point for approval):** the prototype will run on **SQLite inside this sandbox**, while the schema, migrations, and documentation are written to be **PostgreSQL-compatible** for the production/cloud target. Prisma `enum` and scalar-list types are avoided (SQLite does not support them) in favor of `String` + Zod-validated value sets, which migrate to PostgreSQL unchanged. The switch is a documented two-line change (see `03-database-design.md`, §5).

## 5. Network & serving topology

| Item | Finding |
|---|---|
| Dev server | Started automatically by the platform on **port 3000 only** (verified HTTP 200; log in `dev.log`) |
| Gateway | Caddy (`Caddyfile`) proxies **all paths** to `localhost:3000`; additional local ports reachable only via `?XTransformPort=<port>` query (for mini-services) |
| Multi-route support | All App Router paths (`/login`, `/dashboard`, ...) are served through the gateway — full multi-route application is supported. To be re-verified with browser testing in Phase 2. |
| API rule | Frontend must use relative URLs only (no absolute hosts/ports) |
| Build rule | `bun run build` must not be used in the sandbox; quality gates are `bun run lint` + `tsc --noEmit` + runtime tests |

## 6. Platform constraints affecting the design

1. Single externally exposed port (3000) — no side-car services required for MVP; the WebSocket mini-service pattern exists if real-time features are added later.
2. `z-ai-web-dev-sdk` is backend-only — not used in MVP.
3. Files under `/home/z/my-project/` persist between sessions; uploaded documents stored under `storage/` persist for the demo lifetime.
4. UI color rule from the platform: avoid blue/indigo as primary palette → proposed **emerald/teal + stone** earth-science palette (see `02-architecture.md` §9).

## 7. Audit verdict

The environment matches the requested production stack (Next.js 16 + TypeScript + Tailwind + shadcn/ui + Prisma) with exactly one substitution: **SQLite instead of PostgreSQL for the sandbox runtime**, with a documented, tested path to PostgreSQL for deployment. No blocking gaps were found; all required capabilities (auth, GIS, charts, validation, tables) are covered by installed or installable packages.
