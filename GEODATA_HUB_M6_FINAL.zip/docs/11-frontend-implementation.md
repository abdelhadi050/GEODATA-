# GEODATA HUB — Frontend Implementation (M4)

**Status:** Implemented and tested (M4) · **Applies to:** `src/app/(app)/**`, `src/components/**`, `src/lib/api-client.ts`, `src/lib/server-api.ts`, `src/lib/api-types.ts`, `src/lib/format.ts`
**Prerequisites:** M1 (auth shell, RBAC), M2 (schema, services, registry), M3 (API endpoints, envelope, security) — **unchanged** (verified by regression suites and file timestamps; see §10).

---

## 1. Scope

M4 delivers the complete frontend application on top of the existing M3 API:

- Polished application shell (grouped RBAC-filtered navigation, breadcrumbs, mobile sheet, theme, user menu).
- Real dashboard driven by live API data.
- Projects, Boreholes (+ geological layers + stratigraphy column), Samples, Laboratory Tests (12-type registry, charts, result entry), Documents (upload/download), Sharing (lifecycle), Reports, Activity, Users (team management), Organization settings.
- Consistent loading / empty / error / unauthorized / not-found states.
- Light and dark themes; responsive desktop → mobile (no horizontal overflow at 390 px, tested).

Not in M4 (unchanged decision boundaries): full GIS map (M6), cross-test visual analytics (M5), billing, real-time collaboration. A stratigraphic depth column (not a map) implements the M4 "depth and layer visualization" requirement.

## 2. Frontend architecture

### 2.1 API consumption — one path, no duplicated rules

Every byte of data rendered comes from the real M3 HTTP endpoints. The UI never re-implements authorization, validation or tenant rules — it consumes the API and shapes UX.

| Layer | File | Role |
| --- | --- | --- |
| Browser client | `src/lib/api-client.ts` | Relative-URL fetch wrapper: unwraps the envelope, throws `ApiClientError` (status, code, message, Zod field details), routes 401 → re-login. `apiGet/Post/Patch/Put/Delete/Upload` + `qs()` helper. Multipart upload keeps the browser-set boundary. |
| Server client | `src/lib/server-api.ts` | Server components call the same endpoints with the incoming session cookie forwarded (`cookies()`), React-`cache()`-deduped per render pass. `requireData()` maps 401 → `/login`, 403 → dashboard with a permission notice, 404 → styled not-found. |
| Types | `src/lib/api-types.ts` | The envelope + the exact JSON projections the services return (mirrors docs/10; `filePath` never modeled — the API strips it). |

Server-side self-fetch base URL: `API_BASE_URL` env override, default `http://127.0.0.1:3000`.

### 2.2 Rendering model

- **Reads** — server components; list state (search / filters / sort / page) lives in the URL as search params, so results are shareable and there is no duplicated client state. `PaginationNav` renders link-based pagination preserving filters.
- **Mutations** — client "islands": dialogs and controls built on react-hook-form. Client-side validation mirrors the M2 Zod rules (`validateWithSchema` runs the shared schemas); the payload is re-validated by the API, and envelope `details` are mapped back onto form fields (`handleFormError` + `fieldSetter`).
- **Result entry** — the laboratory result form validates against the **exact registry schema** client-side (`parseLabTestResult`, the same function the API service uses) before `PUT /api/lab-tests/[id]/result`; the server remains authoritative.
- **Session expiry** — server reads redirect to `/login`; client mutations detect 401 and relocate. DB-fresh role checks make deactivation/role changes effective on the next render.

## 3. Application shell

| Element | Implementation |
| --- | --- |
| Navigation | `nav-config.ts` — 5 groups (Overview / Field & Laboratory / Documents & Deliverables / Collaboration / Administration), 11 items, each gated by a capability; sidebar filters by the DB-fresh role (`can()`). VIEWER sees no Sharing/Users; every role sees the data modules it can read. |
| Sidebar | shadcn `Sidebar` — collapsible on desktop, swipe/trigger sheet on mobile; active-route highlighting; tooltips. |
| Top bar | `SidebarTrigger` + breadcrumbs + organization name + theme switcher + user menu (avatar, role, org, sign-out). |
| Breadcrumbs | Static segments map to labels and link back; database-id segments are hidden (the page title identifies the record). |
| States | `loading.tsx` skeletons per route group; `error.tsx` retry card (never leaks internals); `not-found.tsx` explains cross-tenant indistinguishability; `UnauthorizedState` / `EmptyState` shared components; page-level capability guards render 403 UIs instead of crashing. |

## 4. Modules and their API integrations

| Page | Endpoints consumed (all via the M3 API) |
| --- | --- |
| Dashboard | `GET /projects?pageSize=100&sortBy=createdAt&sortOrder=desc`, `GET /projects?status=ACTIVE&pageSize=1` (meta.total), `GET /boreholes?pageSize=1`, `GET /samples?pageSize=1`, `GET /lab-tests?pageSize=100`, `GET /activity?limit=8`, `GET /sharing/requests` (SHARING_MANAGE roles only — viewers see an explicit “requires permission” dash) |
| Projects list | `GET /projects` (search, status, page, pageSize=12) |
| Project create/edit | `POST /projects`, `PATCH /projects/[id]` (own-org only — button hidden for shared projects) |
| Project detail | `GET /projects/[id]` (boreholes, documents, reports, sharing requests embedded; shared projects render read-only notices and hide management actions) |
| Boreholes list | `GET /boreholes` (search, type, status, projectId, page) |
| Borehole create/edit | `POST /boreholes`, `PATCH /boreholes/[id]` |
| Borehole detail | `GET /boreholes/[id]` — drilling record, CSS stratigraphic column (depth-proportional bands, material coloring, USCS labels, sample markers, depth axis), layers table, samples table |
| Layers CRUD | `POST /layers`, `PATCH /layers/[id]`, `DELETE /layers/[id]` (LAYER_MANAGE + own org) |
| Samples list | `GET /samples` (search, type, labStatus, projectId, page) |
| Sample create/edit | `POST /samples`, `PATCH /samples/[id]` |
| Sample detail | `GET /samples/[id]` + `GET /lab-tests/registry` (type options grouped by category; existing types excluded) |
| Lab tests list | `GET /lab-tests` (testType, status, search, page) + registry for labels |
| Test registration | `POST /lab-tests` (one per sample+type — API 409 surfaced) |
| Test detail | `GET /lab-tests/[id]` — registry metadata (label, standard, units, validation notes), result scalar/array tables, chart |
| Result entry | `PUT /api/lab-tests/[id]/result` — per-type structured form (scalars + repeatable point/stage rows), registry-Zod validated client- and server-side |
| Status control | `PATCH /lab-tests/[id]` (re-open warns that the result is cleared — server rule) |
| Documents | `GET /documents` (search, docType, page); upload dialog → `POST /documents/upload` (multipart; 413/415 surfaced readably; own projects only); download → `GET /documents/[id]/download` (secure streaming, no storage paths) |
| Sharing | `GET /sharing/requests` (sent/inbox tabs), `GET /sharing/organizations`, `POST /sharing/requests`, `POST /sharing/requests/[id]/decision`, `DELETE /sharing/requests/[id]` (revoke); 403 UI for roles without SHARING_MANAGE |
| Reports | `GET /reports` (reportType, projectId), `POST /reports` (own projects) |
| Activity | `GET /activity?limit=50` — per-action icons, readable sentences, reference chips |
| Users | `GET /users?search=`, `PATCH /users/[id]/role`, `PATCH /users/[id]/status` (admin only; self-changes disabled — API rejects them anyway) |
| Organization | `GET /organizations/current` |

### 4.1 Charts (registry-driven, recharts)

`TestChart` renders the `registry.chart` configuration of each test: grain-size curve (semi-log), Casagrande plasticity chart with A-line/U-line reference segments, Proctor compaction curve with MDD/OMC annotation, CBR load–penetration with 2.5/5.0 mm references, SPT/water-content depth profiles, CPT dual profile (qc, fs vs depth, inverted), oedometer e–log p with σ′p marker, and bar summaries (UCS, triaxial stages, direct shear). No plottable data → an explicit "no chart data" state; nothing is invented.

### 4.2 Design system

Emerald/teal primary on stone neutrals (M1 tokens kept); `STATUS_COLORS` semantics mapped to tone classes shared by badges, bars and charts; light/dark via `next-themes` class strategy; Geist typography; tabular numerals for measurements; `format.ts` provides deterministic UTC date/number formatting (no hydration drift — client components receive preformatted strings).

## 5. RBAC in the UI

Navigation visibility and action buttons use the M1 matrix (`can(role, cap)` with the DB-fresh role from the layout session). This is **UX shaping only** — every request still passes the M3 guards, and pages render `UnauthorizedState` when the API answers 403. The UI adds no second, potentially wrong security boundary.

## 6. Test results (executed, not asserted)

Run on a live dev server against the freshly seeded demo database
(`scripts/m4-part1-regressions.sh` + `scripts/m4-part2-ui.sh`; M1 suite run standalone after the final shell fix):

| Suite | Result |
| --- | --- |
| `bunx tsc --noEmit` | PASS (0 errors) |
| `bun run lint` | PASS (0 errors) |
| Seed (`bun run db:seed`) | PASS |
| M2 regression — lab-test registry | PASS |
| M2 regression — service layer (tenant isolation) | PASS |
| M3 regression — API integration (`m3-test-api.ts`) | **175/175 PASS** |
| M1 regression — browser auth (`m1-auth-test.sh`) | **13/13 PASS** |
| **M4 browser UI suite (`m4-test-ui.sh`)** | **92/92 PASS** |

M4 suite coverage: login/logout, navigation groups, role-based nav visibility (admin sees 11 items; viewer loses Sharing/Users), dashboard live metrics (projects 5 / active 3 / pending shares 2 verified against the seed), recent projects & activity, project create → detail, borehole create → detail, layer add → table + stratigraphy column, sample add, test registration, Zod-validated water-content result entry, Proctor/Granulometry/Atterberg charts (recharts surface + in-chart MDD/A-line annotations), document upload through the M3 endpoint (download verified byte-for-byte), sharing approve (seeded request) + create + cross-org approval by the partner admin + shared badge + read-only marker, viewer 403 state, team page, activity feed, reports, dark theme, mobile 390 px no-overflow on 5 routes, mobile nav sheet, styled 404, and a dev-log scan (no hydration/module/unhandled errors).

Issues found and fixed during testing are listed in §9.

## 7. Files

**Created (M4):** `src/lib/api-types.ts`, `src/lib/api-client.ts`, `src/lib/server-api.ts`, `src/lib/format.ts`; `src/components/shared/{status-badge,states,pagination-nav,list-toolbar,activity-feed}.tsx`; `src/components/layout/nav-config.ts`; `src/components/{projects,boreholes,layers,samples,lab-tests,documents,sharing,reports,users}/*.tsx` (14 components); pages: `(app)/{dashboard,projects,projects/[id],boreholes,boreholes/[id],samples,samples/[id],lab-tests,lab-tests/[id],documents,sharing,reports,activity,users,settings}/page.tsx`; `(app)/{loading,error,not-found}.tsx`; `scripts/m4-test-ui.sh`, `scripts/m4-part1-regressions.sh`, `scripts/m4-part2-ui.sh`, `scripts/m4-run-all.sh`; screenshots `download/m4-screenshots/`.

**Modified (authorized M4 surface only):** `(app)/layout.tsx` (fetches org via API, passes to shell), `app-shell.tsx`, `app-sidebar.tsx`, `breadcrumbs.tsx`, `user-menu.tsx` (org/role display), `(app)/dashboard/page.tsx` (M1 placeholder replaced by the real dashboard; kept the M1 `SignOutButton` contract), `login/page.tsx` (post-login redirect is now a full-page navigation — removes a client-transition race; no auth logic changed).

**Untouched:** all of `src/lib/services/**`, `src/lib/api/**`, `src/app/api/**`, `src/lib/{auth,rbac,db,errors,constants}.ts`, `src/lib/lab-tests/registry.ts`, `src/lib/validation/**`, `prisma/**`, all M1/M2/M3 test scripts (one exception: `m1-auth-test.sh` TEST 3 now polls for the dashboard document instead of a single-shot read — the assertions are unchanged; see §9).

**Environment note:** `.env` lost its `NEXTAUTH_SECRET` between sessions (the file contained only `DATABASE_URL`), which invalidated cookies across dev-server restarts with silent JWT decrypt errors. A stable secret was restored (value not printed). No application code was involved.

## 8. Screenshots

`download/m4-screenshots/`: 01 login, 02 dashboard (light), 03 projects, 04 project detail, 05 Proctor chart, 06 granulometry chart, 07 documents, 08 sharing, 09 users, 10 borehole detail with stratigraphy, 11 dashboard (dark), 12 projects at 390 px.

## 9. Issues found and fixed during M4 testing

1. **Grid-item min-width overflow** — the dashboard "Recent projects"/"Recent activity" cards expanded to their `min-content` (nowrap project names) at mobile widths (572 px > 390 px). Fixed with `min-w-0` on the cards; mobile no-overflow is asserted on 5 routes.
2. **Lost M1 sign-out contract** — the M1 dashboard carried a dedicated Sign out button; the first M4 shell draft removed it (menu-only), failing the M1 regression. Restored on the dashboard.
3. **Login redirect race** — client-side `router.push` changed the URL before the dashboard document committed, so URL-based waits read the login DOM. Login now performs a full-page navigation.
4. **Ambiguous dialog buttons** — layer/test/result dialogs used the same label for the opening trigger and the submit button; automated (and keyboard) users could re-click the trigger and close the dialog. Submit buttons renamed ("Save layer", "Create test", "Save result").
5. **Optional-field regex** — an empty optional USCS input failed its pattern (`.optional()` ≠ accepts `""`). Empty is now normalized to undefined before validation.
6. **Corrupted Turbopack cache** — a crashed compile left `.next` wedged (silent dev-server death on page compile). Diagnosed by isolating compiles; fixed by clearing `.next`; all pages compile in seconds on a clean cache.
7. **M1 harness timing** — TEST 3 read the DOM once immediately after the URL wait; the poll keeps the assertion identical while removing the race.

## 10. M1–M3 integrity confirmation

- M1: `auth.ts`, `rbac.ts`, NextAuth route, health endpoint, login page auth logic, `SignOutButton`, theme system — intact; **M1 browser regression 13/13 PASS**.
- M2: schema, seed, services, registry, validation — **zero file modifications** (timestamps predate M4); registry + service suites PASS.
- M3: all route handlers and API utilities — **zero file modifications**; **API integration suite 175/175 PASS**.
- Database: backed up before M4 (`db/custom.db.bak-pre-m4`), re-seeded to the pristine demo dataset after testing.

## 11. Known limitations

1. Lab-test **input parameters** (planned test definitions) are still not persisted — the M3 API records results only (docs/10 §9.8); the UI displays registry metadata instead of inventing input fields. Arrives with the test-definition flow in a later milestone.
2. No client-side deletion buttons for projects/boreholes/samples/tests/documents — the endpoints exist, but destructive actions beyond layer delete and share revoke were not requested in the M4 scope; they remain available via the API and can be added on request.
3. Reports are metadata records (no document generation yet) — consistent with the M3 contract.
4. The browser client surfaces field errors from Zod `details` when present; cross-field errors (e.g. Proctor MDD/curve consistency) surface as dialog-level messages.
5. Search params drive one filter dimension per select; multi-select faceting is future polish.
6. `next dev` (Turbopack) caches can wedge after a killed compile in this sandbox; clearing `.next` resolves it (documented in §9.6).

## 12. Milestone boundary

**M5 (laboratory test visualizations at project scale) has NOT been started.** No cross-test analytics, comparison views, or batch visualization features were built. The charts implemented in M4 render single-test results via the registry chart configuration, exactly as scoped by §9 of the M4 authorization.
