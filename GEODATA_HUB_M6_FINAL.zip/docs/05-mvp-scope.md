# GEODATA HUB — Phase 1: MVP Scope — Functional vs. Simulated

**Status:** Proposed — awaiting approval. Rule: every screen element either works or is explicitly labeled; **no dead buttons**.

---

## 1. Fully functional in the MVP (implemented, tested, browser-verified)

| # | Feature | What works |
|---|---|---|
| 1 | Login / logout | Email + password sign-in against seeded users; session cookie; logout via user menu; unauthenticated access redirects to `/login` |
| 2 | Navigation | Collapsible sidebar, breadcrumbs, mobile drawer; session-aware root redirect; role-adaptive menu (Team visible only to ADMIN/PM) |
| 3 | Project CRUD | Create, view, edit, delete (admin only), status transitions; per-org unique codes; GeoJSON boundary viewer/editor |
| 4 | Borehole CRUD | Create, view, edit, delete; coordinates, depth, type, status; per-project unique codes |
| 5 | Geological layers CRUD | Stratigraphy intervals with depth validation (`depthFrom < depthTo`), USCS, material type |
| 6 | Sample CRUD + lab workflow | Create, edit, delete; lab status lifecycle (NOT_SENT → SENT → IN_TEST → COMPLETED/REJECTED); SPT blows, recovery |
| 7 | Lab tests + result entry | Create tests on samples; per-type structured result forms (Zod-validated); status lifecycle |
| 8 | Test result visualization | Grain-size semi-log curve, Atterberg chart with A-line, SPT/depth profiles, UCS & triaxial summaries, moisture profiles |
| 9 | Borehole log view | Depth-scaled stratigraphy column with layers + sample positions (HTML/CSS render) |
| 10 | Search / filtering / sorting | Every list view (projects, boreholes, samples, tests, documents): text search, faceted status/type filters, sortable columns, pagination (TanStack Table) |
| 11 | Forms with validation | react-hook-form + Zod on every form; inline field errors; server-side re-validation with the same schemas; disabled submit while pending; toast feedback |
| 12 | Map (Leaflet) | OSM basemap (+ satellite toggle), borehole markers colored by status, project boundary polygons, click-to-select with popup + info panel, map filters (project/status/type), zoom/fit/basemap/visibility controls, scale bar |
| 13 | Document management | Upload (multipart) with type/title metadata, list with filters, permission-checked streaming download, delete; 10 MB demo cap |
| 14 | Sharing workflow | Create request (target org, message, optional expiry) → partner inbox → approve / reject → requester side status; revoke; approved shares appear read-only in partner org with "Shared with you" badge; expiry honored |
| 15 | Team management | Member list with roles; role changes and deactivation (admin); add user directly (simulated invite — see §2) |
| 16 | Role-based interface | UI hides/labels restricted actions per the RBAC matrix; identical rules enforced server-side (403 on violation) |
| 17 | Tenant isolation | All queries org-scoped from the session; cross-org access only via approved shares; verified by test (Phase 7) |
| 18 | Dashboard | KPI cards (projects, boreholes, samples, tests by status), status distribution chart, recent activity feed |
| 19 | Reports | Borehole log + test summary print-optimized views; browser print → PDF; report records with generation history |
| 20 | Demo mode | Demo credentials panel on the login page; seeded data rich enough to exercise every feature on first login |
| 21 | Dark mode / responsiveness | Light + dark theme; mobile-first layouts; sticky footer; skeletons and empty states everywhere |

## 2. Simulated / prototype-labeled (clearly marked in the UI)

| # | Feature | Prototype behavior | Production path |
|---|---|---|---|
| S1 | Email notifications (sharing invites, status changes) | Not sent; events recorded in the activity feed; UI badge "Prototype: email notifications not sent" on sharing actions | Transactional email provider (SMTP/SES/Postmark) |
| S2 | User invitations | Admin creates the user directly with a generated password shown once in a dismissible dialog; labeled "Simulated invite" | Email invite + tokenized onboarding link |
| S3 | Password reset | Admin resets a member's password (same one-time reveal); no self-service email flow | Reset email flow |
| S4 | Report PDF export | Print-optimized HTML view + browser print dialog ("Print / Save as PDF" button) — no server-side PDF rendering | Server-side PDF (Playwright/print CSS pipeline) |
| S5 | File storage | Private local folder (`storage/uploads`) streamed through the permission-checked API | S3-compatible object storage adapter (interface already isolated in the documents service) |
| S6 | Real-time collaboration | None (no live cursors/presence) | WebSocket mini-service (pattern available in the platform) |
| S7 | Map data sources | OSM raster tiles + optional Esri World Imagery; no WMS/WMTS/geoserver feeds, no coordinate reprojection (WGS84 only) | Tile server / WMS integration, proj4 |
| S8 | Billing / subscription | None | SaaS billing module (out of MVP scope) |
| S9 | Audit trail | Simplified activity log (not tamper-proof) | Append-only audit table + hashing |
| S10 | Data exchange formats (AGS/DIGES) | Not implemented; noted in docs | Export module |

Every simulated feature carries a visible **"Prototype"** badge/tooltip at its point of use, plus a section in the README — satisfying "clearly distinguish implemented from simulated".

## 3. Demo credentials (seeded, shown on login page)

| Account (email) | Organization | Role | Password |
|---|---|---|---|
| `admin@geodata.demo` | GeoStruct Consulting | ORG_ADMIN | `Demo1234!` |
| `manager@geodata.demo` | GeoStruct Consulting | PROJECT_MANAGER | `Demo1234!` |
| `engineer@geodata.demo` | GeoStruct Consulting | ENGINEER | `Demo1234!` |
| `viewer@geodata.demo` | GeoStruct Consulting | VIEWER | `Demo1234!` |
| `admin@rockworks.demo` | RockWorks Laboratory | ORG_ADMIN | `Demo1234!` |
| `engineer@rockworks.demo` | RockWorks Laboratory | ENGINEER | `Demo1234!` |

(These accounts and this password exist only in the fictional seed data for demonstration; they are generated by `prisma/seed.ts`.)
