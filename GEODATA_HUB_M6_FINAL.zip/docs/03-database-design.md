# GEODATA HUB — Phase 1: Database Design

**Status:** Proposed — awaiting approval. 11 models. ERD: [`erd.png`](erd.png) (rendered from [`erd.mmd`](erd.mmd), Mermaid source included in §2).

---

## 1. Design principles

1. **Tenant-scoped by default** — every business table carries `organizationId` (directly or via its parent chain) and every query is filtered by the session organization.
2. **Portable across SQLite (sandbox) and PostgreSQL (production)** — no Prisma `enum` (unsupported on SQLite); constrained values are `String` + Zod-validated sets; no scalar lists; `Json` verified working on both engines (probe in `01-environment-audit.md` §4).
3. **Referential integrity via cascades** — deleting a project removes its boreholes, layers, samples, tests, documents, shares and reports; deleting an organization removes everything under it.
4. **Natural uniqueness within scope** — `code` fields are unique per parent (`@@unique([projectId, code])`), preventing duplicate borehole/sample codes while allowing the same code in different projects.

## 2. Entity-Relationship Diagram

![GEODATA HUB ERD](erd.png)

<details>
<summary>Mermaid source (erd.mmd)</summary>

```mermaid
erDiagram
    ORGANIZATION ||--o{ USER : "employs"
    ORGANIZATION ||--o{ PROJECT : "owns"
    ORGANIZATION ||--o{ SHARING_REQUEST : "receives"
    ORGANIZATION ||--o{ ACTIVITY_LOG : "scopes"
    USER ||--o{ PROJECT : "creates"
    USER ||--o{ DOCUMENT : "uploads"
    USER ||--o{ SHARING_REQUEST : "requests"
    USER ||--o{ SHARING_REQUEST : "decides"
    USER ||--o{ REPORT : "generates"
    USER ||--o{ ACTIVITY_LOG : "performs"
    PROJECT ||--o{ BOREHOLE : "contains"
    PROJECT ||--o{ DOCUMENT : "has"
    PROJECT ||--o{ SHARING_REQUEST : "shared via"
    PROJECT ||--o{ REPORT : "produces"
    BOREHOLE ||--o{ GEOLOGICAL_LAYER : "stratigraphy"
    BOREHOLE ||--o{ SAMPLE : "yields"
    BOREHOLE ||--o{ DOCUMENT : "has"
    GEOLOGICAL_LAYER |o--o{ SAMPLE : "sampled from"
    SAMPLE ||--o{ LAB_TEST : "tested by"
```

(Full attribute lists are rendered in `erd.png`; the authoritative field set is the Prisma schema in §4.)

</details>

## 3. Entity dictionary

| Model | Purpose | Key fields & rules |
|---|---|---|
| **Organization** | Tenant. One per company. | `slug` unique (used in URLs/labels); owns users, projects, logs |
| **User** | Authenticated person, member of exactly one organization in MVP. | `email` unique; `passwordHash` (bcrypt); `role` ∈ {ORG_ADMIN, PROJECT_MANAGER, ENGINEER, VIEWER}; `isActive` for soft deactivation |
| **Project** | A geotechnical investigation project. | `code` unique per org; `status` ∈ {ACTIVE, ON_HOLD, COMPLETED, ARCHIVED}; optional center lat/lng + `boundary` GeoJSON Polygon; `createdBy` |
| **Borehole** | Location investigation point. | `code` unique per project; `type` ∈ {ROTARY_CORE, SPT, CPT, TRIAL_PIT, AUGER}; lat/lng (WGS84); `depth` m; `status` ∈ {PLANNED, DRILLED, SAMPLED, COMPLETED, ABANDONED} |
| **GeologicalLayer** | Stratigraphy interval of a borehole. | `depthFrom` < `depthTo` (validated); `materialType` ∈ {SOIL, ROCK, FILL}; `uscs` classification; free-text `description` |
| **Sample** | Physical sample taken from a borehole. | `code` unique per borehole; `type` ∈ {DISTURBED, UNDISTURBED, SPT, CPT, ROCK_CORE, WATER}; `sptBlows`, `recovery` optional; `labStatus` ∈ {NOT_SENT, SENT, IN_TEST, COMPLETED, REJECTED}; optional link to the layer it was taken from |
| **LabTest** | A laboratory test performed on a sample. | one per (sample, testType); `testType` ∈ {MOISTURE, ATTERBERG, GRAIN_SIZE, UCS, TRIAXIAL_UU, TRIAXIAL_CU, DIRECT_SHEAR, CONSOLIDATION, SPECIFIC_GRAVITY, ORGANIC_CONTENT}; `resultData` Json — **type-specific structure validated by a Zod schema registry** (e.g. grain size → `{ points: [{ diameterMm, percentFiner }] }`, Atterberg → `{ liquidLimit, plasticLimit, plasticityIndex }`) |
| **Document** | File attached to a project (optionally a borehole). | `docType` ∈ {REPORT, DRAWING, LAB_DATA, PHOTO, CORRESPONDENCE, OTHER}; `filePath` points into private storage (never under `public/`); served only through a permission-checked streaming endpoint |
| **SharingRequest** | Controlled cross-tenant sharing. | unique per (project, target org); `permission` = VIEW in MVP; `status` ∈ {PENDING, APPROVED, REJECTED, REVOKED}; optional `expiresAt`; `decidedBy/decidedAt` audit |
| **Report** | Record of a generated report. | `reportType` ∈ {BOREHOLE_LOG, TEST_SUMMARY, PROJECT_SUMMARY}; rendered as print-optimized view (prototype approach) |
| **ActivityLog** | Append-only feed of significant actions (dashboard "Recent activity"). | `action` string (e.g. `PROJECT_CREATED`, `SHARE_APPROVED`); optional `details` Json |

## 4. Prisma schema (implementation draft for Phase 3)

```prisma
generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "sqlite" // sandbox | production: "postgresql"
  url      = env("DATABASE_URL")
}

model Organization {
  id        String   @id @default(cuid())
  name      String
  slug      String   @unique
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt

  users          User[]
  projects       Project[]
  receivedShares SharingRequest[] @relation("TargetOrg")
  activityLogs   ActivityLog[]
}

model User {
  id             String   @id @default(cuid())
  email          String   @unique
  passwordHash   String
  name           String
  role           String // ORG_ADMIN | PROJECT_MANAGER | ENGINEER | VIEWER (Zod-enforced)
  isActive       Boolean  @default(true)
  organizationId String
  createdAt      DateTime @default(now())
  updatedAt      DateTime @updatedAt

  organization      Organization    @relation(fields: [organizationId], references: [id], onDelete: Cascade)
  createdProjects   Project[]       @relation("ProjectCreator")
  uploadedDocuments Document[]
  requestedShares   SharingRequest[] @relation("Requester")
  decidedShares     SharingRequest[] @relation("Decider")
  generatedReports  Report[]
  activityLogs      ActivityLog[]
}

model Project {
  id             String   @id @default(cuid())
  organizationId String
  code           String
  name           String
  description    String?
  client         String?
  status         String   @default("ACTIVE") // ACTIVE | ON_HOLD | COMPLETED | ARCHIVED
  locationName   String?
  latitude       Float?
  longitude      Float?
  boundary       Json? // GeoJSON Polygon
  createdById    String
  createdAt      DateTime @default(now())
  updatedAt      DateTime @updatedAt

  @@unique([organizationId, code])

  organization    Organization     @relation(fields: [organizationId], references: [id], onDelete: Cascade)
  createdBy       User             @relation("ProjectCreator", fields: [createdById], references: [id])
  boreholes       Borehole[]
  documents       Document[]
  sharingRequests SharingRequest[]
  reports         Report[]
}

model Borehole {
  id           String    @id @default(cuid())
  projectId    String
  code         String
  type         String // ROTARY_CORE | SPT | CPT | TRIAL_PIT | AUGER
  latitude     Float
  longitude    Float
  elevation    Float?
  depth        Float?
  drillingDate DateTime?
  drilledBy    String?
  status       String    @default("PLANNED") // PLANNED | DRILLED | SAMPLED | COMPLETED | ABANDONED
  notes        String?
  createdAt    DateTime  @default(now())
  updatedAt    DateTime  @updatedAt

  @@unique([projectId, code])

  project   Project            @relation(fields: [projectId], references: [id], onDelete: Cascade)
  layers    GeologicalLayer[]
  samples   Sample[]
  documents Document[]
}

model GeologicalLayer {
  id           String   @id @default(cuid())
  boreholeId   String
  depthFrom    Float
  depthTo      Float
  layerCode    String?
  materialType String // SOIL | ROCK | FILL
  description  String
  uscs         String? // e.g. CL, SP, GW
  consistency  String? // soil: very soft..very stiff / rock: RQD class
  createdAt    DateTime @default(now())
  updatedAt    DateTime @updatedAt

  borehole Borehole @relation(fields: [boreholeId], references: [id], onDelete: Cascade)
  samples  Sample[]
}

model Sample {
  id          String    @id @default(cuid())
  boreholeId  String
  layerId     String?
  code        String
  type        String // DISTURBED | UNDISTURBED | SPT | CPT | ROCK_CORE | WATER
  depthFrom   Float
  depthTo     Float
  sptBlows    Int?
  recovery    Float? // % recovery
  labStatus   String    @default("NOT_SENT") // NOT_SENT | SENT | IN_TEST | COMPLETED | REJECTED
  collectedAt DateTime?
  notes       String?
  createdAt   DateTime  @default(now())
  updatedAt   DateTime  @updatedAt

  @@unique([boreholeId, code])

  borehole Borehole           @relation(fields: [boreholeId], references: [id], onDelete: Cascade)
  layer    GeologicalLayer?   @relation(fields: [layerId], references: [id], onDelete: SetNull)
  labTests LabTest[]
}

model LabTest {
  id          String    @id @default(cuid())
  sampleId    String
  testType    String // MOISTURE | ATTERBERG | GRAIN_SIZE | UCS | TRIAXIAL_UU | TRIAXIAL_CU | DIRECT_SHEAR | CONSOLIDATION | SPECIFIC_GRAVITY | ORGANIC_CONTENT
  status      String    @default("PENDING") // PENDING | IN_PROGRESS | COMPLETED | REJECTED
  performedBy String?
  performedAt DateTime?
  resultData  Json? // structure validated per testType by Zod registry
  summary     String?
  createdAt   DateTime  @default(now())
  updatedAt   DateTime  @updatedAt

  @@unique([sampleId, testType])

  sample Sample @relation(fields: [sampleId], references: [id], onDelete: Cascade)
}

model Document {
  id             String   @id @default(cuid())
  organizationId String
  projectId      String
  boreholeId     String?
  title          String
  docType        String // REPORT | DRAWING | LAB_DATA | PHOTO | CORRESPONDENCE | OTHER
  fileName       String
  filePath       String // private storage path (not under public/)
  fileSize       Int
  mimeType       String
  uploadedById   String
  createdAt      DateTime @default(now())
  updatedAt      DateTime @updatedAt

  organization Organization @relation(fields: [organizationId], references: [id])
  project      Project      @relation(fields: [projectId], references: [id], onDelete: Cascade)
  borehole     Borehole?    @relation(fields: [boreholeId], references: [id], onDelete: SetNull)
  uploadedBy   User         @relation(fields: [uploadedById], references: [id])
}

model SharingRequest {
  id                   String    @id @default(cuid())
  projectId            String
  requesterId          String
  targetOrganizationId String
  permission           String    @default("VIEW") // VIEW (MVP); COMMENT future
  status               String    @default("PENDING") // PENDING | APPROVED | REJECTED | REVOKED
  message              String?
  expiresAt            DateTime?
  decidedById          String?
  decidedAt            DateTime?
  createdAt            DateTime  @default(now())
  updatedAt            DateTime  @updatedAt

  @@unique([projectId, targetOrganizationId])

  project            Project       @relation(fields: [projectId], references: [id], onDelete: Cascade)
  requester          User          @relation("Requester", fields: [requesterId], references: [id])
  targetOrganization Organization  @relation("TargetOrg", fields: [targetOrganizationId], references: [id])
  decidedBy          User?         @relation("Decider", fields: [decidedById], references: [id])
}

model Report {
  id            String   @id @default(cuid())
  projectId     String
  reportType    String // BOREHOLE_LOG | TEST_SUMMARY | PROJECT_SUMMARY
  title         String
  generatedById String
  createdAt     DateTime @default(now())

  project     Project @relation(fields: [projectId], references: [id], onDelete: Cascade)
  generatedBy User    @relation(fields: [generatedById], references: [id])
}

model ActivityLog {
  id             String   @id @default(cuid())
  organizationId String
  userId         String?
  action         String // e.g. PROJECT_CREATED, BOREHOLE_UPDATED, SHARE_APPROVED
  entityType     String
  entityId       String?
  details        Json?
  createdAt      DateTime @default(now())

  organization Organization @relation(fields: [organizationId], references: [id], onDelete: Cascade)
  user         User?         @relation(fields: [userId], references: [id], onDelete: SetNull)
}
```

> Note: the scaffold's demo `User`/`Post` models are **replaced** by this schema in Phase 3 (announced in the environment audit — they are sandbox boilerplate, not user work). `db:push` is used in the sandbox (fast iterate); `prisma migrate dev` is used to produce the migration history required for the PostgreSQL deployment path.

## 5. SQLite (sandbox) → PostgreSQL (production) switch

The schema above is written to be portable. Switching to PostgreSQL for deployment:

1. Provision a PostgreSQL 16+ database and user.
2. In `prisma/schema.prisma` set `provider = "postgresql"`.
3. Set `DATABASE_URL=postgresql://user:password@host:5432/geodatahub`.
4. Run `bunx prisma migrate dev --name init` (or `prisma db push`) against the empty database, then run the seed script.
5. No application code changes are required — value-set fields remain `String` + Zod validation (they can be migrated to native PG enums later via a transparent column-type change migration).

**Verified compatibility facts:** Prisma `Json` fields round-trip correctly on SQLite (probe, Phase 1) and are natively supported on PostgreSQL. Prisma `enum` and scalar lists are not used anywhere.

## 6. Seed data plan (fictional demonstration data)

| Item | Content |
|---|---|
| Organizations | 2 — **GeoStruct Consulting** (engineering firm, primary demo tenant) and **RockWorks Laboratory** (partner lab, second tenant for sharing demo) |
| Users | 6 — org A: admin/manager/engineer/viewer (`@geodata.demo`); org B: admin + engineer (`@rockworks.demo`); shared demo password, shown on the login page |
| Projects | 5 — e.g. *Riverside Bridge Crossing*, *Metro Line 2 Extension – Section B*, *Northgate Industrial Park*, *Coastal Wind Farm Access Roads* (org A); *Harbor Redevelopment Lab Program* (org B); realistic statuses, one with a drawn GeoJSON boundary |
| Boreholes | ~30 across projects, clustered coordinates near a fictional river-delta site, mixed types and statuses |
| Layers | 4–8 per borehole — realistic Dutch-style stratigraphy (fill, soft clay, peat, loose–dense sand, gravel, Pleistocene sand) |
| Samples | 2–4 per drilled borehole (SPT, undisturbed, rock core) with lab statuses across the full lifecycle |
| Lab tests | ~60 with completed realistic results (moisture 18–46%, Atterberg LL/PL pairs, full grain-size curves, UCS 40–320 kPa, triaxial cu values) — enough density for meaningful charts |
| Documents | 6–8 seeded files (PDF/TXT generated at seed time) across projects |
| Sharing | 1 approved share (GeoStruct → RockWorks, expiring), 1 pending request (reverse direction) — lets both approval and rejection paths be demonstrated |
| Activity | Seeded log entries so the dashboard activity feed is populated on first login |
