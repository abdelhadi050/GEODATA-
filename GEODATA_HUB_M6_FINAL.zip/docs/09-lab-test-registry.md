# GEODATA HUB — Laboratory Test Registry (M2)

**Source of truth:** `src/lib/lab-tests/registry.ts` · Every `LabTest.resultData` payload is validated against the registry's Zod schema at write time (`recordLabTestResult`) and at seed time. Results are never stored as unvalidated arbitrary JSON.

## Registry entry structure

Each of the 12 test types defines: `code`, `label`, `description`, `standard` (ASTM/NF reference), `category` (INDEX_PROPERTIES · COMPACTION · MECHANICAL · IN_SITU), `inputSchema` (test-definition inputs), `resultSchema` (structured results), `units`, `validationNotes` (cross-field rules), `chart` (configuration consumed by the M5 visualization layer).

## The 12 test types

| # | Code | Label | Standard | Key result fields (units) | Cross-field validation rules | Chart |
|---|---|---|---|---|---|---|
| 1 | `GRANULOMETRY` | Granulometry (sieve & hydrometer) | ASTM D6913 / NF P94-056 | points: diameterMm (mm) × percentFiner (%); d10/d30/d60 (mm); Cu, Cc (–); USCS | 4–40 points; unique diameters; percentFiner 0–100 and **non-decreasing** with increasing diameter; Cu = d60/d10 | Grain-size curve (semi-log X) |
| 2 | `ATTERBERG_LIMITS` | Atterberg limits | ASTM D4318 / NF P94-051 | liquidLimit, plasticLimit, plasticityIndex (%); shrinkageLimit optional | LL 10–150, PL 5–100; **PL < LL**; **PI = LL − PL (±1)** | Casagrande plasticity chart |
| 3 | `PROCTOR` | Proctor compaction | ASTM D698 / D1557 / NF P94-093 | method (STANDARD/MODIFIED); points: moistureContent (%) × dryDensity (Mg/m³); maxDryDensity; optimumMoisture | 3–8 points; dryDensity 1.0–2.7; **maxDryDensity ≥ curve peak**; optimum within tested moisture range (±1) | Compaction curve with optimum marker |
| 4 | `CBR` | California Bearing Ratio | ASTM D1883 / NF P94-078 | condition (SOAKED/UNSOAKED); points: penetrationMm (mm) × loadKn (kN); cbrAt2_5, cbrAt5_0, cbrValue (%); swellPercent | 2–20 points; penetration 0–15 mm, unique; **cbrValue = max(cbrAt2_5, cbrAt5_0)**; swell 0–15 % | Load–penetration curve with 2.5/5.0 mm markers |
| 5 | `SPT` | Standard Penetration Test | ASTM D1586 / NF P94-116 | depthFrom/depthTo (m); blows per 150 mm; nValue; energyRatio (%); n60 | **N = blows2nd150 + blows3rd150**; **n60 = N × ER/60** when ER given; depthTo > depthFrom | N-value depth profile |
| 6 | `CPT` | Cone Penetration Test | ASTM D5778 / NF P94-119 | finalDepth (m); points: depth (m) × coneResistanceMpa (MPa) × sleeveFrictionKpa (kPa); frictionRatioAvg | 2–600 points; **depths strictly increasing**; qc 0–120 MPa; fs 0–900 kPa; finalDepth ≥ deepest point | CPT depth profiles (qc, fs) |
| 7 | `UCS` | Unconfined Compressive Strength | ASTM D2166 / D7012 / NF P94-425 | specimenDiameterMm (mm); peakStressKpa (kPa); strainAtFailurePercent (%); failurePattern | peakStress 0–25 000 kPa; strain 0–20 %; specimen geometry consistent with input | Strength summary bars |
| 8 | `TRIAXIAL` | Triaxial compression (UU/CU/CD) | ASTM D2850 / D4767 / NF P94-077 | type; stages: confiningPressureKpa × peakDeviatorStressKpa (kPa) + strain; cohesionKpa; frictionAngleDeg (°) | 1–5 stages; **unique confining pressures**; **Mohr-Coulomb parameters require ≥ 2 stages**; φ 0–45° | Stage summary / deviator bars |
| 9 | `OEDOMETER` | Oedometer consolidation | ASTM D2435 / NF P94-090 | stages: verticalPressureKpa (kPa) × voidRatio (–); Cc, Cs; preConsolidationPressureKpa; Cv (m²/year) | 2–12 stages; **pressures strictly increasing**; voidRatio 0.15–4 | e–log p curve |
| 10 | `DIRECT_SHEAR` | Direct shear | ASTM D3080 / NF P94-071-1 | normalStressKpa, peakShearStressKpa, residualShearStressKpa (kPa); cohesionKpa; frictionAngleDeg (°) | **residual ≤ peak**; φ 0–45° | Shear strength summary |
| 11 | `WATER_CONTENT` | Water content | ASTM D2216 / NF P94-050 | waterContentPercent (%); wetMassG/dryMassG/containerMassG (g) optional | 0–300 %; **wetMassG > dryMassG** when both given | Moisture depth profile |
| 12 | `SPECIFIC_GRAVITY` | Specific gravity | ASTM D854 / NF P94-054 | specificGravity (–); method; temperatureC (°C) | **2.30–2.95** (mineral-soil range) | none |

## Usage

```ts
import { parseLabTestResult, getLabTestDefinition, LAB_TEST_TYPES } from "@/lib/lab-tests/registry";

parseLabTestResult("CBR", payload);   // { ok: true, data } | { ok: false, error }
getLabTestDefinition("PROCTOR");      // metadata, units, chart config, validation notes
```

- **Service layer** (`recordLabTestResult`) rejects invalid results with `VALIDATION_ERROR` before any write.
- **Seed** validates every seeded result through the same registry (fails fast on any invalid value).
- **M5** will render charts from the `chart` configuration (`grainSizeCurve`, `plasticityChart`, `compactionCurve`, `cbrCurve`, `depthProfile`, `cptProfile`, `oedometerCurve`, `barSummary`, `none`).

## Schema deviations vs docs/03 (recorded in the Prisma schema header)

1. `Sample.sptBlows` removed — SPT N-values live in the structured SPT lab-test result (single source of truth).
2. `Sample.type` no longer includes SPT/CPT — those are test types; sample types are physical specimens (DISTURBED, UNDISTURBED, ROCK_CORE, WATER).
3. `LabTest.notes` added (test observations) — additive.
