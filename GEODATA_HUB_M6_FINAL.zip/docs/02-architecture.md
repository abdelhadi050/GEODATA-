# GEODATA HUB — Phase 1: System Architecture

**Status:** Proposed — awaiting approval. Once approved, this document is the implementation contract for Phases 2–8.

---

## 1. Product definition

GEODATA HUB is a **multi-tenant geotechnical data management and GIS collaboration platform**. Engineering organizations store their projects, boreholes, geological layers, samples and laboratory test results; visualize them on an interactive map; manage documents; and share projects with partner organizations through a controlled request/approval workflow. The MVP is a working prototype that demonstrates the real value of the product and is architected to evolve into a cloud-based SaaS.

## 2. Technology stack (final)

| Layer | Choice | Rationale |
|---|---|---|
| Framework | Next.js 16 (App Router) + React 19 + TypeScript 5 strict | Mandated stack; server components for fast data pages, client islands for interactivity |
| Styling / UI | Tailwind CSS 4 + shadcn/ui (New York) + Lucide | Full component library already provisioned; consistent design system |
| Data access | Prisma ORM (service layer, org-scoped queries) | Type-safe, portable across SQLite/PostgreSQL |
| Database (sandbox) | SQLite (`db/custom.db`) | Platform mandate; no PostgreSQL server in sandbox |
| Database (production target) | PostgreSQL 16+ | As specified; switch procedure in `03-database-design.md` §5 |
| Auth | NextAuth v4 — Credentials provider, JWT sessions, bcryptjs hashing | Pre-installed; stateless; roles carried in session token |
| Forms & validation | react-hook-form + Zod (client) → Zod re-validation (server) | Same schema objects shared by form and API |
| Tables | TanStack Table | Search, column sort, filtering, pagination on every list view |
| Server/client state | Server Components + TanStack Query + Zustand (map & UI state only) | Minimal client state; cache invalidation after mutations |
| GIS | Leaflet + react-leaflet v5, OpenStreetMap tiles (+ optional Esri World Imagery toggle) | Industry standard, lightweight, no API key |
| Charts | Recharts + custom stratigraphy column (HTML/CSS) | Lab test visualization |
| Notifications | sonner toasts; activity feed | (Email = simulated, see `05-mvp-scope.md`) |

## 3. Logical architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│ Browser (user)                                                      │
│  RSC pages  +  client islands (forms, tables, map, charts)          │
└───────────────┬─────────────────────────────────────────────────────┘
                │ HTTPS (relative URLs only)
┌───────────────▼─────────────────────────────────────────────────────┐
│ Caddy gateway (single exposed port → :3000)                         │
└───────────────┬─────────────────────────────────────────────────────┘
                │
┌───────────────▼─────────────────────────────────────────────────────┐
│ Next.js 16 application                                              │
│                                                                     │
│  Presentation      src/app/**        Server Components (read paths) │
│                                       Client islands (mutations)    │
│  API               src/app/api/**    Route handlers (REST-ish)      │
│  Services          src/lib/services  Business logic + TENANT SCOPE  │
│  Validation        src/lib/validation/zod schemas (shared)          │
│  Auth/RBAC         src/lib/auth.ts, src/lib/rbac.ts                 │
│  Storage           storage/uploads (private, streamed via API)      │
└───────────────┬─────────────────────────────────────────────────────┘
                │
┌───────────────▼─────────────────────────────────────────────────────┐
│ Prisma ORM → SQLite (sandbox) / PostgreSQL (production)             │
└─────────────────────────────────────────────────────────────────────┘
```

**Data-flow rules**

1. Every read on a page load goes: RSC page → service → Prisma (no HTTP hop).
2. Every mutation from a client island goes: client (react-hook-form + zod) → `/api/*` route handler → zod re-parse → RBAC guard → service → Prisma → activity log entry → response → TanStack Query invalidation → UI refresh.
3. Services **never** accept an `organizationId` from the client; it is always derived from the session.
4. Every service function that returns tenant data filters by the session organization (or by an approved share).

## 4. Multi-tenancy model

- **Pattern:** shared database, shared schema, `organizationId` discriminator on every tenant-owned table (the standard evolution path to cloud SaaS; enables PostgreSQL row-level security later).
- **Isolation guarantees (defense in depth):**
  1. Service layer: all queries org-scoped from the session.
  2. API layer: guard helpers reject requests whose target resource is outside the caller's org (unless covered by an approved share).
  3. UI layer: navigation and actions restricted by role; foreign-tenant data never linked.
- **Cross-tenant collaboration:** a project can be shared with another organization **only** through an approved `SharingRequest` (project-scoped, `VIEW` permission, optional expiry). Shared projects appear read-only in the partner's project list with a "Shared with you" badge.
- **Tenant isolation is a tested requirement** (Phase 7): log in as Org A, attempt reads/writes against Org B resources → must fail.

## 5. Authentication design

| Aspect | Decision |
|---|---|
| Provider | NextAuth v4 Credentials (email + password) |
| Password storage | bcryptjs (cost 10); seeded users get a documented demo password |
| Session | JWT strategy, httpOnly cookie; token carries `id, email, name, role, organizationId` |
| Login page | `/login` — custom shadcn form, demo credentials panel, field-level validation |
| Root `/` | Redirects to `/dashboard` when authenticated, `/login` otherwise |
| Logout | Sign-out via user menu → session destroyed, redirect to `/login` |
| Route protection | Server-side session check in the `(app)` layout (no protected content renders without session); API handlers re-check per request |
| Simulated (labeled) | Password reset (admin resets instead), email invites (admin creates user directly) — see scope doc |

**Why not OAuth/Magic links:** the prototype must demonstrate role-based multi-tenant behavior locally; credentials auth is self-contained, testable and demo-friendly. External identity providers are a documented production evolution path.

## 6. Role & permission model (RBAC)

Four roles, assigned per user (one organization per user in MVP):

| Capability | ORG_ADMIN | PROJECT_MANAGER | ENGINEER | VIEWER |
|---|---|---|---|---|
| View dashboard, projects, map, data, documents | ✓ | ✓ | ✓ | ✓ |
| Create / edit projects | ✓ | ✓ | ✗ | ✗ |
| Delete projects | ✓ | ✗ | ✗ | ✗ |
| Create / edit / delete boreholes, layers, samples, lab tests | ✓ | ✓ | ✓ | ✗ |
| Enter lab test results | ✓ | ✓ | ✓ | ✗ |
| Upload / delete documents | ✓ | ✓ | ✓ | ✗ |
| Download documents | ✓ | ✓ | ✓ | ✓ |
| Create / revoke sharing requests | ✓ | ✓ | ✗ | ✗ |
| Approve / reject incoming sharing requests | ✓ | ✓ | ✗ | ✗ |
| Generate reports | ✓ | ✓ | ✓ | ✗ |
| View team page | ✓ | ✓ | ✗ | ✗ |
| Change roles / deactivate users | ✓ | ✗ | ✗ | ✗ |
| View shared (read-only) projects from partners | ✓ | ✓ | ✓ | ✓ |

**Enforcement:** UI hides/disables restricted controls (no dead buttons — restricted actions are simply not rendered); API handlers enforce the same matrix server-side; the RBAC matrix lives in one module (`src/lib/rbac.ts`) consumed by both layers.

## 7. API surface (Route Handlers)

| Endpoint group | Methods | Purpose |
|---|---|---|
| `/api/auth/[...nextauth]` | POST/GET | NextAuth (login, session, logout) |
| `/api/projects` | GET, POST | List (search/filter/sort/paginate), create |
| `/api/projects/[id]` | GET, PATCH, DELETE | Detail, update, delete (admin) |
| `/api/projects/[id]/boundary` | PUT | Replace GeoJSON boundary |
| `/api/boreholes` , `/api/boreholes/[id]` | GET, POST / GET, PATCH, DELETE | Borehole CRUD |
| `/api/boreholes/[id]/layers`, `/api/layers/[id]` | GET, POST / PATCH, DELETE | Stratigraphy CRUD |
| `/api/samples`, `/api/samples/[id]` | GET, POST / GET, PATCH, DELETE | Sample CRUD |
| `/api/lab-tests`, `/api/lab-tests/[id]` | GET, POST / GET, PATCH, DELETE | Test CRUD + result entry |
| `/api/documents` , `/api/documents/[id]` | GET, POST (multipart) / GET (download stream), PATCH, DELETE | Document management |
| `/api/sharing`, `/api/sharing/[id]` | GET (inbox/sent), POST / PATCH (approve/reject/revoke) | Sharing workflow |
| `/api/team`, `/api/team/[id]` | GET, POST / PATCH | Team list, add user (simulated invite), role change |
| `/api/reports` | GET, POST | Report records + print views |
| `/api/map/data` | GET | GeoJSON feed: borehole points + project boundaries for accessible projects |
| `/api/dashboard/stats`, `/api/activity` | GET | Dashboard KPIs and activity feed |

Conventions: JSON bodies; Zod-validated inputs; uniform error envelope `{ error: { code, message, details? } }` with correct HTTP status; 401 unauthenticated / 403 forbidden / 404 not-in-tenant.

## 8. GIS design (Leaflet)

- **Rendering:** `react-leaflet` v5 (React 19 compatible) inside a client component loaded with `next/dynamic` + `ssr: false` (Leaflet requires `window`).
- **Basemaps:** OpenStreetMap default; optional Esri World Imagery satellite toggle; attribution line kept (license requirement).
- **Markers:** custom `divIcon` (colored by borehole status, sized consistently) — avoids the classic broken default-icon asset path and gives a designed look.
- **Layers:** project boundary polygons (GeoJSON from `Project.boundary`), borehole markers, optional layer toggles in a map control panel.
- **Interaction:** marker click → popup with summary (code, type, depth, status) → "Open details" navigates to the borehole page; selection also populates a side info panel with quick links (samples, tests).
- **Filters (map toolbar):** by project, borehole status, borehole type. **Controls:** zoom, fit-to-project, basemap switch, boundary visibility, scale bar.
- **Coordinates:** stored as WGS84 (`Float` lat/lng); Leaflet handles display projection; no reprojection engine (documented limitation — future: proj4/proj4leaflet).

## 9. Design system (consistent across every screen)

| Element | Standard |
|---|---|
| Palette | **Emerald/teal primary** (earth-science identity, platform rule: no blue/indigo), stone/slate neutrals, amber for pending/warning states, red for destructive/rejected; light + dark mode via `next-themes` |
| Status colors | ACTIVE → emerald · PENDING/SENT → amber · COMPLETED → teal · PLANNED/NOT_SENT → slate · REJECTED/REVOKED/ABANDONED → red |
| Layout | Collapsible shadcn sidebar (desktop) + drawer navigation (mobile), sticky topbar with breadcrumbs + user menu, content max-width container |
| Page pattern | `PageHeader` (title, description, primary action) → optional `StatCard` row → `DataTable` (toolbar: search + filters + sort) or detail cards; `EmptyState` with a call-to-action where lists are empty; loading skeletons for every async region |
| Forms | Dialog or dedicated page sections; react-hook-form + zod; inline field errors; disabled submit while pending; toast on success/failure |
| Feedback | sonner toasts for all mutations; `ConfirmDialog` for destructive actions |
| Accessibility | Semantic landmarks, keyboard navigable tables/dialogs, focus states, ARIA labels, 44px touch targets |
| Responsive | Mobile-first; tables become stacked cards on small screens; map full-width with collapsible info panel |

## 10. Error handling & quality conventions

- Zod schemas are the single source of truth for input shapes (shared client/server).
- Services throw typed `AppError(code, httpStatus)`; API handlers map them to the error envelope; RSC pages use `notFound()` / `error.tsx` boundaries.
- Every mutation writes an `ActivityLog` entry (powers the dashboard activity feed).
- Quality gates per phase: `bun run lint`, `tsc --noEmit`, Prisma validation (`db:push`/`migrate`), runtime CRUD/auth/tenant-isolation tests, and browser-verified flows (agent-browser) — see `07-implementation-plan.md`.
