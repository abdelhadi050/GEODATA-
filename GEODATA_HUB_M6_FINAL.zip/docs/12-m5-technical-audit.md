# GEODATA HUB — M5 Technical Audit Report (Laboratory Tests & Charts)

**Status:** Audit only — no implementation started, no files modified · **Date:** 2026-11-21
**Scope:** Everything required to authorize and plan M5: current implementation status, reusable assets, gap analysis, scientific calculation requirements, database / API / frontend changes, testing strategy, dependency map, and a sub-milestone implementation sequence.

**Audit rule applied:** every statement below was verified by reading the actual code and documentation (file paths cited). Scientific formulas are quoted only where they are textbook-standard; every standard-specific constant is flagged for verification against the actual standard text during implementation. Nothing is invented.

---

## 1. Audit scope and method

Inspected (read-only):

| Area | Files |
| --- | --- |
| Database | `prisma/schema.prisma` (11 models), `prisma/seed.ts` (lab-test seed data & patterns) |
| Registry & validation | `src/lib/lab-tests/registry.ts`, `src/lib/validation/lab-test.ts`, `src/lib/api/schemas.ts` |
| Services | `src/lib/services/lab-tests.ts`, `src/lib/services/access.ts` (access scoping), `src/lib/services/activity.ts` (vocabulary) |
| API layer | `src/app/api/lab-tests/{route,[id]/route,[id]/result/route,registry/route}.ts` |
| Frontend | `src/app/(app)/lab-tests/{page,[id]/page}.tsx`, `src/app/(app)/samples/[id]/page.tsx`, `src/components/lab-tests/{test-chart,result-form-dialog,test-form-dialog,status-controls}.tsx`, `src/lib/{api-types,api-client,server-api,format}.ts` |
| Charts | `src/components/lab-tests/test-chart.tsx` (8 renderers), `src/components/ui/chart.tsx` (shadcn/recharts wrapper), `recharts@2.15.4` in `package.json` |
| RBAC & constants | `src/lib/rbac.ts` (22 capabilities), `src/lib/constants.ts` |
| Docs | `docs/09-lab-test-registry.md`, `docs/10-api-design.md` (esp. §9.8), `docs/11-frontend-implementation.md` (esp. §11.1, §12) |
| Tests | `scripts/m2-test-registry.ts` (40/40), `scripts/m2-test-services.ts`, `scripts/m3-test-api.ts` (175/175, incl. lab-test suite), `scripts/m1-auth-test.sh` (13/13), `scripts/m4-test-ui.sh` (92/92), `scripts/m4-run-all.sh` (protocol) |
| Backups | `db/custom.db.bak-pre-m1…pre-m4` present (backup convention per milestone) |

**No files were modified. No code was written.**

---

## 2. Current implementation status

### 2.1 Data layer (`LabTest` model)

```
LabTest: id, sampleId (FK, cascade), testType: String, status: String (default PENDING),
         performedBy?, performedAt?, resultData: Json?, summary?, notes?, createdAt, updatedAt
         @@unique([sampleId, testType])   @@index([sampleId])
```

Verified facts and their M5 consequences:

1. **`testType` is a plain String** (schema header: no native enums, portable SQLite → PostgreSQL). Adding a new test type (**PRESSUREMETER**) is a registry/Zod change, **not a schema migration**. The comment listing 12 types on line 156 is documentation, not a DB constraint.
2. **There is no `inputData` column.** This is the root of the M4-documented input gap (§7 below).
3. `resultData` is validated per type at write time (`recordLabTestResult` → `parseLabTestResult`) — never arbitrary JSON. Stored rows are **not re-validated on read** (`getLabTest` only embeds registry metadata), so *stricter future write rules do not invalidate historical rows* — a key backward-compatibility property for M5 validation additions.
4. **One test per (sample, testType)** — matters for Direct Shear multi-stage design (§6.7) and Pressuremeter sampling pattern (§6.10).
5. In-situ tests attach to **synthetic interval samples** (seed: SPT samples `SPT-01 @ 2.0–2.45 m`; CPT as one continuous record `CPT-R1 @ 0.5–12 m`). Pressuremeter can follow the same pattern — no new FK or model needed.
6. `Sample.labStatus` (NOT_SENT → SENT → IN_TEST → COMPLETED/REJECTED) is independent of LabTest.status; both exist today and are not auto-synchronized (verified in seed: samples with IN_PROGRESS tests stay `SENT`/`IN_TEST`). M5 may surface the discrepancy but should not silently couple them without a decision.

### 2.2 Test registry (`src/lib/lab-tests/registry.ts`)

- 12 types, each with `inputSchema`, `resultSchema` (Zod + `superRefine` cross-field rules), `units`, `validationNotes`, `chart` config. Category set: `INDEX_PROPERTIES | COMPACTION | MECHANICAL | IN_SITU`.
- `parseLabTestInput()` **already exists and is already tested** (`scripts/m2-test-registry.ts` imports and exercises it) — but **no endpoint or service calls it today** (verified by grep: only the M2 test script uses it). M5 input persistence can adopt it as-is.
- `ChartConfig` union (8 renderable kinds + `none`): `grainSizeCurve`, `plasticityChart`, `compactionCurve`, `cbrCurve`, `depthProfile`, `cptProfile`, `oedometerCurve`, `barSummary`.
- Cross-field rules already enforced: %finer monotonicity, Cu = d60/d10, PL < LL, PI = LL − PL (±1), Proctor MDD/OMC vs curve, CBR = max(2.5, 5.0), SPT N & N60 identities, CPT depth monotonicity + finalDepth, triaxial unique σ3 + ≥2 stages for c′/φ′, oedometer pressure monotonicity, residual ≤ peak shear, wet > dry mass, Gs range 2.30–2.95.
- **Registry gaps found:** no Cc consistency rule (Cc = d30²/(d60·d10) is never checked although the field exists); no DIRECT_SHEAR c′/φ′ vs data consistency rule; WATER_CONTENT chart is configured as `depthProfile` but its result schema contains **no depth fields** (§5.6 defect); triaxial has a single scalar `excessPorePressureKpa` which is meaningless for multi-stage CU (per-stage values are the physical reality).

### 2.3 Service layer (`src/lib/services/lab-tests.ts`)

- `listLabTests`: filters `sampleId, boreholeId, projectId, testType, status, search` (search hits only `summary`/`performedBy`), pageSize ≤ 200, tenant-scoped via `getAccessibleProjectIds` (own + actively shared). **Does not return `resultData`** — lists embed sample/borehole/project context only.
- `getLabTest`: returns full detail **including `resultData`** + embedded registry metadata (`label, units, chart, validationNotes`) + `accessSource: own|shared`.
- `createLabTest`: `LAB_TEST_MANAGE`; validates parent sample is own-org; 409 on duplicate (sample, type); creates `PENDING` with `notes` only — **no inputs accepted**.
- `recordLabTestResult`: `LAB_TEST_RESULT`; registry validation → store, set `COMPLETED`, stamp performer/time, optional summary. Activity `LAB_TEST_RESULT_RECORDED`.
- `updateLabTest`: `LAB_TEST_MANAGE`; status/notes; re-opening a COMPLETED test clears `resultData` (server rule, UI warns).
- `deleteLabTest`: `LAB_TEST_MANAGE`; activity `LAB_TEST_DELETED`.
- Activity vocabulary already covers lab events (LAB_TEST_CREATED/RESULT_RECORDED/STATUS_UPDATED/DELETED) — **no new action types needed for input persistence** (details JSON can carry them), or optionally one additive `LAB_TEST_INPUT_RECORDED`.

### 2.4 API layer (M3)

Endpoints (docs/10 §4, verified in route files):

| Method & path | Capability | Notes relevant to M5 |
| --- | --- | --- |
| `GET /api/lab-tests` | `LAB_TEST_VIEW` | Filters above; envelope + pagination meta; **no `resultData` in items** |
| `POST /api/lab-tests` | `LAB_TEST_MANAGE` | Body strict: `{ sampleId, testType, notes? }` — **no `input` key accepted** (strict schema would 400 it today) |
| `GET /api/lab-tests/registry` | authenticated | Registry metadata (labels, standards, units, chart configs, validation notes) — PRESSUREMETER appears automatically once the registry is extended |
| `GET /api/lab-tests/[id]` | `LAB_TEST_VIEW` | Detail + registry embed; shared-access read-only |
| `PATCH /api/lab-tests/[id]` | `LAB_TEST_MANAGE` | `{ status?, notes? }` strict |
| `PUT /api/lab-tests/[id]/result` | `LAB_TEST_RESULT` | `{ result: unknown, summary? }` — per-type validated in service |
| `DELETE /api/lab-tests/[id]` | `LAB_TEST_MANAGE` | |

The M3 suite (`m3-test-api.ts`, 175 tests) covers lab-test CRUD, RBAC (viewer cannot PUT result), 409 duplicate, bad testType, registry access — this suite must keep passing unchanged.

### 2.5 Frontend (M4)

- **Pages:** `/lab-tests` list (filters testType/status/search + registry labels), `/lab-tests/[id]` detail (registry metadata card, scalar + array result tables via `friendlyKey`, `TestChart`, result entry, status control), sample detail hosts `TestFormDialog`.
- **`TestChart`** (`test-chart.tsx`, client, recharts): one function per chart kind + `NoData` guard for every missing-data path; uses CSS-variable theme colors (`--chart-1/2/4`), `isAnimationActive={false}`, tabular tooltips. Existing renderers: grain-size (semi-log + fixed ticks 0.001–100 mm), plasticity chart (A-line, U-line segments, CL/ML boundary segment, single sample point), Proctor curve (MDD/OMC `ReferenceDot`), CBR curve (2.5/5.0 mm `ReferenceLine`s), depth profile (single-point bar), CPT dual panel (qc, fs, inverted depth axis), oedometer e–log σ′ (σ′p marker), bar summary (UCS / triaxial stages / direct shear).
- **`ResultFormDialog`:** generic structured entry — scalar grid + repeatable point/stage rows; **client-side validation with the exact registry schema** (`parseLabTestResult` — same code as the API), 400 details surfaced, arrays with min/max row controls. **Weakness:** `RESULT_SPECS` hand-duplicates the registry field lists in the component — a drift risk that grows with PRESSUREMETER and input forms (§7.3).
- **`TestFormDialog`:** registers a type only (posts `{ sampleId, testType }`), shows the registry standard; excludes existing types; grouped by category.
- **`TestStatusControl`:** status PATCH with the re-open-clears-result warning.
- **API clients:** `api-client.ts` (browser, envelope unwrap, `ApiClientError` with field details, 401 → login), `server-api.ts` (RSC self-fetch with cookie forward + `cache()` dedupe, 401/403/404 mapping). `api-types.ts` mirrors all payload shapes including `ChartConfigDto` and `RegistryEntryDto`.
- **Seed data for charts:** all 12 types have COMPLETED results somewhere in the demo dataset (verified in `prisma/seed.ts`: Proctor STD+MOD, CBR soaked+unsoaked, granulometry ×3 materials, Atterberg CL/CH, triaxial UU+CU, oedometer, direct shear ×3 stress levels, SPT ×4 depths, CPT ×3 series via `cptSeries()`, UCS ×4 rocks, water content ×6, Gs ×3) — M5 chart work can be tested against real seeded data immediately; PRESSUREMETER will need new seed data.

### 2.6 What does NOT exist anywhere today (verified by search)

- No calculation/derivation module (no `calculate|derive|interpolate` logic in `src/lib`); every derived value (PI, Cu, N, N60, MDD/OMC, CBR%, Cc/Cs/σ′p, c′/φ′) is **user-entered and Zod cross-checked** at best.
- No soil-classification engine — USCS exists only as free text (`Layer.uscs` regex `^[A-Z]{2}(\([A-Z]\))?$`, optional `uscsClassification`/`uscsSymbol` strings on results).
- No Mohr-circle, stress–strain, direct-shear-envelope or pressuremeter rendering.
- No cross-test analytics of any kind (docs/11 §12 boundary: M5 = "laboratory test visualizations at project scale" — explicitly not started).
- No chart export (PNG/CSV) — not required by M5, listed as optional.

---

## 3. Existing reusable components (asset inventory)

| Asset | File | M5 reuse |
| --- | --- | --- |
| 12-type registry with Zod schemas + chart configs | `src/lib/lab-tests/registry.ts` | Extend additively: PRESSUREMETER entry, optional fields, new chart kinds (union members) |
| `parseLabTestInput()` (tested, unused) | `registry.ts` | Direct adoption for input persistence — zero new validation code |
| `recordLabTestResult` service pattern (validate → store → stamp → log) | `services/lab-tests.ts` | Template for `inputData` handling |
| Envelope/error utilities, `withApi`, strict body schemas | `lib/api/**` | New optional body keys follow the exact `labTestResultBody` precedent (`z.unknown()` + per-type validation in the service) |
| `TestChart` architecture (kind-router + per-kind renderer + `NoData`) | `components/lab-tests/test-chart.tsx` | Add renderers: `stressStrainCurves`, `mohrCircles`, `shearEnvelope`, `pressuremeterCurve`; fix `depthProfile` |
| recharts 2.15.4 (`ReferenceLine/Dot`, `Scatter`, `Line`, `LabelList` already used) | dependency | Sufficient for all M5 charts incl. Mohr circles (parametric `Line` sampling + envelope `ReferenceLine`). **No new chart dependency needed.** |
| shadcn `ui/chart.tsx` wrapper | `components/ui/chart.tsx` | Available if a chart needs its theming container; TestChart does not use it today — no forced migration |
| `ResultFormDialog` generic scalar/array form | `components/lab-tests/` | Refactor its specs to be registry-driven (removes duplication) while adding auto-calc helpers |
| `api-client` / `server-api` / `api-types` | `src/lib/` | Extend `ChartConfigDto` + lab-test DTOs in lockstep (additive) |
| States system (`EmptyState`, `UnauthorizedState`, loading/error) | `components/shared/states.tsx` | Reuse for new analytics pages |
| `stratigraphy-column.tsx` (CSS depth-proportional column) | `components/boreholes/` | Visual language reference for borehole lab profiles (depth axis, bands) |
| Test suites m1–m4 + `m4-run-all.sh` protocol (backup → seed → regressions → browser suite → error scan → re-seed) | `scripts/` | Clone as `m5-run-all.sh`; m1–m4 suites must pass unchanged |
| Seed framework with registry-validated results | `prisma/seed.ts` | Extend with PRESSUREMETER + input data |

---

## 4. Gap analysis — M5 requirements vs. current state

### 4.1 Test-by-test matrix

| Test (M5 §3) | Registry | Result schema adequate? | Chart today | Gaps for M5 |
| --- | --- | --- | --- | --- |
| Granulometry | ✅ | Mostly — %finer points + optional d10/d30/d60/Cu/Cc/USCS | ✅ PSD curve | Auto-derive Cu/Cc (and **add the missing Cc consistency rule**); d-values by log-interpolation as an aid; classification automation (see 4.2) |
| Atterberg limits | ✅ | Final values only (raw flow-curve/blow data not captured — out of M5 scope, noted) | ✅ plasticity chart (single point) | A-line evaluation + symbol suggestion (CL/ML/CH/MH/CL-ML); multi-sample overlay on one chart |
| Water content | ✅ | Yes, but **mass semantics ambiguous** (see 6.3) | ⚠️ **broken** — `depthProfile` reads `result.depthFrom/To` which the schema lacks → always renders NoData | Fix: borehole-scale profile sourced from sample depths (cross-test) |
| Soil classification USCS/LCPC | ❌ not a test — missing as a **capability** | — | — | New pure classification function + sample-level synthesis card (see 4.2) |
| Proctor N/M | ✅ | Yes (w, ρd points + MDD/OMC) | ✅ curve + MDD/OMC marker | Auto peak-fit suggestion; optional zero-air-voids overlay (needs Gs cross-link); method/energy constants documented |
| CBR | ✅ | Yes (points + cbrAt2.5/5.0/cbrValue/swell) | ✅ curve + 2.5/5.0 refs | Auto-compute CBR% from curve by interpolation at 2.5/5.0 mm **with standard-load constants cited**; seating-correction suggestion; consistency rule (interpolated vs entered) |
| Direct shear | ✅ but **single-stage only** | ❌ for the required τ–σn envelope chart | barSummary | Additive optional multi-`stages` array + envelope chart + least-squares c′/φ′ fit + consistency rule (§6.7) |
| Oedometer | ✅ | Yes (stages + Cc/Cs/σ′p/cv) | ✅ e–log p + σ′p marker | Auto Cc/Cs from stages; Casagrande σ′p construction as a suggestion; cv stays manual (time-deformation data not modeled — documented limitation) |
| Triaxial UU/CU/CD | ✅ but **peak-only stages** | ❌ for stress–strain + Mohr circles | barSummary only | Additive optional per-stage `stressStrain[]` + `porePressureAtFailureKpa`; two new chart kinds; p-q regression → c′/φ′ (§6.9) |
| Pressuremeter Ménard | ❌ **test type does not exist** | ❌ | ❌ | Full new registry entry + chart kind + seed + tests (§6.10) |
| SPT | ✅ | Yes (blows, N, ER, N60, refusal) | single-point bar | Borehole-scale N profile (cross-test); optional (N1)60 with explicit overburden input (§6.11) |
| CPT | ✅ | Yes (qc, fs points) | ✅ dual profile | Auto frictionRatioAvg; optional per-point Rf in tooltip; NF citation check (see 6.12) |
| UCS / Specific gravity (registry extras, not in M5 §3 list) | ✅ | Yes | bar / none | No functional change — must keep working; Gs becomes the Proctor ZAV data source |

### 4.2 Soil classification — current state and required design

Today: `Layer.uscs` free text (regex-validated symbol format only), optional `uscsClassification`/`uscsSymbol` strings on granulometry/Atterberg results. No computation, no linkage.

M5 requirement: classification from **USCS (ASTM D2487)** with applicable Algerian/LCPC references.

Recommended design (to be approved with the plan):

1. **Pure function, compute-on-read, not persisted** — `classifyUSCS(granulometryResult, atterbergResult?, naturalWaterContent?)` returning `{ symbol, groupName?, ruleTrace[] }`. Rationale: results are editable and re-openable; persisting derived classification creates staleness the schema cannot track. The rule trace (which branches fired: %fines, coarse-fraction split, Cu/Cc checks, A-line position) is shown in the UI so engineers can audit the decision — this is an interpretation aid, and the engineer remains responsible (consistent with the project's "never invent" rule).
2. **Data dependency:** one granulometry + (for fine soils) one Atterberg test on the **same sample**. The sample detail page already lists both — the synthesis card joins them client/server-side via existing endpoints.
3. **Inputs to the decision tree (ASTM D2487):** fines % = percentFiner at 0.075 mm (interpolated from the PSD if no exact point); gravel/sand split at 4.75 mm (% retained on #4 of the coarse fraction); Cu, Cc; LL, PI, A-line position. Borderline handling: 4 ≤ PI ≤ 7 and LL < 50 → CL-ML; 5–12% fines on coarse soils → dual symbols (e.g. SP-SM). Organic distinction (OL/OH) requires oven-dried LL ratio or visual judgment — **will be surfaced as "insufficient data, engineer judgment"**, never auto-assigned.
4. **Group names** (full ASTM D2487 naming needs sand/gravel percentages and plasticity adjectives — partially derivable): M5 restricts to **symbol + simplified name** (e.g. "SC — clayey sand") and states the limitation.
5. **Algerian/LCPC reference:** French earthworks practice classifies soils per **NF P11-300 (GTR)** — a table-based system (dmax, %passing 80 µm / 2 mm, plasticity, water content, consistency). Its tables are normative content that must not be reproduced from memory: M5 will cite it and, **if the table values cannot be verified from an authoritative source during implementation, the GTR output will be documented as out of scope** rather than approximated. Decision requested (see §13, D6).

### 4.3 Cross-test analytics (the M5 "project scale" mandate)

docs/11 §12 defines M5 as laboratory visualizations **at project scale**. Today nothing aggregates tests. Two blocking facts:

1. `GET /lab-tests` does not return `resultData` → comparison views would need N× detail calls.
2. No page composes tests by borehole/project.

Proposed minimal solution (additive, backward compatible): an opt-in `include=resultData` query parameter on the existing list endpoint (default off → current payloads byte-identical; capped by the existing pageSize ≤ 200). CPT caveat: 600 points × many tests is heavy — the UI will page/reasonably bound comparisons, and the parameter stays opt-in. A dedicated `/lab-tests/comparison` endpoint remains a documented future option if payload size ever matters.

Views to build on top: borehole laboratory profile (N, w, qc/fs vs depth, one composite view per borehole), Proctor/PSD/CBR/plasticity comparison overlays across samples (project filter), sample-level classification synthesis card.

---

## 5. Defects and risks found in existing code (to fix or accept in M5)

| # | Finding | Severity | Proposed handling |
| --- | --- | --- | --- |
| F1 | **WATER_CONTENT chart always renders NoData** — `DepthProfile` reads `result.depthFrom/depthTo`; the water-content result schema has no depth fields | Medium (broken feature, silent) | Replace with borehole-scale water-content profile sourced from `sample.depthFrom/To` (cross-test view); keep per-test "no chart" honest state |
| F2 | Water-content **mass semantics ambiguous** — `wetMassG/dryMassG/containerMassG` never defined as (tare+wet / tare+dry / tare) vs solids-only; only `wet > dry` checked | Medium (scientific correctness) | Define explicitly: `containerMassG` = tare, `wetMassG` = tare+wet, `dryMassG` = tare+dry; add cross-check `w ≈ 100·(wet−dry)/(dry−container)` within tolerance when all three present; document in registry notes |
| F3 | Missing **Cc consistency rule** (`Cc = d30²/(d60·d10)`) although all fields exist | Low | Additive write-time rule; historical rows unaffected (no read re-validation) |
| F4 | `RESULT_SPECS` in `result-form-dialog.tsx` duplicates registry field lists by hand | Medium (maintenance drift, grows with 13 types + input forms) | Introduce declarative field descriptors in the registry (`formFields`/`inputFields` metadata, additive) and drive both result and input forms from them |
| F5 | Triaxial scalar `excessPorePressureKpa` is unphysical for multi-stage CU | Low-Medium | Add optional per-stage `porePressureAtFailureKpa`; keep the scalar (seed uses it) with clarified semantics |
| F6 | Registry standard citations need verification against current editions (CPT cites NF P94-119; French CPT references are NF P94-113 / NF EN ISO 22476-1; oedometer NF P94-090 vs ISO 17892-5; Atterberg NF P94-051/-052) | Low (documentation) | Verify during implementation; corrections are registry-string changes (additive) with a changelog note |
| F7 | `LabTest.search` matches only `summary`/`performedBy` — fine today | Info | No change needed for M5 |
| F8 | Sample `labStatus` and test statuses are independent (no auto-sync) | Info | Surface in M5 UX where visible; coupling is a product decision — not proposed |

---

## 6. Scientific calculation requirements (per test)

Conventions used below: **[S]** = textbook-standard formula, safe to implement with unit tests; **[V]** = standard-specific constant/procedure that MUST be verified against the actual standard text during implementation before being coded as a constant; **[A]** = explicit engineering assumption to be shown in the UI. Derived values are **suggestions the user confirms** unless stated otherwise — the API stays the persistence authority and the Zod consistency rules remain the gate.

### 6.1 Granulometry — ASTM D6913 / NF P94-056 (sieve), D7928 / NF P94-057 (hydrometer)

- **Inputs (planned):** method (SIEVE / SIEVE_AND_HYDROMETER), sample mass, notes. *(Current input schema — keep.)*
- **Raw measurements:** percent-finer per diameter (computed by the lab from retained masses; retained-mass bookkeeping is out of M5 scope).
- **Calculations [S]:** `Cu = d60/d10`; `Cc = d30²/(d60·d10)`; d-values by **log-linear interpolation** between bracketing PSD points (method note shown when interpolated [A]).
- **Validation additions:** Cc consistency (F3); existing monotonicity + unique diameters + Cu rule unchanged.
- **Charts:** PSD semi-log (exists); M5 adds multi-sample overlay comparison.
- **Interpretation:** feeds USCS classification (4.2). Hydrometer Stokes' law computation is out of scope (no hydrometer reading arrays in the schema) — documented limitation.

### 6.2 Atterberg limits — ASTM D4318 / NF P94-051 (cup) / NF P94-052 (rolling); cone variant [V]

- **Inputs (planned):** method CASAGRANDE_CUP / CONE_PENETROMETER, notes.
- **Raw measurements:** final LL, PL (raw multipoint flow-curve data not captured — out of M5 scope; noted as a future additive array).
- **Calculations [S]:** `PI = LL − PL` (rule exists — keep as cross-check, auto-fill in form); `LI = (w_natural − PL)/PI` when a same-sample WATER_CONTENT result exists [A: natural moisture representativeness]; A-line `PI = 0.73(LL−20)` and U-line `PI = 0.9(LL−8)` already drawn — M5 adds the **symbol suggestion** from chart position (CL/ML/CL-ML/CH/MH; OL/OH → "judgment required").
- **Charts:** plasticity chart (exists) + multi-sample overlay.

### 6.3 Water content — ASTM D2216 / NF P94-050

- **Inputs (planned):** container id, oven temperature (100–120 °C range already bounded), notes.
- **Raw measurements:** masses; with F2 semantics: `w = 100·(m_wet+tare − m_dry+tare)/(m_dry+tare − m_tare)` [S].
- **Calculation:** auto-fill `waterContentPercent` from the three masses when all present; add the consistency cross-check (tolerance ±0.5 % abs / rel — to fix in implementation tests).
- **Charts:** per-test: none (honest empty state after F1 fix); **borehole profile: w vs depth** across all water-content tests of a borehole's samples [cross-test].

### 6.4 Soil classification (USCS) — ASTM D2487; French reference NF P11-300 [V]

- Full design in §4.2. Pure function + traceable rule output; engineer confirms; no persistence of derived values.

### 6.5 Proctor — ASTM D698 / D1557 / NF P94-093

- **Inputs (planned):** method (STANDARD/MODIFIED), mold (101.6/152.4 mm), optional blows/layer and rammer data; **energy constants per method [V]** (≈600 kJ/m³ normal, ≈2700 kJ/m³ modified — display-only, cite standard, do not compute).
- **Raw measurements:** per point (w, ρd). Optional additive per-point `wetDensityMgM3` enabling `ρd = ρ/(1+w)` [S] auto-derivation when mold volume is known — decision point (D4).
- **Calculations:** MDD/OMC **peak-fit suggestion** from the points (quadratic fit through the points bracketing the maximum [A] — method disclosed; user can override; existing Zod rules keep the entered values honest against the curve). **Zero-air-voids overlay [S]:** `ρ_zav = Gs·ρw/(1 + w·Gs)` using same-sample SPECIFIC_GRAVITY when present, else **Gs = 2.65 assumed with a visible assumption label [A]** — optional toggle.
- **Charts:** compaction curve (exists) + ZAV overlay + multi-test comparison (standard vs modified on one sample set / across samples).

### 6.6 CBR — ASTM D1883 / NF P94-078

- **Inputs (planned):** condition (SOAKED/UNSOAKED), surcharge, soaking days (already in input schema).
- **Raw measurements:** load–penetration points, swell.
- **Calculations:** standard loads **[V]**: ≈13.2 kN @ 2.5 mm and ≈19.9 kN @ 5.0 mm (the classic 1000/1500 psi values on the standard piston — must be verified against the standard table before coding as constants, then cited). `CBR@x = 100·P(x)/P_std(x)` [S once P_std verified]; `P(x)` by linear interpolation between bracketing points; **seating correction** (origin shift by extending the initial steep straight segment) as an explicit, user-confirmed suggestion [A]. New consistency rule: interpolated vs entered CBR within tolerance.
- **Charts:** curve with 2.5/5.0 refs (exists) + standard-load reference markers + soaked/unsoaked comparison.

### 6.7 Direct shear — ASTM D3080 / NF P94-071-1

- **Inputs (planned):** specimen dimensions, rate (already in input schema; note French boxes are commonly square — diameter field is fine for circular specimens; box-type note added to registry text).
- **Current limitation:** one (σn, τpeak, τres) per test record. The required **τ vs σn failure-envelope chart** needs multiple stress levels. Standard practice runs ≥3 stress levels on nominally identical specimens.
- **Additive schema design:** optional `stages: [{ normalStressKpa, peakShearStressKpa, residualShearStressKpa? }]` array; scalar fields remain valid for single-stage records (backward compatible; `superRefine` requires stages OR scalars, not neither).
- **Calculations [S]:** least-squares fit `τ = c′ + σn·tanφ′` over stage peaks → suggested c′, φ′ (with R² displayed as a fit-quality indicator); residual envelope optional. New consistency rule: entered c′/φ′ vs fit within tolerance (like Proctor MDD).
- **Charts:** NEW `shearEnvelope` kind — σn–τ scatter, fitted line, c′ intercept marker, φ′ annotation.

### 6.8 Oedometer — ASTM D2435 / NF P94-090 [V citation] / ISO 17892-5

- **Inputs (planned):** specimen geometry, initial void ratio (already in input schema).
- **Raw measurements:** (σv, e) stages (deformation-to-void-ratio bookkeeping out of scope; e computed by the lab or from `e = e0 − ΔH·(1+e0)/H0` as a helper if raw deformations were available — they are not modeled).
- **Calculations:** `Cc = Δe/Δ log₁₀ σv` over the steepest virgin segment [S] — auto-suggested; `Cs` similarly over unloading if present (schema stages are monotonic loading only — unload stages not modeled, documented); **σ′p by Casagrande construction** implemented numerically (curvature-maximum point + bisector) as an explicit suggestion [A: graphical method digitized]; `cv` remains user-entered (Taylor √t / Casagrande log-t constructions need time–deformation arrays not in the schema — documented limitation; additive future).
- **Charts:** e–log σ′ curve + σ′p marker (exists) + Cc/Cs slope annotations.

### 6.9 Triaxial UU/CU/CD — ASTM D2850 / D4767 / D7181 / NF P94-077 / ISO 17892-8,9,10

- **Inputs (planned):** type, specimen count, back pressure (already in input schema).
- **Raw measurements — additive schema extensions (all optional, backward compatible):**
  - per stage: `stressStrain: [{ strainPercent, deviatorStressKpa }]` (the actual curve data);
  - per stage: `porePressureAtFailureKpa` (CU);
  - keep existing `confiningPressureKpa`, `peakDeviatorStressKpa`, `strainAtFailurePercent`.
- **Calculations [S]:**
  - `σ1f = σ3 + q_peak` (per stage);
  - **Mohr-Coulomb from p–q regression**: least squares on `(p, q) = ((σ1f+σ3f)/2, (σ1f−σ3f)/2)` gives the Kf line `q = a + p·tanα`; then `sinφ = tanα`, `c = a/cosφ` (total-stress for UU with φu≈0 → cu from the φ=0 envelope; effective-stress for CU using `σ′ = σ − u_f`). Method attribution shown in the UI.
  - Existing rule (c′/φ′ need ≥2 stages) kept; new consistency rule: entered c′/φ′ vs regression within tolerance (like Proctor/CBR).
  - Area correction for stress-strain display (`A = A0/(1−ε)`) [S] — display-level only, standard practice for axial strain reporting; toggle with visible assumption.
- **Charts:** NEW `stressStrainCurves` (multi-series: deviator vs strain%, one series per stage) and NEW `mohrCircles` (parametric circle rendering per stage + fitted envelope + Kf line; effective + total circles for CU when pore pressures given). UU: total circles only.

### 6.10 Pressuremeter Ménard — **NEW TEST TYPE** — NF P94-110-1/-2, ASTM D4719 [V]

- **Registry entry (all new):** code `PRESSUREMETER`, category `IN_SITU`, standard string, input/result schemas, units, validation notes, chart kind `pressuremeterCurve`.
- **Inputs (planned):** probe type, test depth, borehole diameter, calibration readings (membrane + probe), groundwater presence, notes.
- **Raw measurements:** pressure steps with volume readings at hold times (30/60/120 s convention **[V]** — step count and timing to be verified against NF P94-110-1).
- **Corrected curve [V — procedure per standard]:** measured pressure/volume corrected by calibration terms → P–V expansion curve.
- **Derived parameters:** creep pressure `pf` (departure from the pseudo-elastic segment — detection rule to follow the standard's definition **[V]**); **Ménard modulus** `EM = 2(1+ν)·V·ΔP/ΔV` with ν = 0.33, `V = V0 + ΔV/2` of the elastic segment **[V]**; **limit pressure** `PL` at ΔV = 2·V1 (V1 = volume at pf) **[V]**; `EM/PL` ratio; rhéologique category α **[V]** (table per soil/probe type).
- **Data-model placement:** follows the SPT/CPT pattern — a synthetic interval sample per test depth (`PM-01 @ depth interval`), one PRESSUREMETER test per interval. No schema relation changes.
- **Charts:** NEW `pressuremeterCurve` — corrected P vs V with elastic segment highlighted, pf and PL markers, EM annotation.
- **Honesty rule:** where a constant cannot be verified during implementation, the derived field is left user-entered (Zod-checked only) and the limitation documented — never a guessed coefficient.

### 6.11 SPT — ASTM D1586 / NF P94-116

- Existing identities kept (`N = blows2nd + blows3rd`, `N60 = N·ER/60`). Auto-fill both in the form.
- **(N1)60 — optional additive input** `effectiveOverburdenKpa` with `CN = √(95.8/σ′v0)` (kPa, Liao–Whitman / Youd et al. 1997; CN ≤ 1.7) **[V — cite and verify]**; if the user provides no σ′v0, the feature is simply absent (no default invented).
- **Charts:** borehole-scale N (and N60) profile vs depth across all SPT tests of a borehole [cross-test]; refusal markers.

### 6.12 CPT — ASTM D5778 / NF P94-113 / NF EN ISO 22476-1 (citation check F6)

- Auto-compute `frictionRatioAvg = mean(100·fs/qt)` (≈fs/qc absent pore pressure) [S]; per-point Rf in tooltip.
- SBT classification (Robertson charts) — **not required by M5 §5**; noted as a documented future option (qt/net-area-ratio data not in schema; non-normalized chart possible but adds interpretation risk — deliberately deferred).

### 6.13 UCS / Specific gravity — unchanged

Registry extras; keep working; Gs becomes the Proctor ZAV source via same-sample lookup.

---

## 7. Database changes required (all additive, backward compatible)

| # | Change | Type | Compatibility analysis |
| --- | --- | --- | --- |
| D1 | `LabTest.inputData Json?` (nullable) | Additive column | Nullable Json — old rows NULL; `prisma db push` in sandbox; PG migration path documented (add column). **Resolves the M4-documented gap (§2.1-2).** |
| D2 | PRESSUREMETER test type | Registry-only | `testType` is String (no native enums) — no migration; Zod enum + registry entry + constants label map; update the schema comment listing types (documentation) |
| D3 | TRIAXIAL optional per-stage `stressStrain[]`, `porePressureAtFailureKpa` | Registry JSON optional fields | Old rows parse unchanged (optional keys); write-time only validation |
| D4 | DIRECT_SHEAR optional `stages[]` | Registry JSON optional fields | Same; scalar path preserved |
| D5 | PROCTOR optional per-point `wetDensityMgM3` | Registry JSON optional field | Optional; auto-derivation `ρd = ρ/(1+w)` — decision point |
| D6 | SPT optional `effectiveOverburdenKpa` input + derived `(N1)60` | Registry JSON optional field | Optional; formula-cited |
| D7 | WATER_CONTENT mass-semantics definition + consistency rule | Validation semantics (no structural change) | Write-time rule; seed data must be re-verified to pass (it will — rule only fires when all three masses present and consistent; seed values are consistent) |
| D8 | GRANULOMETRY Cc consistency rule | Validation rule | Write-time only |
| D9 | Seed extension | Data | PRESSUREMETER test(s) on a synthetic sample (e.g. in the Algiers or Chlef borehole set); `inputData` on a representative subset of tests (one per type where the input schema is non-trivial) so M5 UI/tests have fixtures |

**Migration safety protocol (project convention):** back up `db/custom.db` → `db/custom.db.bak-pre-m5` before any push; additive only; re-seed after tests; m2/m3 suites must pass unchanged. No changes to Organization/User/Project/Borehole/Sample/Layer/Document/Sharing/Report/ActivityLog models — tenant isolation untouched.

**Input editability rule (decision point D-Input):** recommendation — `inputData` editable via `PATCH /lab-tests/[id]` while `resultData` is NULL; once a result exists, inputs lock (matching the existing "re-open clears result" semantics — reopening re-enables input editing). Rationale: scientific traceability of what was planned vs what was measured.

---

## 8. API changes required (all additive)

| # | Change | Detail | Compatibility |
| --- | --- | --- | --- |
| A1 | `POST /api/lab-tests` accepts optional `input` | `createLabTestSchema` gains `input: z.unknown().optional()` (strict schema stays strict — the new key is recognized); the service validates it with the **existing** `parseLabTestInput` per type → 400 `VALIDATION_ERROR` with registry message on failure; stores `inputData` | Old clients unaffected (key optional); envelope/status codes unchanged |
| A2 | `PATCH /api/lab-tests/[id]` accepts optional `input` | Same validation; editability rule per D-Input; activity `LAB_TEST_STATUS_UPDATED` details extended or one additive action `LAB_TEST_INPUT_RECORDED` (decision) | Additive |
| A3 | `GET /lab-tests/[id]` returns `inputData` | Comes free via the model once D1 exists; `api-types.ts` extended in lockstep | Additive field |
| A4 | `GET /api/lab-tests?include=resultData` | Opt-in projection of `resultData` in list items for cross-test analytics; default off keeps payloads identical; still capped by pageSize ≤ 200; documented CPT payload caveat | Additive query key (strict query schema gains the key) |
| A5 | Registry endpoint | PRESSUREMETER + any new chart kinds appear automatically (registry-driven) | No code change |
| A6 | docs/10 addendum | New/changed endpoints + the §9.8 gap closure documented during implementation (this audit does not modify docs) | Documentation |

No changes to: envelope shape, error-code table, CSRF/same-origin rules, caching headers, capability matrix (input persistence rides on `LAB_TEST_MANAGE`; nothing new for viewers), tenant scoping (new data flows through the same `getOwnLabTestOrThrow` / `getAccessibleProjectIds` guards).

**Non-goals (explicit):** no calculation endpoints (calculations are client-side pure functions; the API persists and validates — the server never silently rewrites user data), no bulk import, no report generation changes.

---

## 9. Frontend changes required

| # | Area | Change |
| --- | --- | --- |
| U1 | Registry | Declarative **field descriptors** for inputs and results (`inputFields`, `resultFields` metadata: key, label, unit, kind, options, required) — additive; drives forms and removes the `RESULT_SPECS` duplication (F4) |
| U2 | `TestFormDialog` | Per-type input-parameter form (from U1) posted with `input`; shown again as read-only on the test page; edit per D-Input rule |
| U3 | Test detail page | "Test definition (inputs)" card; calculated-suggestion affordances with visible formula/standard/assumption attribution ([S]/[V]/[A] surfaced as human-readable notes) |
| U4 | `ResultFormDialog` | Registry-driven specs; auto-fill helpers: PI, Cu/Cc, N, N60, CBR@2.5/5.0, water content from masses, Proctor ρd from wet density (if D5), direct-shear/triaxial envelope fits, MDD/OMC peak fit, σ′p construction — each labeled as a suggestion; user confirms/overrides; Zod remains the gate |
| U5 | `TestChart` | New renderers: `stressStrainCurves`, `mohrCircles`, `shearEnvelope`, `pressuremeterCurve`; Proctor ZAV overlay (toggle, Gs source + assumption label); CBR standard-load markers; fix WATER_CONTENT depth profile (F1) via borehole-scale view; keep `NoData` honesty states |
| U6 | Sample detail | **Soil synthesis card**: USCS classification (symbol + simplified name + rule trace) from same-sample granulometry + Atterberg (+ natural w); links to the source tests; explicit "insufficient data" states |
| U7 | New analytics views (project scale) | Borehole laboratory profile page (N/N60, w, qc/fs vs depth composed from that borehole's tests); comparison view for Proctor / PSD / CBR / plasticity across samples within a project (uses A4); all read-only, RBAC-visible like other data modules; new nav item or a tab under Laboratory Tests — **decision point** |
| U8 | `api-types.ts` | Additive DTO updates (inputData, new chart kinds, PRESSUREMETER) in lockstep with the registry |
| U9 | UX honesty rules | Every computed value shows its formula/standard/assumption; every reference constant shows its citation; no invented data anywhere; cross-field Zod errors surfaced inline where the details array provides paths (improvement over current dialog-level-only messages, per docs/11 §11.4) |

Design system reuse: existing tokens (emerald/teal on stone), `Card`/`Tabs` layout language, chart CSS-variable colors, `EmptyState`/`LoadingState`, tabular numerals, light/dark — all unchanged.

---

## 10. Testing strategy (all tests executed, never asserted)

| Layer | Suite | Content |
| --- | --- | --- |
| Static | `bunx tsc --noEmit`, `bun run lint` | Zero errors, as in M1–M4 |
| Unit (NEW) | `scripts/m5-test-calculations.ts` | Pure-function golden cases with hand-computed expected values: w from masses; PI; Cu/Cc; CBR interpolation + standard loads (post-[V] verification); Proctor peak fit + ZAV; direct-shear & triaxial least-squares fits (perfect + noisy data, R²); p–q → c′/φ′ conversion; σ′p Casagrande construction on a synthetic curve; USCS classifier vectors incl. borderline cases (CL-ML band, dual symbols, A-line boundary, organic "insufficient data") |
| Registry (EXTEND) | new `m5-test-registry.ts` (keep m2 script pristine) | PRESSUREMETER valid/invalid; triaxial stressStrain + per-stage pore pressure; direct-shear stages vs scalars; new consistency rules (Cc, mass-based w, CBR interpolation, envelope fits); **input schemas round-trip for all 13 types** |
| Services (EXTEND) | new `m5-test-services.ts` | inputData create/read/update + editability rule; per-type input validation failures; registry validation of new result shapes; tenant isolation spot-checks for new fields |
| API (EXTEND) | new `m5-test-api.ts` (live dev server) | A1–A4 happy paths + validation errors + RBAC (viewer cannot POST input; PM can; shared-project tests read-only); envelope shape on every new error path; `include=resultData` on/off payload comparison; leak scan (no new fields leak internals) |
| Browser (EXTEND) | new `m5-test-ui.sh` | Input-parameter form flow (create test with inputs → detail shows them); result entry with auto-calc suggestion → override → Zod cross-check error path; every new chart renders from seeded data (triaxial stress-strain + Mohr, direct-shear envelope, pressuremeter curve, Proctor ZAV overlay, CBR markers); water-content borehole profile (F1 fixed); classification card on a sample with granulometry+atterberg; comparison view; dark theme; mobile 390 px no-overflow on new pages; dev-log error scan |
| Regression (MANDATORY) | m2 registry 40/40, m2 services 50/50, m3 API 175/175, m1 auth 13/13, m4 UI 92/92 | All unchanged suites pass — proves additivity and no regressions |
| Protocol | `m5-run-all.sh` (clone of m4-run-all) | backup → seed → static → unit/registry/service/API → regressions → browser suite → error scan → re-seed pristine; everything in one bash invocation (sandbox process-group rule) |
| Data | seed extension | New seed values pass registry validation at seed time (fail-fast, existing pattern) |

---

## 11. Dependency map

**Runtime (unchanged — no new dependencies):**

```
recharts 2.15.4  ── TestChart (all existing + 4 new renderers)     [sufficient; no lib added]
zod 4            ── registry schemas + new optional fields/rules
react-hook-form  ── input/result dialogs (existing pattern)
shadcn/ui        ── forms, tables, tabs, states
Prisma 6         ── LabTest.inputData column (additive)
NextAuth v4 + rbac.ts ── unchanged guards for all new surface
```

**Code dependency chain for each M5 change (what touches what):**

```
D1 inputData   : prisma/schema.prisma → services/lab-tests.ts → validation/lab-test.ts
                 → api/schemas.ts → api-types.ts → test-form-dialog.tsx → lab-tests/[id]/page.tsx
PRESSUREMETER  : registry.ts (entry+schemas+chart kind) → constants? (labels optional)
                 → api-types.ts (ChartConfigDto) → test-chart.tsx (renderer)
                 → result-form-dialog.tsx (via U1 descriptors) → seed.ts → m5 tests
Triaxial/DS/etc.: registry.ts → test-chart.tsx + result-form-dialog.tsx (+ api-types)
Classification  : NEW src/lib/lab-tests/classification.ts (pure) → samples/[id]/page.tsx (card)
Calculations    : NEW src/lib/lab-tests/calculations.ts (pure) → result-form-dialog + charts
Cross-test      : api lab-tests/route.ts (+include) → services listLabTests
                 → NEW analytics page/components → api-types.ts
```

**Sequencing constraints (hard):** D1 before A1–A3; U1 before U2/U4 (descriptors drive forms); PRESSUREMETER registry before its seed/chart/tests; A4 before U7; calculation module before U4 auto-fills; F1/F2/F3 fixes belong to the registry/schema sub-milestone so later UI work builds on corrected contracts.

---

## 12. Proposed implementation sequence (sub-milestones)

> Each sub-milestone is independently verifiable (static + relevant suites green) and leaves the app in a working state. Approval of this plan authorizes 5.1 first; the rest follow the established one-milestone-at-a-time protocol.

**5.1 — Data contracts & the input-persistence gap (backend, small)**
Registry additions: PRESSUREMETER entry (schemas + chart kind), triaxial/direct-shear/Proctor/SPT optional fields, new validation rules (Cc, water-content masses, CBR interpolation consistency, envelope consistency, editability semantics). Prisma: `inputData` column (backup first). Services + API: input persistence (A1–A3), `include=resultData` (A4). Seed: PRESSUREMETER + input fixtures. Tests: m5 registry + services + API suites; m1–m4 regressions. Fixes F1–F3, F5, F6 at the registry level. *Exit: input round-trip works end-to-end via API; all regressions green.*

**5.2 — Calculation engine (pure functions)**
`src/lib/lab-tests/calculations.ts` + `classification.ts` with full standard citations and [V] constants verified (or explicitly left user-entered). Unit suite `m5-test-calculations.ts` (golden values, borderline vectors). No UI yet. *Exit: every formula unit-tested; nothing untested ships.*

**5.3 — Laboratory UX upgrade (forms + single-test charts)**
U1 field descriptors; U2 input forms; U3 input cards; U4 auto-calc suggestions with attribution; U5 new chart renderers (Mohr, stress–strain, shear envelope, pressuremeter, ZAV, CBR markers) + F1 water-content fix; U8/U9 types and error surfacing. Browser suite extension. *Exit: a full lab workflow — register with inputs → record calculated-assisted result → interpret chart — works per test type.*

**5.4 — Classification synthesis & project-scale analytics**
U6 sample synthesis card; U7 borehole laboratory profile + comparison views (uses A4); nav placement decision. Browser suite extension; responsive/dark verification. *Exit: cross-test views render from real seeded data with honest empty states.*

**5.5 — Hardening, documentation & milestone report**
`m5-run-all.sh` full protocol (all suites, backups, re-seed); docs/10 addendum (input persistence, include param) + docs/12 update + new `docs/13-laboratory-analysis.md` (formulas, standards, assumptions — the scientific reference card); completion report with screenshots, API integration inventory, known limitations (cv time-data, hydrometer, GTR tables, CPT SBT, report generation), and explicit M6-not-started confirmation.

---

## 13. Open decisions requested with the plan approval

| # | Decision | Recommendation |
| --- | --- | --- |
| D1 | Approve `LabTest.inputData Json?` additive column | **Yes** — minimal safe fix for the M4-documented gap; per-type validated like results; no security surface change |
| D2 | Input editability rule | Lock inputs once a result exists; reopen (which clears the result) re-enables editing |
| D3 | Cross-test data access | `include=resultData` opt-in query param now; dedicated comparison endpoint only if payload size becomes a problem |
| D4 | Proctor per-point optional `wetDensityMgM3` | Include (optional) — enables the ρd = ρ/(1+w) derivation without breaking old data |
| D5 | Analytics page placement | New "Laboratory analytics" view reachable from the Laboratory Tests area (tab or sibling route) — final call during 5.4 UX |
| D6 | NF P11-300 (GTR) classification output | Implement only if standard tables can be verified from an authoritative source during 5.2; otherwise document as out of scope (USCS remains the implemented system) |
| D7 | Activity logging for input writes | Reuse existing actions with details (no vocabulary growth) — simplest; additive new action if traceability review prefers it |
| D8 | [V] constants policy | Constants are coded only after verification against the standard text, each with a citation comment; anything unverifiable stays user-entered + documented |

---

## 14. Boundary confirmation

- **Not in M5** (unchanged milestone boundaries): GIS map (M6), report document generation, billing, real-time collaboration, external integrations, CSV bulk import, hydrometer Stokes computations, CPT SBT classification, cv time-settlement analysis.
- **Architecture preserved:** Next.js 16 / TS strict / Prisma + existing service layer / M3 API + envelope / Zod / NextAuth + 22-capability RBAC / multi-tenant isolation / M4 design system. All changes additive and documented.
- **No new runtime dependencies.**
- **No files were modified during this audit.** Implementation has not started. Awaiting approval of this plan (and the §13 decisions) before beginning 5.1.
