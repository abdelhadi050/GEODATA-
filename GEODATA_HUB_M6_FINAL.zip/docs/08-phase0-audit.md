# GEODATA HUB — Phase 0: Project Audit & Implementation Preparation

**Date:** 2026-11-21 · **Status:** Complete — presented for approval before any implementation. This document is **additive**; docs 01–07 are unchanged and remain the authoritative architecture.

---

## A. Current project state (verified by inspection)

| Area | State |
|---|---|
| Application code | **Scaffold only.** No GEODATA HUB modules exist yet — docs 01–07 are the approved plan; code has not started (as agreed in Phase 1). |
| Documentation | `docs/01…07` + ERD (`erd.png`, `erd.mmd`) intact; verified unchanged. |
| Database | SQLite `db/custom.db` in scaffold state — only demo `User`/`Post` tables (verified via sqlite_master). |
| Dependencies | Present: next 16.1.1, react 19, next-auth 4.24.11, zod 4, react-hook-form + resolvers, TanStack Table/Query, zustand, recharts, full shadcn/ui set. **Missing:** `leaflet`, `react-leaflet`, `@types/leaflet`, `bcryptjs`, `@types/bcryptjs`. |
| Environment vars | `.env` contains only `DATABASE_URL`. `NEXTAUTH_SECRET`, `NEXTAUTH_URL` absent. No `.env.example`. |
| Dev server | Currently **down** (sandbox recycled between sessions — expected). Platform runner `.zscripts/dev.sh` (inspected) performs `bun install` → `db:push` → `bun run dev` → health check → mini-services automatically. To be re-verified at Milestone 1. |
| Quality config | **Findings:** `tsconfig.json` has `strict: true` but `noImplicitAny: false` (weakens strict mode); `next.config.ts` has `typescript.ignoreBuildErrors: true` and `reactStrictMode: false`. All three conflict with the "TypeScript 5 strict mode" and quality requirements. |
| Branding | Root layout/page/API route carry Z.ai scaffold branding and demo content; `public/logo.svg` is the scaffold logo. |

## B. Existing files and components that can be reused (no recreation)

| Asset | Reuse plan |
|---|---|
| `src/components/ui/*` (≈50 shadcn New York components) | Reuse 100%. Key ones: `sidebar.tsx` (premium app shell base), `chart.tsx` (Recharts theming wrapper), `form.tsx` (react-hook-form wiring), `table.tsx`, `dialog/sheet/drawer` (forms + mobile nav), `command.tsx` (search), `sonner`/`toaster` (feedback), `alert-dialog` (confirmations), `calendar` (date pickers), `badge/card/skeleton/empty` primitives |
| `src/hooks/use-toast.ts`, `use-mobile.ts` | Reuse as-is (use-mobile drives responsive sidebar) |
| `src/lib/db.ts` | Reuse (Prisma singleton). Minor: reduce `log: ['query']` noise in development |
| `src/lib/utils.ts` (`cn`) | Reuse as-is |
| `src/app/globals.css` | Reuse structure (Tailwind 4 `@theme inline`, oklch tokens, `.dark` variant, sidebar + chart variables). **Re-theme:** primary/accent/ring/chart/sidebar tokens → emerald/teal identity; values only, no structural change |
| `src/app/layout.tsx` | Reuse structure (Geist fonts, Toaster mount). **Rebrand** metadata to GEODATA HUB |
| `prisma/` setup, `db/` folder, `.env`, bun db scripts | Reuse; schema content replaced (see §E) |
| `components.json`, `tsconfig.json`, `eslint.config.mjs`, `postcss.config.mjs`, `Caddyfile`, `bun.lock` | Reuse (tsconfig/next.config get the §E fixes) |
| `tailwind.config.ts` | **Vestigial** under Tailwind 4 (CSS-first config in `globals.css` is authoritative; the JS config is not loaded). Kept untouched (no-deletion rule); noted as inert |
| `.zscripts/dev.sh` | Platform runner — reuse as-is (handles dev lifecycle incl. automatic `db:push`) |
| `examples/websocket/` | Reference only (future real-time); not used in MVP |
| `tests/*.sh` | Sandbox runtime checks; unrelated to app; untouched |

## C. Missing or incomplete modules (the build list)

1. **Auth & security core:** `lib/auth.ts` (NextAuth config, DB-fresh session loader), `lib/rbac.ts`, `lib/api-utils.ts` (session → RBAC → Zod → error envelope), `/api/auth/[...nextauth]`.
2. **Domain layer:** `lib/validation/*` (all entity schemas + 12-type lab-test result registry), `lib/services/*` (tenant-scoped logic + share-aware access resolver + activity logging), `lib/constants.ts`.
3. **API surface:** ~20 route handler groups from architecture §7 (projects, boreholes, layers, samples, lab-tests, documents, sharing, team, reports, map, dashboard, activity, health).
4. **UI:** login page; `(app)` shell (sidebar, topbar, breadcrumbs, user menu); pages for dashboard, projects, boreholes, samples, lab tests, map, documents, sharing, team, reports; `print/` report views.
5. **Components to build:** `layout/`, `shared/` (page-header, status-badge, stat-card, empty-state, confirm-dialog, data-toolbar), `data-table/` (generic search/sort/filter/pagination), `forms/` (7 entity forms), `map/` (Leaflet island), `charts/` (8 visualizations), `stratigraphy/` (borehole log column).
6. **Data:** full 11-model schema + `prisma/seed.ts` (2 orgs, 6 users, 5 projects, ~30 boreholes, layers, samples, ~60+ tests, documents, shares, activity); `storage/uploads/` private folder; document streaming with path-traversal protection.
7. **Config gaps:** `.env` additions + `.env.example`; tsconfig/next.config fixes; branding (metadata, logo, favicon); `package.json` name → `geodata-hub` (cosmetic).

## D. Architecture & database inconsistencies found

| # | Inconsistency | Severity |
|---|---|---|
| D1 | `prisma/schema.prisma` holds demo `User`/`Post` vs. the approved 11-model design (docs 03). Expected gap — code never started. Replacement was pre-announced in doc 01 §1. | Blocking (must resolve in M2) |
| D2 | **New requirement vs docs:** Proctor + CBR tests are now required. Doc 03 defines 10 test types; the set must grow to 12 with result schemas + 2 new visualizations. Docs 01–07 are **not modified** (no-overwrite rule); this doc records the addendum (§E.2). | Additive scope |
| D3 | **Security refinement vs doc 02 §5:** docs specify JWT carrying `role` (stateless). New requirement §5: deactivated users and changed permissions must not ride stale tokens. Refinement: JWT = identity only; **authoritative role + `isActive` fetched fresh from DB on every request** (one indexed query) in `api-utils` and the `(app)` layout. Documented deviation, not silent. | High priority design fix |
| D4 | `tsconfig.json` `noImplicitAny: false` contradicts "TypeScript 5 strict mode". | Config fix |
| D5 | `next.config.ts` `ignoreBuildErrors: true` + `reactStrictMode: false` contradict quality rules and React 19 best practice (strict mode also forces Leaflet effects to be cleanup-safe). | Config fix |
| D6 | `.env` missing `NEXTAUTH_SECRET`/`NEXTAUTH_URL` (auth cannot run). No `.env.example` (secret-handling documentation gap). | Blocking for M1 |
| D7 | Scaffold branding in `layout.tsx`, `page.tsx`, `api/route.ts`, logo. | Cosmetic/branding |
| D8 | Migration strategy nuance: platform runner executes `db:push --accept-data-loss` on each start. Mixing `prisma migrate dev` with `db:push` on the same SQLite file causes drift. Resolution: sandbox uses `db:push` exclusively; the PostgreSQL migration history is generated with `prisma migrate diff --from-empty --to-schema-datamodel …` (deterministic, no drift). | Process clarification |
| D9 | `db.ts` logs every query — noisy `dev.log`, slows hot paths. | Minor |
| D10 | NextAuth v4 behind the preview proxy: CSRF/origin validation must be smoke-tested against the browser-facing origin (folded into R1 smoke test, M1). | Risk to retire early |

## E. Required modifications and justification (announced before applying — per rules)

### E.1 Database schema (applied in M2, not before)

1. **Replace demo `User`/`Post` with the 11 approved models** from doc 03 §4, verbatim except the changes below. *Justification: they are sandbox boilerplate, not user work; announced in doc 01 §1 and required by the approved design. The database file is not deleted — `db:push` migrates it; any demo rows are worthless scaffold rows.*
2. **Extend `LabTest.testType` value set:** + `PROCTOR`, `CBR` (12 total). *Justification: new functional requirement §4. Value lives in `String` + Zod registry, so this is a constants/validation change — no column-type change.*
3. **New result schemas (Zod registry, doc 03 addendum):**
   - `PROCTOR`: `{ method: 'STANDARD' | 'MODIFIED', points: [{ moistureContent %, dryDensity Mg/m³ }] (≥3), maxDryDensity, optimumMoisture }` → visualization: moisture–density compaction curve with optimum point marker.
   - `CBR`: `{ condition: 'SOAKED' | 'UNSOAKED', points: [{ penetrationMm, loadKn }] (≥2), cbrAt2_5, cbrAt5_0, cbrValue, swellPct? }` → visualization: load–penetration curve with 2.5/5.0 mm reference lines and result card.
4. **No other model changes.** `User` needs no schema change for D3 (staleness is handled at runtime).
5. Migration history for PostgreSQL produced via `prisma migrate diff` (see D8).

### E.2 Configuration (applied in M1)

| Change | File | Justification |
|---|---|---|
| `noImplicitAny: true` | tsconfig.json | Honor "TypeScript 5 strict mode" (D4) |
| Remove `typescript.ignoreBuildErrors`, set `reactStrictMode: true` | next.config.ts | Quality gates + React 19 correctness (D5) |
| Add `NEXTAUTH_SECRET` (generated, never printed), `NEXTAUTH_URL`; create `.env.example` with SQLite + PostgreSQL templates | .env / .env.example | Auth cannot run without it; secret-handling documentation (D6). No secrets hardcoded |
| Rebrand metadata/title/description; GEODATA HUB logo + favicon | layout.tsx, public/ | Product identity (D7) |
| Query log → `['error','warn']` | lib/db.ts | Reduce noise/overhead (D9) |
| Rename package to `geodata-hub` | package.json | Identity (cosmetic, no functional effect) |

### E.3 Security implementation commitments (M1–M3)

- `organizationId` derived **only** from the session (never client input) — enforced in `api-utils` + services.
- **DB-fresh authorization** on every request (D3): identity from JWT; `role`/`isActive` re-read from DB; 401/403 on mismatch or deactivation.
- Documents: stored under `storage/uploads` with generated names (UUID), original filename kept in metadata only; downloads stream through a permission-checked handler with `Content-Disposition`; **path traversal prevented** by resolving and prefix-checking the real path against the storage root; MIME allow-list + 10 MB cap enforced server-side; folder never under `public/`.
- Cross-org reads only through `SharingRequest` with status APPROVED and non-expired `expiresAt`.

## F. Detailed implementation roadmap (dependency-ordered)

```
M1 Foundation & Auth Shell ──► M2 Data Layer ──► M3 API Layer ──► M4 Core UI ──► M5 Lab Tests & Viz ──► M6 GIS ──► M7 Collab & Docs ──► M8 Hardening & Delivery
        (Phase 2)                (Phase 3a)        (Phase 3b)      (Phase 4a)       (Phase 4b)          (Phase 5)     (Phase 6)             (Phases 7–8)
```

| Milestone | Contents | Depends on | Gate |
|---|---|---|---|
| **M1 Foundation & Auth Shell** | Deps (`bcryptjs`), env + `.env.example`, config fixes (E.2), emerald/teal re-theme, shared components (page-header, status-badge, stat-card, empty-state, confirm-dialog, data-toolbar), constants, `rbac.ts`, NextAuth config + DB-fresh session loader, login page + demo-credentials panel, `(app)` shell, root redirect, bootstrap seed (Organization + User models only, 1 org + 1 admin), providers, `/api/health`. **Retires R1** (NextAuth-on-Next-16 smoke test incl. proxy CSRF) or applies the documented fallback | — | §G below |
| **M2 Data Layer** | Remaining 9 models (E.1), `db:push`, full seed (2 orgs, 6 users, 5 projects, ~30 boreholes, layers, samples, 60+ tests incl. Proctor/CBR, documents, shares, activity), validation schemas + 12-type result registry, services with tenant scoping + share-aware access resolver, activity logging | M1 | seed clean; service-level unit checks pass |
| **M3 API Layer** | `api-utils` wrapper, all ~20 route handler groups, uniform error envelope, document upload/download streaming with security rules | M2 | scripted tests: CRUD per entity, auth, RBAC matrix, tenant isolation matrix, sharing lifecycle — all green |
| **M4 Core UI** | Dashboard (KPIs, activity), projects module (list/create/edit/detail/delete/boundary), boreholes module (list/create/edit/detail), layers CRUD, samples CRUD + lab status workflow | M3 | browser-verified CRUD per role; validation UX; empty/loading states |
| **M5 Lab Tests & Visualization** | Tests module (list, create, result entry per type), 8 chart components (grain-size semi-log, Atterberg + A-line, moisture/SPT/UCS/triaxial profiles, **Proctor curve**, **CBR curve**), stratigraphy log column | M4 | charts render seeded data correctly; per-type result forms validate |
| **M6 GIS** | Leaflet island (client-only), status-colored markers, boundary polygons, selection panel + popups, map filters, basemap/zoom/fit controls | M2 (map API), M4 (detail links) | browser-verified map interactions; no SSR/hydration errors |
| **M7 Collaboration & Documents** | Sharing workflow UI (create/inbox/approve/reject/revoke), team management (roles, deactivate, simulated invite), documents UI, reports + print views | M3, M4 | end-to-end cross-org sharing in browser; upload/download per role; clean print output |
| **M8 Hardening & Delivery** | `tsc`/lint/db validation, scripted regression suites, agent-browser workflow regression, UI polish, responsiveness audit, demo-credentials panel, README + install instructions + deployment guide (PostgreSQL switch, S3/email evolution) | M1–M7 | all gates green; definition of done (doc 07 Phase 8) |

Deviations from doc 07 (both additive, not structural): M1 includes a **bootstrap seed** (1 org + 1 admin) so login is genuinely testable before the full seed; lab tests are split M5 (visualization depth) to keep milestones verifiable. Phases otherwise map 1:1.

## G. First implementation milestone — M1 and its acceptance tests

**Scope:** Foundation & Authenticated Shell (see roadmap table). No feature modules; no dead buttons (sidebar shows only functional destinations plus a muted "further modules in upcoming milestones" label).

**Acceptance tests (all must pass; browser items verified with agent-browser):**

1. `bun run lint` → 0 errors; `bunx tsc --noEmit` → 0 errors **with `noImplicitAny: true`**.
2. Dev server running via platform runner; `/api/health` returns 200 JSON.
3. `/` redirects unauthenticated → `/login`; authenticated → `/dashboard`.
4. Login with the bootstrap admin succeeds; wrong password → inline validation error; session cookie is httpOnly.
5. App shell renders: sidebar, topbar, breadcrumbs, user menu, theme toggle; mobile viewport → drawer navigation.
6. Logout destroys the session; subsequent `/dashboard` access redirects to `/login`.
7. **Deactivation security test:** deactivate the bootstrap user directly in DB → next authenticated request is rejected (proves DB-fresh authorization, D3).
8. Dark/light themes render correctly with the emerald/teal token set.
9. No runtime/hydration errors in `dev.log` during all flows; agent-browser confirms renders and interactions.
10. **R1 verdict recorded:** NextAuth v4 works on Next.js 16 behind the preview proxy (incl. CSRF/origin), **or** the pre-approved fallback (custom cookie-session auth, same `lib/auth.ts` interface) is applied and documented in this file's successor note.

Upon your approval of this report, implementation begins with M1.
