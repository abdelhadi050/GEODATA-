# GEODATA HUB — Phase 1: Folder Structure (proposed)

**Status:** Proposed — awaiting approval. Directories are created incrementally as each phase's code lands (empty folders are not created in advance). Existing scaffold folders (`src/components/ui`, `src/hooks`, `prisma`, ...) are kept and extended — nothing is deleted.

```
/home/z/my-project/
├── docs/                          # Technical documentation (this set)
│   ├── 01-environment-audit.md
│   ├── 02-architecture.md
│   ├── 03-database-design.md      # + erd.mmd / erd.png
│   ├── 04-folder-structure.md
│   ├── 05-mvp-scope.md
│   ├── 06-risks.md
│   └── 07-implementation-plan.md
├── prisma/
│   ├── schema.prisma              # 11 models (Phase 3)
│   └── seed.ts                    # Fictional demonstration data (Phase 3)
├── db/
│   └── custom.db                  # SQLite database (sandbox runtime)
├── storage/
│   └── uploads/                   # Private document storage (never under public/)
├── scripts/                       # Dev/test scripts (probe, verification suites)
├── public/                        # Static assets only (logo, icons)
├── src/
│   ├── app/
│   │   ├── layout.tsx             # Root layout: ThemeProvider, fonts, Toaster
│   │   ├── page.tsx               # Entry: session-aware redirect (/dashboard | /login)
│   │   ├── globals.css            # Tailwind 4 tokens, design-system CSS vars
│   │   ├── login/
│   │   │   └── page.tsx           # Login + demo credentials panel
│   │   ├── (app)/                 # Authenticated shell (sidebar + topbar layout)
│   │   │   ├── layout.tsx         # Server-side session guard + AppShell
│   │   │   ├── dashboard/page.tsx
│   │   │   ├── projects/
│   │   │   │   ├── page.tsx       # List: search / filter / sort / paginate
│   │   │   │   ├── new/page.tsx
│   │   │   │   └── [id]/
│   │   │   │       ├── page.tsx   # Overview, boreholes, documents, shares, reports
│   │   │   │       ├── edit/page.tsx
│   │   │   │       └── settings/page.tsx   # Boundary editor + danger zone (admin)
│   │   │   ├── boreholes/
│   │   │   │   ├── page.tsx       # Cross-project list with map preview link
│   │   │   │   └── [id]/page.tsx  # Detail: stratigraphy log, samples, tests, docs
│   │   │   ├── samples/page.tsx   # List + lab status workflow
│   │   │   ├── lab-tests/
│   │   │   │   ├── page.tsx       # List + result status
│   │   │   │   └── [id]/page.tsx  # Result entry + visualization
│   │   │   ├── map/page.tsx       # GIS page (Leaflet client island)
│   │   │   ├── documents/page.tsx # Document manager (upload/download/delete)
│   │   │   ├── sharing/page.tsx   # Sent requests + inbox (approve/reject/revoke)
│   │   │   ├── team/page.tsx      # Members, roles, add user (simulated invite)
│   │   │   └── reports/page.tsx   # Report records + print views
│   │   ├── print/                 # Print-optimized report routes (no app chrome)
│   │   │   └── borehole-log/[id]/page.tsx
│   │   └── api/                   # Route handlers (see architecture §7)
│   │       ├── auth/[...nextauth]/route.ts
│   │       ├── projects/...  boreholes/...  layers/...  samples/...
│   │       ├── lab-tests/...  documents/...  sharing/...  team/...
│   │       ├── reports/...  map/...  dashboard/...  activity/...
│   │       └── health/route.ts
│   ├── components/
│   │   ├── ui/                    # shadcn/ui (existing, untouched)
│   │   ├── layout/                # app-sidebar, topbar, breadcrumbs, user-menu,
│   │   │                          #   role-guarded-action helpers
│   │   ├── shared/                # page-header, stat-card, status-badge,
│   │   │                          #   empty-state, confirm-dialog, data-toolbar
│   │   ├── data-table/            # Generic TanStack Table wrapper:
│   │   │                          #   search, column sort, faceted filters, pagination,
│   │   │                          #   mobile card layout
│   │   ├── forms/                 # Entity forms (project, borehole, layer, sample,
│   │   │                          #   lab-test result, document, sharing, team)
│   │   ├── map/                   # map-view (client-only dynamic), borehole-marker,
│   │   │                          #   boundary-layer, map-filters, selection-panel
│   │   ├── charts/                # grain-size-curve, atterberg-chart,
│   │   │                          #   depth-profile, test-summary-charts
│   │   └── stratigraphy/          # Borehole log column (HTML/CSS depth-scaled)
│   ├── lib/
│   │   ├── db.ts                  # Prisma client singleton (existing)
│   │   ├── auth.ts                # NextAuth config + session helpers
│   │   ├── rbac.ts                # Role matrix: can(role, action, resource)
│   │   ├── api-utils.ts           # handler wrapper: auth → rbac → zod → error envelope
│   │   ├── constants.ts           # Value sets (statuses, types), label maps, colors
│   │   ├── utils.ts               # Existing helpers (cn, ...)
│   │   ├── validation/            # Zod schemas per entity + lab-test result registry
│   │   └── services/              # Tenant-scoped business logic (one file per domain):
│   │       ├── projects.ts  boreholes.ts  layers.ts  samples.ts
│   │       ├── lab-tests.ts documents.ts  sharing.ts team.ts
│   │       ├── reports.ts   activity.ts   dashboard.ts  map.ts
│   │       └── access.ts           # Resolves accessible projects incl. approved shares
│   ├── hooks/                     # use-toast, use-mobile (existing) + use-debounce,
│   │                              #   use-map-selection, use-entities (TanStack Query)
│   ├── providers/                 # query-provider, theme-provider, session-provider
│   └── types/                     # Shared DTO types derived from Zod schemas
├── .env                           # DATABASE_URL, NEXTAUTH_SECRET, NEXTAUTH_URL (never committed in production)
├── .env.example                   # Template with both SQLite and PostgreSQL examples
├── Caddyfile                      # Gateway (existing, untouched)
└── package.json                   # bun scripts: dev, lint, db:push, db:migrate, seed
```

**Rules applied**

- Feature-first organization inside a single Next.js app; no speculative abstraction.
- Every module has one responsibility: `validation` = shapes, `services` = logic + tenancy, `api` = transport, `components` = presentation.
- The print routes live outside the `(app)` shell so report printouts have no navigation chrome.
- `storage/uploads` is private: downloads stream through `/api/documents/[id]` after permission checks.
