# GEODATA HUB — Phase 1: Technical Risks & Dependencies

**Status:** Proposed — awaiting approval. Each risk has an owner phase where it is retired.

---

## 1. Risk register

| # | Risk | L | I | Mitigation (and where it is retired) |
|---|---|---|---|---|
| R1 | **NextAuth v4 on Next.js 16** — v4 predates Next 16; potential App Router edge cases (async `headers()`, route handler signature) | M | H | Smoke-test credentials login immediately in Phase 3 before building on it. **Fallback (prepared):** replace with a ~150-line custom session-cookie auth (bcrypt + signed httpOnly JWT) using the same `lib/auth.ts` interface — service/UI code unaffected |
| R2 | **react-leaflet v5 with React 19** — newer major; SSR incompatibilities | M | M | Load map with `next/dynamic` + `ssr: false`; verify in Phase 5 first hour. **Fallback:** drop react-leaflet, drive Leaflet directly in a `useEffect` client component (same UX, zero dependency on wrapper maturity) |
| R3 | **Leaflet default marker icons break in bundlers** (missing asset paths) | H | L | Use custom `divIcon` markers from day one — no default icon assets referenced |
| R4 | **SQLite limitations** — no Prisma `enum`/scalar lists; single-writer concurrency | C | L | Already designed around: String + Zod value sets (portable); demo write load is trivial; PostgreSQL switch documented (`03-database-design.md` §5) |
| R5 | **`Json` fields on SQLite** | — | — | **Retired in Phase 1** — verified by probe (DDL + GeoJSON round-trip OK, Prisma 6.19.2) |
| R6 | **Tailwind 4 CSS-first config** differs from v3 habits (no `tailwind.config` content array; `@theme` tokens) | M | L | Scaffold already provides working tokens + shadcn variables; only additive changes in `globals.css` (Phase 2) |
| R7 | **Next.js 16 async `params`/`searchParams`** — must `await` in pages/handlers | H | L | Coding convention from Phase 2: every dynamic route awaits params; caught by `tsc --noEmit` + lint each phase |
| R8 | **Multi-route serving through the preview gateway** — preview panel opens `/`; deep-link behavior to be confirmed | L | M | Caddy proxies all paths (audited); root page is a smart redirect; full navigation verified with agent-browser in Phase 2 gate; worst case: client-side navigation still works from `/` |
| R9 | **Map tiles need internet from the user's browser** (OSM/Esri CDNs) | M | L | Documented requirement; graceful degradation: map area shows tiles-off overlay with data layers still functional |
| R10 | **Upload body limits / disk (4 GB RAM, container disk)** | L | M | 10 MB per-file demo cap + type allow-list; storage directory isolated for future S3 swap |
| R11 | **Scope creep / prototype bloat** | M | H | Phase gates with browser-verified checklists; simulated list (scope doc §2) is fixed — anything beyond it needs explicit approval |
| R12 | **Seed data realism** (stratigraphy, lab values must look professional) | L | M | Seed script authored once in Phase 3 with realistic Dutch-style stratigraphy and plausible index-property correlations (e.g., moisture vs. depth trends in soft clay) |
| R13 | **4 GB RAM dev box** — Turbopack + Prisma + browser tests together | L | M | Keep dependency set lean; no parallel mini-services in MVP; agent-browser checks run sequentially |

L = likelihood, I = impact (H/M/L, C = certain). R4/R5 are facts, not risks, thanks to Phase 1 probes.

## 2. New dependencies to install (Phase 2/5)

| Package | Purpose | Notes |
|---|---|---|
| `leaflet` | GIS engine | Industry standard |
| `react-leaflet@^5` | React 19 bindings | See R2 fallback |
| `@types/leaflet` | Types | devDependency |
| `bcryptjs` + `@types/bcryptjs` | Password hashing | Pure JS — no native build step |

Everything else required is already installed (see `01-environment-audit.md` §3). No other additions are planned — the preinstalled stack covers forms, tables, charts, state, and theming.

## 3. External service dependencies

| Service | Prototype use | Production path |
|---|---|---|
| OpenStreetMap tiles | Basemap (attribution displayed) | Keep or self-host tiles |
| Esri World Imagery tiles (optional toggle) | Satellite view | Verify license terms before production use |
| None else | — | Email provider, object storage, PostgreSQL listed as production evolution paths only |
