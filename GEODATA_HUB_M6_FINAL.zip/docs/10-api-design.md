# GEODATA HUB — API Design (M3)

**Status:** Implemented and tested (M3) · **Applies to:** `src/app/api/**`, `src/lib/api/**`
**Prerequisites:** M1 (auth shell) and M2 (schema, services, validation, seed) — unchanged.

---

## 1. Architecture

```
Client (browser / future integrations)
  │  HTTPS (session cookie, SameSite=Lax, HttpOnly)
  ▼
Next.js App Router route handlers  (src/app/api/**/route.ts)
  │   every handler wrapped in withApi():
  │     – same-origin check on unsafe methods (CSRF defense in depth)
  │     – uniform error envelope (never leaks internals)
  │     – safe access log (method, path, status)
  ▼
API guard layer  (src/lib/api/**)
  │   requireUser()          → DB-fresh session (role/isActive re-read per request)
  │   requireCapability()    → RBAC matrix guard (fast-fail)
  │   parseJsonBody/Query()  → Zod, STRICT schemas, normalized 400s
  │   requireId()            → route id format validation
  ▼
M2 domain services  (src/lib/services/** — unchanged)
  │   tenant scoping · parent-child validation · share boundaries
  │   lab-result registry validation · activity logging
  ▼
Prisma (SQLite dev / PostgreSQL production target)
```

Rules the layer enforces end-to-end:

1. **Organization identity is never client input.** It derives from the session → DB-fresh user record. An `organizationId` key in a body is rejected by the strict schemas before any service runs (tested).
2. **Every handler is thin.** Business logic lives in the M2 services; routes parse, guard, call, and shape the response. No logic was duplicated.
3. **Foreign or inaccessible resources are `404 NOT_FOUND`** — existence is never leaked, matching the M2 service contracts.

### Shared utilities (`src/lib/api/`)

| File | Responsibility |
| --- | --- |
| `api-response.ts` | `apiSuccess(data, {status, meta})`, `apiError(code, message, status, details?)`, `listMeta()`; sets `Cache-Control: private, no-store` + `X-Content-Type-Options: nosniff` on every response |
| `api-errors.ts` | `handleApiError()`: `AppError` → its status/code; Prisma `P2002` → 409, `P2025` → 404; everything else → generic 500 `INTERNAL_ERROR` (details only in server logs) |
| `api-auth.ts` | `requireUser()` (401 when no active session), `requireCapability(user, cap)` (403) |
| `api-validation.ts` | `parseJsonBody()` (malformed JSON → 400), `parseQuery()` (string coercion), `requireId()` (bad id format → 400), `assertSameOrigin()` (403 `CROSS_ORIGIN_REJECTED`) |
| `api-utils.ts` | `withApi()` wrapper, `omit()` response helper |
| `schemas.ts` | All route-level Zod schemas: STRICT bodies (unknown keys → 400), bounded queries (page ≤ 10 000, per-domain pageSize caps) |

---

## 2. Response envelope

Success:

```json
{
  "success": true,
  "data": { "…": "…" },
  "meta": { "page": 1, "pageSize": 20, "total": 42, "totalPages": 3 }
}
```

`meta` is optional; list endpoints always include the pagination meta above (array endpoints use `meta.total` only).

Failure:

```json
{
  "success": false,
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "code — Code must use uppercase letters, digits, dashes or underscores",
    "details": [{ "path": "code", "message": "…" }]
  }
}
```

### Error codes and HTTP status mapping

| HTTP | `error.code` | Source |
| --- | --- | --- |
| 400 | `VALIDATION_ERROR` | Zod body/query/id validation, malformed JSON/multipart, service validation rules (overlap, depth, parent mismatch…) |
| 401 | `UNAUTHENTICATED` | No session, or session user deactivated (DB-fresh check) |
| 403 | `FORBIDDEN` | RBAC capability missing, or boundary violation (deciding another org's request, revoking a share you don't own) |
| 403 | `CROSS_ORIGIN_REJECTED` | Unsafe method with foreign `Origin` header (CSRF defense in depth) |
| 404 | `NOT_FOUND` | Unknown id, foreign-tenant resource, inaccessible-via-share resource |
| 409 | `CONFLICT` | Duplicate scoped codes (project/borehole/sample/lab-test), duplicate or state-conflicting share operations |
| 413 | `PAYLOAD_TOO_LARGE` | Upload over 10 MB (post-parse; pathological ≥50 MB bodies rejected on `Content-Length`) |
| 415 | `UNSUPPORTED_MEDIA_TYPE` | MIME not in allowlist, or magic bytes disagree with declared type |
| 500 | `INTERNAL_ERROR` | Unexpected — generic message, details server-side only |
| 503 | `SERVICE_UNAVAILABLE` | Health probe with unreachable DB |

Conventions:

- **Bad id format → 400; well-formed but unknown/inaccessible id → 404.**
- `DELETE` returns `200` with `{ deleted: true }` (uniform envelope rather than 204).
- Unknown routes under `/api/**` fall through to Next.js's default 404 (not enveloped) — known limitation.

### Request-body strictness

Bodies are parsed with **strict** variants of the M2 schemas: unknown keys (including any attempted `organizationId` smuggle) are rejected with `VALIDATION_ERROR` instead of being silently stripped. Query strings are strict as well (unknown parameters → 400).

---

## 3. Authentication & authorization

- **Authentication:** NextAuth v4 credentials session (JWT, 30 d). `requireUser()` calls `getSessionUser()` which re-reads `role`/`isActive` from the DB on **every** request — deactivation and role changes take effect immediately (tested: deactivated viewer → next request 401; reactivation → session valid again).
- **Authorization:** the 22-capability RBAC matrix from M1 (`src/lib/rbac.ts`). Route-level guards fast-fail; services keep their own checks (defense in depth). Role → capability examples (all verified by tests): only PM+ create projects and manage sharing; ORG_ADMIN deletes projects and manages the team; ENGINEER manages boreholes/layers/samples/lab results but not projects; VIEWER is read-only plus document download.
- **CSRF:** the session cookie is `SameSite=Lax` + `HttpOnly` (primary barrier, verified in M1). `withApi` additionally rejects `POST/PUT/PATCH/DELETE` whose `Origin` header mismatches the request host (`X-Forwarded-Host` aware for the proxy). Non-browser clients without `Origin` are unaffected.
- **Caching:** every API response carries `Cache-Control: private, no-store` + `nosniff` — private tenant data is never cacheable.
- **Logs:** `[api] METHOD path → status` access lines and server-side-only error summaries; request bodies, credentials, and storage paths are never logged.

---

## 4. Endpoint inventory

Base path `/api`. All endpoints except `/api/health` and NextAuth's own `/api/auth/*` require an authenticated session.

### Diagnostics

| Method & path | Capability | Notes |
| --- | --- | --- |
| `GET /health` | — | Enveloped liveness + DB probe; unauthenticated |

### Organizations & users

| Method & path | Capability | Notes |
| --- | --- | --- |
| `GET /organizations/current` | authenticated | Actor's own org; no org listing, no org deletion (§7) |
| `GET /users?search=` | `TEAM_VIEW` | Own-org directory; safe fields only (never password hashes) |
| `PATCH /users/[id]/role` | `TEAM_MANAGE` | Body `{ role }`; validated against ALL_ROLES; own role change → 400; foreign user → 404 |
| `PATCH /users/[id]/status` | `TEAM_MANAGE` | Body `{ isActive }`; self-deactivation → 400; last-active-admin → 409 |

### Projects

| Method & path | Capability | Notes |
| --- | --- | --- |
| `GET /projects` | `PROJECT_VIEW` | Own + actively shared; filters `search,status,sortBy,sortOrder,page,pageSize` (cap 100) |
| `POST /projects` | `PROJECT_CREATE` | 201; `organizationId` derived from session |
| `GET /projects/[id]` | `PROJECT_VIEW` | Detail + boreholes/documents/reports/shares; embedded documents stripped of `filePath` |
| `PATCH /projects/[id]` | `PROJECT_EDIT` | Own-org only (shared → 404) |
| `DELETE /projects/[id]` | `PROJECT_DELETE` | Admin-only; cascade (§7) |
| `PUT /projects/[id]/boundary` | `PROJECT_EDIT` | GeoJSON Polygon (closed rings, `[lon,lat]`) |

### Boreholes & layers

| Method & path | Capability | Notes |
| --- | --- | --- |
| `GET /boreholes` | `BOREHOLE_VIEW` | Filters `projectId,search,type,status,sortBy,sortOrder,page,pageSize` (cap 200) |
| `POST /boreholes` | `BOREHOLE_MANAGE` | Parent project must be own-org |
| `GET /boreholes/[id]` | `BOREHOLE_VIEW` | Layers + samples (with lab tests) + documents (no `filePath`) |
| `PATCH /boreholes/[id]` | `BOREHOLE_MANAGE` | Own-org only |
| `DELETE /boreholes/[id]` | `BOREHOLE_MANAGE` | Cascade layers/samples/tests |
| `GET /boreholes/[id]/layers` | `BOREHOLE_VIEW` | Ordered by depth |
| `POST /layers` | `LAYER_MANAGE` | Overlap + borehole-depth validation |
| `PATCH /layers/[id]` | `LAYER_MANAGE` | Re-runs overlap validation |
| `DELETE /layers/[id]` | `LAYER_MANAGE` | |

### Samples & laboratory tests

| Method & path | Capability | Notes |
| --- | --- | --- |
| `GET /samples` | `SAMPLE_VIEW` | Filters `boreholeId,projectId,type,labStatus,search,page,pageSize` |
| `POST /samples` | `SAMPLE_MANAGE` | Parent borehole own-org; depth checks |
| `GET /samples/[id]` | `SAMPLE_VIEW` | Detail + lab tests |
| `PATCH /samples/[id]` | `SAMPLE_MANAGE` | |
| `DELETE /samples/[id]` | `SAMPLE_MANAGE` | |
| `GET /lab-tests` | `LAB_TEST_VIEW` | Filters `sampleId,boreholeId,projectId,testType,status,search,page,pageSize` |
| `POST /lab-tests` | `LAB_TEST_MANAGE` | One test per (sample, testType) |
| `GET /lab-tests/registry` | authenticated | The 12-type registry (labels, standards, units, chart configs) |
| `GET /lab-tests/[id]` | `LAB_TEST_VIEW` | Embeds registry metadata for rendering |
| `PATCH /lab-tests/[id]` | `LAB_TEST_MANAGE` | Status/notes; re-opening a completed test clears its result |
| `PUT /lab-tests/[id]/result` | `LAB_TEST_RESULT` | Body `{ result, summary? }`; validated per-type by the registry — never arbitrary JSON |
| `DELETE /lab-tests/[id]` | `LAB_TEST_MANAGE` | |

### Documents

| Method & path | Capability | Notes |
| --- | --- | --- |
| `GET /documents` | `PROJECT_VIEW` (service) | Own + shared projects; `filePath` stripped |
| `POST /documents/upload` | `DOCUMENT_MANAGE` | Multipart; see §5 |
| `GET /documents/[id]` | `PROJECT_VIEW` | Metadata; `filePath` stripped |
| `PATCH /documents/[id]` | `DOCUMENT_MANAGE` | Title / docType |
| `DELETE /documents/[id]` | `DOCUMENT_MANAGE` | Removes DB record + best-effort file unlink |
| `GET /documents/[id]/download` | `DOCUMENT_DOWNLOAD` | Streams via §5; own-org or approved share only |

### Sharing

| Method & path | Capability | Notes |
| --- | --- | --- |
| `GET /sharing/requests` | `SHARING_MANAGE` | `{ sent, inbox }` split |
| `POST /sharing/requests` | `SHARING_MANAGE` | Owner org → target org; own org → 400; duplicate active → 409 |
| `POST /sharing/requests/[id]/decision` | `SHARING_DECIDE` | Body `{ decision: "APPROVE" \| "REJECT" }`; target org only; non-pending → 409 |
| `DELETE /sharing/requests/[id]` | `SHARING_MANAGE` | Revoke; owner org only; approved/pending only |
| `GET /sharing/organizations` | `SHARING_MANAGE` | Shareable partner orgs |

Route-level guard note: the M2 `listSharingRequests` service itself performs no capability check; the M3 route adds `SHARING_MANAGE` per the RBAC matrix (sharing administration is a PM+ capability). Engineers/viewers still see shared content through the project/sample/... endpoints.

### Reports & activity

| Method & path | Capability | Notes |
| --- | --- | --- |
| `GET /reports` | `REPORT_VIEW` | Filters `projectId,reportType` |
| `POST /reports` | `REPORT_GENERATE` | Own-org project only |
| `GET /reports/[id]` | `REPORT_VIEW` | |
| `GET /activity?limit=` | authenticated | Own-org feed, newest first, limit ≤ 100 |

---

## 5. Document upload / download security

**Upload** (`POST /api/documents/upload`, multipart form: `file` + `projectId` + `title` + `docType` + optional `boreholeId`, `fileName`, `mimeType`):

1. **Authorize before accepting the file** — `requireUser()` + `DOCUMENT_MANAGE` (viewer upload → 403 without touching the body).
2. **Size:** exact per-file limit 10 MB after parsing (413 with a readable envelope); pathological bodies (≥ 50 MB by `Content-Length`) are rejected before parsing.
3. **Declared type allowlist:** PDF, TXT, CSV, PNG, JPEG, WebP, DOCX, XLSX, ZIP (415 otherwise). Declared MIME is normalized (parameters like `;charset=utf-8` stripped).
4. **Content sniffing:** magic bytes must match the declared family (PDF `%PDF-`, PNG, JPEG, WebP RIFF, ZIP containers). Text types (unsniffable) require the declared type to be text/plain|csv **and** a matching extension. A text file declared as PDF → 415; an executable → 415.
5. **Filename:** validated by the shared safe-filename schema (charset allowlist, no `..`, length ≤ 200) — `../../etc/passwd` → 400. The filename is metadata only.
6. **Storage name:** server-generated `crypto.randomUUID()` + extension derived from the *validated MIME type* (never from the client filename) inside `storage/uploads/` — path traversal is structurally impossible.
7. **Ownership:** the M2 service re-validates project + optional borehole against the actor's organization (foreign project → 404; cross-project borehole → 400) and logs `DOCUMENT_UPLOADED`.
8. **No orphans:** if metadata registration fails after the file was written, the file is unlinked again.
9. **Response:** 201 with metadata; `filePath` is never returned.

**Download** (`GET /api/documents/[id]/download`):

1. Authenticated + `DOCUMENT_DOWNLOAD` on every request.
2. Access = own-organization document **or** approved, non-expired share of the parent project; everything else → 404 (indistinguishable from missing).
3. Path resolved through the hardened `resolveStoragePath()` (traversal outside `storage/uploads` impossible); missing backing file → 404 without any path detail.
4. Response: `Content-Type` from the DB record, `Content-Disposition: attachment; filename="…"` (ASCII-sanitized), `nosniff`, `private, no-store`. No direct storage URL is ever exposed.

---

## 6. Pagination & filtering conventions

- `page` (default 1, ≥ 1, ≤ 10 000) and `pageSize` (default per domain, capped: projects 100, others 200).
- List responses: `data` = items array; `meta` = `{ page, pageSize, total, totalPages }`.
- Filters are domain enums or id references; unknown or malformed values → 400 (strict query schemas). Empty-result filters are valid.
- Unbounded retrieval is impossible: caps are enforced by both the schema and the service clamps.

Example:

```
GET /api/projects?status=ACTIVE&page=2&pageSize=2&sortBy=name&sortOrder=asc
→ 200 { success: true,
        data: [ …2 items… ],
        meta: { page: 2, pageSize: 2, total: 3, totalPages: 2 } }
```

---

## 7. Organization deletion & audit preservation (review)

Before exposing any `DELETE`, the cascade behavior was reviewed against `prisma/schema.prisma`:

- `Organization` deletion would cascade **users**, **projects** (and their entire chain), and — critically — **ActivityLog** (`onDelete: Cascade`), silently erasing the audit trail.
- Therefore **no organization deletion endpoint is exposed** in M3, and none will be until a deactivation/archiving strategy exists. The safe pattern already in place is **user deactivation** (`PATCH /users/[id]/status`) — reversible, audit-preserving, immediate effect via DB-fresh sessions.
- No schema change was made for this in M3 (an `Organization.isActive` flag is a documented candidate for a future milestone — it would be additive and requires no destructive migration).
- `DELETE /projects/[id]` (admin-only) intentionally cascades the project chain; the deletion itself is recorded in the activity log first. Known limitation: cascade deletion does not unlink stored document files (only `DELETE /documents/[id]` does) — an administrative cleanup job is a future milestone item.

---

## 8. Test results (executed, not asserted)

Run via `scripts/m3-run-all.sh` against a live dev server with the freshly seeded demo DB (full log preserved in the milestone report):

| Suite | Result |
| --- | --- |
| `bunx tsc --noEmit` | PASS (0 errors) |
| `bun run lint` | PASS (0 errors) |
| Seed (`bun run db:seed`) | PASS (2 orgs, 6 users, 6 projects, 26 boreholes, 83 layers, 42 samples, 66 lab tests, 6 documents, 4 shares, 3 reports, 15 activity entries) |
| M2 regression — lab-test registry | 40/40 PASS |
| M2 regression — service layer | 50/50 PASS |
| **M3 API integration** (`scripts/m3-test-api.ts`, 15 suites) | **175/175 PASS** |
| M1 regression — browser auth | 13/13 PASS |

M3 suite coverage by area: envelope/health/cache (3), unauthenticated (8), authentication (9), pagination/filtering/query validation (11), project CRUD+RBAC+validation (16), tenant isolation + all four share states incl. expiry (19), sharing lifecycle (17), boreholes/layers/samples/lab-tests (31), document upload/download security (21), reports (6), team management (14), activity logging (9), CSRF (3), 404-vs-400 + cascade (6), cross-suite invariants — envelope shape on every error response and leak scan for storage paths / hashes / Prisma internals / secrets (15).

Selected proof points: cross-tenant PATCH/DELETE/POST on a *shared* project → 404 (read-only sharing); pending/rejected/revoked/expired shares → 404; `organizationId` in body → 400 (spoof); 11 MB and 15 MB uploads → 413; text-declared-as-PDF and executables → 415; `../../etc/passwd` filename → 400; deactivated user's live session → 401 on next request; foreign-Origin mutation → 403; every error response matched the standard envelope; zero internal-path/internal-error leaks in any response.

---

## 9. Known limitations

1. **Next.js default 404s** for unknown `/api/*` paths are not enveloped (framework behavior; only handled routes are).
2. **Project cascade deletion does not unlink stored files** (only per-document DELETE does). Cleanup job deferred.
3. **No organization deactivation flag** exists yet; org deletion is therefore simply not exposed (§7).
4. **Team-management mutations are not activity-logged** — the M2 activity vocabulary (`ACTIVITY_ACTIONS`) has no team events; extending it was out of M3 scope (would be additive).
5. **Upload buffering:** bodies under 50 MB are parsed into memory before the size check (bounded and acceptable at the 10 MB demo cap; a production deployment should enforce body limits at the reverse proxy).
6. **Sharing list requires SHARING_MANAGE** at the route level (per the RBAC matrix) although the underlying M2 service list call itself is unchecked — a deliberate M3 authorization decision, documented in §4.
7. **Rate limiting** is not implemented (no brute-force protection beyond NextAuth's credential flow); recommended at the proxy before production.
8. Lab-test **input schemas** (planned test parameters) are validated by the registry helpers but no dedicated M3 endpoint records them yet; they arrive with the test-definition flow in a later milestone.

---

## 10. Quick examples

Login is the standard NextAuth credentials flow (`/api/auth/csrf` → `/api/auth/callback/credentials`); all examples assume the session cookie.

```bash
# List active projects (page 2, 20 per page)
curl -b cookies.txt "/api/projects?status=ACTIVE&page=2&pageSize=20"

# Create a project (PM+)
curl -b cookies.txt -X POST /api/projects -H "Content-Type: application/json" \
  -d '{"code":"BLIDA-2026","name":"Blida Ring Road — Geotechnical Study","status":"ACTIVE","latitude":36.47,"longitude":2.83}'

# Record a lab result (structured, registry-validated)
curl -b cookies.txt -X PUT /api/lab-tests/<id>/result -H "Content-Type: application/json" \
  -d '{"result":{"waterContentPercent":18.5,"wetMassG":120.5,"dryMassG":101.6,"containerMassG":45.2},"summary":"w = 18.5%"}'

# Upload a document
curl -b cookies.txt -X POST /api/documents/upload \
  -F "file=@report.pdf" -F "projectId=<id>" -F "title=Site report" -F "docType=REPORT"

# Download a document (streams with attachment headers)
curl -b cookies.txt -o report.pdf /api/documents/<id>/download
```
