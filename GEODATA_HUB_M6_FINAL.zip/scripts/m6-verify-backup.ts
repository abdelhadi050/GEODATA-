/**
 * M6 — database backup integrity verification.
 * Verifies that the backup file is a valid SQLite database with the
 * expected row counts for each table.
 */
import { Database } from "bun:sqlite";
import path from "node:path";

const backupPath = process.argv[2] ?? "/tmp/m6-backup-test.db";
console.log(`Verifying backup: ${backupPath}\n`);

const db = new Database(path.resolve(backupPath), { readonly: true });

const tables = [
  "Organization",
  "User",
  "Project",
  "Borehole",
  "GeologicalLayer",
  "Sample",
  "LabTest",
  "CalculationRecord",
  "ClassificationRecord",
  "Document",
  "SharingRequest",
  "Report",
  "ActivityLog",
];

const counts: Record<string, number> = {};
let totalErrors = 0;
for (const t of tables) {
  try {
    const result = db.query(`SELECT COUNT(*) as n FROM ${t}`).get() as { n: number };
    counts[t] = result.n;
    console.log(`  ${t.padEnd(22)}: ${result.n}`);
  } catch (e) {
    console.log(`  ${t.padEnd(22)}: ERROR — ${(e as Error).message}`);
    totalErrors++;
  }
}

// Integrity check
console.log("\n=== SQLite integrity_check ===");
try {
  const integrity = db.query("PRAGMA integrity_check").all() as Array<{ integrity_check: string }>;
  if (integrity.length === 1 && integrity[0].integrity_check === "ok") {
    console.log("  PASS: integrity_check returned 'ok'");
  } else {
    console.log(`  FAIL: integrity_check returned ${JSON.stringify(integrity)}`);
    totalErrors++;
  }
} catch (e) {
  console.log(`  FAIL: ${(e as Error).message}`);
  totalErrors++;
}

// Foreign-key check
console.log("\n=== SQLite foreign_key_check ===");
try {
  const fk = db.query("PRAGMA foreign_key_check").all();
  if (fk.length === 0) {
    console.log("  PASS: no foreign-key violations");
  } else {
    console.log(`  WARN: ${fk.length} foreign-key violations (SQLite does not enforce FKs by default; Prisma manages referential integrity)`);
  }
} catch (e) {
  console.log(`  FAIL: ${(e as Error).message}`);
  totalErrors++;
}

db.close();

console.log(`\n=== Summary ===`);
console.log(`Tables verified: ${Object.keys(counts).length}/${tables.length}`);
console.log(`Errors: ${totalErrors}`);
process.exit(totalErrors === 0 ? 0 : 1);
