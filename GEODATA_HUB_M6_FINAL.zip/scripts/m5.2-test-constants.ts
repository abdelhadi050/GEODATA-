/**
 * M5.2-a TEST — D8 constants governance enforcement.
 *
 * Covers: VERIFIED retrieval with full provenance, PENDING refusal (the
 * unverified γw constant must be unconsumable), unknown-key refusal, deep
 * runtime immutability, and the inspection/listing API.
 * Exit code = number of failures.
 */
import {
  GOVERNED_CONSTANTS,
  inspectConstant,
  listGovernedConstants,
  requireVerifiedConstant,
} from "../src/lib/calc/constants/sources";

let pass = 0;
let fail = 0;
const ok = (m: string) => { console.log(`PASS: ${m}`); pass++; };
const no = (m: string) => { console.log(`FAIL: ${m}`); fail++; };

// ---------------------------------------------------------------------------
// 1. VERIFIED constants — values and provenance
// ---------------------------------------------------------------------------
{
  const cases: Array<[string, number, string]> = [
    ["si.mass.milligramsPerGram", 1000, "1 g = 1000 mg"],
    ["si.mass.gramsPerKilogram", 1000, "1 kg = 1000 g"],
    ["si.length.millimetresPerCentimetre", 10, "1 cm = 10 mm"],
    ["si.length.millimetresPerMetre", 1000, "1 m = 1000 mm"],
  ];
  for (const [key, expected, label] of cases) {
    const got = requireVerifiedConstant(key);
    if (got === expected) ok(`requireVerifiedConstant('${key}') = ${expected} (${label})`);
    else no(`requireVerifiedConstant('${key}') — got ${got}, expected ${expected}`);
  }
}
{
  const verified = Object.entries(GOVERNED_CONSTANTS).filter(
    ([, c]) => c.status === "VERIFIED",
  );
  const allSourced = verified.every(([, c]) => {
    if (c.status !== "VERIFIED") return false;
    const s = c.source;
    return (
      s.reference.length > 0 &&
      s.location.length > 0 &&
      s.verification.length > 0 &&
      /^\d{4}-\d{2}-\d{2}$/.test(s.verifiedOn)
    );
  });
  if (verified.length === 9 && allSourced) {
    ok(`all ${verified.length} VERIFIED constants carry full provenance (reference/location/method/date)`);
  } else {
    no(`VERIFIED provenance incomplete (${verified.length} verified)`);
  }
}

// ---------------------------------------------------------------------------
// 2. PENDING constants — structurally unconsumable (D8)
// ---------------------------------------------------------------------------
{
  try {
    requireVerifiedConstant("water.unitWeight");
    no("PENDING constant 'water.unitWeight' was consumed — D8 VIOLATION");
  } catch (error) {
    const e = error as { code?: string; message?: string; constantKey?: string; details?: { constantKey?: string; constantStatus?: string } };
    if (
      e.code === "UNVERIFIED_CONSTANT" &&
      e.constantKey === "water.unitWeight" &&
      e.details?.constantStatus === "PENDING" &&
      (e.message ?? "").includes("PENDING")
    ) {
      ok("requireVerifiedConstant('water.unitWeight') — UNVERIFIED_CONSTANT (PENDING refused)");
    } else {
      no(`PENDING refusal wrong shape: ${String(e.code)} / ${String(e.message)}`);
    }
  }
}
{
  const pending = inspectConstant("water.unitWeight");
  if (pending && pending.status === "PENDING" && !("value" in pending)) {
    ok("PENDING constant carries NO value field at the type/structure level");
  } else {
    no("PENDING constant exposes a value or is missing");
  }
}
{
  const pendingCount = listGovernedConstants().filter((e) => e.constant.status === "PENDING").length;
  if (pendingCount === 1) ok("exactly one PENDING constant registered (water.unitWeight)");
  else no(`PENDING count = ${pendingCount}, expected 1`);
}

// ---------------------------------------------------------------------------
// 3. Unknown keys
// ---------------------------------------------------------------------------
{
  try {
    requireVerifiedConstant("gtr.classificationTable");
    no("unknown constant key was consumed");
  } catch (error) {
    const e = error as { code?: string; details?: { constantStatus?: string } };
    if (e.code === "UNVERIFIED_CONSTANT" && e.details?.constantStatus === "UNKNOWN") {
      ok("requireVerifiedConstant('gtr.classificationTable') — UNVERIFIED_CONSTANT (UNKNOWN)");
    } else {
      no(`unknown-key refusal wrong shape: ${String(e.code)}`);
    }
  }
}
if (inspectConstant("does.not.exist") === undefined) {
  ok("inspectConstant of unknown key returns undefined");
} else {
  no("inspectConstant of unknown key returned a value");
}

// ---------------------------------------------------------------------------
// 4. Runtime immutability (deep-frozen registry)
// ---------------------------------------------------------------------------
{
  if (Object.isFrozen(GOVERNED_CONSTANTS)) ok("registry record is frozen");
  else no("registry record is NOT frozen");

  const verifiedEntry = GOVERNED_CONSTANTS["si.mass.gramsPerKilogram"];
  if (verifiedEntry && verifiedEntry.status === "VERIFIED" && Object.isFrozen(verifiedEntry) && Object.isFrozen(verifiedEntry.source)) {
    ok("constant entries and their sources are frozen");
  } else {
    no("constant entries are not deeply frozen");
  }

  // Mutation attempts must not change any value (throws in strict mode ESM).
  let threw = false;
  try {
    (GOVERNED_CONSTANTS["si.mass.gramsPerKilogram"] as { value?: number }).value = 9999;
  } catch {
    threw = true;
  }
  const stillCorrect = requireVerifiedConstant("si.mass.gramsPerKilogram") === 1000;
  if (stillCorrect && (threw || true)) {
    ok(`mutation attempt rejected (threw=${threw}) and value still 1000`);
  } else {
    no("mutation attempt changed a governed constant — D8 VIOLATION");
  }
}

// ---------------------------------------------------------------------------
// 5. Listing API — complete audit snapshot
// ---------------------------------------------------------------------------
{
  // M5.2-d/e/f/g registry growth: the inventory below tracks the governed
  // constants registry as it gains VERIFIED entries (each with its own
  // provenance, checked above). water.unitWeight remains the sole PENDING
  // entry. The four SI factors are M5.2-a; the five later entries were
  // verified and activated by the M5.2-d/e/f/g authorizations.
  const list = listGovernedConstants();
  const keys = list.map((e) => e.key);
  const expectedKeys = [
    "si.mass.milligramsPerGram",
    "si.mass.gramsPerKilogram",
    "si.length.millimetresPerCentimetre",
    "si.length.millimetresPerMetre",
    "water.massDensityMgPerM3",
    "cbr.standardLoadKnAt2_5mm",
    "cbr.standardLoadKnAt5_0mm",
    "consolidation.timeFactorT50",
    "pressuremeter.menardPoissonRatio",
    "water.unitWeight",
  ];
  if (keys.length === expectedKeys.length && expectedKeys.every((k) => keys.includes(k))) {
    ok(`listGovernedConstants returns all ${expectedKeys.length} entries (9 VERIFIED + 1 PENDING)`);
  } else {
    no(`listing incomplete: ${keys.join(", ")}`);
  }
  // The M5.2-d/e/f/g constants must carry the exact verified values the
  // modules consume (any drift is a governance failure).
  const laterValues: Array<[string, number]> = [
    ["water.massDensityMgPerM3", 1],
    ["cbr.standardLoadKnAt2_5mm", 13.24],
    ["cbr.standardLoadKnAt5_0mm", 19.96],
    ["consolidation.timeFactorT50", 0.197],
    ["pressuremeter.menardPoissonRatio", 0.33],
  ];
  for (const [key, expected] of laterValues) {
    const got = requireVerifiedConstant(key);
    if (got === expected) ok(`requireVerifiedConstant('${key}') = ${expected}`);
    else no(`requireVerifiedConstant('${key}') — got ${got}, expected ${expected}`);
  }
}

console.log(`\n================ M5.2-a CONSTANTS TEST SUMMARY: ${pass} passed, ${fail} failed ================`);
process.exit(fail);
