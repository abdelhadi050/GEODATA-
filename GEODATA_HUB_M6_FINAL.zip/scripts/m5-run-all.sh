#!/usr/bin/env bash
# M5.1 full run protocol.
#   Phase 1: static checks → seed → M2 regressions → M5.1 registry/services
#            suites → M3 API regression (live server) → M1 browser regression.
#   Phase 2: fresh seed → M5.1 API suite → M4 browser UI suite → error scan →
#            final pristine re-seed + integrity check.
# Each phase is one bash invocation (sandbox process-group rule).
set -u
cd /home/z/my-project

BASE=http://127.0.0.1:3000
PHASE="${1:-all}"
PASS=0; FAIL=0
step(){ echo ""; echo "###############################################"; echo "### $1"; echo "###############################################"; }

stop_dev(){ pkill -f "next dev" 2>/dev/null || true; sleep 1; }
start_dev(){
  nohup bun run dev < /dev/null > /tmp/m5-dev.out 2>&1 &
  DEV_PID=$!
  for i in $(seq 1 90); do
    curl -sf "$BASE/api/health" >/dev/null 2>&1 && break
    sleep 1
  done
  if curl -sf "$BASE/api/health" >/dev/null 2>&1; then echo "dev server up (pid $DEV_PID)"; else echo "DEV SERVER FAILED"; tail -40 /tmp/m5-dev.out; exit 1; fi
}

if [ "$PHASE" = "1" ] || [ "$PHASE" = "all" ]; then

step "0. Static checks"
bunx tsc --noEmit && { echo "tsc: PASS"; PASS=$((PASS+1)); } || { echo "tsc: FAIL"; FAIL=$((FAIL+1)); }
bun run lint && { echo "lint: PASS"; PASS=$((PASS+1)); } || { echo "lint: FAIL"; FAIL=$((FAIL+1)); }

stop_dev

step "1. Pristine seed (deterministic state)"
bun run db:seed && { echo "seed: PASS"; PASS=$((PASS+1)); } || { echo "seed: FAIL"; FAIL=$((FAIL+1)); }

step "2. M2 regression — lab-test registry (unchanged suite)"
bun scripts/m2-test-registry.ts > /tmp/m5-m2-registry.txt 2>&1
M2R=$?; tail -1 /tmp/m5-m2-registry.txt
[ $M2R -eq 0 ] && PASS=$((PASS+1)) || FAIL=$((FAIL+1))

step "3. M2 regression — service layer (unchanged suite)"
bun scripts/m2-test-services.ts > /tmp/m5-m2-services.txt 2>&1
M2S=$?; tail -1 /tmp/m5-m2-services.txt
[ $M2S -eq 0 ] && PASS=$((PASS+1)) || FAIL=$((FAIL+1))

step "4. M2 suite re-seed (it mutates share states)"
stop_dev
bun run db:seed >/dev/null 2>&1 && echo "re-seed: done" && PASS=$((PASS+1)) || FAIL=$((FAIL+1))

step "5. M5.1 suite — registry additions"
bun scripts/m5-test-registry.ts > /tmp/m5-registry.txt 2>&1
M5R=$?; tail -1 /tmp/m5-registry.txt
[ $M5R -eq 0 ] && PASS=$((PASS+1)) || FAIL=$((FAIL+1))

step "6. M5.1 suite — services (input persistence, editability, isolation)"
bun scripts/m5-test-services.ts > /tmp/m5-services.txt 2>&1
M5S=$?; tail -1 /tmp/m5-services.txt
[ $M5S -eq 0 ] && PASS=$((PASS+1)) || FAIL=$((FAIL+1))

# The M5 services suite mutates fixtures it cleans up itself; re-seed anyway
# so the M3 regression runs against the pristine dataset.
stop_dev
bun run db:seed >/dev/null 2>&1

step "7. M3 regression — API integration suite (live dev server, unchanged)"
start_dev
bun scripts/m3-test-api.ts > /tmp/m5-m3-api.txt 2>&1
M3_RC=$?
echo "  rc=$M3_RC — summary:"; tail -1 /tmp/m5-m3-api.txt
grep -c "^FAIL" /tmp/m5-m3-api.txt | sed 's/^/  FAIL lines: /'
grep "^FAIL" /tmp/m5-m3-api.txt || true
[ $M3_RC -eq 0 ] && PASS=$((PASS+1)) || FAIL=$((FAIL+1))

step "8. M1 regression — browser auth tests (manages own dev server)"
stop_dev
bash scripts/m1-auth-test.sh > /tmp/m5-m1-auth.txt 2>&1
M1_RC=$?
echo "  rc=$M1_RC — summary:"; tail -3 /tmp/m5-m1-auth.txt
[ $M1_RC -eq 0 ] && PASS=$((PASS+1)) || FAIL=$((FAIL+1))

echo ""
echo "============================================="
echo "M5.1 PHASE 1 SUMMARY: $PASS steps passed, $FAIL failed"
echo "  (m2 registry rc=$M2R, m2 services rc=$M2S, m5 registry rc=$M5R,"
echo "   m5 services rc=$M5S, m3 api rc=$M3_RC, m1 browser rc=$M1_RC)"
echo "============================================="
exit $((FAIL > 0 ? 1 : 0))
fi

if [ "$PHASE" = "2" ] || [ "$PHASE" = "all" ]; then

stop_dev

step "9. Fresh seed for M5.1 API + M4 UI suites"
bun run db:seed >/dev/null 2>&1 && echo "seed: done" && PASS=$((PASS+1)) || FAIL=$((FAIL+1))
start_dev

step "10. M5.1 suite — API integration (live dev server)"
bun scripts/m5-test-api.ts > /tmp/m5-api.txt 2>&1
M5A=$?
tail -1 /tmp/m5-api.txt
[ $M5A -eq 0 ] && PASS=$((PASS+1)) || FAIL=$((FAIL+1))

step "11. M4 regression — browser UI suite (unchanged, live server)"
bash scripts/m4-test-ui.sh > /tmp/m5-m4-ui.txt 2>&1
M4_RC=$?
echo "  rc=$M4_RC — summary:"; tail -2 /tmp/m5-m4-ui.txt
[ $M4_RC -eq 0 ] && PASS=$((PASS+1)) || FAIL=$((FAIL+1))

step "12. Runtime error scan (dev log)"
if grep -aqiE "hydration|Module not found|unhandled promise" /tmp/m5-dev.out; then
  echo "  potential errors:"
  grep -aiE "hydration|Module not found|unhandled promise" /tmp/m5-dev.out | head -5
  FAIL=$((FAIL+1))
else
  echo "no hydration/module/unhandled errors in dev log"; PASS=$((PASS+1))
fi

step "13. Re-seed pristine demo data + integrity check"
stop_dev
bun run db:seed >/dev/null 2>&1 && echo "final seed: done" && PASS=$((PASS+1)) || FAIL=$((FAIL+1))
bun scripts/m5-count-records.ts && PASS=$((PASS+1)) || FAIL=$((FAIL+1))

echo ""
echo "============================================="
echo "M5.1 PHASE 2 SUMMARY: $PASS steps passed, $FAIL failed"
echo "  (m5 api rc=$M5A, m4 ui rc=$M4_RC)"
echo "============================================="
exit $((FAIL > 0 ? 1 : 0))
fi

echo "usage: bash scripts/m5-run-all.sh [1|2|all]"
exit 1
