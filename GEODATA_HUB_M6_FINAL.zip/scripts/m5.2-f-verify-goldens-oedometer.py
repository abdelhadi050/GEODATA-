#!/usr/bin/env python3
"""M5.2-f golden-value independent verification (Oedometer: Cc / Cs / mv /
sigma'_p Casagrande / Cv log-time).

Run BEFORE writing the test expectations. Every expected value below is
computed independently of the TypeScript engine:

- high-precision Decimal (60 digits) for the regression truth,
- IEEE-754 double probes mirroring the exact JS operation order designed for
  the module (sequential-sum two-pass line fits, hypot-based circumscribed
  curvature, central-secant tangent, bisector/VCL intersection, fixed-window
  Casagrande log-time fit with log10-interpolated t50),
- half-away-from-zero rounding predictions with tie-distance guards.

Designed module arithmetic (M5.2-f, ASTM D2435 / NF P94-090 / ISO 17892-5):

  Height datum : e(H) = (H / H_ref) * (1 + e_ref) - 1
  VCL          : least squares of e on log10(sigma') over the TERMINAL
                 loading window (last 3 stages; secant for 2 stages)
                 Cc = -slope
  Cs           : least squares of e on log10(sigma') over all unloading
                 stages; Cs = -slope
  mv_i         : (e_i - e_{i+1}) / ((1 + e_i) * (sigma_{i+1} - sigma_i))
  sigma'_p     : Casagrande construction - max-curvature point B (circumscribed
                 circle 1/R over consecutive triples), tangent = central secant,
                 bisector of (horizontal, tangent) intersected with the VCL;
                 reported only when it closes strictly inside the tested range.
  Cv           : Casagrande log-time fit - d0 = early sqrt(t)-line intercept;
                 d100 = primary/secondary semi-log line intersection;
                 t50 = d50 crossing (log10 t interpolation);
                 Cv = 0.197 * Hd^2 / t50  [mm^2/min]; cm^2/s = /6000 (exact).
"""
from decimal import Decimal as D, getcontext
import math

getcontext().prec = 60


def round_to_double(x, dp):
    scaled = x * 10 ** dp
    if abs(scaled) > 2 ** 53:
        raise ValueError("out of safe range")
    corrected_abs = abs(scaled) * (1 + 2.220446049250313e-16)
    rounded = math.floor(corrected_abs + 0.5)
    signed = -rounded if scaled < 0 else rounded
    result = signed / 10 ** dp
    return 0.0 if result == 0 else result


def tie_guard(x, dp, label):
    scaled = abs(x) * 10 ** dp
    dist = abs(scaled - math.floor(scaled) - 0.5)
    if dist < 1e-9:
        print(f"  !! TIE WARNING {label}: {x} at {dp} dp (scaled {scaled})")


def show(label, value, dp):
    tie_guard(value, dp, label)
    print(f"  {label:<56} = {value!r:<24} -> {dp} dp: {round_to_double(value, dp)}")
    return round_to_double(value, dp)


def js_fit_line(pts):
    """Mirror of the module fitLine (two-pass, sequential sums)."""
    n = len(pts)
    sx = 0.0
    sy = 0.0
    for x, y in pts:
        sx += x
        sy += y
    xm = sx / n
    ym = sy / n
    sxy = 0.0
    sxx = 0.0
    for x, y in pts:
        dx = x - xm
        dy = y - ym
        sxy += dx * dy
        sxx += dx * dx
    slope = sxy / sxx
    intercept = ym - slope * xm
    return slope, intercept


def dec_fit_line(pts):
    n = len(pts)
    sx = sum((D(str(x)) for x, _ in pts), D(0))
    sy = sum((D(str(y)) for _, y in pts), D(0))
    xm = sx / n
    ym = sy / n
    sxy = sxx = D(0)
    for x, y in pts:
        sxy += (D(str(x)) - xm) * (D(str(y)) - ym)
        sxx += (D(str(x)) - xm) ** 2
    slope = sxy / sxx
    intercept = ym - slope * xm
    return slope, intercept


def triple_curvature(p1, p2, p3):
    """Mirror of tripleCurvature (hypot sides, cross-product area)."""
    a = math.hypot(p2[0] - p1[0], p2[1] - p1[1])
    b = math.hypot(p3[0] - p2[0], p3[1] - p2[1])
    c = math.hypot(p3[0] - p1[0], p3[1] - p1[1])
    twice_area = abs((p2[0] - p1[0]) * (p3[1] - p1[1]) - (p3[0] - p1[0]) * (p2[1] - p1[1]))
    if twice_area == 0:
        return 0.0
    radius = (a * b * c) / (2 * twice_area)
    if not math.isfinite(radius) or radius <= 0:
        return 0.0
    return 1.0 / radius


def casagrande_sigma_p(stages, vcl_slope, vcl_intercept):
    """Mirror of casagrandePreconsolidation. stages: [(sigma, e)]."""
    log_stages = [(math.log10(s), e) for s, e in stages]
    best_i, best_k = -1, 0.0
    for i in range(1, len(log_stages) - 1):
        k = triple_curvature(log_stages[i - 1], log_stages[i], log_stages[i + 1])
        if k > best_k:
            best_k, best_i = k, i
    if best_i < 0 or best_k == 0:
        return None, None, None
    xb, eb = log_stages[best_i]
    prev = log_stages[best_i - 1]
    nxt = log_stages[best_i + 1]
    m = (nxt[1] - prev[1]) / (nxt[0] - prev[0])
    norm = math.sqrt(1 + m * m)
    dx = 1 + 1 / norm
    dy = m / norm
    denom = dy - vcl_slope * dx
    if denom == 0 or not math.isfinite(denom):
        return None, xb, best_k
    t = (vcl_intercept + vcl_slope * xb - eb) / denom
    x_int = xb + t * dx
    x_max = log_stages[-1][0]
    if not (t > 0 and x_int > xb and x_int <= x_max):
        return None, xb, best_k
    return 10 ** x_int, xb, best_k


def analyze(label, stages, unloading=None):
    print("=" * 100)
    print(f"FIXTURE {label}")
    print("=" * 100)
    log_pts = [(math.log10(s), e) for s, e in stages]
    w = min(3, len(stages))
    window = log_pts[-w:]
    slope, intercept = js_fit_line(window)
    dslope, dinter = dec_fit_line([(D(str(math.log10(s))), D(str(e))) for s, e in stages[-w:]])
    print(f"  VCL window: last {w} stages, pressures {[s for s, _ in stages[-w:]]}")
    print(f"  Decimal truth: slope = {dslope}, intercept = {dinter}")
    show("vclSlope", slope, 4)
    show("vclIntercept", intercept, 4)
    show("Cc = -slope", -slope, 4)
    sigma_p, xb, kbest = casagrande_sigma_p(stages, slope, intercept)
    if sigma_p is not None:
        show("sigma'_p (Casagrande) [kPa]", sigma_p, 1)
        print(f"  B at sigma' = {10 ** xb:.2f} kPa (curvature 1/R = {kbest!r})")
        print(f"  inside tested range [{stages[0][0]}, {stages[-1][0]}]: {stages[0][0] < sigma_p <= stages[-1][0]}")
    else:
        print(f"  sigma'_p NOT CLOSABLE (B at {10 ** xb if xb else None}, curvature {kbest}) -> null + INSUFFICIENT_DATA")
    print("  mv per loading increment [1/kPa]:")
    for i in range(len(stages) - 1):
        e1, e2 = stages[i][1], stages[i + 1][1]
        ds = stages[i + 1][0] - stages[i][0]
        mv = (e1 - e2) / ((1 + e1) * ds)
        show(f"  mv({stages[i][0]:.0f}->{stages[i + 1][0]:.0f} kPa)", mv, 6)
    if unloading:
        ul = [(math.log10(s), e) for s, e in unloading]
        us, ui = js_fit_line(ul)
        print(f"  unloading slope = {us!r}")
        show("Cs = -unloading slope", -us, 4)
    print(f"  e0 = {stages[0][1]}, eF = {(unloading or stages)[-1][1]}")
    print()
    return slope, intercept, sigma_p


OEDO = [(25, 0.912), (50, 0.898), (100, 0.876), (200, 0.841), (400, 0.796), (800, 0.748)]
s1, i1, sp1 = analyze("O1 - OEDO_CLAY (registry seed shape; entered Cc 0.155, Cs 0.022, sp 180, cv 1.8 echoed)", OEDO)

UNLOAD = [(400, 0.782), (200, 0.801), (100, 0.815), (50, 0.826)]
analyze("O2 - OEDO_CLAY + unloading branch (Cs from rebound)", OEDO, unloading=UNLOAD)

# O3 - height-based stages: datum H_ref = 20 mm at e_ref = 0.912
print("=" * 100)
print("FIXTURE O3 - height-based stages (datum H=20.00 mm at e=0.912)")
print("=" * 100)
HREF, EREF = 20.0, 0.912
targets = [(25, 0.912), (50, 0.898), (100, 0.876), (200, 0.841), (400, 0.796), (800, 0.748)]
heights = []
for sig, e in targets:
    H = HREF * (1 + e) / (1 + EREF)
    heights.append((sig, H))
    e_back = (H / HREF) * (1 + EREF) - 1
    print(f"  sigma={sig} kPa: target e={e} -> H={H!r} -> e_roundtrip={e_back!r}")
print()

# O4 - Casagrande log-time fit (designed: d0 = 0.5, d100 = 0.91, flat tail)
print("=" * 100)
print("FIXTURE O4 - Cv reading series (12 readings, clean three-phase design)")
print("=" * 100)
ts = [0.1, 0.25, 0.5, 1, 2, 4, 8, 15, 30, 60, 120, 240]
# early: dial = 0.5 + 0.15*sqrt(t) for t in {0.1, 0.25, 0.5, 1}
# primary: line through (2, 0.72) and (15, 0.90) in log10 t
kA = (0.90 - 0.72) / (math.log10(15) - math.log10(2))
dA = 0.72 - kA * math.log10(2)
# secondary: flat 0.91 for t in {30, 60, 120, 240}
dial = []
for t in ts:
    if t <= 1:
        dial.append(0.5 + 0.15 * math.sqrt(t))
    elif t <= 15:
        dial.append(dA + kA * math.log10(t))
    else:
        dial.append(0.91)
print(f"  primary line: kA = {kA!r}, dA = {dA!r}")
print(f"  readings: {list(zip(ts, [round(d, 8) for d in dial]))}")
n = len(ts)
window = max(2, n // 3)
early = [(math.sqrt(t), d) for t, d in list(zip(ts, dial))[:window]]
e_slope, e_intercept = js_fit_line(early)
print(f"  early window: first {window} readings (t <= {ts[window - 1]})")
show("d0 (early sqrt(t)-line intercept)", e_intercept, 6)
primary = [(math.log10(t), d) for t, d in list(zip(ts, dial))[window:n - window]]
secondary = [(math.log10(t), d) for t, d in list(zip(ts, dial))[n - window:]]
p_slope, p_intercept = js_fit_line(primary)
s_slope, s_intercept = js_fit_line(secondary)
print(f"  primary window: t in {ts[window:n - window]}")
print(f"  secondary window: t in {ts[n - window:]}")
show("primary slope", p_slope, 8)
show("secondary slope", s_slope, 8)
x100 = (s_intercept - p_intercept) / (p_slope - s_slope)
d100 = p_intercept + p_slope * x100
show("d100 (line intersection)", d100, 6)
print(f"  t100 = {10 ** x100!r} min")
d0 = e_intercept
d50 = (d0 + d100) / 2
show("d50", d50, 6)
# crossing between (1, 0.65) and (2, dial(2))
t50 = None
for i in range(1, n):
    y1, y2 = dial[i - 1], dial[i]
    if (y1 <= d50 <= y2) or (y2 <= d50 <= y1):
        if y2 == y1:
            continue
        x1, x2 = math.log10(ts[i - 1]), math.log10(ts[i])
        frac = (d50 - y1) / (y2 - y1)
        t50 = 10 ** (x1 + frac * (x2 - x1))
        print(f"  crossing bracket: t={ts[i - 1]} ({y1!r}) -> t={ts[i]} ({y2!r})")
        break
show("t50 [min]", t50, 6)
HD = 10.0
cv_mm2_min = (0.197 * HD * HD) / t50
show("Cv [mm2/min]", cv_mm2_min, 4)
show("Cv [cm2/s] (= /6000)", cv_mm2_min / 6000, 6)
print()

# O5 - heavily overconsolidated curve (construction does not close)
analyze("O5 - heavily OC curve (all-recompression slopes; sp beyond range)",
        [(25, 0.900), (50, 0.896), (100, 0.891), (200, 0.885), (400, 0.878), (800, 0.870)])

# O6 - two loading stages only
print("=" * 100)
print("FIXTURE O6 - two loading stages (Cc = secant; sp undefined)")
print("=" * 100)
two = [(100, 0.90), (200, 0.86)]
cc2 = (0.90 - 0.86) / (math.log10(200) - math.log10(100))
show("Cc (2-point secant)", cc2, 4)
print()

print("=" * 100)
print("VALIDATION-CASE NUMBERS")
print("=" * 100)
print("  loading pressures not strictly increasing -> INVALID_INPUT")
print("  unloading pressures not strictly decreasing -> INVALID_INPUT")
print("  stage with BOTH voidRatio and specimenHeightMm -> INVALID_INPUT")
print("  stage with neither -> INVALID_INPUT")
print("  height-based stage without the datum -> MISSING_INPUT")
print("  terminal window with non-negative slope -> INVALID_INPUT (non-compressing)")
print("  derived void ratio outside 0.15-4 -> INVALID_INPUT (e.g. heights 5 mm at datum)")
print("  readings with non-increasing time -> INVALID_INPUT")
print("  incrementFromIndex beyond the last increment -> INVALID_INPUT")
print("  13 loading stages -> INVALID_INPUT (max 12); 1 stage -> INVALID_INPUT (min 2)")
print()
print("ALL GOLDENS VERIFIED - values above are the independent expectations for")
print("scripts/m5.2-test-oedometer.ts")
