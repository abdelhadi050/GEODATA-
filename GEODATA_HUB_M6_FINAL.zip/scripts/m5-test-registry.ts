/**
 * M5.1 TEST — Registry additions: PRESSUREMETER entry, Triaxial per-stage
 * stressStrain + porePressureAtFailureKpa, Direct Shear stages[], Proctor
 * wetDensityMgM3, SPT effectiveOverburdenKpa input, water-content mass
 * semantics, Granulometry Cc consistency — plus backward compatibility with
 * every legacy payload shape. Exit code = number of failures.
 */
import {
  parseLabTestResult,
  parseLabTestInput,
  LAB_TEST_TYPES,
  LAB_TEST_REGISTRY,
} from "../src/lib/lab-tests/registry";

let pass = 0;
let fail = 0;
const ok = (m: string) => { console.log(`PASS: ${m}`); pass++; };
const no = (m: string) => { console.log(`FAIL: ${m}`); fail++; };

function expectValid(type: string, label: string, payload: unknown) {
  const r = parseLabTestResult(type, payload);
  if (r.ok) ok(`${label} — valid accepted`); else no(`${label} — valid REJECTED (${r.error})`);
}
function expectInvalid(type: string, label: string, payload: unknown, hint?: string) {
  const r = parseLabTestResult(type, payload);
  if (!r.ok) {
    const matched = !hint || r.error.includes(hint);
    if (matched) ok(`${label} — invalid rejected (${hint ?? r.error})`);
    else no(`${label} — rejected but wrong rule (${r.error}, expected ${hint})`);
  } else no(`${label} — invalid payload ACCEPTED`);
}

// ---------------------------------------------------------------------------
// 1. PRESSUREMETER (new test type)
// ---------------------------------------------------------------------------
const PMT_VALID = {
  points: [
    { pressureKpa: 0, volumeCm3: 45 },
    { pressureKpa: 50, volumeCm3: 55 },
    { pressureKpa: 100, volumeCm3: 68 },
    { pressureKpa: 150, volumeCm3: 82 },
    { pressureKpa: 200, volumeCm3: 97 },
    { pressureKpa: 400, volumeCm3: 168 },
    { pressureKpa: 800, volumeCm3: 410 },
  ],
  creepPressureKpa: 450,
  limitPressureKpa: 950,
  menardModulusMPa: 12.4,
  emPlRatio: 13.05,
};
expectValid("PRESSUREMETER", "pressuremeter full record", PMT_VALID);
expectValid("PRESSUREMETER", "pressuremeter points-only (derived fields all optional)", {
  points: PMT_VALID.points,
});
expectInvalid("PRESSUREMETER", "pressuremeter non-increasing pressure", {
  ...PMT_VALID,
  points: [
    { pressureKpa: 0, volumeCm3: 45 },
    { pressureKpa: 100, volumeCm3: 55 },
    { pressureKpa: 100, volumeCm3: 68 },
    { pressureKpa: 200, volumeCm3: 82 },
    { pressureKpa: 300, volumeCm3: 97 },
  ],
}, "strictly increasing");
expectInvalid("PRESSUREMETER", "pressuremeter decreasing volume", {
  ...PMT_VALID,
  points: [
    { pressureKpa: 0, volumeCm3: 45 },
    { pressureKpa: 100, volumeCm3: 68 },
    { pressureKpa: 200, volumeCm3: 60 },
    { pressureKpa: 300, volumeCm3: 82 },
    { pressureKpa: 400, volumeCm3: 97 },
  ],
}, "non-decreasing");
expectInvalid("PRESSUREMETER", "pressuremeter pf >= PL", {
  ...PMT_VALID,
  creepPressureKpa: 1000,
}, "creepPressureKpa");
expectInvalid("PRESSUREMETER", "pressuremeter bad emPlRatio", {
  ...PMT_VALID,
  emPlRatio: 20,
}, "emPlRatio");
expectInvalid("PRESSUREMETER", "pressuremeter too few points", {
  points: [
    { pressureKpa: 0, volumeCm3: 45 },
    { pressureKpa: 100, volumeCm3: 55 },
    { pressureKpa: 200, volumeCm3: 68 },
  ],
});
{
  const r = parseLabTestInput("PRESSUREMETER", {
    probeType: "Ménard NB (74 mm)",
    testDepthM: 2.5,
    boreholeDiameterMm: 76,
    groundwaterPresent: true,
    membraneCalibration: [{ pressureKpa: 0, volumeCm3: 0 }, { pressureKpa: 200, volumeCm3: 36 }],
  });
  if (r.ok) ok("pressuremeter input schema valid accepted"); else no(`pressuremeter input rejected (${(r as { error: string }).error})`);
}
{
  const r = parseLabTestInput("PRESSUREMETER", { probeType: "Ménard NB" });
  if (!r.ok) ok("pressuremeter input missing testDepthM rejected"); else no("pressuremeter invalid input accepted");
}
{
  const def = LAB_TEST_REGISTRY.PRESSUREMETER;
  if (def.chart.kind === "pressuremeterCurve" && def.category === "IN_SITU" && def.units.menardModulusMPa === "MPa") {
    ok("pressuremeter registry entry: chart contract + category + units");
  } else no("pressuremeter registry entry misconfigured");
}
{
  const wrongType = parseLabTestResult("NOT_A_TEST", {});
  if (!wrongType.ok && wrongType.error.includes("Unknown")) ok("unknown test type still rejected"); else no("unknown test type accepted");
}

// ---------------------------------------------------------------------------
// 2. TRIAXIAL — per-stage stressStrain + porePressureAtFailureKpa
// ---------------------------------------------------------------------------
expectValid("TRIAXIAL", "triaxial with per-stage stressStrain + pore pressure", {
  type: "CU",
  stages: [
    {
      confiningPressureKpa: 150, peakDeviatorStressKpa: 184, strainAtFailurePercent: 2.9,
      porePressureAtFailureKpa: -32,
      stressStrain: [
        { strainPercent: 0, deviatorStressKpa: 0 },
        { strainPercent: 0.5, deviatorStressKpa: 38 },
        { strainPercent: 1.0, deviatorStressKpa: 72 },
        { strainPercent: 2.9, deviatorStressKpa: 184 },
      ],
    },
    {
      confiningPressureKpa: 300, peakDeviatorStressKpa: 281, strainAtFailurePercent: 3.2,
      porePressureAtFailureKpa: -48,
      stressStrain: [
        { strainPercent: 0, deviatorStressKpa: 0 },
        { strainPercent: 1.0, deviatorStressKpa: 104 },
        { strainPercent: 3.2, deviatorStressKpa: 281 },
      ],
    },
  ],
  cohesionKpa: 26,
  frictionAngleDeg: 19,
});
expectInvalid("TRIAXIAL", "triaxial non-increasing strain within a stage", {
  type: "CU",
  stages: [
    {
      confiningPressureKpa: 150, peakDeviatorStressKpa: 184,
      stressStrain: [
        { strainPercent: 0, deviatorStressKpa: 0 },
        { strainPercent: 1.0, deviatorStressKpa: 72 },
        { strainPercent: 0.5, deviatorStressKpa: 38 },
        { strainPercent: 2.9, deviatorStressKpa: 184 },
      ],
    },
  ],
}, "strictly increasing");
expectInvalid("TRIAXIAL", "triaxial stressStrain single point (min 2)", {
  type: "CU",
  stages: [
    { confiningPressureKpa: 150, peakDeviatorStressKpa: 184, stressStrain: [{ strainPercent: 0, deviatorStressKpa: 0 }] },
  ],
});
// Backward compatibility: legacy peak-only stage payload (no stressStrain) —
// the shape every pre-M5.1 record uses — must stay valid.
expectValid("TRIAXIAL", "triaxial LEGACY payload (no stressStrain) still valid", {
  type: "UU",
  stages: [
    { confiningPressureKpa: 100, peakDeviatorStressKpa: 95 },
    { confiningPressureKpa: 200, peakDeviatorStressKpa: 130 },
  ],
  cohesionKpa: 38,
  frictionAngleDeg: 14,
  excessPorePressureKpa: -74,
});

// ---------------------------------------------------------------------------
// 3. DIRECT SHEAR — stages[] (new) vs scalar (legacy)
// ---------------------------------------------------------------------------
expectValid("DIRECT_SHEAR", "direct shear multi-stage program", {
  stages: [
    { normalStressKpa: 50, peakShearStressKpa: 43 },
    { normalStressKpa: 100, peakShearStressKpa: 67 },
    { normalStressKpa: 150, peakShearStressKpa: 90, residualShearStressKpa: 66 },
  ],
  cohesionKpa: 20,
  frictionAngleDeg: 25,
});
expectValid("DIRECT_SHEAR", "direct shear LEGACY scalar record still valid", {
  normalStressKpa: 100, peakShearStressKpa: 68, cohesionKpa: 20, frictionAngleDeg: 25,
});
expectInvalid("DIRECT_SHEAR", "direct shear empty record (neither stages nor scalars)", {}, "either stages");
expectInvalid("DIRECT_SHEAR", "direct shear stages AND scalars together rejected", {
  normalStressKpa: 100, peakShearStressKpa: 68,
  stages: [{ normalStressKpa: 50, peakShearStressKpa: 43 }, { normalStressKpa: 100, peakShearStressKpa: 67 }],
}, "not both");
expectInvalid("DIRECT_SHEAR", "direct shear duplicate stage normal stresses", {
  stages: [
    { normalStressKpa: 100, peakShearStressKpa: 68 },
    { normalStressKpa: 100, peakShearStressKpa: 72 },
  ],
}, "unique");
expectInvalid("DIRECT_SHEAR", "direct shear stage residual > peak", {
  stages: [
    { normalStressKpa: 50, peakShearStressKpa: 43 },
    { normalStressKpa: 100, peakShearStressKpa: 67, residualShearStressKpa: 90 },
  ],
}, "residual");
expectInvalid("DIRECT_SHEAR", "direct shear single stage array (min 2)", {
  stages: [{ normalStressKpa: 100, peakShearStressKpa: 68 }],
});

// ---------------------------------------------------------------------------
// 4. PROCTOR — optional wetDensityMgM3
// ---------------------------------------------------------------------------
expectValid("PROCTOR", "proctor with wetDensityMgM3", {
  method: "MODIFIED",
  points: [
    { moistureContent: 6, dryDensity: 1.9, wetDensityMgM3: 2.014 },
    { moistureContent: 10, dryDensity: 2.09, wetDensityMgM3: 2.299 },
    { moistureContent: 14, dryDensity: 2.05, wetDensityMgM3: 2.337 },
  ],
  maxDryDensity: 2.1,
  optimumMoisture: 11.5,
});
expectInvalid("PROCTOR", "proctor wetDensity below dryDensity", {
  method: "MODIFIED",
  points: [
    { moistureContent: 6, dryDensity: 1.9, wetDensityMgM3: 1.85 },
    { moistureContent: 10, dryDensity: 2.09, wetDensityMgM3: 2.299 },
    { moistureContent: 14, dryDensity: 2.05, wetDensityMgM3: 2.337 },
  ],
  maxDryDensity: 2.1,
  optimumMoisture: 11.5,
}, "wetDensityMgM3");
// Legacy payload (no wet density) must stay valid.
expectValid("PROCTOR", "proctor LEGACY payload (no wetDensity) still valid", {
  method: "STANDARD",
  points: [
    { moistureContent: 8, dryDensity: 1.72 },
    { moistureContent: 12, dryDensity: 1.94 },
    { moistureContent: 14, dryDensity: 1.97 },
    { moistureContent: 18, dryDensity: 1.84 },
  ],
  maxDryDensity: 1.97, optimumMoisture: 13.5,
});

// ---------------------------------------------------------------------------
// 5. WATER CONTENT — approved mass semantics
// ---------------------------------------------------------------------------
// w = 100 × (wet − dry) / (dry − tare): 100 × (235.5 − 205.3)/(205.3 − 42.1) = 18.50
expectValid("WATER_CONTENT", "water content consistent masses (Δ = 0.005)", {
  waterContentPercent: 18.5, wetMassG: 235.5, dryMassG: 205.3, containerMassG: 42.1,
});
// Boundary: computed 18.75 vs entered 18.5 → Δ = 0.25 ≤ 0.5 → accepted
expectValid("WATER_CONTENT", "water content within tolerance (Δ = 0.25)", {
  waterContentPercent: 18.5, wetMassG: 235.9, dryMassG: 205.3, containerMassG: 42.1,
});
// computed 100 × (236.5 − 205.3)/163.2 = 19.12 → Δ = 0.62 > 0.5 → rejected
expectInvalid("WATER_CONTENT", "water content inconsistent masses (Δ = 0.62)", {
  waterContentPercent: 18.5, wetMassG: 236.5, dryMassG: 205.3, containerMassG: 42.1,
}, "waterContentPercent");
expectInvalid("WATER_CONTENT", "water content dryMass ≤ tare", {
  waterContentPercent: 18.5, wetMassG: 60, dryMassG: 42.1, containerMassG: 42.1,
}, "containerMassG");
// Rule only fires when all three masses present — partial masses stay valid.
expectValid("WATER_CONTENT", "water content two masses only (rule skipped)", {
  waterContentPercent: 18.5, wetMassG: 235.5, dryMassG: 205.3,
});
expectValid("WATER_CONTENT", "water content percent only (legacy minimal record)", {
  waterContentPercent: 12.5,
});

// ---------------------------------------------------------------------------
// 6. GRANULOMETRY — Cc consistency
// ---------------------------------------------------------------------------
// Cc = d30²/(d60·d10) = 0.25²/(1.5×0.05) = 0.833
expectValid("GRANULOMETRY", "granulometry consistent Cc", {
  points: [
    { diameterMm: 0.002, percentFiner: 5 }, { diameterMm: 0.063, percentFiner: 20 },
    { diameterMm: 0.5, percentFiner: 52 }, { diameterMm: 2, percentFiner: 78 },
    { diameterMm: 63, percentFiner: 100 },
  ],
  d10: 0.05, d30: 0.25, d60: 1.5, uniformityCoefficient: 30, coefficientOfCurvature: 0.83,
});
expectInvalid("GRANULOMETRY", "granulometry inconsistent Cc", {
  points: [
    { diameterMm: 0.002, percentFiner: 5 }, { diameterMm: 0.063, percentFiner: 20 },
    { diameterMm: 0.5, percentFiner: 52 }, { diameterMm: 2, percentFiner: 78 },
    { diameterMm: 63, percentFiner: 100 },
  ],
  d10: 0.05, d30: 0.25, d60: 1.5, uniformityCoefficient: 30, coefficientOfCurvature: 1.5,
}, "coefficientOfCurvature");
// Rule skipped when d30 absent (legacy payload shape).
expectValid("GRANULOMETRY", "granulometry without d30 (Cc rule skipped)", {
  points: [
    { diameterMm: 0.002, percentFiner: 5 }, { diameterMm: 0.063, percentFiner: 20 },
    { diameterMm: 0.5, percentFiner: 52 }, { diameterMm: 2, percentFiner: 78 },
    { diameterMm: 63, percentFiner: 100 },
  ],
  d10: 0.05, d60: 1.5, uniformityCoefficient: 30,
});

// ---------------------------------------------------------------------------
// 7. SPT — optional effectiveOverburdenKpa input (M5.1)
// ---------------------------------------------------------------------------
{
  const r = parseLabTestInput("SPT", { hammerType: "AUTOMATIC", energyRatio: 72, effectiveOverburdenKpa: 46.9 });
  if (r.ok) ok("SPT input with effectiveOverburdenKpa accepted"); else no(`SPT input rejected (${(r as { error: string }).error})`);
}
{
  const r = parseLabTestInput("SPT", { hammerType: "AUTOMATIC", effectiveOverburdenKpa: 9999 });
  if (!r.ok) ok("SPT input out-of-range overburden rejected"); else no("SPT invalid overburden accepted");
}
{
  const r = parseLabTestInput("SPT", { hammerType: "AUTOMATIC" });
  if (r.ok) ok("SPT legacy input (no overburden) still accepted"); else no("SPT legacy input rejected");
}

// ---------------------------------------------------------------------------
// 8. Input schema round-trip: every registry type has a working inputSchema
// ---------------------------------------------------------------------------
const MINIMAL_INPUTS: Record<string, unknown> = {
  GRANULOMETRY: { method: "SIEVE" },
  ATTERBERG_LIMITS: { method: "CASAGRANDE_CUP" },
  PROCTOR: { method: "STANDARD" },
  CBR: { condition: "SOAKED" },
  SPT: { hammerType: "SAFETY" },
  CPT: { coneType: "STANDARD_10CM2" },
  UCS: { specimenDiameterMm: 54, specimenHeightMm: 108 },
  TRIAXIAL: { type: "UU", specimenCount: 3 },
  OEDOMETER: { specimenDiameterMm: 75, specimenHeightMm: 20 },
  DIRECT_SHEAR: { specimenDiameterMm: 63.5 },
  WATER_CONTENT: { containerId: "TIN-1" },
  SPECIFIC_GRAVITY: { method: "PYCNOMETER" },
  PRESSUREMETER: { probeType: "Ménard NB (74 mm)", testDepthM: 2.5 },
};
for (const t of LAB_TEST_TYPES) {
  const r = parseLabTestInput(t, MINIMAL_INPUTS[t]);
  if (r.ok) ok(`input schema round-trip: ${t}`); else no(`input schema round-trip FAILED: ${t} (${(r as { error: string }).error})`);
}

// ---------------------------------------------------------------------------
// 9. Registry completeness
// ---------------------------------------------------------------------------
{
  const missing = LAB_TEST_TYPES.filter((t) => !LAB_TEST_REGISTRY[t]);
  if (missing.length === 0) ok(`registry defines all ${LAB_TEST_TYPES.length} test types (13 incl. PRESSUREMETER)`);
  else no(`registry missing: ${missing}`);
}
{
  const standards: Record<string, string> = {};
  for (const t of LAB_TEST_TYPES) standards[t] = LAB_TEST_REGISTRY[t].standard;
  if (
    standards.CPT.includes("NF P94-113") && !standards.CPT.includes("NF P94-119") &&
    standards.OEDOMETER.includes("ISO 17892-5") &&
    standards.TRIAXIAL.includes("D7181") &&
    standards.GRANULOMETRY.includes("NF P94-057") &&
    standards.PRESSUREMETER.includes("NF P94-110-1") && standards.PRESSUREMETER.includes("ASTM D4719")
  ) {
    ok("standard references corrected & verified (CPT, oedometer, triaxial, granulometry, pressuremeter)");
  } else no(`standard strings wrong: ${JSON.stringify(standards)}`);
}
{
  const wcNotes = LAB_TEST_REGISTRY.WATER_CONTENT.validationNotes.join(" ");
  if (wcNotes.includes("tare") && wcNotes.includes("±0.5")) ok("water-content mass semantics documented in registry notes");
  else no("water-content semantics not documented");
}

console.log(`\n================ M5.1 REGISTRY TEST SUMMARY: ${pass} passed, ${fail} failed ================`);
process.exit(fail);
