/**
 * M5.2-a TEST — Statistical and phase-relation formulas.
 *
 * Golden values produced independently (exact rational arithmetic in
 * scripts/m5.2-verify-goldens.py) before being asserted here; no expectation
 * is copied from engine output. Covers both the happy paths and every domain
 * violation (never clamped — always thrown).
 * Exit code = number of failures.
 */
import {
  coefficientOfVariationPercent,
  mean,
  populationStandardDeviation,
  populationVariance,
  sampleStandardDeviation,
  sampleVariance,
} from "../src/lib/calc/formulas/statistics";
import {
  degreeOfSaturationPercent,
  drySoilMassFromTareMasses,
  porosityFromVoidRatio,
  voidRatioFromPorosity,
  waterContentPercent,
  waterMassFromTareMasses,
} from "../src/lib/calc/formulas/phase-relations";

let pass = 0;
let fail = 0;
const ok = (m: string) => { console.log(`PASS: ${m}`); pass++; };
const no = (m: string) => { console.log(`FAIL: ${m}`); fail++; };

const approx = (actual: number, expected: number, tol: number): boolean =>
  Math.abs(actual - expected) <= tol;

function expectThrows(fn: () => unknown, label: string, hint?: string): void {
  try {
    fn();
    no(`${label} — did not throw`);
  } catch (error) {
    const e = error as { code?: string; message?: string };
    if (e && e.code === "ARITHMETIC_DOMAIN_ERROR" && (!hint || (e.message ?? "").includes(hint))) {
      ok(`${label} — ArithmeticDomainError${hint ? ` (${hint})` : ""}`);
    } else {
      no(`${label} — wrong error: ${String(e && e.code)} / ${String(e && e.message)}`);
    }
  }
}

// ---------------------------------------------------------------------------
// 1. Statistics — classic dataset [2, 4, 4, 4, 5, 5, 7, 9]
// (exact: mean 5, population variance 4, sample variance 32/7)
// ---------------------------------------------------------------------------
const CLASSIC = [2, 4, 4, 4, 5, 5, 7, 9];
{
  if (mean(CLASSIC) === 5) ok("mean [2,4,4,4,5,5,7,9] = 5 (exact)");
  else no(`mean — got ${mean(CLASSIC)}`);

  const popVar = populationVariance(CLASSIC);
  if (popVar === 4) ok("populationVariance = 4 (exact)");
  else if (approx(popVar, 4, 1e-12)) ok("populationVariance = 4 (within 1e-12)");
  else no(`populationVariance — got ${popVar}`);

  const popStd = populationStandardDeviation(CLASSIC);
  if (approx(popStd, 2, 1e-12)) ok("populationStandardDeviation = 2");
  else no(`populationStandardDeviation — got ${popStd}`);

  const sampVar = sampleVariance(CLASSIC);
  if (approx(sampVar, 32 / 7, 1e-12)) ok("sampleVariance = 32/7 ≈ 4.571428571428571");
  else no(`sampleVariance — got ${sampVar}`);

  const sampStd = sampleStandardDeviation(CLASSIC);
  if (approx(sampStd, 2.138089935299395, 1e-12)) ok("sampleStandardDeviation ≈ 2.138089935299395");
  else no(`sampleStandardDeviation — got ${sampStd}`);

  const cv = coefficientOfVariationPercent(CLASSIC);
  if (approx(cv, 42.761798705987907, 1e-12)) ok("coefficientOfVariationPercent ≈ 42.761798705987907");
  else no(`coefficientOfVariationPercent — got ${cv}`);
}

// ---------------------------------------------------------------------------
// 2. Statistics — water-content quadruple [18.44, 18.50, 18.62, 18.38]
// (exact: mean 18.485, sample variance 21/2000 = 0.0105)
// ---------------------------------------------------------------------------
const WC_QUAD = [18.44, 18.5, 18.62, 18.38];
{
  if (mean(WC_QUAD) === 18.485) ok("mean [18.44,18.50,18.62,18.38] = 18.485 (exact)");
  else no(`mean WC — got ${mean(WC_QUAD)}`);

  const sampVar = sampleVariance(WC_QUAD);
  if (approx(sampVar, 0.0105, 1e-15)) ok("sampleVariance = 0.0105 (exact 21/2000)");
  else no(`sampleVariance WC — got ${sampVar}`);

  const sampStd = sampleStandardDeviation(WC_QUAD);
  if (approx(sampStd, 0.102469507659596, 1e-12)) ok("sampleStandardDeviation ≈ 0.102469507659596");
  else no(`sampleStandardDeviation WC — got ${sampStd}`);

  const cv = coefficientOfVariationPercent(WC_QUAD);
  if (approx(cv, 0.55433869439868, 1e-12)) ok("coefficientOfVariationPercent ≈ 0.55433869439868");
  else no(`coefficientOfVariationPercent WC — got ${cv}`);
}

// ---------------------------------------------------------------------------
// 3. Statistics — domain violations
// ---------------------------------------------------------------------------
expectThrows(() => mean([]), "mean of empty dataset");
expectThrows(() => populationVariance([]), "populationVariance of empty dataset");
expectThrows(() => populationStandardDeviation([]), "populationStandardDeviation of empty dataset");
expectThrows(() => sampleVariance([5]), "sampleVariance of single value");
expectThrows(() => sampleStandardDeviation([5, 5, 5].slice(0, 1)), "sampleStandardDeviation of single value");
expectThrows(() => coefficientOfVariationPercent([-2, 2]), "coefficientOfVariationPercent with zero mean");
expectThrows(() => mean([1, Number.NaN]), "dataset containing NaN");
expectThrows(() => mean([1, Number.POSITIVE_INFINITY]), "dataset containing +Infinity");
{
  // Degenerate but valid: identical values give zero spread (no error, no clamp).
  if (sampleStandardDeviation([5, 5, 5]) === 0) ok("sampleStandardDeviation of identical values = 0 (valid)");
  else no("sampleStandardDeviation of identical values — expected 0");
}

// ---------------------------------------------------------------------------
// 4. Phase relations — mass bookkeeping goldens (M5.1 F2 semantics)
// ---------------------------------------------------------------------------
{
  // Golden A masses: wet 112.0, dry 101.6, tare 45.2 (exact: 10.4 g / 56.4 g).
  const wm = waterMassFromTareMasses(112.0, 101.6);
  if (approx(wm, 10.4, 1e-9)) ok("waterMassFromTareMasses(112.0, 101.6) ≈ 10.4 g");
  else no(`waterMassFromTareMasses — got ${wm}`);

  const dm = drySoilMassFromTareMasses(101.6, 45.2);
  if (approx(dm, 56.4, 1e-9)) ok("drySoilMassFromTareMasses(101.6, 45.2) ≈ 56.4 g");
  else no(`drySoilMassFromTareMasses — got ${dm}`);

  // Exact rational: 100 × 10.4 / 56.4 = 2600/141 = 18.439716312056737588…
  const w = waterContentPercent(10.4, 56.4);
  if (approx(w, 2600 / 141, 1e-9)) ok("waterContentPercent(10.4, 56.4) ≈ 18.4397163120567376 %");
  else no(`waterContentPercent — got ${w}`);

  // Seed WC_18_5 masses: 100 × 30.2 / 163.2 = 3775/204 = 18.504901960784…
  const wB = waterContentPercent(30.2, 163.2);
  if (approx(wB, 3775 / 204, 1e-9)) ok("waterContentPercent(30.2, 163.2) ≈ 18.5049019607843 %");
  else no(`waterContentPercent WC_18_5 — got ${wB}`);

  // Zero water mass is a computable domain edge (w = 0 %) — no clamp.
  if (waterContentPercent(0, 50) === 0) ok("waterContentPercent(0, 50) = 0 % (edge, valid)");
  else no("waterContentPercent(0, 50) — expected 0");
}

// ---------------------------------------------------------------------------
// 5. Phase relations — e ↔ n and Sr
// ---------------------------------------------------------------------------
{
  const n = porosityFromVoidRatio(0.8);
  if (approx(n, 0.4444444444444444, 1e-15)) ok("porosityFromVoidRatio(0.8) = 0.8/1.8 ≈ 0.4444444444444444");
  else no(`porosityFromVoidRatio — got ${n}`);

  const e = voidRatioFromPorosity(0.4444444444444444);
  if (approx(e, 0.8, 1e-12)) ok("voidRatioFromPorosity(4/9) ≈ 0.8 (round trip)");
  else no(`voidRatioFromPorosity — got ${e}`);

  if (porosityFromVoidRatio(0) === 0) ok("porosityFromVoidRatio(0) = 0 (edge)");
  else no("porosityFromVoidRatio(0) — expected 0");
  if (voidRatioFromPorosity(0) === 0) ok("voidRatioFromPorosity(0) = 0 (edge)");
  else no("voidRatioFromPorosity(0) — expected 0");

  // Sr = w(%) × Gs / e — exact: 25 × 2.65 / 0.8 = 82.8125
  const sr = degreeOfSaturationPercent(0.8, 25, 2.65);
  if (approx(sr, 82.8125, 1e-9)) ok("degreeOfSaturationPercent(0.8, 25 %, 2.65) = 82.8125 %");
  else no(`degreeOfSaturationPercent — got ${sr}`);

  // Sr > 100 % is computable and NOT clamped (docs/14 §4.9): 40 × 2.7 / 0.8 = 135
  const srHigh = degreeOfSaturationPercent(0.8, 40, 2.7);
  if (approx(srHigh, 135, 1e-9)) ok("degreeOfSaturationPercent(0.8, 40 %, 2.7) = 135 % (unclamped)");
  else no(`degreeOfSaturationPercent high — got ${srHigh}`);
}

// ---------------------------------------------------------------------------
// 6. Phase relations — domain violations
// ---------------------------------------------------------------------------
expectThrows(() => waterMassFromTareMasses(100, 110), "waterMassFromTareMasses wet < dry", "negative");
expectThrows(() => waterMassFromTareMasses(-112, 101.6), "waterMassFromTareMasses negative mass", "non-negative");
expectThrows(() => drySoilMassFromTareMasses(40, 45), "drySoilMassFromTareMasses dry < tare", "negative");
expectThrows(() => drySoilMassFromTareMasses(101.6, -45.2), "drySoilMassFromTareMasses negative tare", "non-negative");
expectThrows(() => waterContentPercent(10.4, 0), "waterContentPercent zero dry mass", "strictly positive");
expectThrows(() => waterContentPercent(10.4, -5), "waterContentPercent negative dry mass", "strictly positive");
expectThrows(() => waterContentPercent(-1, 56.4), "waterContentPercent negative water mass", "non-negative");
expectThrows(() => porosityFromVoidRatio(-0.1), "porosityFromVoidRatio negative e", "non-negative");
expectThrows(() => voidRatioFromPorosity(1), "voidRatioFromPorosity n = 1");
expectThrows(() => voidRatioFromPorosity(1.5), "voidRatioFromPorosity n > 1");
expectThrows(() => voidRatioFromPorosity(-0.2), "voidRatioFromPorosity negative n", "[0, 1)");
expectThrows(() => degreeOfSaturationPercent(0, 25, 2.65), "degreeOfSaturationPercent e = 0", "strictly positive");
expectThrows(() => degreeOfSaturationPercent(0.8, -5, 2.65), "degreeOfSaturationPercent negative w", "non-negative");
expectThrows(() => degreeOfSaturationPercent(0.8, 25, 0), "degreeOfSaturationPercent Gs = 0", "strictly positive");
expectThrows(() => degreeOfSaturationPercent(Number.NaN, 25, 2.65), "degreeOfSaturationPercent NaN argument", "finite");

console.log(`\n================ M5.2-a FORMULAS TEST SUMMARY: ${pass} passed, ${fail} failed ================`);
process.exit(fail);
