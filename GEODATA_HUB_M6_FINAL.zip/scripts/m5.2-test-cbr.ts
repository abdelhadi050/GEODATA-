/**
 * M5.2-e TEST — California Bearing Ratio calculation module.
 *
 * Golden values independently verified BEFORE being asserted here (60-digit
 * Decimal regression + IEEE-double probes mirroring the module's exact op
 * order — exact-hit reads, linear interpolation, 100 × load / standard load,
 * steepest-segment origin correction — plus half-away-from-zero rounding
 * predictions in scripts/m5.2-e-verify-goldens.py). Sources: M5.2-e
 * authorization §5, registry cbrResult contract (ASTM D1883 / NF P94-078),
 * prisma/seed.ts fixtures CBR_SOAKED_A1 {18, 21, 21, swell 1.2} and
 * CBR_UNSOAKED_A1 {45, 38, 45}.
 *
 * Coverage (authorization §9): normal valid cases (exact-hit goldens,
 * interpolation, soaked/unsoaked distinction); invalid inputs (bounds,
 * duplicates, ordering, NaN/strings, 1/21 points); missing measurements
 * (empty payload, out-of-range targets); boundary conditions (entered
 * identity ±0.01); unit consistency (kN loads vs kN standard loads);
 * insufficient experimental data (targets outside the curve, correction not
 * applicable); calculation accuracy (Decimal-agreed ratios); physical and
 * engineering consistency (CBR > 100 reported unclamped, max reporting
 * rule); error and warning handling (registry mirrors, entered
 * discrepancies, CORRECTION_APPLIED / REPORTING_RULE / INSUFFICIENT_DATA
 * codes); M5.1 registry parity with documented divergences; determinism
 * (25 runs × paths); purity; envelope provenance.
 *
 * Key verifier goldens (double probes; Decimal agrees to <1e-13):
 *   C1 soaked:  CBR2.5 = 67.22054380664652, CBR5.0 = 86.17234468937875
 *               (5.0 governs -> REPORTING_RULE; entered {18,21,21} warn).
 *   C2 unsoaked: CBR2.5 = 144.25981873111783, CBR5.0 = 181.36272545090182
 *               (unclamped > 100 %).
 *   C3 interpolation: loads 8.15 / 16.2 kN -> 61.5558912386707 / 81.1623246492986.
 *   C4 origin correction: shift 1.0298507462686572 mm, loads
 *               8.375000000000002 / 16.554328358208956 kN -> 63.26 / 82.94 %.
 * Exit code = number of failures.
 */
import { runCalculation } from "../src/lib/calc/engine";
import type { CalculationOutcome } from "../src/lib/calc/types";
import {
  CBR_ENTERED_TOLERANCE,
  CBR_PENETRATION_TARGET_2_5_MM,
  applyOriginCorrection,
  cbrCalcInput,
  cbrModule,
  loadAtPenetration,
  type CbrInput,
  type CbrRaw,
  type CbrResults,
} from "../src/lib/calc/modules/cbr";
import { parseLabTestResult } from "../src/lib/lab-tests/registry";

let pass = 0;
let fail = 0;
const ok = (m: string) => { console.log(`PASS: ${m}`); pass++; };
const no = (m: string) => { console.log(`FAIL: ${m}`); fail++; };

const approx = (actual: number, expected: number, tol: number): boolean =>
  Math.abs(actual - expected) <= tol;

type Outcome = CalculationOutcome<CbrInput, CbrRaw, CbrResults>;

interface ExpectedError {
  code: string;
  fieldPath?: string;
  messageHint?: string;
}

function expectError(outcome: Outcome, label: string, expected: ExpectedError): void {
  if (outcome.status !== "error") {
    no(`${label} — expected ${expected.code}, got success`);
    return;
  }
  const { code, message, details } = outcome.error;
  if (code !== expected.code) {
    no(`${label} — expected ${expected.code}, got ${code}`);
    return;
  }
  if (expected.fieldPath !== undefined && details?.fieldPath !== expected.fieldPath) {
    no(`${label} — expected fieldPath ${expected.fieldPath}, got ${String(details?.fieldPath)}`);
    return;
  }
  if (expected.messageHint !== undefined && !message.includes(expected.messageHint)) {
    no(`${label} — message '${message}' lacks hint '${expected.messageHint}'`);
    return;
  }
  ok(`${label} — ${code}${expected.fieldPath ? ` @ ${expected.fieldPath}` : ""}`);
}

// ---------------------------------------------------------------------------
// Fixtures (independently verified in scripts/m5.2-e-verify-goldens.py)
// ---------------------------------------------------------------------------

/** CBR_SOAKED_A1 seed — exact 2.5/5.0 mm points, entered {18, 21, 21}. */
const SOAKED_POINTS = [
  { penetrationMm: 0.5, loadKn: 1.6 },
  { penetrationMm: 1, loadKn: 3.2 },
  { penetrationMm: 2, loadKn: 6.8 },
  { penetrationMm: 2.5, loadKn: 8.9 },
  { penetrationMm: 4, loadKn: 14.1 },
  { penetrationMm: 5, loadKn: 17.2 },
  { penetrationMm: 7.5, loadKn: 22.4 },
  { penetrationMm: 10, loadKn: 26.5 },
  { penetrationMm: 12.5, loadKn: 30.1 },
];
const SOAKED_ENTERED = { cbrAt2_5: 18, cbrAt5_0: 21, cbrValue: 21, swellPercent: 1.2 };

/** CBR_UNSOAKED_A1 seed — exact points; computed CBR exceeds 100 %. */
const UNSOAKED_POINTS = [
  { penetrationMm: 0.5, loadKn: 3.5 },
  { penetrationMm: 1, loadKn: 7.1 },
  { penetrationMm: 2, loadKn: 14.9 },
  { penetrationMm: 2.5, loadKn: 19.1 },
  { penetrationMm: 4, loadKn: 29.6 },
  { penetrationMm: 5, loadKn: 36.2 },
  { penetrationMm: 7.5, loadKn: 47.5 },
  { penetrationMm: 10, loadKn: 55.3 },
];

/** Interpolation fixture — no exact 2.5/5.0 mm points. */
const INTERP_POINTS = [
  { penetrationMm: 1, loadKn: 3.0 },
  { penetrationMm: 2, loadKn: 6.5 },
  { penetrationMm: 3, loadKn: 9.8 },
  { penetrationMm: 4, loadKn: 13.1 },
  { penetrationMm: 6, loadKn: 19.3 },
];

/** Concave-upward start fixture for the origin correction. */
const CONCAVE_UP_POINTS = [
  { penetrationMm: 0.5, loadKn: 0.2 },
  { penetrationMm: 1.0, loadKn: 0.9 },
  { penetrationMm: 2.0, loadKn: 3.4 },
  { penetrationMm: 3.0, loadKn: 6.6 },
  { penetrationMm: 5.0, loadKn: 13.3 },
  { penetrationMm: 7.5, loadKn: 21.2 },
];

/** Normal concave-down curve — correction requested but not applicable. */
const NORMAL_POINTS = [
  { penetrationMm: 0.5, loadKn: 3.0 },
  { penetrationMm: 1.0, loadKn: 5.6 },
  { penetrationMm: 2.0, loadKn: 10.2 },
  { penetrationMm: 4.0, loadKn: 17.8 },
  { penetrationMm: 7.5, loadKn: 27.4 },
];

// ---------------------------------------------------------------------------
// 1. Golden envelopes
// ---------------------------------------------------------------------------
{
  // C1 — soaked seed: exact hits; 5.0 mm governs; entered finals disagree.
  const outcome = runCalculation(cbrModule, {
    condition: "SOAKED", points: SOAKED_POINTS, ...SOAKED_ENTERED,
  });
  if (outcome.status !== "ok") no(`golden C1 — failed: ${outcome.error.message}`);
  else {
    const ruleWarnings = outcome.warnings.filter((w) => w.code === "REPORTING_RULE");
    const discWarnings = outcome.warnings.filter((w) => w.code === "ENTERED_VALUE_DISCREPANCY");
    const checks: Array<[boolean, string]> = [
      [outcome.results.condition === "SOAKED", "condition echoed (SOAKED)"],
      [outcome.raw.loadAt2_5Kn === 8.9, "raw load at 2.5 mm = 8.9 kN (exact hit)"],
      [outcome.raw.loadAt5_0Kn === 17.2, "raw load at 5.0 mm = 17.2 kN (exact hit)"],
      [approx(outcome.raw.cbrAt2_5 ?? 0, 67.22054380664652, 1e-9), "raw CBR2.5 ≈ 67.22054380664652 = 100 × 8.9/13.24"],
      [approx(outcome.raw.cbrAt5_0 ?? 0, 86.17234468937875, 1e-9), "raw CBR5.0 ≈ 86.17234468937875 = 100 × 17.2/19.96"],
      [approx(outcome.raw.cbrValue ?? 0, 86.17234468937875, 1e-12), "raw reported CBR = max = 86.172…"],
      [outcome.results.cbrAt2_5 === 67.22, "results CBR2.5 = 67.22 (2 dp)"],
      [outcome.results.cbrAt5_0 === 86.17, "results CBR5.0 = 86.17"],
      [outcome.results.cbrValue === 86.17, "results reported CBR = 86.17"],
      [outcome.results.reportedFrom === "5.0MM", "reported from 5.0MM"],
      [outcome.results.loadAt2_5Kn === 8.9, "results load 2.5 mm = 8.9 kN (3 dp)"],
      [outcome.results.swellPercent === 1.2, "swellPercent echoed (1.2)"],
      [outcome.results.enteredCbrAt2_5 === 18 && outcome.results.enteredCbrValue === 21, "entered finals echoed"],
      [outcome.results.originCorrectionApplied === false, "no correction applied by default"],
      [ruleWarnings.length === 1, "one REPORTING_RULE warning (5.0 mm value governs)"],
      [ruleWarnings[0].message.includes("repeated") || ruleWarnings[0].message.includes("repeat"), "REPORTING_RULE notes the standard's repeat directive"],
      [discWarnings.length === 3, "three ENTERED_VALUE_DISCREPANCY warnings (entered {18, 21, 21} vs computed)"],
      [outcome.warnings.length === 4, "exactly 4 warnings total"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`golden C1 — ${label}`);
      else no(`golden C1 — ${label}`);
    }
  }
}
{
  // C2 — unsoaked seed: computed CBR exceeds 100 % — reported unclamped.
  const outcome = runCalculation(cbrModule, {
    condition: "UNSOAKED", points: UNSOAKED_POINTS, cbrAt2_5: 45, cbrAt5_0: 38, cbrValue: 45,
  });
  if (outcome.status !== "ok") no(`golden C2 — failed: ${outcome.error.message}`);
  else {
    const checks: Array<[boolean, string]> = [
      [outcome.results.condition === "UNSOAKED", "condition echoed (UNSOAKED)"],
      [approx(outcome.raw.cbrAt2_5 ?? 0, 144.25981873111783, 1e-9), "raw CBR2.5 ≈ 144.25981873111783"],
      [approx(outcome.raw.cbrAt5_0 ?? 0, 181.36272545090182, 1e-9), "raw CBR5.0 ≈ 181.36272545090182"],
      [outcome.results.cbrAt2_5 === 144.26, "results CBR2.5 = 144.26 — ABOVE 100 %, reported unclamped (registry storage bound is 0–100)"],
      [outcome.results.cbrAt5_0 === 181.36, "results CBR5.0 = 181.36 unclamped"],
      [outcome.results.cbrValue === 181.36, "reported CBR = 181.36 (max rule)"],
      [outcome.results.reportedFrom === "5.0MM", "reported from 5.0MM"],
      [outcome.warnings.some((w) => w.code === "REPORTING_RULE"), "REPORTING_RULE warning present"],
      [outcome.warnings.filter((w) => w.code === "ENTERED_VALUE_DISCREPANCY").length === 3, "three entered-discrepancy warnings"],
      [outcome.results.swellPercent === null, "no swell for unsoaked test (null)"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`golden C2 — ${label}`);
      else no(`golden C2 — ${label}`);
    }
  }
}
{
  // C3 — interpolation: loads read between bracketing points.
  const outcome = runCalculation(cbrModule, {
    condition: "SOAKED", points: INTERP_POINTS,
  });
  if (outcome.status !== "ok") no(`golden C3 — failed: ${outcome.error.message}`);
  else {
    const checks: Array<[boolean, string]> = [
      [approx(outcome.raw.loadAt2_5Kn ?? 0, 8.15, 1e-12), "raw load at 2.5 mm ≈ 8.15 kN (interpolated 2→3 mm)"],
      [approx(outcome.raw.loadAt5_0Kn ?? 0, 16.2, 1e-12), "raw load at 5.0 mm ≈ 16.2 kN (interpolated 4→6 mm)"],
      [approx(outcome.raw.cbrAt2_5 ?? 0, 61.5558912386707, 1e-9), "raw CBR2.5 ≈ 61.5558912386707"],
      [approx(outcome.raw.cbrAt5_0 ?? 0, 81.1623246492986, 1e-9), "raw CBR5.0 ≈ 81.1623246492986"],
      [outcome.results.cbrAt2_5 === 61.56, "results CBR2.5 = 61.56"],
      [outcome.results.cbrAt5_0 === 81.16, "results CBR5.0 = 81.16"],
      [outcome.results.cbrValue === 81.16, "reported CBR = 81.16 (5.0 governs)"],
      [outcome.warnings.length === 1 && outcome.warnings[0].code === "REPORTING_RULE", "only the REPORTING_RULE warning"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`golden C3 — ${label}`);
      else no(`golden C3 — ${label}`);
    }
  }
}
{
  // C4 — origin correction (analyst-requested): steepest-segment line
  // (3.0, 6.6)→(5.0, 13.3) projected to zero load at 1.0299 mm.
  const outcome = runCalculation(cbrModule, {
    condition: "SOAKED", originCorrection: true, points: CONCAVE_UP_POINTS,
  });
  if (outcome.status !== "ok") no(`golden C4 — failed: ${outcome.error.message}`);
  else {
    const correctionWarnings = outcome.warnings.filter((w) => w.code === "CORRECTION_APPLIED");
    const checks: Array<[boolean, string]> = [
      [approx(outcome.raw.originShiftMm, 1.0298507462686572, 1e-9), "raw origin shift ≈ 1.0298507462686572 mm"],
      [outcome.results.originCorrectionApplied === true, "correctionApplied = true"],
      [correctionWarnings.length === 1, "one CORRECTION_APPLIED warning"],
      [outcome.raw.curve.length === 4, "corrected curve keeps 4 points (2 discarded before the corrected origin)"],
      [approx(outcome.raw.curve[0].penetrationMm, 0.9701492537313428, 1e-9), "corrected point[0] penetration ≈ 0.9701 mm"],
      [approx(outcome.raw.loadAt2_5Kn ?? 0, 8.375000000000002, 1e-9), "raw load at corrected 2.5 mm ≈ 8.375000000000002 kN"],
      [approx(outcome.raw.loadAt5_0Kn ?? 0, 16.554328358208956, 1e-9), "raw load at corrected 5.0 mm ≈ 16.554328358208956 kN"],
      [approx(outcome.raw.cbrAt2_5 ?? 0, 63.25528700906346, 1e-9), "raw CBR2.5 ≈ 63.25528700906346"],
      [approx(outcome.raw.cbrAt5_0 ?? 0, 82.93751682469417, 1e-9), "raw CBR5.0 ≈ 82.93751682469417"],
      [outcome.results.cbrAt2_5 === 63.26, "results CBR2.5 = 63.26"],
      [outcome.results.cbrAt5_0 === 82.94, "results CBR5.0 = 82.94"],
      [outcome.results.cbrValue === 82.94, "reported CBR = 82.94"],
      [outcome.results.curve[0].penetrationMm === 0.97, "results curve[0] penetration = 0.97 (3 dp)"],
      [outcome.warnings.length === 2, "two warnings (CORRECTION_APPLIED + REPORTING_RULE)"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`golden C4 — ${label}`);
      else no(`golden C4 — ${label}`);
    }
  }
}
{
  // C5 — correction requested but the curve has no origin error (shift ≤ 0):
  // no correction, INSUFFICIENT_DATA advisory, raw curve used.
  const outcome = runCalculation(cbrModule, {
    condition: "UNSOAKED", originCorrection: true, points: NORMAL_POINTS,
  });
  if (outcome.status !== "ok") no(`golden C5 — failed: ${outcome.error.message}`);
  else {
    const checks: Array<[boolean, string]> = [
      [outcome.raw.originShiftMm === 0, "no shift applied"],
      [outcome.results.originCorrectionApplied === false, "correctionApplied = false"],
      [outcome.warnings.some((w) => w.code === "INSUFFICIENT_DATA" && w.message.includes("no correction applied")), "INSUFFICIENT_DATA advisory (correction not applicable)"],
      [outcome.raw.curve.length === 5, "raw curve unchanged (5 points)"],
      [approx(outcome.raw.loadAt2_5Kn ?? 0, 12.1, 1e-12), "load at 2.5 mm ≈ 12.1 kN (interpolated 1→2 mm)"],
      [approx(outcome.raw.loadAt5_0Kn ?? 0, 20.542857142857144, 1e-9), "load at 5.0 mm ≈ 20.542857142857144 kN (interpolated 4→7.5 mm)"],
      [outcome.results.cbrAt2_5 === 91.39, "results CBR2.5 = 91.39"],
      [outcome.results.cbrAt5_0 === 102.92, "results CBR5.0 = 102.92 (unclamped)"],
      [outcome.results.cbrValue === 102.92, "reported CBR = 102.92"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`golden C5 — ${label}`);
      else no(`golden C5 — ${label}`);
    }
  }
}
{
  // C6 — both targets beyond the measured range: nulls + INSUFFICIENT_DATA.
  const outcome = runCalculation(cbrModule, {
    condition: "SOAKED", points: [{ penetrationMm: 0.5, loadKn: 1.2 }, { penetrationMm: 1.0, loadKn: 2.4 }, { penetrationMm: 2.0, loadKn: 4.6 }],
  });
  if (outcome.status !== "ok") no(`golden C6 — failed: ${outcome.error.message}`);
  else {
    const insuff = outcome.warnings.filter((w) => w.code === "INSUFFICIENT_DATA");
    const checks: Array<[boolean, string]> = [
      [outcome.results.cbrAt2_5 === null && outcome.results.cbrAt5_0 === null, "both CBR values null"],
      [outcome.results.cbrValue === null, "reported CBR null"],
      [outcome.results.reportedFrom === null, "reportedFrom null"],
      [insuff.length === 2, "two INSUFFICIENT_DATA warnings (2.5 and 5.0 mm out of range)"],
      [insuff.every((w) => w.message.includes("extrapolation")), "warnings name the no-extrapolation policy"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`golden C6 — ${label}`);
      else no(`golden C6 — ${label}`);
    }
  }
}
{
  // C7 — 2.5 mm before the measured range: CBR2.5 null; CBR5.0 computed and
  // reported alone.
  const outcome = runCalculation(cbrModule, {
    condition: "SOAKED", points: [{ penetrationMm: 3.0, loadKn: 9.0 }, { penetrationMm: 5.0, loadKn: 14.0 }, { penetrationMm: 7.5, loadKn: 20.0 }],
  });
  if (outcome.status !== "ok") no(`golden C7 — failed: ${outcome.error.message}`);
  else {
    const checks: Array<[boolean, string]> = [
      [outcome.results.cbrAt2_5 === null, "CBR2.5 null (below range)"],
      [outcome.raw.loadAt5_0Kn === 14, "load at 5.0 mm = 14 kN (exact hit)"],
      [approx(outcome.raw.cbrAt5_0 ?? 0, 70.14028056112224, 1e-9), "raw CBR5.0 ≈ 70.14028056112224"],
      [outcome.results.cbrValue === 70.14, "reported CBR = 70.14 (single available value)"],
      [outcome.results.reportedFrom === "5.0MM", "reported from 5.0MM (single)"],
      [outcome.warnings.filter((w) => w.code === "INSUFFICIENT_DATA").length === 1, "one INSUFFICIENT_DATA warning"],
      [outcome.warnings.filter((w) => w.code === "REPORTING_RULE").length === 0, "no REPORTING_RULE (nothing to compare)"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`golden C7 — ${label}`);
      else no(`golden C7 — ${label}`);
    }
  }
}
{
  // Entered-tolerance boundary: entered cbrAt2_5 = 67.22 vs computed
  // 67.22054… → |Δ| = 0.0005 ≤ 0.01 → NO warning; entered 67.24 → |Δ| =
  // 0.0195 > 0.01 → warning.
  const clean = runCalculation(cbrModule, {
    condition: "SOAKED", points: SOAKED_POINTS, cbrAt2_5: 67.22,
  });
  if (clean.status === "ok" && !clean.warnings.some((w) => w.details?.field === "cbrAt2_5")) {
    ok("entered tolerance — cbrAt2_5 67.22 (|Δ| = 0.0005): no warning");
  } else {
    no("entered tolerance — cbrAt2_5 67.22 should not warn");
  }
  const dirty = runCalculation(cbrModule, {
    condition: "SOAKED", points: SOAKED_POINTS, cbrAt2_5: 67.24,
  });
  if (dirty.status === "ok" && dirty.warnings.some((w) => w.details?.field === "cbrAt2_5" && w.code === "ENTERED_VALUE_DISCREPANCY")) {
    ok("entered tolerance — cbrAt2_5 67.24 (|Δ| = 0.0195 > 0.01): warning");
  } else {
    no("entered tolerance — cbrAt2_5 67.24 should warn");
  }
}

// ---------------------------------------------------------------------------
// 2. Registry mirrors and validation
// ---------------------------------------------------------------------------
{
  const outcome = runCalculation(cbrModule, {
    condition: "SOAKED", points: SOAKED_POINTS, cbrAt2_5: 18, cbrAt5_0: 21, cbrValue: 30,
  });
  expectError(outcome, "entered cbrValue ≠ max identity (registry mirror)", {
    code: "INVALID_INPUT",
    fieldPath: "cbrValue",
    messageHint: "max(cbrAt2_5, cbrAt5_0)",
  });
}
{
  const outcome = runCalculation(cbrModule, {
    condition: "SOAKED",
    points: [
      { penetrationMm: 2.5, loadKn: 8.9 },
      { penetrationMm: 2.5, loadKn: 9.1 },
      { penetrationMm: 5, loadKn: 17.2 },
    ],
  });
  expectError(outcome, "duplicate penetration (registry mirror + ordering)", {
    code: "INVALID_INPUT",
    fieldPath: "points.1.penetrationMm",
    messageHint: "strictly increasing",
  });
}
{
  const outcome = runCalculation(cbrModule, {
    condition: "SOAKED",
    points: [
      { penetrationMm: 5, loadKn: 17.2 },
      { penetrationMm: 2.5, loadKn: 8.9 },
      { penetrationMm: 1, loadKn: 3.2 },
    ],
  });
  expectError(outcome, "unordered points (module ordering rule)", {
    code: "INVALID_INPUT",
    fieldPath: "points.1.penetrationMm",
    messageHint: "strictly increasing",
  });
}
{
  const outcome = runCalculation(cbrModule, {
    condition: "SOAKED",
    points: [{ penetrationMm: 16, loadKn: 8.9 }, { penetrationMm: 17, loadKn: 9.1 }],
  });
  expectError(outcome, "penetration 16 out of bounds", { code: "INVALID_INPUT", messageHint: "15" });
}
{
  const outcome = runCalculation(cbrModule, {
    condition: "SOAKED",
    points: [{ penetrationMm: 1, loadKn: 61 }, { penetrationMm: 2, loadKn: 62 }],
  });
  expectError(outcome, "loadKn 61 out of bounds", { code: "INVALID_INPUT", messageHint: "60" });
}
{
  const outcome = runCalculation(cbrModule, {
    condition: "SOAKED", points: SOAKED_POINTS, swellPercent: 16,
  });
  expectError(outcome, "swellPercent 16 out of bounds", { code: "INVALID_INPUT", messageHint: "15" });
}
{
  const outcome = runCalculation(cbrModule, {
    condition: "SOAKED", points: [{ penetrationMm: 2.5, loadKn: 8.9 }],
  });
  expectError(outcome, "1 point (min 2)", { code: "INVALID_INPUT" });
}
{
  const outcome = runCalculation(cbrModule, {
    condition: "SOAKED",
    points: Array.from({ length: 21 }, (_, i) => ({ penetrationMm: i * 0.5, loadKn: i })),
  });
  expectError(outcome, "21 points (max 20)", { code: "INVALID_INPUT" });
}
{
  const outcome = runCalculation(cbrModule, {
    condition: "SOAKED",
    points: [{ penetrationMm: 1, loadKn: Number.NaN }, { penetrationMm: 2, loadKn: 3.2 }],
  });
  expectError(outcome, "NaN load", { code: "INVALID_INPUT" });
}
{
  const outcome = runCalculation(cbrModule, {
    condition: "SOAKED",
    points: [{ penetrationMm: "1", loadKn: 3.2 }, { penetrationMm: 2, loadKn: 3.4 }] as unknown as CbrInput["points"],
  });
  expectError(outcome, "string penetration", { code: "INVALID_INPUT" });
}
{
  const outcome = runCalculation(cbrModule, {});
  expectError(outcome, "empty payload", { code: "MISSING_INPUT", messageHint: "condition, points" });
}
{
  const outcome = runCalculation(cbrModule, { condition: "SOAKED" });
  expectError(outcome, "condition only", { code: "MISSING_INPUT", messageHint: "points" });
}
{
  const outcome = runCalculation(cbrModule, { points: SOAKED_POINTS } as { points: unknown });
  expectError(outcome, "points only (no condition)", { code: "MISSING_INPUT", messageHint: "condition" });
}
{
  const outcome = runCalculation(cbrModule, {
    condition: "MOIST", points: SOAKED_POINTS,
  } as unknown as { condition: string });
  expectError(outcome, "unknown condition value", { code: "INVALID_INPUT" });
}

// ---------------------------------------------------------------------------
// 3. Direct helper tests
// ---------------------------------------------------------------------------
{
  const pts = [{ penetrationMm: 1, loadKn: 2 }, { penetrationMm: 3, loadKn: 6 }];
  if (loadAtPenetration(pts, 0.5) === null) ok("helper — target below range returns null");
  else no("helper — target below range should return null");
  if (loadAtPenetration(pts, 4) === null) ok("helper — target above range returns null");
  else no("helper — target above range should return null");
  if (loadAtPenetration(pts, 3) === 6) ok("helper — exact hit returns the measured load");
  else no("helper — exact hit failed");
  const interp = loadAtPenetration(pts, 2);
  if (interp !== null && approx(interp, 4, 1e-12)) ok("helper — midpoint interpolation = 4 kN");
  else no(`helper — midpoint interpolation = ${String(interp)}`);
}
{
  const r = applyOriginCorrection(NORMAL_POINTS);
  if (r.shiftMm === 0 && r.curve.length === 5) ok("helper — no origin error: shift 0, curve unchanged");
  else no(`helper — no-origin-error case wrong: shift ${r.shiftMm}`);
}
{
  const r = applyOriginCorrection(CONCAVE_UP_POINTS);
  if (approx(r.shiftMm, 1.0298507462686572, 1e-9) && r.curve.length === 4 && r.steepestSegmentIndex === 3) {
    ok("helper — concave-up correction: shift ≈ 1.0299, 4 points kept, steepest segment 3");
  } else {
    no(`helper — concave-up correction wrong: shift ${r.shiftMm}, ${r.curve.length} pts, seg ${r.steepestSegmentIndex}`);
  }
}

// ---------------------------------------------------------------------------
// 4. Schema stripping
// ---------------------------------------------------------------------------
{
  const parsed = cbrCalcInput.safeParse({
    condition: "SOAKED", points: SOAKED_POINTS, surchargeKg: 4.5, soakingDays: 4, notes: "extra",
  });
  if (parsed.success && !("surchargeKg" in parsed.data) && !("notes" in parsed.data)) {
    ok("schema — registry input fields (surchargeKg, soakingDays, notes) stripped from the calculable contract");
  } else {
    no("schema — stripping failed");
  }
}

// ---------------------------------------------------------------------------
// 5. M5.1 registry compatibility — parity and documented divergences
// ---------------------------------------------------------------------------
{
  // Shared valid: the full registry-shaped payload passes both.
  const payload = {
    condition: "SOAKED" as const,
    points: SOAKED_POINTS,
    cbrAt2_5: 18,
    cbrAt5_0: 21,
    cbrValue: 21,
    swellPercent: 1.2,
  };
  const moduleOutcome = runCalculation(cbrModule, payload);
  const registryOutcome = parseLabTestResult("CBR", payload);
  const checks: Array<[boolean, string]> = [
    [moduleOutcome.status === "ok", "shared valid — module accepts the registry-shaped payload"],
    [registryOutcome.ok, "shared valid — registry result schema accepts it"],
  ];
  // Computed finals revalidate through the registry ONLY when within the
  // 0–100 storage bound: C1 computed (67.22, 86.17, 86.17) is in-bounds.
  if (moduleOutcome.status === "ok") {
    const computedPayload = {
      condition: "SOAKED" as const,
      points: moduleOutcome.results.curve,
      cbrAt2_5: moduleOutcome.results.cbrAt2_5 ?? 0,
      cbrAt5_0: moduleOutcome.results.cbrAt5_0 ?? 0,
      cbrValue: moduleOutcome.results.cbrValue ?? 0,
    };
    const revalidated = parseLabTestResult("CBR", computedPayload);
    checks.push([revalidated.ok, `computed finals (67.22/86.17/86.17) revalidate through the registry${revalidated.ok ? "" : `: ${revalidated.error}`}`]);
  }
  for (const [condition, label] of checks) {
    if (condition) ok(`parity — ${label}`);
    else no(`parity — ${label}`);
  }
}
{
  // Shared invalid (both reject): cbrValue identity violation.
  const payload = { condition: "SOAKED" as const, points: SOAKED_POINTS, cbrAt2_5: 18, cbrAt5_0: 21, cbrValue: 30 };
  const moduleOutcome = runCalculation(cbrModule, payload);
  const registryOutcome = parseLabTestResult("CBR", payload);
  if (moduleOutcome.status === "error" && !registryOutcome.ok) ok("shared invalid — cbrValue identity violation: both reject");
  else no(`shared invalid — identity: module ${moduleOutcome.status}, registry ok=${registryOutcome.ok}`);
}
{
  // Shared invalid (both reject): duplicate penetrations.
  const payload = {
    condition: "SOAKED" as const,
    points: [{ penetrationMm: 2.5, loadKn: 8.9 }, { penetrationMm: 2.5, loadKn: 9.1 }, { penetrationMm: 5, loadKn: 17.2 }],
    cbrAt2_5: 18, cbrAt5_0: 21, cbrValue: 21,
  };
  const moduleOutcome = runCalculation(cbrModule, payload);
  const registryOutcome = parseLabTestResult("CBR", payload);
  if (moduleOutcome.status === "error" && !registryOutcome.ok) ok("shared invalid — duplicate penetrations: both reject");
  else no(`shared invalid — duplicates: module ${moduleOutcome.status}, registry ok=${registryOutcome.ok}`);
}
{
  // Shared invalid (both reject): bounds (penetration 16 / load 61 / swell 16).
  const bad1 = { condition: "SOAKED" as const, points: [{ penetrationMm: 16, loadKn: 8.9 }, { penetrationMm: 17, loadKn: 9 }], cbrAt2_5: 18, cbrAt5_0: 21, cbrValue: 21 };
  const bad2 = { condition: "SOAKED" as const, points: [{ penetrationMm: 1, loadKn: 61 }, { penetrationMm: 2, loadKn: 62 }], cbrAt2_5: 18, cbrAt5_0: 21, cbrValue: 21 };
  const m1 = runCalculation(cbrModule, bad1);
  const r1 = parseLabTestResult("CBR", bad1);
  const m2 = runCalculation(cbrModule, bad2);
  const r2 = parseLabTestResult("CBR", bad2);
  if (m1.status === "error" && !r1.ok) ok("shared invalid — penetration 16: both reject");
  else no(`shared invalid — penetration 16: module ${m1.status}, registry ok=${r1.ok}`);
  if (m2.status === "error" && !r2.ok) ok("shared invalid — load 61: both reject");
  else no(`shared invalid — load 61: module ${m2.status}, registry ok=${r2.ok}`);
}
{
  // Documented divergence 1 — unordered points: registry stores (it only
  // checks uniqueness), module rejects (ordering rule).
  const payload = {
    condition: "SOAKED" as const,
    points: [{ penetrationMm: 5, loadKn: 17.2 }, { penetrationMm: 2.5, loadKn: 8.9 }, { penetrationMm: 1, loadKn: 3.2 }],
    cbrAt2_5: 18, cbrAt5_0: 21, cbrValue: 21,
  };
  const moduleOutcome = runCalculation(cbrModule, payload);
  const registryOutcome = parseLabTestResult("CBR", payload);
  if (moduleOutcome.status === "error" && registryOutcome.ok) ok("divergence — unordered points: registry stores, module rejects");
  else no(`divergence — unordered: module ${moduleOutcome.status}, registry ok=${registryOutcome.ok}`);
}
{
  // Documented divergence 2 — computed CBR above 100 %: reported unclamped;
  // the registry storage bound (0–100) rejects persisting it.
  const outcome = runCalculation(cbrModule, { condition: "UNSOAKED", points: UNSOAKED_POINTS });
  if (outcome.status !== "ok") no(`divergence — unsoaked run failed`);
  else {
    const computedPayload = {
      condition: "UNSOAKED" as const,
      points: outcome.results.curve,
      cbrAt2_5: outcome.results.cbrAt2_5 ?? 0,
      cbrAt5_0: outcome.results.cbrAt5_0 ?? 0,
      cbrValue: outcome.results.cbrValue ?? 0,
    };
    const revalidated = parseLabTestResult("CBR", computedPayload);
    if (outcome.results.cbrAt2_5 === 144.26 && !revalidated.ok) {
      ok("divergence — computed CBR 144.26 reported unclamped; registry storage bound rejects it (engine advises, registry gates)");
    } else {
      no(`divergence — unclamped reporting failed: cbr ${outcome.results.cbrAt2_5}, registry ok=${revalidated.ok}`);
    }
  }
}
{
  // Documented divergence 3 — points below the required registry minimum of
  // results shape: the module accepts 2 points (its own minimum), the
  // registry also accepts (2–20) — shared bound; instead document the
  // condition distinction: soaked vs unsoaked carried in every result.
  const soaked = runCalculation(cbrModule, { condition: "SOAKED", points: INTERP_POINTS });
  const unsoaked = runCalculation(cbrModule, { condition: "UNSOAKED", points: INTERP_POINTS });
  if (soaked.status === "ok" && unsoaked.status === "ok" &&
      soaked.results.condition === "SOAKED" && unsoaked.results.condition === "UNSOAKED" &&
      JSON.stringify(soaked.raw) === JSON.stringify(unsoaked.raw)) {
    ok("condition distinction — identical loads give identical raw values; the condition is echoed (never mixed)");
  } else {
    no("condition distinction failed");
  }
}

// ---------------------------------------------------------------------------
// 6. Determinism, purity, envelope
// ---------------------------------------------------------------------------
{
  const payload = { condition: "SOAKED", points: SOAKED_POINTS, ...SOAKED_ENTERED };
  const first = runCalculation(cbrModule, payload);
  let allEqual = true;
  for (let i = 0; i < 25; i++) {
    if (JSON.stringify(runCalculation(cbrModule, payload)) !== JSON.stringify(first)) allEqual = false;
  }
  if (allEqual) ok("determinism — 25 runs deeply identical (warning path)");
  else no("determinism — warning path outputs differ");
}
{
  const payload = { condition: "SOAKED", originCorrection: true, points: CONCAVE_UP_POINTS };
  const first = runCalculation(cbrModule, payload);
  let allEqual = true;
  for (let i = 0; i < 25; i++) {
    if (JSON.stringify(runCalculation(cbrModule, payload)) !== JSON.stringify(first)) allEqual = false;
  }
  if (allEqual) ok("determinism — 25 runs deeply identical (correction path)");
  else no("determinism — correction path outputs differ");
}
{
  const payload = {
    condition: "SOAKED" as const,
    points: [
      { penetrationMm: 0.5, loadKn: 1.6 },
      { penetrationMm: 1, loadKn: 3.2 },
      { penetrationMm: 2, loadKn: 6.8 },
      { penetrationMm: 2.5, loadKn: 8.9 },
      { penetrationMm: 4, loadKn: 14.1 },
      { penetrationMm: 5, loadKn: 17.2 },
    ],
  };
  const snapshot = JSON.stringify(payload);
  runCalculation(cbrModule, payload);
  if (JSON.stringify(payload) === snapshot) ok("purity — input payload never mutated");
  else no("purity — input payload mutated");
}
{
  const outcome = runCalculation(cbrModule, { condition: "SOAKED", points: SOAKED_POINTS });
  if (outcome.status !== "ok") no(`envelope — failed: ${outcome.error.message}`);
  else {
    const checks: Array<[boolean, string]> = [
      [outcome.engineVersion === "1.0.0", "engineVersion = 1.0.0"],
      [outcome.moduleId === "cbr", "moduleId = cbr"],
      [outcome.moduleVersion === "1.0.0", "moduleVersion = 1.0.0"],
      [outcome.testType === "CBR", "testType = CBR"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`envelope — ${label}`);
      else no(`envelope — ${label}`);
    }
  }
}
{
  // Constant provenance sanity: the standard loads consumed are the
  // governed VERIFIED values (13.24 / 19.96 kN) — verified in the constants
  // suite; here assert the arithmetic identity CBR × standard = 100 × load.
  const outcome = runCalculation(cbrModule, { condition: "SOAKED", points: SOAKED_POINTS });
  if (outcome.status === "ok") {
    const identity = approx((outcome.raw.cbrAt2_5 ?? 0) * 13.24, 100 * 8.9, 1e-9);
    if (identity) ok("unit consistency — CBR2.5 × 13.24 kN = 100 × 8.9 kN (identity at full precision)");
    else no("unit consistency — standard-load identity failed");
  }
}

console.log(`\n================ M5.2-e CBR TEST SUMMARY: ${pass} passed, ${fail} failed ================`);
process.exit(fail);
