/**
 * M5.2-b TEST — Granulometry (PSD) calculation module.
 *
 * Golden values independently verified BEFORE being asserted here (high-
 * precision Decimal + exact Fraction + IEEE-double probes in
 * scripts/m5.2-b-verify-goldens.py). Sources: authorization M5.2-b §3/§5,
 * registry granulometryResult contract, prisma/seed.ts PSD fixtures
 * (GRAN_DUNE_SAND, GRAN_SANDY_SILT, GRAN_SILTY_CLAY — reordered ascending).
 *
 * Coverage (authorization §5): exact measured D10/D30/D60; log-linear
 * interpolation between sieve points; Cu and Cc; percentage passing 0.075 mm;
 * coarse/fine split at 4.75 mm; missing target range (reject, no
 * extrapolation); duplicate diameters; duplicate percentages causing
 * ambiguous interpolation; unordered points; zero/negative diameter;
 * percentages outside 0–100; insufficient points; NaN/Infinity and overflow
 * protection; deterministic output across repeated runs. Plus: tolerance
 * boundaries, entered-identity mirror, M5.1 registry parity with the
 * documented divergences, purity and envelope provenance.
 *
 * Intermediates and tolerances (from the verifier, Decimal 60-digit):
 *   Curve A: D10 t=5/9 in (0.05,5)–(0.10,14); D30 t=16/16.5 in
 *     (0.10,14)–(0.20,30.5); D60 t=0.2 in (0.80,58)–(1.60,68);
 *     P(0.075): t=ln(1.5)/ln(2)=0.5849625; P(4.75): t=ln(1.484375)/ln(2).
 *   Curve B: exact hits; Cu=425/53; Cc=625/901.
 *   Raw values asserted at 1e-9 against double probes; rounded results
 *   asserted exactly (tie distances ≥ 1e-2 — no rounding-tie sensitivity).
 * Exit code = number of failures.
 */
import { runCalculation } from "../src/lib/calc/engine";
import type { CalculationOutcome } from "../src/lib/calc/types";
import {
  granulometryModule,
  interpolatePercentAtDiameter,
  type GranulometryInput,
  type GranulometryRaw,
  type GranulometryResults,
} from "../src/lib/calc/modules/granulometry";
import { parseLabTestResult } from "../src/lib/lab-tests/registry";

let pass = 0;
let fail = 0;
const ok = (m: string) => { console.log(`PASS: ${m}`); pass++; };
const no = (m: string) => { console.log(`FAIL: ${m}`); fail++; };

const approx = (actual: number, expected: number, tol: number): boolean =>
  Math.abs(actual - expected) <= tol;

type Outcome = CalculationOutcome<GranulometryInput, GranulometryRaw, GranulometryResults>;

interface ExpectedError {
  code: string;
  fieldPath?: string;
  messageHint?: string;
}

function expectError(outcome: Outcome, label: string, expected: ExpectedError): void {
  if (outcome.status !== "error") {
    no(`${label} — expected ${expected.code}, got success`);
    return;
  }
  const { code, message, details } = outcome.error;
  if (code !== expected.code) {
    no(`${label} — expected ${expected.code}, got ${code}`);
    return;
  }
  if (expected.fieldPath !== undefined && details?.fieldPath !== expected.fieldPath) {
    no(`${label} — expected fieldPath ${expected.fieldPath}, got ${String(details?.fieldPath)}`);
    return;
  }
  if (expected.messageHint !== undefined && !message.includes(expected.messageHint)) {
    no(`${label} — message '${message}' lacks hint '${expected.messageHint}'`);
    return;
  }
  ok(`${label} — ${code}${expected.fieldPath ? ` @ ${expected.fieldPath}` : ""}`);
}

/** point-list helper: [[d, p], ...] → contract points (ascending by construction) */
const pts = (pairs: ReadonlyArray<readonly [number, number]>): GranulometryPointLike[] =>
  pairs.map(([diameterMm, percentFiner]) => ({ diameterMm, percentFiner }));
interface GranulometryPointLike { diameterMm: number; percentFiner: number }

// ---------------------------------------------------------------------------
// Fixtures (all ascending; seed fixtures reordered from prisma/seed.ts)
// ---------------------------------------------------------------------------
// Curve A — primary log-linear interpolation golden (no exact hits).
const CURVE_A = pts([
  [0.05, 5.0], [0.10, 14.0], [0.20, 30.5], [0.40, 46.0], [0.80, 58.0],
  [1.60, 68.0], [3.20, 79.0], [6.40, 90.0], [12.8, 100.0],
]);
// Curve B — exact measured hits for every required indicator.
const CURVE_B = pts([
  [0.075, 3.0], [0.106, 10.0], [0.180, 19.0], [0.250, 30.0], [0.420, 41.0],
  [0.850, 60.0], [2.000, 82.0], [4.750, 92.0], [9.500, 100.0],
]);
// Curve P — power-of-two exact values + unsupported (null) indicators.
const CURVE_P = pts([
  [0.125, 10], [0.25, 30], [0.5, 60], [1, 85], [2, 95], [4, 100],
]);
// Curve N — registry noise tolerance (0.005 decrease accepted).
const CURVE_N = pts([
  [0.05, 5.005], [0.10, 5.000], [0.20, 20.0], [0.40, 45.0], [0.80, 58.0],
  [1.60, 68.0], [3.20, 79.0], [6.40, 90.0],
]);
// Seed GRAN_DUNE_SAND (ascending) with its entered values.
const DUNE = pts([
  [0.063, 2], [0.125, 6], [0.25, 24], [0.5, 62], [1, 91], [2, 99], [4, 100],
]);
const DUNE_ENTERED = { d10: 0.14, d30: 0.21, d60: 0.32, uniformityCoefficient: 2.29, coefficientOfCurvature: 0.98 };
// Seed GRAN_SANDY_SILT (ascending) with its entered values.
const SILT = pts([
  [0.002, 5], [0.006, 8], [0.02, 13], [0.063, 20], [0.125, 27], [0.25, 38],
  [0.5, 52], [1, 66], [2, 78], [4, 87], [8, 93], [16, 97], [31.5, 99], [63, 100],
]);
const SILT_ENTERED = { d10: 0.05, d30: 0.25, d60: 1.5, uniformityCoefficient: 30, coefficientOfCurvature: 0.83 };
// Seed GRAN_SILTY_CLAY (ascending) — fine curve, D10 below measured range.
const CLAY = pts([
  [0.001, 21], [0.002, 27], [0.006, 41], [0.02, 62], [0.063, 88], [0.125, 93],
  [0.25, 96], [0.5, 98], [1, 99], [2, 100],
]);

// ---------------------------------------------------------------------------
// 1. Golden A — log-linear interpolation (all three percentiles interpolated)
// ---------------------------------------------------------------------------
{
  const outcome = runCalculation(granulometryModule, { points: CURVE_A });
  if (outcome.status !== "ok") {
    no(`golden A — failed: ${outcome.error.message}`);
  } else {
    const checks: Array<[boolean, string]> = [
      // Intermediates (verifier): t(d10)=5/9, t(d30)=16/16.5, t(d60)=0.2;
      // D10=0.0734867246137799, D30=0.1958429194492, D60=0.918958683997628.
      [outcome.results.d10 === 0.0735, "results.d10 = 0.0735 (4 dp)"],
      [outcome.results.d30 === 0.1958, "results.d30 = 0.1958 (4 dp)"],
      [outcome.results.d60 === 0.919, "results.d60 = 0.919 (4 dp)"],
      [outcome.results.uniformityCoefficient === 12.505, "results.Cu = 12.505 (3 dp)"],
      [outcome.results.coefficientOfCurvature === 0.568, "results.Cc = 0.568 (3 dp)"],
      [outcome.results.percentPassing0075Mm === 10.26, "results.P(0.075) = 10.26 (2 dp)"],
      [outcome.results.percentPassing475Mm === 85.27, "results.P(4.75) = 85.27 (2 dp)"],
      [outcome.results.percentCoarserThan475Mm === 14.73, "results.coarser(4.75) = 14.73 (2 dp)"],
      [approx(outcome.raw.d10, 0.0734867246137799, 1e-9), "raw.d10 full precision ≈ 0.0734867246137799"],
      [approx(outcome.raw.d30, 0.1958429194492, 1e-9), "raw.d30 full precision ≈ 0.1958429194492"],
      [approx(outcome.raw.d60, 0.918958683997628, 1e-9), "raw.d60 full precision ≈ 0.918958683997628"],
      [approx(outcome.raw.uniformityCoefficient, 12.5050978775738, 1e-9), "raw.Cu full precision ≈ 12.5050978775738"],
      [approx(outcome.raw.coefficientOfCurvature, 0.567951004807257, 1e-9), "raw.Cc full precision ≈ 0.567951004807257"],
      [approx(outcome.raw.percentPassing0075Mm ?? NaN, 10.2646625064904, 1e-9), "raw.P(0.075) full precision ≈ 10.2646625064904"],
      [approx(outcome.raw.percentPassing475Mm ?? NaN, 85.2684116916404, 1e-9), "raw.P(4.75) full precision ≈ 85.2684116916404"],
      [approx(outcome.raw.percentCoarserThan475Mm ?? NaN, 14.7315883083596, 1e-9), "raw.coarser(4.75) = 100 − P full precision"],
      [outcome.raw.d10 !== outcome.results.d10, "raw NOT rounded (raw ≠ results value)"],
      [outcome.warnings.length === 0, "no warnings (no entered values)"],
      [outcome.results.enteredD10 === null && outcome.results.enteredD30 === null &&
        outcome.results.enteredD60 === null && outcome.results.enteredUniformityCoefficient === null &&
        outcome.results.enteredCoefficientOfCurvature === null, "entered echoes are null when absent (missing vs present preserved)"],
      [JSON.stringify(outcome.input) === JSON.stringify({ points: CURVE_A }), "input echo — parsed points echoed verbatim"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`golden A — ${label}`);
      else no(`golden A — ${label}`);
    }
  }
}

// ---------------------------------------------------------------------------
// 2. Golden B — exact measured D10/D30/D60 and exact indicator diameters
// ---------------------------------------------------------------------------
{
  const outcome = runCalculation(granulometryModule, { points: CURVE_B });
  if (outcome.status !== "ok") {
    no(`golden B — failed: ${outcome.error.message}`);
  } else {
    const checks: Array<[boolean, string]> = [
      // Exact hits: D10=0.106, D30=0.25, D60=0.85 (measured points);
      // Cu = 0.85/0.106 = 425/53 = 8.018867924528301; Cc = 625/901 = 0.693673695893452.
      [outcome.raw.d10 === 0.106, "raw.d10 === 0.106 EXACT (measured point, no interpolation)"],
      [outcome.raw.d30 === 0.25, "raw.d30 === 0.25 EXACT"],
      [outcome.raw.d60 === 0.85, "raw.d60 === 0.85 EXACT"],
      [approx(outcome.raw.uniformityCoefficient, 425 / 53, 1e-12), "raw.Cu = 425/53 (exact rational) ≈ 8.018867924528302"],
      [approx(outcome.raw.coefficientOfCurvature, 625 / 901, 1e-12), "raw.Cc = 625/901 (exact rational) ≈ 0.693673695893452"],
      [outcome.results.d10 === 0.106, "results.d10 = 0.106 (4 dp of exact hit)"],
      [outcome.results.d30 === 0.25, "results.d30 = 0.25"],
      [outcome.results.d60 === 0.85, "results.d60 = 0.85"],
      [outcome.results.uniformityCoefficient === 8.019, "results.Cu = 8.019 (3 dp)"],
      [outcome.results.coefficientOfCurvature === 0.694, "results.Cc = 0.694 (3 dp)"],
      [outcome.results.percentPassing0075Mm === 3, "results.P(0.075) = 3 EXACT (0.075 is a measured diameter)"],
      [outcome.results.percentPassing475Mm === 92, "results.P(4.75) = 92 EXACT (4.75 is a measured diameter)"],
      [outcome.results.percentCoarserThan475Mm === 8, "results.coarser(4.75) = 8 EXACT"],
      [outcome.warnings.length === 0, "no warnings"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`golden B — ${label}`);
      else no(`golden B — ${label}`);
    }
  }
}

// ---------------------------------------------------------------------------
// 3. Golden P — power-of-two exact values; unsupported indicators are null
// ---------------------------------------------------------------------------
{
  const outcome = runCalculation(granulometryModule, { points: CURVE_P });
  if (outcome.status !== "ok") {
    no(`golden P — failed: ${outcome.error.message}`);
  } else {
    const checks: Array<[boolean, string]> = [
      [outcome.raw.d10 === 0.125 && outcome.raw.d30 === 0.25 && outcome.raw.d60 === 0.5, "raw d10/d30/d60 = 0.125/0.25/0.5 (exact binary hits)"],
      [outcome.raw.uniformityCoefficient === 4, "raw.Cu === 4 EXACT (0.5/0.125)"],
      [outcome.raw.coefficientOfCurvature === 1, "raw.Cc === 1 EXACT ((0.25/0.125)×(0.25/0.5))"],
      [outcome.results.percentPassing0075Mm === null, "P(0.075) = null — 0.075 < 0.125 (min measured diameter), never extrapolated"],
      [outcome.results.percentPassing475Mm === null, "P(4.75) = null — 4.75 > 4 (max measured diameter), never extrapolated"],
      [outcome.results.percentCoarserThan475Mm === null, "coarser(4.75) = null — split unsupported"],
      [outcome.raw.percentPassing0075Mm === null && outcome.raw.percentPassing475Mm === null, "raw indicator nulls preserved (missing ≠ invalid)"],
      [outcome.warnings.length === 0, "no warnings"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`golden P — ${label}`);
      else no(`golden P — ${label}`);
    }
  }
}

// ---------------------------------------------------------------------------
// 4. Curve N — registry noise tolerance (0.005 decrease accepted, correct bracket)
// ---------------------------------------------------------------------------
{
  const outcome = runCalculation(granulometryModule, { points: CURVE_N });
  if (outcome.status !== "ok") {
    no(`curve N — failed: ${outcome.error.message}`);
  } else {
    const checks: Array<[boolean, string]> = [
      // Decrease 5.005 → 5.000 (0.005 ≤ 0.01) is registry-tolerated noise;
      // D10 t = (10−5)/15 = 1/3 in (0.10,5)–(0.20,20) → 0.10 × 2^(1/3).
      [outcome.results.d10 === 0.126, "results.d10 = 0.126 (4 dp; noise-tolerated curve, anchored bracket)"],
      [approx(outcome.raw.d10, 0.125992104989487, 1e-9), "raw.d10 ≈ 0.125992104989487 (0.10 × 2^(1/3))"],
      [outcome.results.d30 === 0.2639, "results.d30 = 0.2639"],
      [outcome.results.d60 === 0.919, "results.d60 = 0.919"],
      [outcome.warnings.length === 0, "no warnings"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`curve N — ${label}`);
      else no(`curve N — ${label}`);
    }
  }
}

// ---------------------------------------------------------------------------
// 5. Seed DUNE_SAND — entered-value discrepancy warnings (advisory, no overwrite)
// ---------------------------------------------------------------------------
{
  const outcome = runCalculation(granulometryModule, { points: DUNE, ...DUNE_ENTERED });
  if (outcome.status !== "ok") {
    no(`dune sand — failed: ${outcome.error.message}`);
  } else {
    const checks: Array<[boolean, string]> = [
      // Verifier: D10=0.145816129947015 (Δ +0.0058 ≤ 0.05 → no warning),
      // D30=0.278914479440386 (Δ +0.0689 → warning), D60=0.482087998971248
      // (Δ +0.1621 → warning), Cu=3.30613629059024 (Δ +1.0161 → warning),
      // Cc=1.10664985966958 (Δ +0.1266 → warning).
      [outcome.results.d10 === 0.1458, "results.d10 = 0.1458"],
      [outcome.results.d30 === 0.2789, "results.d30 = 0.2789"],
      [outcome.results.d60 === 0.4821, "results.d60 = 0.4821"],
      [outcome.results.uniformityCoefficient === 3.306, "results.Cu = 3.306"],
      [outcome.results.coefficientOfCurvature === 1.107, "results.Cc = 1.107"],
      [outcome.warnings.length === 4, "exactly 4 warnings (d30, d60, Cu, Cc — d10 within tolerance)"],
      [outcome.warnings.every((w) => w.code === "ENTERED_VALUE_DISCREPANCY"), "all warnings are ENTERED_VALUE_DISCREPANCY"],
      [outcome.warnings.map((w) => w.details?.field).join(",") === "d30,d60,uniformityCoefficient,coefficientOfCurvature", "deterministic warning order (d10 skipped)"],
      [outcome.results.percentPassing0075Mm === 3.02, "results.P(0.075) = 3.02 (interpolated)"],
      [outcome.results.percentPassing475Mm === null, "results.P(4.75) = null — max measured diameter is 4 mm"],
      [outcome.results.percentCoarserThan475Mm === null, "results.coarser(4.75) = null"],
      [outcome.results.enteredD10 === 0.14 && outcome.results.enteredD30 === 0.21 &&
        outcome.results.enteredD60 === 0.32, "entered d-values echoed unchanged (never overwritten)"],
      [outcome.results.enteredUniformityCoefficient === 2.29 && outcome.results.enteredCoefficientOfCurvature === 0.98, "entered coefficients echoed unchanged"],
      [approx(outcome.raw.percentPassing0075Mm ?? NaN, 3.01785597263419, 1e-9), "raw.P(0.075) ≈ 3.01785597263419"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`dune sand — ${label}`);
      else no(`dune sand — ${label}`);
    }
    // Warning details for d30 (verifier: computed 0.278914479440386, Δ 0.0689144794403859).
    const w = outcome.warnings[0];
    if (
      w.details?.field === "d30" &&
      w.details?.enteredValue === 0.21 &&
      w.details?.computedValue === 0.2789 &&
      w.details?.discrepancy === 0.0689 &&
      w.details?.tolerance === 0.05 &&
      w.message.includes("0.2789 mm") && w.message.includes("0.0689 mm") && w.message.includes("0.21 mm")
    ) {
      ok("dune sand — d30 warning details and message (4 dp values, tolerance, field)");
    } else {
      no(`dune sand — d30 warning wrong: ${JSON.stringify(w)}`);
    }
    const wCu = outcome.warnings[2];
    if (
      wCu.details?.field === "uniformityCoefficient" &&
      wCu.details?.computedValue === 3.3061 &&
      wCu.details?.discrepancy === 1.0161 &&
      wCu.message.includes("entered 2.29")
    ) {
      ok("dune sand — Cu warning details (dimensionless, 4 dp detail values)");
    } else {
      no(`dune sand — Cu warning wrong: ${JSON.stringify(wCu)}`);
    }
  }
}

// ---------------------------------------------------------------------------
// 6. Seed SANDY_SILT — warnings + interpolated indicators on a 14-point curve
// ---------------------------------------------------------------------------
{
  const outcome = runCalculation(granulometryModule, { points: SILT, ...SILT_ENTERED });
  if (outcome.status !== "ok") {
    no(`sandy silt — failed: ${outcome.error.message}`);
  } else {
    const checks: Array<[boolean, string]> = [
      // Verifier: D10=0.00971186749660408 (Δ −0.0403, no warning),
      // D30=0.151011180550556 (Δ −0.0990), D60=0.742997144568474 (Δ −0.7570),
      // Cu=76.5040446472603 (Δ +46.504), Cc=3.16030000806135 (Δ +2.3303).
      [outcome.results.d10 === 0.0097, "results.d10 = 0.0097"],
      [outcome.results.d30 === 0.151, "results.d30 = 0.151"],
      [outcome.results.d60 === 0.743, "results.d60 = 0.743"],
      [outcome.results.uniformityCoefficient === 76.504, "results.Cu = 76.504"],
      [outcome.results.coefficientOfCurvature === 3.16, "results.Cc = 3.16"],
      [outcome.warnings.length === 4, "4 warnings (d30, d60, Cu, Cc)"],
      [outcome.warnings.map((w) => w.details?.discrepancy).join(",") === "-0.099,-0.757,46.504,2.3303", "warning discrepancies (4 dp): −0.099, −0.757, +46.504, +2.3303"],
      [outcome.results.percentPassing0075Mm === 21.78, "results.P(0.075) = 21.78 (interpolated between 0.063/20 and 0.125/27)"],
      [outcome.results.percentPassing475Mm === 88.49, "results.P(4.75) = 88.49 (interpolated between 4/87 and 8/93)"],
      [outcome.results.percentCoarserThan475Mm === 11.51, "results.coarser(4.75) = 11.51"],
      [approx(outcome.raw.percentPassing0075Mm ?? NaN, 21.7812479521098, 1e-9), "raw.P(0.075) ≈ 21.7812479521098"],
      [approx(outcome.raw.percentPassing475Mm ?? NaN, 88.4875650806615, 1e-9), "raw.P(4.75) ≈ 88.4875650806615"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`sandy silt — ${label}`);
      else no(`sandy silt — ${label}`);
    }
  }
}

// ---------------------------------------------------------------------------
// 7. Flat segment not at target — duplicates elsewhere are tolerated
// ---------------------------------------------------------------------------
{
  const flat = pts([[0.063, 5], [0.125, 5], [0.25, 30], [0.5, 60], [2, 90]]);
  const outcome = runCalculation(granulometryModule, { points: flat });
  if (outcome.status !== "ok") {
    no(`flat segment — failed: ${outcome.error.message}`);
  } else {
    const checks: Array<[boolean, string]> = [
      // D10 t = 5/25 = 0.2 in (0.125,5)–(0.25,30) → 0.125 × 2^0.2 = 0.143587294374629;
      // D30 = 0.25 and D60 = 0.5 exact hits; P(0.075) on the flat (0.063,5)–(0.125,5) → 5.
      [outcome.results.d10 === 0.1436, "results.d10 = 0.1436 (flat 5%/5% pair does not affect the 10 % bracket)"],
      [outcome.raw.d30 === 0.25 && outcome.raw.d60 === 0.5, "raw d30/d60 = 0.25/0.5 exact hits"],
      [outcome.results.uniformityCoefficient === 3.482, "results.Cu = 3.482"],
      [outcome.results.coefficientOfCurvature === 0.871, "results.Cc = 0.871"],
      [outcome.results.percentPassing0075Mm === 5, "results.P(0.075) = 5 EXACT (flat interval, well-defined inverse)"],
      [outcome.results.percentPassing475Mm === null, "results.P(4.75) = null (max diameter 2 mm)"],
      [outcome.warnings.length === 0, "no warnings"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`flat segment — ${label}`);
      else no(`flat segment — ${label}`);
    }
  }
}

// ---------------------------------------------------------------------------
// 8. Tolerance boundary — |Δ| = 0.05 inclusive (no warning), 0.051 → warning
// ---------------------------------------------------------------------------
{
  // Curve P: computed d10 = 0.125 exactly; 0.125 − 0.075 === 0.05 (verified
  // IEEE double identity) → NOT > 0.05 → no warning.
  const atBoundary = runCalculation(granulometryModule, { points: CURVE_P, d10: 0.075 });
  if (atBoundary.status === "ok" && atBoundary.warnings.length === 0) {
    ok("boundary |Δ| = 0.05 (entered d10 0.075) — within tolerance, NO warning");
  } else no("boundary 0.05 — warning wrongly emitted");
}
{
  // 0.125 − 0.074 = 0.051000000000000004 > 0.05 → warning.
  const beyond = runCalculation(granulometryModule, { points: CURVE_P, d10: 0.074 });
  if (beyond.status === "ok" && beyond.warnings.length === 1 && beyond.warnings[0].details?.field === "d10") {
    ok("boundary |Δ| = 0.051 (entered d10 0.074) — beyond tolerance, warning emitted");
  } else no("boundary 0.051 — warning missing");
}
{
  // Computed Cu = 4 exactly; 4 − 3.95 = 0.04999999999999982 ≤ 0.05 → no warning
  // (entered Cu alone — no entered d-values, so the registry identity is skipped).
  const atBoundaryCu = runCalculation(granulometryModule, { points: CURVE_P, uniformityCoefficient: 3.95 });
  if (atBoundaryCu.status === "ok" && atBoundaryCu.warnings.length === 0) {
    ok("boundary |Δ| < 0.05 (entered Cu 3.95 vs computed 4) — NO warning");
  } else no("boundary Cu 3.95 — warning wrongly emitted");
}
{
  // 4 − 3.949 = 0.051000000000000156 > 0.05 → warning.
  const beyondCu = runCalculation(granulometryModule, { points: CURVE_P, uniformityCoefficient: 3.949 });
  if (beyondCu.status === "ok" && beyondCu.warnings.length === 1 && beyondCu.warnings[0].details?.field === "uniformityCoefficient") {
    ok("boundary |Δ| = 0.051 (entered Cu 3.949) — warning emitted");
  } else no("boundary Cu 3.949 — warning missing");
}
{
  // Consistent entered values within tolerance of the computed ones → clean run.
  const clean = runCalculation(granulometryModule, {
    points: CURVE_B, d10: 0.106, d30: 0.25, d60: 0.85, uniformityCoefficient: 8.02, coefficientOfCurvature: 0.69,
  });
  if (clean.status === "ok" && clean.warnings.length === 0) {
    ok("entered values matching computed (within ±0.05) — no warnings, echoes unchanged");
  } else no(`clean entered case — unexpected warnings: ${clean.status === "ok" ? clean.warnings.length : clean.error.message}`);
}

// ---------------------------------------------------------------------------
// 9. Missing inputs and payload shape
// ---------------------------------------------------------------------------
{
  const outcome = runCalculation(granulometryModule, {});
  expectError(outcome, "empty payload", { code: "MISSING_INPUT", messageHint: "points" });
}
{
  const outcome = runCalculation(granulometryModule, {
    points: [{ diameterMm: 0.1 }, { diameterMm: 0.2, percentFiner: 20 }, { diameterMm: 0.4, percentFiner: 40 }, { diameterMm: 0.8, percentFiner: 60 }],
  });
  expectError(outcome, "point missing percentFiner", { code: "MISSING_INPUT", messageHint: "points.0.percentFiner" });
}
{
  const outcome = runCalculation(granulometryModule, { points: null });
  expectError(outcome, "points present but null", { code: "INVALID_INPUT", fieldPath: "points" });
}
{
  const outcome = runCalculation(granulometryModule, { points: CURVE_A, d30: null });
  expectError(outcome, "entered d30 present but null", { code: "INVALID_INPUT", fieldPath: "d30" });
}
{
  const outcome = runCalculation(granulometryModule, 42);
  expectError(outcome, "payload is a number", { code: "INVALID_INPUT", fieldPath: "(root)" });
}
{
  const outcome = runCalculation(granulometryModule, [CURVE_A]);
  expectError(outcome, "payload is an array", { code: "INVALID_INPUT", fieldPath: "(root)" });
}

// ---------------------------------------------------------------------------
// 10. Contract bounds and types (registry mirror)
// ---------------------------------------------------------------------------
{
  const mk = (points: unknown): unknown => ({ points });
  const cases: Array<[string, unknown, ExpectedError]> = [
    ["zero diameter", mk([{ diameterMm: 0, percentFiner: 10 }, { diameterMm: 0.2, percentFiner: 20 }, { diameterMm: 0.4, percentFiner: 40 }, { diameterMm: 0.8, percentFiner: 60 }]), { code: "INVALID_INPUT", fieldPath: "points.0.diameterMm" }],
    ["negative diameter", mk([{ diameterMm: -0.075, percentFiner: 10 }, { diameterMm: 0.2, percentFiner: 20 }, { diameterMm: 0.4, percentFiner: 40 }, { diameterMm: 0.8, percentFiner: 60 }]), { code: "INVALID_INPUT", fieldPath: "points.0.diameterMm" }],
    ["diameter 300.5 (max 300)", mk([{ diameterMm: 0.1, percentFiner: 10 }, { diameterMm: 0.2, percentFiner: 20 }, { diameterMm: 0.4, percentFiner: 40 }, { diameterMm: 300.5, percentFiner: 60 }]), { code: "INVALID_INPUT", fieldPath: "points.3.diameterMm" }],
    ["percentFiner −2 (min 0)", mk([{ diameterMm: 0.1, percentFiner: -2 }, { diameterMm: 0.2, percentFiner: 20 }, { diameterMm: 0.4, percentFiner: 40 }, { diameterMm: 0.8, percentFiner: 60 }]), { code: "INVALID_INPUT", fieldPath: "points.0.percentFiner" }],
    ["percentFiner 100.5 (max 100)", mk([{ diameterMm: 0.1, percentFiner: 10 }, { diameterMm: 0.2, percentFiner: 20 }, { diameterMm: 0.4, percentFiner: 40 }, { diameterMm: 0.8, percentFiner: 100.5 }]), { code: "INVALID_INPUT", fieldPath: "points.3.percentFiner" }],
    ["NaN diameter", mk([{ diameterMm: Number.NaN, percentFiner: 10 }, { diameterMm: 0.2, percentFiner: 20 }, { diameterMm: 0.4, percentFiner: 40 }, { diameterMm: 0.8, percentFiner: 60 }]), { code: "INVALID_INPUT", fieldPath: "points.0.diameterMm" }],
    ["Infinity percentFiner", mk([{ diameterMm: 0.1, percentFiner: 10 }, { diameterMm: 0.2, percentFiner: Number.POSITIVE_INFINITY }, { diameterMm: 0.4, percentFiner: 40 }, { diameterMm: 0.8, percentFiner: 60 }]), { code: "INVALID_INPUT", fieldPath: "points.1.percentFiner" }],
    ["string diameter", mk([{ diameterMm: "0.1", percentFiner: 10 }, { diameterMm: 0.2, percentFiner: 20 }, { diameterMm: 0.4, percentFiner: 40 }, { diameterMm: 0.8, percentFiner: 60 }]), { code: "INVALID_INPUT", fieldPath: "points.0.diameterMm", messageHint: "expected number" }],
    ["entered d10 = 0 (positive required)", { points: CURVE_A, d10: 0 }, { code: "INVALID_INPUT", fieldPath: "d10" }],
    ["entered Cu = −2", { points: CURVE_A, uniformityCoefficient: -2 }, { code: "INVALID_INPUT", fieldPath: "uniformityCoefficient" }],
  ];
  for (const [label, payload, expected] of cases) {
    expectError(runCalculation(granulometryModule, payload), label, expected);
  }
}
{
  // 3 points — below the registry minimum of 4.
  const three = pts([[0.1, 10], [0.2, 30], [0.4, 60]]);
  expectError(runCalculation(granulometryModule, { points: three }), "insufficient points (3 < 4)", { code: "INVALID_INPUT", fieldPath: "points", messageHint: ">=4" });
}
{
  // 41 points — above the registry maximum of 40.
  const many = Array.from({ length: 41 }, (_, i) => ({ diameterMm: 0.001 * (i + 1), percentFiner: Math.min(100, 2 * (i + 1)) }));
  expectError(runCalculation(granulometryModule, { points: many }), "excessive points (41 > 40)", { code: "INVALID_INPUT", fieldPath: "points", messageHint: "<=40" });
}
{
  // Empty points array.
  expectError(runCalculation(granulometryModule, { points: [] }), "empty points array", { code: "INVALID_INPUT", fieldPath: "points" });
}

// ---------------------------------------------------------------------------
// 11. Ordering, duplicates and monotonicity (module contract + registry mirror)
// ---------------------------------------------------------------------------
{
  // Duplicate diameter — registry rule violation.
  const dup = pts([[0.1, 10], [0.2, 20], [0.2, 30], [0.4, 45], [0.8, 60], [2, 90]]);
  expectError(runCalculation(granulometryModule, { points: dup }), "duplicate diameters", {
    code: "INVALID_INPUT", fieldPath: "points[2].diameterMm", messageHint: "diameters must be unique",
  });
}
{
  // Unordered — descending (the storage order of the seed data).
  const descending = [...DUNE].sort((a, b) => b.diameterMm - a.diameterMm);
  expectError(runCalculation(granulometryModule, { points: descending }), "unordered points (descending, seed storage order)", {
    code: "INVALID_INPUT", messageHint: "strictly increasing diameterMm",
  });
}
{
  // Unordered — single swap in the middle.
  const swapped = pts([[0.05, 5], [0.20, 30.5], [0.10, 14], [0.40, 46], [0.80, 58], [1.60, 68], [3.20, 79], [6.40, 90]]);
  expectError(runCalculation(granulometryModule, { points: swapped }), "unordered points (mid-array swap)", {
    code: "INVALID_INPUT", fieldPath: "points[2].diameterMm", messageHint: "not greater than",
  });
}
{
  // percentFiner decreasing beyond the 0.01 registry tolerance.
  const decreasing = pts([[0.05, 20], [0.10, 19.5], [0.20, 35], [0.40, 46], [0.80, 58], [1.60, 68], [3.20, 79], [6.40, 90]]);
  expectError(runCalculation(granulometryModule, { points: decreasing }), "percentFiner decreasing (0.5 > 0.01 tolerance)", {
    code: "INVALID_INPUT", fieldPath: "points[1].percentFiner", messageHint: "non-decreasing",
  });
}

// ---------------------------------------------------------------------------
// 12. Ambiguity — duplicate percentages at the target / multiple brackets
// ---------------------------------------------------------------------------
{
  // Two measured points share percentFiner = 10 → D10 ambiguous.
  const dupPct = pts([[0.063, 10], [0.125, 10], [0.25, 30], [0.5, 60], [2, 90]]);
  expectError(runCalculation(granulometryModule, { points: dupPct }), "duplicate percentages at target (exact hits)", {
    code: "INVALID_INPUT", fieldPath: "points", messageHint: "Ambiguous d10",
  });
}
{
  // Noise-tolerated non-monotonicity creating TWO bracketing intervals for 10 %.
  const multi = pts([[0.063, 9.995], [0.125, 10.004], [0.25, 9.996], [0.5, 10.004], [2, 40]]);
  expectError(runCalculation(granulometryModule, { points: multi }), "duplicate percentages at target (two brackets)", {
    code: "INVALID_INPUT", fieldPath: "points", messageHint: "2 interpolation intervals",
  });
}
{
  // Target inside the measured range but no interval covers it (noise gap).
  // Decrease 10.004 → 9.995 = 0.009 < 0.01 is tolerated by the shared
  // registry/module expression (verified: 10.004 − 0.01 = 9.994 in doubles,
  // and 9.995 < 9.994 is false); target 10 has no exact hit and no bracket.
  const gap = pts([[0.063, 10.004], [0.125, 9.995], [0.25, 9.996], [0.5, 9.997]]);
  expectError(runCalculation(granulometryModule, { points: gap }), "noise gap around the target", {
    code: "ARITHMETIC_DOMAIN_ERROR", messageHint: "no valid interpolation interval",
  });
}
{
  // A decrease of exactly 0.010 in DECIMAL terms (10.005 → 9.995) is rejected
  // by the shared expression in double arithmetic (10.005 − 0.01 =
  // 9.995000000000001 > 9.995) — the registry's superRefine rejects it too
  // (same expression), so INVALID_INPUT here is parity, not a divergence.
  const decimalTie = pts([[0.063, 10.005], [0.125, 9.995], [0.25, 9.996], [0.5, 9.997]]);
  const moduleOutcome = runCalculation(granulometryModule, { points: decimalTie });
  const registryRejects = !parseLabTestResult("GRANULOMETRY", { points: decimalTie }).ok;
  if (
    moduleOutcome.status === "error" && moduleOutcome.error.code === "INVALID_INPUT" && registryRejects
  ) {
    ok("0.010-decimal decrease — module AND registry both reject (shared expression, FP semantics)");
  } else {
    no(`0.010-decimal decrease — module code=${moduleOutcome.status === "error" ? moduleOutcome.error.code : "ok"}, registry rejects=${registryRejects}`);
  }
}

// ---------------------------------------------------------------------------
// 13. Missing target range — extrapolation rejected (authorization §3.1)
// ---------------------------------------------------------------------------
{
  // Seed GRAN_SILTY_CLAY: finest point already at 21 % — D10 not measurable.
  expectError(runCalculation(granulometryModule, { points: CLAY }), "D10 below measured range (seed silty clay)", {
    code: "ARITHMETIC_DOMAIN_ERROR", messageHint: "outside the measured range",
  });
}
{
  const outcome = runCalculation(granulometryModule, { points: CLAY });
  if (outcome.status === "error" && outcome.error.message.includes("[21, 100]")) {
    ok("range rejection reports the measured percentFiner range [21, 100]");
  } else no("range rejection — measured range missing from message");
}
{
  // Coarse curve stopping at 48 % — D60 not measurable (D10/D30 are).
  const high = pts([[0.002, 5], [0.006, 8], [0.02, 12], [0.063, 18], [0.125, 25], [0.25, 33], [0.5, 41], [1.0, 48]]);
  expectError(runCalculation(granulometryModule, { points: high }), "D60 above measured range", {
    code: "ARITHMETIC_DOMAIN_ERROR", messageHint: "d60 requires percentFiner = 60",
  });
}

// ---------------------------------------------------------------------------
// 14. Entered-identity mirror (registry superRefine, ±0.05)
// ---------------------------------------------------------------------------
{
  const outcome = runCalculation(granulometryModule, {
    points: CURVE_A, d10: 0.1, d60: 0.8, uniformityCoefficient: 5, // 0.8/0.1 = 8 ≠ 5
  });
  expectError(outcome, "entered Cu inconsistent with entered d60/d10", {
    code: "INVALID_INPUT", fieldPath: "uniformityCoefficient", messageHint: "must equal d60 / d10",
  });
}
{
  const outcome = runCalculation(granulometryModule, {
    points: CURVE_A, d10: 0.1, d30: 0.2, d60: 0.8, coefficientOfCurvature: 2, // true 0.5
  });
  expectError(outcome, "entered Cc inconsistent with entered d-values", {
    code: "INVALID_INPUT", fieldPath: "coefficientOfCurvature", messageHint: "must equal d30² / (d60 × d10)",
  });
}

// ---------------------------------------------------------------------------
// 15. NaN/Infinity and overflow protection
// ---------------------------------------------------------------------------
{
  // Subnormal D10 → Cu = D60/D10 overflows to Infinity → structured rejection
  // (verifier: raw D10 = 2.2e-322, D60 = 141.42135623730945, Cu = Infinity).
  const overflow = pts([[5e-324, 5], [1e-320, 15], [0.001, 30], [100, 59], [200, 61], [300, 100]]);
  expectError(runCalculation(granulometryModule, { points: overflow }), "Cu overflows to Infinity (subnormal D10)", {
    code: "ARITHMETIC_DOMAIN_ERROR", messageHint: "finite number",
  });
}
{
  // Cu ≈ 1e13 is finite but roundTo(Cu, 3) leaves the safe-integer range
  // (verifier: Cu = 10000000000000.002; ×1000 = 1.0000000000000002e16 > 2^53−1).
  const huge = pts([[1e-11, 5], [2e-11, 15], [0.01, 30], [100, 59], [200, 61], [300, 100]]);
  expectError(runCalculation(granulometryModule, { points: huge }), "Cu exceeds the safe-integer rounding range", {
    code: "ARITHMETIC_DOMAIN_ERROR", messageHint: "safe integer range",
  });
}
{
  // Zero logarithmic interval width (diameters indistinguishable in double
  // precision) — direct helper test; without the guard this yields 0/0 = NaN.
  // Pair verified in scripts/m5.2-b-verify-goldens.py: at 1e-12 the doubles
  // 1e-12 and 1.0000000000000004e-12 have identical Math.log, and
  // 1.0000000000000002e-12 lies strictly between them.
  const tiny: Array<{ diameterMm: number; percentFiner: number }> = [
    { diameterMm: 1e-12, percentFiner: 20 },
    { diameterMm: 1.0000000000000004e-12, percentFiner: 30 },
  ];
  let threw = false;
  let message = "";
  try {
    interpolatePercentAtDiameter(tiny, 1.0000000000000002e-12, "percentPassing0075Mm");
  } catch (e) {
    threw = true;
    message = e instanceof Error ? e.message : String(e);
  }
  if (threw && message.includes("zero logarithmic width")) {
    ok("zero log-width interval — NaN guard fires (structured ARITHMETIC_DOMAIN rejection)");
  } else no(`zero log-width guard — threw=${threw}, message='${message}'`);
}

// ---------------------------------------------------------------------------
// 16. M5.1 registry compatibility (behavioral parity + documented divergences)
// ---------------------------------------------------------------------------
{
  // Shared valid — module AND registry both accept (no-warning cases).
  const sharedValid: Array<[string, unknown]> = [
    ["curve A (points only)", { points: CURVE_A }],
    ["curve B (exact hits)", { points: CURVE_B }],
    ["curve P (power-of-two)", { points: CURVE_P }],
    ["curve B + consistent entered values", { points: CURVE_B, d10: 0.106, d30: 0.25, d60: 0.85, uniformityCoefficient: 8.02, coefficientOfCurvature: 0.69 }],
    ["curve N (noise-tolerated monotonicity)", { points: CURVE_N }],
    ["flat segment (non-target duplicates)", { points: pts([[0.063, 5], [0.125, 5], [0.25, 30], [0.5, 60], [2, 90]]) }],
    ["full result payload with uscsClassification (unknown key)", { points: CURVE_A, uscsClassification: "SM" }],
  ];
  for (const [label, payload] of sharedValid) {
    const moduleOutcome = runCalculation(granulometryModule, payload);
    const moduleOk = moduleOutcome.status === "ok" && moduleOutcome.warnings.length === 0;
    const registryOk = parseLabTestResult("GRANULOMETRY", payload).ok;
    if (moduleOk && registryOk) ok(`parity — ${label}: module AND M5.1 registry both accept`);
    else no(`parity — ${label}: module=${moduleOk}, registry=${registryOk}`);
  }

  // Shared valid with advisory warnings — registry accepts, module accepts AND
  // warns (computed-from-points ≠ entered, the engine advises, never overwrites).
  for (const [label, payload] of [["seed DUNE_SAND (ascending)", { points: DUNE, ...DUNE_ENTERED }], ["seed SANDY_SILT (ascending)", { points: SILT, ...SILT_ENTERED }]] as Array<[string, unknown]>) {
    const moduleOutcome = runCalculation(granulometryModule, payload);
    const moduleAdvises = moduleOutcome.status === "ok" && moduleOutcome.warnings.length > 0;
    const registryOk = parseLabTestResult("GRANULOMETRY", payload).ok;
    if (moduleAdvises && registryOk) ok(`parity — ${label}: registry accepts, module accepts + warns (advisory)`);
    else no(`parity — ${label}: module advises=${moduleAdvises}, registry=${registryOk}`);
  }

  // Shared invalid — module AND registry both reject.
  const sharedInvalid: Array<[string, unknown]> = [
    ["duplicate diameters", { points: pts([[0.1, 10], [0.2, 20], [0.2, 30], [0.4, 45], [0.8, 60], [2, 90]]) }],
    ["percentFiner decreasing beyond tolerance", { points: pts([[0.05, 20], [0.10, 19.5], [0.20, 35], [0.40, 46], [0.80, 58], [1.60, 68], [3.20, 79], [6.40, 90]]) }],
    ["3 points", { points: pts([[0.1, 10], [0.2, 30], [0.4, 60]]) }],
    ["zero diameter", { points: pts([[0, 10], [0.2, 20], [0.4, 40], [0.8, 60]]) }],
    ["diameter 301", { points: pts([[0.1, 10], [0.2, 20], [0.4, 40], [301, 60]]) }],
    ["percentFiner 105", { points: pts([[0.1, 10], [0.2, 20], [0.4, 40], [0.8, 105]]) }],
    ["percentFiner negative", { points: pts([[0.1, -5], [0.2, 20], [0.4, 40], [0.8, 60]]) }],
    ["NaN diameter", { points: pts([[Number.NaN, 10], [0.2, 20], [0.4, 40], [0.8, 60]]) }],
    ["string diameter", { points: [{ diameterMm: "0.1", percentFiner: 10 }, { diameterMm: 0.2, percentFiner: 20 }, { diameterMm: 0.4, percentFiner: 40 }, { diameterMm: 0.8, percentFiner: 60 }] }],
    ["entered Cu identity violated", { points: CURVE_A, d10: 0.1, d60: 0.8, uniformityCoefficient: 5 }],
    ["entered Cc identity violated", { points: CURVE_A, d10: 0.1, d30: 0.2, d60: 0.8, coefficientOfCurvature: 2 }],
  ];
  for (const [label, payload] of sharedInvalid) {
    const moduleRejects = runCalculation(granulometryModule, payload).status === "error";
    const registryRejects = !parseLabTestResult("GRANULOMETRY", payload).ok;
    if (moduleRejects && registryRejects) ok(`parity — ${label}: module AND M5.1 registry both reject`);
    else no(`parity — ${label}: module rejects=${moduleRejects}, registry rejects=${registryRejects}`);
  }

  // Divergence 1 — point ordering: the registry stores any order (its
  // superRefine sorts a copy; seed data is coarse-to-fine); the module
  // requires ascending order and never silently sorts.
  {
    const descending = [...DUNE].sort((a, b) => b.diameterMm - a.diameterMm);
    const registryAccepts = parseLabTestResult("GRANULOMETRY", { points: descending }).ok;
    const moduleOutcome = runCalculation(granulometryModule, { points: descending });
    if (registryAccepts && moduleOutcome.status === "error" && moduleOutcome.error.code === "INVALID_INPUT") {
      ok("divergence 1 — registry accepts unordered storage; module rejects (never silently sorts)");
    } else {
      no(`divergence 1 — registry accepts=${registryAccepts}, module code=${moduleOutcome.status === "error" ? moduleOutcome.error.code : "ok"}`);
    }
  }

  // Divergence 2 — measured range: d-values are OPTIONAL in the registry
  // (curves that never reach 10 % finer are valid storage); the module
  // rejects them rather than extrapolating D10.
  {
    const registryAccepts = parseLabTestResult("GRANULOMETRY", { points: CLAY }).ok;
    const moduleOutcome = runCalculation(granulometryModule, { points: CLAY });
    if (registryAccepts && moduleOutcome.status === "error" && moduleOutcome.error.code === "ARITHMETIC_DOMAIN_ERROR") {
      ok("divergence 2 — registry accepts a curve without a 10 % crossing; module rejects (extrapolation refused)");
    } else {
      no("divergence 2 — behavior does not match the documented contract");
    }
  }

  // Divergence 3 — ambiguous duplicates: registry-valid storage (flat or
  // noise-wiggled curves) that makes a percentile ambiguous is rejected.
  {
    const dupPct = pts([[0.063, 10], [0.125, 10], [0.25, 30], [0.5, 60], [2, 90]]);
    const registryAccepts = parseLabTestResult("GRANULOMETRY", { points: dupPct }).ok;
    const moduleOutcome = runCalculation(granulometryModule, { points: dupPct });
    if (registryAccepts && moduleOutcome.status === "error" && moduleOutcome.error.code === "INVALID_INPUT") {
      ok("divergence 3 — registry accepts duplicate percentages; module rejects when the target is ambiguous");
    } else {
      no("divergence 3 — behavior does not match the documented contract");
    }
  }
  {
    const multi = pts([[0.063, 9.995], [0.125, 10.004], [0.25, 9.996], [0.5, 10.004], [2, 40]]);
    const registryAccepts = parseLabTestResult("GRANULOMETRY", { points: multi }).ok;
    const moduleRejects = runCalculation(granulometryModule, { points: multi }).status === "error";
    if (registryAccepts && moduleRejects) {
      ok("divergence 3b — registry accepts noise-wiggled curve; module rejects (two brackets)");
    } else no("divergence 3b — behavior mismatch");
  }
  {
    // Gap instance of the same divergence class: tolerated noise leaves the
    // target without any covering interval — valid storage, not calculable.
    const gap = pts([[0.063, 10.004], [0.125, 9.995], [0.25, 9.996], [0.5, 9.997]]);
    const registryAccepts = parseLabTestResult("GRANULOMETRY", { points: gap }).ok;
    const moduleOutcome = runCalculation(granulometryModule, { points: gap });
    if (registryAccepts && moduleOutcome.status === "error" && moduleOutcome.error.code === "ARITHMETIC_DOMAIN_ERROR") {
      ok("divergence 3c — registry accepts the noise-gap curve; module rejects (no covering interval)");
    } else no("divergence 3c — behavior mismatch");
  }

  // Results revalidation — the computed indicator set satisfies the registry
  // result contract (positive d-values; Cu and Cc identities within ±0.05).
  {
    const outcome = runCalculation(granulometryModule, { points: CURVE_A });
    if (outcome.status !== "ok") no("results revalidation — run failed");
    else {
      const reconstructed = {
        points: CURVE_A,
        d10: outcome.results.d10,
        d30: outcome.results.d30,
        d60: outcome.results.d60,
        uniformityCoefficient: outcome.results.uniformityCoefficient,
        coefficientOfCurvature: outcome.results.coefficientOfCurvature,
      };
      if (parseLabTestResult("GRANULOMETRY", reconstructed).ok) {
        ok("results revalidation — computed d10/d30/d60/Cu/Cc pass the M5.1 registry result schema");
      } else no("results revalidation — computed values violate the registry contract");
    }
  }

  // Module metadata matches the registry code.
  if (granulometryModule.testType === "GRANULOMETRY" && granulometryModule.id === "granulometry") {
    ok("module metadata — testType 'GRANULOMETRY' matches the registry code");
  } else no("module metadata — testType mismatch");
}

// ---------------------------------------------------------------------------
// 17. Determinism, purity and envelope provenance
// ---------------------------------------------------------------------------
{
  const payload = { points: CURVE_A };
  const before = JSON.stringify(payload);
  const signatures = new Set<string>();
  for (let i = 0; i < 25; i++) signatures.add(JSON.stringify(runCalculation(granulometryModule, payload)));
  if (signatures.size === 1) ok("determinism — 25 runs deeply identical (success path)");
  else no("determinism — success-path runs diverged");
  if (JSON.stringify(payload) === before) ok("purity — input payload not mutated");
  else no("purity — input payload mutated");
}
{
  const payload = { points: DUNE, ...DUNE_ENTERED };
  const signatures = new Set<string>();
  for (let i = 0; i < 25; i++) signatures.add(JSON.stringify(runCalculation(granulometryModule, payload)));
  if (signatures.size === 1) ok("determinism — 25 warning-case runs deeply identical");
  else no("determinism — warning-case runs diverged");
}
{
  const outcome = runCalculation(granulometryModule, { points: CURVE_A });
  if (outcome.status === "ok") {
    if (
      outcome.moduleId === "granulometry" &&
      outcome.moduleVersion === "1.0.0" &&
      outcome.testType === "GRANULOMETRY" &&
      typeof outcome.engineVersion === "string" && outcome.engineVersion.length > 0
    ) {
      ok("envelope — moduleId/moduleVersion/testType/engineVersion present");
    } else no("envelope — provenance incomplete");
  } else {
    no("envelope — run failed");
  }
}

console.log(`\n================ M5.2-b GRANULOMETRY TEST SUMMARY: ${pass} passed, ${fail} failed ================`);
process.exit(fail);
