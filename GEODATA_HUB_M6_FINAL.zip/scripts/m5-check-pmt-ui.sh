#!/usr/bin/env bash
# M5.1 supplementary browser check (v2 — direct URLs, case-insensitive):
# PRESSUREMETER + multi-stage direct shear render gracefully in the UNCHANGED
# M4 frontend. Screenshots captured for the M5.1 completion report.
set -u
cd /home/z/my-project
BASE=http://127.0.0.1:3000

stop_dev(){ pkill -f "next dev" 2>/dev/null || true; sleep 1; }
start_dev(){
  nohup bun run dev < /dev/null > /tmp/m5-ui-dev.out 2>&1 &
  for i in $(seq 1 90); do
    curl -sf "$BASE/api/health" >/dev/null 2>&1 && break
    sleep 1
  done
  curl -sf "$BASE/api/health" >/dev/null 2>&1 || { echo "DEV SERVER FAILED"; exit 1; }
}

P=0; F=0
ok(){ echo "PASS: $1"; P=$((P+1)); }
no(){ echo "FAIL: $1"; F=$((F+1)); }
body(){ agent-browser get text body 2>/dev/null | head -c 30000; }

stop_dev
start_dev

mkdir -p download/m5-screenshots
PMT_URL=$(bun scripts/m5-get-pmt-url.ts | awk "{print \$1}")
DS_URL=$(bun scripts/m5-get-ds-stages-url.ts | awk "{print \$1}")
echo "PMT: $PMT_URL | DS: $DS_URL"

agent-browser close >/dev/null 2>&1 || true
agent-browser open "$BASE/login" >/dev/null 2>&1; sleep 2
agent-browser find label "Email" fill "admin@geodata.demo" >/dev/null 2>&1
agent-browser find label "Password" fill "Demo1234!" >/dev/null 2>&1
agent-browser find role button click --name "Sign in" >/dev/null 2>&1; sleep 4

# 1. Laboratory tests list filtered to PRESSUREMETER
agent-browser open "$BASE/lab-tests?testType=PRESSUREMETER" >/dev/null 2>&1; sleep 3
B=$(body)
echo "$B" | grep -q "Pressuremeter (Ménard)" && ok "PMT list rows render" || no "PMT list rows"
agent-browser screenshot download/m5-screenshots/01-labtests-pressuremeter-list.png >/dev/null 2>&1

# 2. PMT detail page (direct URL)
agent-browser open "$BASE$PMT_URL" >/dev/null 2>&1; sleep 3
B=$(body)
echo "$B" | grep -q "Test record" && ok "PMT detail page renders" || no "PMT detail page"
echo "$B" | grep -q "NF P94-110-1 / NF P94-110-2 / ASTM D4719" && ok "PMT registry standard shown" || no "PMT registry standard"
echo "$B" | grep -q "950" && ok "PMT result values (PL 950) rendered" || no "PMT result values"
echo "$B" | grep -qi "unknown chart configuration" && ok "graceful no-renderer chart state" || no "chart state not graceful"
agent-browser screenshot download/m5-screenshots/02-labtest-pressuremeter-detail.png >/dev/null 2>&1

# 3. Multi-stage direct shear detail (stages[] format)
agent-browser open "$BASE$DS_URL" >/dev/null 2>&1; sleep 3
B=$(body)
echo "$B" | grep -q "Multi-stage envelope" && ok "DS stages test renders with summary" || no "DS stages test"
echo "$B" | grep -q "Stages" && ok "DS stages table rendered" || no "DS stages table"
agent-browser screenshot download/m5-screenshots/03-labtest-directshear-stages.png >/dev/null 2>&1

# 4. General lab-tests list intact (case-insensitive)
agent-browser open "$BASE/lab-tests" >/dev/null 2>&1; sleep 3
B=$(body)
echo "$B" | grep -qi "laboratory tests" && ok "lab tests list intact" || no "lab tests list"

# 5. A test WITH inputData shows nothing new in list (inputData is detail-only)
agent-browser open "$BASE/lab-tests?testType=PROCTOR&status=COMPLETED" >/dev/null 2>&1; sleep 3
B=$(body)
echo "$B" | grep -q "Proctor compaction" && ok "proctor list intact" || no "proctor list"

agent-browser close >/dev/null 2>&1 || true
stop_dev
echo ""
echo "M5.1 SUPPLEMENTARY UI CHECK: $P passed, $F failed"
exit $((F > 0 ? 1 : 0))
