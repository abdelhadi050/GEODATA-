#!/usr/bin/env bash
# M5.4 screenshots — capture the classification panel on a sample page and the
# reports list + report detail with PDF download. Runs in a single bash
# invocation (sandbox process-group rule).
set -u
cd /home/z/my-project

stop_dev(){ pkill -f "next dev" 2>/dev/null || true; sleep 1; }
trap stop_dev EXIT

stop_dev
nohup bun run dev < /dev/null > /tmp/m54-dev.out 2>&1 &
DEV_PID=$!
for i in $(seq 1 30); do
  curl -sf http://localhost:3000/api/health > /dev/null 2>&1 && break
  sleep 1
done
if ! curl -sf http://localhost:3000/api/health > /dev/null 2>&1; then
  echo "Dev server failed"; tail -30 /tmp/m54-dev.out; exit 1
fi
echo "Dev server ready"

SHOTS=download/m5.4-screenshots
mkdir -p "$SHOTS"

# Login + navigate via agent-browser (handles cookies natively)
agent-browser goto "http://localhost:3000/login" >/dev/null 2>&1
sleep 1
agent-browser eval '(function(){const e=document.querySelector("input[type=email]");if(!e)return "missing";const s=Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,"value").set;s.call(e,"engineer@geodata.demo");e.dispatchEvent(new Event("input",{bubbles:true}));const p=document.querySelector("input[type=password]");s.call(p,"Demo1234!");p.dispatchEvent(new Event("input",{bubbles:true}));return "ok";})()' >/dev/null 2>&1
agent-browser click "button[type=submit]" >/dev/null 2>&1
sleep 2

# 1. Reports list
agent-browser goto "http://localhost:3000/reports" >/dev/null 2>&1
sleep 2
agent-browser screenshot "$SHOTS/01-reports-list.png" >/dev/null 2>&1
echo "✓ 01-reports-list"

# 2. Generate a TEST_SUMMARY report via the dialog
agent-browser goto "http://localhost:3000/samples" >/dev/null 2>&1
sleep 1
agent-browser screenshot "$SHOTS/02-samples-list.png" >/dev/null 2>&1
echo "✓ 02-samples-list"

# Find a sample with both GRANULOMETRY and ATTERBERG — click into it
SAMPLE_HREF=$(agent-browser eval 'document.querySelector("table a[href^=\"/samples/\"]")?.getAttribute("href")' 2>/dev/null | tr -d '"')
if [ -n "$SAMPLE_HREF" ]; then
  agent-browser goto "http://localhost:3000$SAMPLE_HREF" >/dev/null 2>&1
  sleep 2
  agent-browser screenshot "$SHOTS/03-sample-detail-with-classification.png" >/dev/null 2>&1
  echo "✓ 03-sample-detail-with-classification"
fi

# 3. Reports list with the new PDF download column
agent-browser goto "http://localhost:3000/reports" >/dev/null 2>&1
sleep 2
agent-browser screenshot "$SHOTS/04-reports-with-pdf.png" >/dev/null 2>&1
echo "✓ 04-reports-with-pdf"

echo "Screenshots saved to $SHOTS/"
ls -lh "$SHOTS/" 2>&1
