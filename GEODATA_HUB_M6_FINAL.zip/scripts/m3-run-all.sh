#!/usr/bin/env bash
# M3 full test run: seed → M2 regression → dev server → M3 API tests →
# M1 browser regression → re-seed pristine → leave dev server for preview.
# Everything happens inside ONE bash invocation (sandbox process-group rule).
set -u
cd /home/z/my-project

BASE=http://127.0.0.1:3000
PASS=0; FAIL=0
step(){ echo ""; echo "###############################################"; echo "### $1"; echo "###############################################"; }

stop_dev(){ pkill -f "next dev" 2>/dev/null || true; sleep 1; }
start_dev(){
  nohup bun run dev < /dev/null > /tmp/m3-dev.out 2>&1 &
  DEV_PID=$!
  for i in $(seq 1 60); do
    curl -sf "$BASE/api/health" >/dev/null 2>&1 && break
    sleep 1
  done
  if curl -sf "$BASE/api/health" >/dev/null 2>&1; then echo "dev server up (pid $DEV_PID)"; else echo "DEV SERVER FAILED"; tail -30 /tmp/m3-dev.out; exit 1; fi
}

step "0. Static checks"
bunx tsc --noEmit && { echo "tsc: PASS"; PASS=$((PASS+1)); } || { echo "tsc: FAIL"; FAIL=$((FAIL+1)); }
bun run lint && { echo "lint: PASS"; PASS=$((PASS+1)); } || { echo "lint: FAIL"; FAIL=$((FAIL+1)); }

stop_dev

step "1. Pristine seed (deterministic state)"
bun run db:seed && { echo "seed: PASS"; PASS=$((PASS+1)); } || { echo "seed: FAIL"; FAIL=$((FAIL+1)); }

step "2. M2 regression — lab-test registry (12 types)"
bun scripts/m2-test-registry.ts && PASS=$((PASS+1)) || FAIL=$((FAIL+1))

step "3. M2 regression — service layer (tenant isolation etc.)"
bun scripts/m2-test-services.ts && PASS=$((PASS+1)) || FAIL=$((FAIL+1))

# The M2 suite legitimately mutates share statuses (approve/revoke flows);
# re-seed so the M3 suite runs against the pristine seeded dataset.
stop_dev
bun run db:seed || { echo "pre-M3 seed failed"; FAIL=$((FAIL+1)); }

step "4. M3 API integration tests (live dev server)"
start_dev
bun scripts/m3-test-api.ts
M3_RC=$?
if [ $M3_RC -eq 0 ]; then PASS=$((PASS+1)); else FAIL=$((FAIL+1)); fi

step "5. M1 regression — browser auth tests"
# m1 script manages its own dev-server lifecycle (kills + restarts)
bash scripts/m1-auth-test.sh
M1_RC=$?
if [ $M1_RC -eq 0 ]; then PASS=$((PASS+1)); else FAIL=$((FAIL+1)); fi

step "6. Re-seed pristine demo data + restart dev for preview"
stop_dev
bun run db:seed || { echo "final seed failed"; FAIL=$((FAIL+1)); }
start_dev
echo "dev.log tail:"; tail -5 /tmp/m3-dev.out

echo ""
echo "============================================="
echo "M3 RUN-ALL SUMMARY: $PASS steps passed, $FAIL failed"
echo "  (m3 api suite rc=$M3_RC, m1 browser rc=$M1_RC)"
echo "============================================="
exit $((FAIL > 0 ? 1 : 0))
