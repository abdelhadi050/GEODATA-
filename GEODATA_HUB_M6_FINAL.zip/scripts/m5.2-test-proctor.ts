/**
 * M5.2-d TEST — Proctor compaction calculation module (MDD / OMC / ZAV).
 *
 * Golden values independently verified BEFORE being asserted here (60-digit
 * Decimal regression + IEEE-double probes mirroring the module's exact op
 * order — orthogonalized centered parabola basis, Cramer 2×2 solve, crest
 * window selection — plus half-away-from-zero rounding predictions with
 * tie-distance guards, in scripts/m5.2-d-verify-goldens.py). Sources: M5.2-d
 * authorization §4, registry proctorResult contract (ASTM D698 / ASTM D1557 /
 * NF P94-093), prisma/seed.ts fixtures PROCTOR_STD (1.97 @ 13.5) and
 * PROCTOR_MOD (2.10 @ 11.5).
 *
 * Coverage (authorization §9): normal valid cases (crest-window parabola
 * goldens, wet-density derivation, mold mass/volume bookkeeping, dish-mass
 * water content, ZAV curve); missing inputs (per-point w / density sources,
 * moldVolumeCm3, partial mass triples); invalid measurements (bounds,
 * NaN/Infinity, strings, 2/9 points, out-of-order points); boundary
 * conditions (entered tolerances both sides, registry mirror boundaries);
 * insufficient experimental data (peak not bracketed, convex crest, < 3
 * distinct moistures); unit consistency (g/cm³ ≡ Mg/m³ mold bookkeeping);
 * calculation consistency (MDD ≥ measured peak − tolerance, vertex inside
 * range, ZAV ≥ ρd, raw identity ρd = ρwet/(1+w)); physical consistency (ZAV
 * exceedance warnings); error and warning handling (registry mirrors,
 * entered discrepancies, INSUFFICIENT_DATA / PHYSICAL_CONSISTENCY codes);
 * M5.1 registry parity with documented divergences; determinism (25 runs ×
 * paths); purity; envelope provenance.
 *
 * Key verifier goldens (double probes; Decimal agrees to <1e-12):
 *   P1 window [(12,1.94),(14,1.97),(16,1.92)]: c0=0.07999999999998808,
 *     c1=0.27500000000000174, c2=-0.010000000000000063,
 *     OMC=13.750000000000002, MDD=1.970625.
 *   P2 window [(10,2.09),(12,2.1),(14,2.05)]: c0=1.1400000000000223,
 *     c1=0.16999999999999613, c2=-0.007499999999999839,
 *     OMC=11.333333333333318, MDD=2.1033333333333326.
 *   P3 window [(10,1.86),(13,1.94),(16,1.91)]: OMC=13.681818181818182,
 *     MDD=1.9428409090909087.
 *   P7 (replicate fallback, all 5 points): OMC=13.97881355932205,
 *     MDD=1.9317940131219244.
 * Raw values asserted at 1e-9 against the double probes; rounded results
 * asserted exactly (tie distances large except ZAV(10%, Gs 2.80) = 2.1875,
 * whose epsilon-corrected roundTo rounding to 2.188 is deterministic and
 * verifier-predicted).
 * Exit code = number of failures.
 */
import { runCalculation } from "../src/lib/calc/engine";
import type { CalculationOutcome } from "../src/lib/calc/types";
import {
  PROCTOR_DENSITY_TOLERANCE,
  PROCTOR_MOISTURE_TOLERANCE,
  dryDensityFromWet,
  fitCompactionParabola,
  proctorCalcInput,
  proctorModule,
  zeroAirVoidsDensity,
  type ProctorInput,
  type ProctorRaw,
  type ProctorResults,
} from "../src/lib/calc/modules/proctor";
import { parseLabTestResult } from "../src/lib/lab-tests/registry";

let pass = 0;
let fail = 0;
const ok = (m: string) => { console.log(`PASS: ${m}`); pass++; };
const no = (m: string) => { console.log(`FAIL: ${m}`); fail++; };

const approx = (actual: number, expected: number, tol: number): boolean =>
  Math.abs(actual - expected) <= tol;

type Outcome = CalculationOutcome<ProctorInput, ProctorRaw, ProctorResults>;

interface ExpectedError {
  code: string;
  fieldPath?: string;
  messageHint?: string;
}

function expectError(outcome: Outcome, label: string, expected: ExpectedError): void {
  if (outcome.status !== "error") {
    no(`${label} — expected ${expected.code}, got success`);
    return;
  }
  const { code, message, details } = outcome.error;
  if (code !== expected.code) {
    no(`${label} — expected ${expected.code}, got ${code}`);
    return;
  }
  if (expected.fieldPath !== undefined && details?.fieldPath !== expected.fieldPath) {
    no(`${label} — expected fieldPath ${expected.fieldPath}, got ${String(details?.fieldPath)}`);
    return;
  }
  if (expected.messageHint !== undefined && !message.includes(expected.messageHint)) {
    no(`${label} — message '${message}' lacks hint '${expected.messageHint}'`);
    return;
  }
  ok(`${label} — ${code}${expected.fieldPath ? ` @ ${expected.fieldPath}` : ""}`);
}

// ---------------------------------------------------------------------------
// Fixtures (independently verified in scripts/m5.2-d-verify-goldens.py)
// ---------------------------------------------------------------------------

/** PROCTOR_STD seed shape — registry points (moistureContent, dryDensity). */
const STD_POINTS = [
  { moistureContent: 8, dryDensity: 1.72 },
  { moistureContent: 10, dryDensity: 1.86 },
  { moistureContent: 12, dryDensity: 1.94 },
  { moistureContent: 14, dryDensity: 1.97 },
  { moistureContent: 16, dryDensity: 1.92 },
  { moistureContent: 18, dryDensity: 1.84 },
];
const STD_ENTERED = { maxDryDensity: 1.97, optimumMoisture: 13.5 };

/** PROCTOR_MOD seed shape — registry points with wetDensityMgM3 per point. */
const MOD_POINTS = [
  { moistureContent: 6, dryDensity: 1.9, wetDensityMgM3: 2.014 },
  { moistureContent: 8, dryDensity: 2.02, wetDensityMgM3: 2.182 },
  { moistureContent: 10, dryDensity: 2.09, wetDensityMgM3: 2.299 },
  { moistureContent: 12, dryDensity: 2.1, wetDensityMgM3: 2.352 },
  { moistureContent: 14, dryDensity: 2.05, wetDensityMgM3: 2.337 },
  { moistureContent: 16, dryDensity: 1.96, wetDensityMgM3: 2.274 },
];
const MOD_ENTERED = { maxDryDensity: 2.1, optimumMoisture: 11.5 };

/** Mass/volume points (mold 944 cm³) — net wet soil masses from the verifier. */
const MOLD_MASS_POINTS = [
  { moistureContent: 10, wetSoilMassG: 1931.4240000000002 },
  { moistureContent: 13, wetSoilMassG: 2069.4367999999995 },
  { moistureContent: 16, wetSoilMassG: 2091.5263999999997 },
  { moistureContent: 19, wetSoilMassG: 2066.9824 },
];

/** Dish-triple water content + entered wet density (w = 10/13/16 % exact). */
const DISH_POINTS = [
  { wetMassG: 155, dryMassG: 145, containerMassG: 45, wetDensityMgM3: 2.046 },
  { wetMassG: 158, dryMassG: 145, containerMassG: 45, wetDensityMgM3: 2.1922 },
  { wetMassG: 161, dryMassG: 145, containerMassG: 45, wetDensityMgM3: 2.2156 },
];

/** Standard calculable payload. */
const BASE = {
  method: "STANDARD" as const,
  points: STD_POINTS,
  ...STD_ENTERED,
};

// ---------------------------------------------------------------------------
// 1. Golden envelopes
// ---------------------------------------------------------------------------
{
  // Golden P1 — PROCTOR_STD + Gs 2.80: clean run, no warnings, crest window
  // [(12,1.94),(14,1.97),(16,1.92)], vertex (13.75 %, 1.970625 Mg/m³).
  const outcome = runCalculation(proctorModule, {
    method: "STANDARD", points: STD_POINTS, specificGravity: 2.8, ...STD_ENTERED,
  });
  if (outcome.status !== "ok") no(`golden P1 — failed: ${outcome.error.message}`);
  else {
    const checks: Array<[boolean, string]> = [
      [approx(outcome.raw.curveCoefficientConstant, 0.07999999999998808, 1e-9), "raw.c0 ≈ 0.08"],
      [approx(outcome.raw.curveCoefficientLinear, 0.27500000000000174, 1e-9), "raw.c1 ≈ 0.275"],
      [approx(outcome.raw.curveCoefficientQuadratic, -0.010000000000000063, 1e-9), "raw.c2 ≈ −0.01"],
      [approx(outcome.raw.optimumMoisture ?? 0, 13.750000000000002, 1e-9), "raw.optimumMoisture ≈ 13.75"],
      [approx(outcome.raw.maxDryDensity ?? 0, 1.970625, 1e-9), "raw.maxDryDensity ≈ 1.970625"],
      [outcome.results.method === "STANDARD", "results.method echoed"],
      [outcome.results.mold === null, "results.mold null when absent"],
      [outcome.results.pointCount === 6, "pointCount = 6"],
      [outcome.results.points.length === 6, "6 resolved points"],
      [outcome.results.points[3].moistureContent === 14, "point[3].moistureContent = 14"],
      [outcome.results.points[3].dryDensity === 1.97, "point[3].dryDensity = 1.97 (3 dp)"],
      [outcome.results.points[3].wetDensityMgM3 === null, "point[3].wetDensity null (no wet measurement)"],
      [outcome.results.curveCoefficientConstant === 0.08, "results.c0 = 0.08 (6 dp)"],
      [outcome.results.curveCoefficientLinear === 0.275, "results.c1 = 0.275"],
      [outcome.results.curveCoefficientQuadratic === -0.01, "results.c2 = −0.01"],
      [outcome.results.optimumMoisture === 13.75, "results.optimumMoisture = 13.75 (2 dp)"],
      [outcome.results.maxDryDensity === 1.971, "results.maxDryDensity = 1.971 (3 dp)"],
      [outcome.results.enteredMaxDryDensity === 1.97, "enteredMaxDryDensity echoed"],
      [outcome.results.enteredOptimumMoisture === 13.5, "enteredOptimumMoisture echoed"],
      [(outcome.raw.maxDryDensity ?? 0) >= 1.97 - PROCTOR_DENSITY_TOLERANCE, "calculation consistency — MDD ≥ measured peak − 0.01 (registry expectation)"],
      [(outcome.raw.optimumMoisture ?? 0) > 8 && (outcome.raw.optimumMoisture ?? 0) < 18, "vertex strictly inside the tested moisture range"],
      [outcome.warnings.length === 0, "no warnings (|ΔMDD| = 0.0006 ≤ 0.01; |ΔOMC| = 0.25 ≤ 1)"],
      [outcome.results.zavCurve !== null && outcome.results.zavCurve.length === 7, "ZAV curve: 6 measured + OMC"],
      [outcome.results.zavCurve?.[0].zavMgM3 === 2.288, "ZAV(8%) = 2.288"],
      [outcome.results.zavCurve?.[1].zavMgM3 === 2.188, "ZAV(10%) = 2.188 (verifier-predicted epsilon tie rounding)"],
      [outcome.results.zavCurve?.[3].zavMgM3 === 2.011, "ZAV(14%) = 2.011"],
      [outcome.results.zavCurve?.[5].zavMgM3 === 1.862, "ZAV(18%) = 1.862"],
      [outcome.results.zavCurve?.[6].zavMgM3 === 2.022, "ZAV(OMC 13.75%) = 2.022"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`golden P1 — ${label}`);
      else no(`golden P1 — ${label}`);
    }
  }
}
{
  // Golden P1b — same curve with Gs 2.71: points at w = 14/16/18 exceed the
  // ZAV curve → 3 PHYSICAL_CONSISTENCY warnings (data reported, not clamped).
  const outcome = runCalculation(proctorModule, {
    method: "STANDARD", points: STD_POINTS, specificGravity: 2.71,
  });
  if (outcome.status !== "ok") no(`golden P1b — failed: ${outcome.error.message}`);
  else {
    const zavWarnings = outcome.warnings.filter((w) => w.code === "PHYSICAL_CONSISTENCY");
    const checks: Array<[boolean, string]> = [
      [zavWarnings.length === 3, "3 PHYSICAL_CONSISTENCY warnings (w = 14, 16, 18 exceed ZAV at Gs 2.71)"],
      [outcome.results.maxDryDensity === 1.971, "MDD unchanged (1.971) — warnings never change results"],
      [outcome.results.zavCurve?.[3].zavMgM3 === 1.965, "ZAV(14%, Gs 2.71) = 1.965"],
      [outcome.results.points[3].zavDryDensityMgM3 === 1.965, "point[3].zavDryDensity = 1.965"],
      [outcome.results.points[3].dryDensity === 1.97 && outcome.results.points[3].dryDensity > 1.965, "point[3].dryDensity 1.97 > ZAV 1.965 — reported as-is, never clamped"],
      [zavWarnings.every((w) => w.details?.pointIndex !== undefined), "ZAV warnings carry pointIndex details"],
      [outcome.warnings.length === 3, "exactly 3 warnings total"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`golden P1b — ${label}`);
      else no(`golden P1b — ${label}`);
    }
  }
}
{
  // Golden P2 — PROCTOR_MOD: ρd = ρwet/(1+w/100) per point; window
  // [(10,2.09),(12,2.1),(14,2.05)]; OMC 11.33 %, MDD 2.103 Mg/m³.
  const outcome = runCalculation(proctorModule, {
    method: "MODIFIED", mold: "152.4MM", points: MOD_POINTS, ...MOD_ENTERED,
  });
  if (outcome.status !== "ok") no(`golden P2 — failed: ${outcome.error.message}`);
  else {
    const derived = [1.9, 2.02, 2.09, 2.1, 2.05, 1.96];
    const checks: Array<[boolean, string]> = [
      [outcome.results.points.every((p, i) => p.dryDensity === derived[i]), "per-point dryDensity = [1.9, 2.02, 2.09, 2.1, 2.05, 2.96→1.96] derived from wet densities"],
      [approx(outcome.raw.points[1].dryDensity, 2.02037037037037, 1e-9), "raw point[1] ρd ≈ 2.02037037037037 (double probe)"],
      [approx(outcome.raw.points[0].dryDensity, 1.8999999999999997, 1e-12), "raw point[0] ρd ≈ 1.8999999999999997 (representation noise kept)"],
      [approx(outcome.raw.curveCoefficientConstant, 1.1400000000000223, 1e-9), "raw.c0 ≈ 1.14"],
      [approx(outcome.raw.curveCoefficientLinear, 0.16999999999999613, 1e-9), "raw.c1 ≈ 0.17"],
      [approx(outcome.raw.curveCoefficientQuadratic, -0.007499999999999839, 1e-9), "raw.c2 ≈ −0.0075"],
      [approx(outcome.raw.optimumMoisture ?? 0, 11.333333333333318, 1e-9), "raw.optimumMoisture ≈ 11.333333333333318"],
      [approx(outcome.raw.maxDryDensity ?? 0, 2.1033333333333326, 1e-9), "raw.maxDryDensity ≈ 2.1033333333333326"],
      [outcome.results.optimumMoisture === 11.33, "results.optimumMoisture = 11.33"],
      [outcome.results.maxDryDensity === 2.103, "results.maxDryDensity = 2.103"],
      [outcome.results.method === "MODIFIED" && outcome.results.mold === "152.4MM", "method/mold echoed"],
      [outcome.warnings.length === 0, "no warnings (all identities within ±0.01 / ±1.0)"],
      [outcome.results.zavCurve === null, "no ZAV curve without Gs (never invented)"],
      [outcome.results.points.every((p) => p.zavDryDensityMgM3 === null), "per-point ZAV null without Gs"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`golden P2 — ${label}`);
      else no(`golden P2 — ${label}`);
    }
  }
}
{
  // Golden P3 — mass/volume bookkeeping: ρwet = wetSoilMassG/944 g/cm³ ≡
  // Mg/m³; window [(10,1.86),(13,1.94),(16,1.91)]; OMC 13.68, MDD 1.943.
  const outcome = runCalculation(proctorModule, {
    method: "MODIFIED", mold: "101.6MM", moldVolumeCm3: 944, points: MOLD_MASS_POINTS,
  });
  if (outcome.status !== "ok") no(`golden P3 — failed: ${outcome.error.message}`);
  else {
    const checks: Array<[boolean, string]> = [
      [approx(outcome.raw.points[0].wetDensityMgM3 ?? 0, 2.0460000000000003, 1e-12), "raw point[0] ρwet ≈ 2.0460000000000003 = 1931.424/944"],
      [outcome.raw.points[0].dryDensity === 1.86, "raw point[0] ρd = 1.86 (exact)"],
      [approx(outcome.raw.points[1].dryDensity, 1.9399999999999995, 1e-12), "raw point[1] ρd ≈ 1.9399999999999995"],
      [outcome.results.points[1].wetDensityMgM3 === 2.192, "results point[1] ρwet = 2.192 (3 dp)"],
      [outcome.results.points[1].dryDensity === 1.94, "results point[1] ρd = 1.94"],
      [approx(outcome.raw.curveCoefficientConstant, 0.7988888888888944, 1e-9), "raw.c0 ≈ 0.798889"],
      [approx(outcome.raw.curveCoefficientLinear, 0.16722222222222136, 1e-9), "raw.c1 ≈ 0.167222"],
      [approx(outcome.raw.curveCoefficientQuadratic, -0.006111111111111079, 1e-9), "raw.c2 ≈ −0.006111"],
      [approx(outcome.raw.optimumMoisture ?? 0, 13.681818181818182, 1e-9), "raw.optimumMoisture ≈ 13.681818181818182"],
      [approx(outcome.raw.maxDryDensity ?? 0, 1.9428409090909087, 1e-9), "raw.maxDryDensity ≈ 1.9428409090909087"],
      [outcome.results.optimumMoisture === 13.68, "results.optimumMoisture = 13.68"],
      [outcome.results.maxDryDensity === 1.943, "results.maxDryDensity = 1.943"],
      [outcome.warnings.length === 0, "no warnings"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`golden P3 — ${label}`);
      else no(`golden P3 — ${label}`);
    }
  }
}
{
  // Golden P8 — dish-triple water content (w = 10/13/16 % exact doubles) with
  // entered wet densities: SAME raw fit as P3 (independent w path consistency).
  const outcome = runCalculation(proctorModule, {
    method: "STANDARD", points: DISH_POINTS,
  });
  if (outcome.status !== "ok") no(`golden P8 — failed: ${outcome.error.message}`);
  else {
    const checks: Array<[boolean, string]> = [
      [outcome.raw.points[0].moistureContent === 10, "point[0] w = 10 exactly from dish masses (155,145,45)"],
      [outcome.raw.points[1].moistureContent === 13, "point[1] w = 13 exactly"],
      [outcome.raw.points[2].moistureContent === 16, "point[2] w = 16 exactly"],
      [approx(outcome.raw.points[0].dryDensity, 1.86, 1e-12), "point[0] ρd = 1.86 (same as P3 w-entered path)"],
      [approx(outcome.raw.points[1].dryDensity, 1.9399999999999995, 1e-12), "point[1] ρd ≈ 1.94"],
      [approx(outcome.raw.optimumMoisture ?? 0, 13.681818181818182, 1e-9), "same OMC as P3 (13.6818…) — mass-derived w path consistent"],
      [approx(outcome.raw.maxDryDensity ?? 0, 1.9428409090909087, 1e-9), "same MDD as P3 (1.9428…)"],
      [outcome.warnings.length === 0, "no warnings"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`golden P8 — ${label}`);
      else no(`golden P8 — ${label}`);
    }
  }
}
{
  // Golden P7 — replicate determinations at the peak moisture: the 3-point
  // window (13, 1.94),(13, 1.93) has 2 distinct w → fit extends to all points.
  const outcome = runCalculation(proctorModule, {
    method: "STANDARD",
    points: [
      { moistureContent: 10, dryDensity: 1.86 },
      { moistureContent: 13, dryDensity: 1.94 },
      { moistureContent: 13, dryDensity: 1.93 },
      { moistureContent: 16, dryDensity: 1.9 },
      { moistureContent: 19, dryDensity: 1.83 },
    ],
  });
  if (outcome.status !== "ok") no(`golden P7 — failed: ${outcome.error.message}`);
  else {
    const checks: Array<[boolean, string]> = [
      [approx(outcome.raw.curveCoefficientConstant, 1.105340501792119, 1e-9), "raw.c0 ≈ 1.105341 (all-points fallback fit)"],
      [approx(outcome.raw.curveCoefficientLinear, 0.11824372759856554, 1e-9), "raw.c1 ≈ 0.118244"],
      [approx(outcome.raw.curveCoefficientQuadratic, -0.004229390681003552, 1e-9), "raw.c2 ≈ −0.004229"],
      [approx(outcome.raw.optimumMoisture ?? 0, 13.97881355932205, 1e-9), "raw.optimumMoisture ≈ 13.97881355932205"],
      [approx(outcome.raw.maxDryDensity ?? 0, 1.9317940131219244, 1e-9), "raw.maxDryDensity ≈ 1.9317940131219244"],
      [outcome.results.optimumMoisture === 13.98, "results.optimumMoisture = 13.98"],
      [outcome.results.maxDryDensity === 1.932, "results.maxDryDensity = 1.932"],
      [outcome.warnings.length === 0, "replicates are legitimate (no warning)"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`golden P7 — ${label}`);
      else no(`golden P7 — ${label}`);
    }
  }
}

// ---------------------------------------------------------------------------
// 2. Insufficient data — MDD/OMC never fabricated
// ---------------------------------------------------------------------------
{
  // P4 — all points rising: fitted vertex (16.73 %) lies outside the tested
  // range [8, 14] → MDD/OMC null + INSUFFICIENT_DATA; the fit is still reported.
  const outcome = runCalculation(proctorModule, {
    method: "STANDARD",
    points: [
      { moistureContent: 8, dryDensity: 1.6 },
      { moistureContent: 10, dryDensity: 1.72 },
      { moistureContent: 12, dryDensity: 1.8 },
      { moistureContent: 14, dryDensity: 1.86 },
    ],
  });
  if (outcome.status !== "ok") no(`P4 peak-not-bracketed — failed: ${outcome.error.message}`);
  else {
    const checks: Array<[boolean, string]> = [
      [outcome.results.maxDryDensity === null, "maxDryDensity null (peak not bracketed — no fabrication)"],
      [outcome.results.optimumMoisture === null, "optimumMoisture null"],
      [outcome.raw.maxDryDensity === null && outcome.raw.optimumMoisture === null, "raw MDD/OMC null too"],
      [outcome.warnings.length === 1 && outcome.warnings[0].code === "INSUFFICIENT_DATA", "one INSUFFICIENT_DATA warning"],
      [outcome.warnings[0].message.includes("bracketed") || outcome.warnings[0].message.includes("outside"), "warning names the bracketing problem"],
      [outcome.results.points.length === 4, "per-point densities still reported"],
      [outcome.results.curveCoefficientQuadratic === -0.00375, "parabola coefficients still reported (c2 = −0.00375)"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`P4 — ${label}`);
      else no(`P4 — ${label}`);
    }
  }
}
{
  // P5 — convex crest (c2 > 0): no maximum exists → null + INSUFFICIENT_DATA.
  const outcome = runCalculation(proctorModule, {
    method: "STANDARD",
    points: [
      { moistureContent: 10, dryDensity: 1.9 },
      { moistureContent: 13, dryDensity: 1.84 },
      { moistureContent: 16, dryDensity: 1.82 },
      { moistureContent: 19, dryDensity: 1.86 },
    ],
  });
  if (outcome.status !== "ok") no(`P5 convex — failed: ${outcome.error.message}`);
  else {
    const checks: Array<[boolean, string]> = [
      [outcome.results.maxDryDensity === null && outcome.results.optimumMoisture === null, "MDD/OMC null (no concave maximum)"],
      [outcome.warnings.length === 1 && outcome.warnings[0].code === "INSUFFICIENT_DATA", "one INSUFFICIENT_DATA warning"],
      [outcome.warnings[0].message.includes("concave"), "warning names the concavity problem"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`P5 — ${label}`);
      else no(`P5 — ${label}`);
    }
  }
}
{
  // Insufficient distinct moistures — 2 distinct w among 4 points.
  const outcome = runCalculation(proctorModule, {
    method: "STANDARD",
    points: [
      { moistureContent: 10, dryDensity: 1.86 },
      { moistureContent: 10, dryDensity: 1.88 },
      { moistureContent: 14, dryDensity: 1.97 },
      { moistureContent: 14, dryDensity: 1.95 },
    ],
  });
  expectError(outcome, "2 distinct moistures — quadratic undefined", {
    code: "ARITHMETIC_DOMAIN_ERROR",
    messageHint: "distinct water contents",
  });
}
{
  // Single distinct moisture.
  const outcome = runCalculation(proctorModule, {
    method: "STANDARD",
    points: [
      { moistureContent: 12, dryDensity: 1.94 },
      { moistureContent: 12, dryDensity: 1.95 },
      { moistureContent: 12, dryDensity: 1.96 },
    ],
  });
  expectError(outcome, "1 distinct moisture — quadratic undefined", {
    code: "ARITHMETIC_DOMAIN_ERROR",
    messageHint: "distinct water contents",
  });
}

// ---------------------------------------------------------------------------
// 3. Entered-value comparison warnings (never overwrite)
// ---------------------------------------------------------------------------
{
  // MDD discrepancy: computed 1.970625 vs entered 1.95 → |Δ| = 0.0206 > 0.01.
  // (entered 1.95 ≥ peak − 0.01 = 1.96? NO — registry mirror fires first; use
  // an entered value that passes the mirrors but deviates from the fit:
  // entered 1.965: ≥ 1.96 OK; |1.970625 − 1.965| = 0.0056 ≤ 0.01 no warning.
  // entered 1.96: ≥ 1.96 boundary OK; |Δ| = 0.0106 > 0.01 → warning.)
  const outcome = runCalculation(proctorModule, {
    method: "STANDARD", points: STD_POINTS, maxDryDensity: 1.96, optimumMoisture: 13.5,
  });
  if (outcome.status !== "ok") no(`MDD boundary — failed: ${outcome.error.message}`);
  else {
    const mddWarnings = outcome.warnings.filter((w) => w.code === "ENTERED_VALUE_DISCREPANCY" && w.details?.field === "maxDryDensity");
    const checks: Array<[boolean, string]> = [
      [mddWarnings.length === 1, "one MDD ENTERED_VALUE_DISCREPANCY warning (|Δ| = 0.0106 > 0.01)"],
      [outcome.results.enteredMaxDryDensity === 1.96, "entered value echoed unchanged (1.96, not overwritten with 1.971)"],
      [mddWarnings[0]?.details?.tolerance === 0.01, "warning details carry tolerance 0.01"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`MDD tolerance — ${label}`);
      else no(`MDD tolerance — ${label}`);
    }
  }
}
{
  // OMC discrepancy: computed 13.75 vs entered 12.0 → |Δ| = 1.75 > 1.0 (and
  // 12.0 ≥ minW − 1 = 7 → registry mirror passes).
  const outcome = runCalculation(proctorModule, {
    method: "STANDARD", points: STD_POINTS, maxDryDensity: 1.97, optimumMoisture: 12,
  });
  if (outcome.status !== "ok") no(`OMC boundary — failed: ${outcome.error.message}`);
  else {
    const omcWarnings = outcome.warnings.filter((w) => w.code === "ENTERED_VALUE_DISCREPANCY" && w.details?.field === "optimumMoisture");
    const checks: Array<[boolean, string]> = [
      [omcWarnings.length === 1, "one OMC ENTERED_VALUE_DISCREPANCY warning (|Δ| = 1.75 > 1.0)"],
      [outcome.results.enteredOptimumMoisture === 12, "entered OMC echoed unchanged"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`OMC tolerance — ${label}`);
      else no(`OMC tolerance — ${label}`);
    }
  }
}
{
  // Per-point ρd identity: ρwet 2.20 at w = 10 % → ρd = 2.0 vs entered 2.05
  // → |Δ| = 0.05 > 0.01 warning (verifier case).
  const outcome = runCalculation(proctorModule, {
    method: "STANDARD",
    points: [
      { moistureContent: 10, dryDensity: 2.05, wetDensityMgM3: 2.2 },
      { moistureContent: 12, dryDensity: 1.94 },
      { moistureContent: 14, dryDensity: 1.97 },
    ],
  });
  if (outcome.status !== "ok") no(`per-point ρd identity — failed: ${outcome.error.message}`);
  else {
    const identity = outcome.warnings.find((w) => w.details?.field === "dryDensity");
    const checks: Array<[boolean, string]> = [
      [identity !== undefined, "one per-point dry-density identity warning (|Δ| = 0.05 > 0.01)"],
      [identity?.details?.pointIndex === 0, "warning carries pointIndex 0"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`per-point ρd identity — ${label}`);
      else no(`per-point ρd identity — ${label}`);
    }
  }
}
{
  // Per-point w identity: entered 15 % vs dish masses (1013, 910, 100) giving
  // 12.716 % → |Δ| = 2.28 > 0.5 warning; the ENTERED w is used (never replaced).
  const outcome = runCalculation(proctorModule, {
    method: "STANDARD",
    points: [
      { moistureContent: 12, dryDensity: 1.94 },
      { moistureContent: 14, dryDensity: 1.97 },
      { moistureContent: 15, wetMassG: 1013, dryMassG: 910, containerMassG: 100, dryDensity: 1.9 },
    ],
  });
  if (outcome.status !== "ok") no(`per-point w identity — failed: ${outcome.error.message}`);
  else {
    const identity = outcome.warnings.find((w) => w.details?.field === "moistureContent");
    const checks: Array<[boolean, string]> = [
      [identity !== undefined, "one per-point water-content identity warning (|Δ| = 2.28 > 0.5)"],
      [approx(outcome.raw.points[2].moistureContent, 15, 1e-12), "the ENTERED w (15) is used, not the mass-derived 12.716"],
      [identity?.details?.pointIndex === 2, "warning carries pointIndex 2"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`per-point w identity — ${label}`);
      else no(`per-point w identity — ${label}`);
    }
  }
}

// ---------------------------------------------------------------------------
// 4. Registry mirrors (entered finals vs measured points) — INVALID_INPUT
// ---------------------------------------------------------------------------
{
  const outcome = runCalculation(proctorModule, {
    method: "STANDARD", points: STD_POINTS, maxDryDensity: 1.95, optimumMoisture: 13.5,
  });
  expectError(outcome, "entered maxDryDensity below peak − 0.01 (registry mirror)", {
    code: "INVALID_INPUT",
    fieldPath: "maxDryDensity",
    messageHint: "cannot be lower",
  });
}
{
  const outcome = runCalculation(proctorModule, {
    method: "STANDARD", points: STD_POINTS, maxDryDensity: 2.25, optimumMoisture: 13.5,
  });
  expectError(outcome, "entered maxDryDensity above peak + 0.2 (registry mirror)", {
    code: "INVALID_INPUT",
    fieldPath: "maxDryDensity",
    messageHint: "inconsistent with the measured curve",
  });
}
{
  const outcome = runCalculation(proctorModule, {
    method: "STANDARD", points: STD_POINTS, maxDryDensity: 1.97, optimumMoisture: 19.5,
  });
  expectError(outcome, "entered optimumMoisture above max + 1 (registry mirror)", {
    code: "INVALID_INPUT",
    fieldPath: "optimumMoisture",
    messageHint: "within the tested moisture range",
  });
}
{
  const outcome = runCalculation(proctorModule, {
    method: "STANDARD", points: STD_POINTS, maxDryDensity: 1.97, optimumMoisture: 19.0,
  });
  if (outcome.status === "ok") ok("entered optimumMoisture 19.0 = max + 1 boundary — accepted (registry mirror boundary)");
  else no(`entered optimumMoisture 19.0 boundary — rejected: ${outcome.error.message}`);
}
{
  const outcome = runCalculation(proctorModule, {
    method: "STANDARD",
    points: [{ moistureContent: 10, dryDensity: 1.86, wetDensityMgM3: 1.8 }, { moistureContent: 12, dryDensity: 1.94 }, { moistureContent: 14, dryDensity: 1.97 }],
  });
  expectError(outcome, "entered wetDensity < dryDensity (registry mirror)", {
    code: "INVALID_INPUT",
    fieldPath: "points.0.wetDensityMgM3",
    messageHint: "greater than or equal",
  });
}

// ---------------------------------------------------------------------------
// 5. Missing and invalid inputs
// ---------------------------------------------------------------------------
{
  const outcome = runCalculation(proctorModule, {});
  expectError(outcome, "empty payload", { code: "MISSING_INPUT", messageHint: "method, points" });
}
{
  const outcome = runCalculation(proctorModule, { method: "STANDARD" });
  expectError(outcome, "method only (no points)", { code: "MISSING_INPUT", messageHint: "points" });
}
{
  // Point without any water-content source.
  const outcome = runCalculation(proctorModule, {
    method: "STANDARD",
    points: [{ dryDensity: 1.86 }, { moistureContent: 12, dryDensity: 1.94 }, { moistureContent: 14, dryDensity: 1.97 }],
  });
  expectError(outcome, "point without water-content measurement", {
    code: "INVALID_INPUT",
    fieldPath: "points.0.moistureContent",
    messageHint: "no water-content measurement",
  });
}
{
  // Point without any density source.
  const outcome = runCalculation(proctorModule, {
    method: "STANDARD",
    points: [{ moistureContent: 10 }, { moistureContent: 12, dryDensity: 1.94 }, { moistureContent: 14, dryDensity: 1.97 }],
  });
  expectError(outcome, "point without density measurement", {
    code: "INVALID_INPUT",
    fieldPath: "points.0.dryDensity",
    messageHint: "no density measurement",
  });
}
{
  // wetSoilMassG without moldVolumeCm3 and without wetDensityMgM3.
  const outcome = runCalculation(proctorModule, {
    method: "STANDARD",
    points: [{ moistureContent: 10, wetSoilMassG: 1900 }, { moistureContent: 12, dryDensity: 1.94 }, { moistureContent: 14, dryDensity: 1.97 }],
  });
  expectError(outcome, "wetSoilMassG without moldVolumeCm3", {
    code: "INVALID_INPUT",
    fieldPath: "points.0.wetSoilMassG",
    messageHint: "moldVolumeCm3",
  });
}
{
  // Partial mass triple.
  const outcome = runCalculation(proctorModule, {
    method: "STANDARD",
    points: [{ moistureContent: 10, wetMassG: 500 }, { moistureContent: 12, dryDensity: 1.94 }, { moistureContent: 14, dryDensity: 1.97 }],
  });
  expectError(outcome, "partial dish-mass triple (1 of 3)", {
    code: "INVALID_INPUT",
    fieldPath: "points.0.wetMassG",
    messageHint: "3 mass fields",
  });
}
{
  const outcome = runCalculation(proctorModule, {
    method: "STANDARD",
    points: [
      { moistureContent: 10, dryDensity: 1.86 },
      { moistureContent: 12, dryDensity: 1.94 },
      { moistureContent: 61, dryDensity: 1.97 },
    ],
  });
  expectError(outcome, "moisture 61 % out of registry bound", { code: "INVALID_INPUT", messageHint: "60" });
}
{
  const outcome = runCalculation(proctorModule, {
    method: "STANDARD",
    points: [
      { moistureContent: 10, dryDensity: 2.8 },
      { moistureContent: 12, dryDensity: 1.94 },
      { moistureContent: 14, dryDensity: 1.97 },
    ],
  });
  expectError(outcome, "dryDensity 2.8 out of registry bound", { code: "INVALID_INPUT", messageHint: "2.7" });
}
{
  const outcome = runCalculation(proctorModule, {
    method: "STANDARD",
    points: [
      { moistureContent: 10, dryDensity: Number.NaN },
      { moistureContent: 12, dryDensity: 1.94 },
      { moistureContent: 14, dryDensity: 1.97 },
    ],
  });
  expectError(outcome, "NaN dryDensity", { code: "INVALID_INPUT" });
}
{
  const outcome = runCalculation(proctorModule, {
    method: "STANDARD",
    points: [
      { moistureContent: 10, dryDensity: "1.86" },
      { moistureContent: 12, dryDensity: 1.94 },
      { moistureContent: 14, dryDensity: 1.97 },
    ] as unknown as ProctorInput["points"],
  });
  expectError(outcome, "string dryDensity", { code: "INVALID_INPUT" });
}
{
  const outcome = runCalculation(proctorModule, {
    method: "STANDARD",
    points: [
      { moistureContent: 10, dryDensity: 1.86 },
      { moistureContent: 12, dryDensity: 1.94 },
    ],
  });
  expectError(outcome, "2 points (min 3)", { code: "INVALID_INPUT" });
}
{
  const outcome = runCalculation(proctorModule, {
    method: "STANDARD",
    points: Array.from({ length: 9 }, (_, i) => ({ moistureContent: 8 + i * 2, dryDensity: 1.8 })),
  });
  expectError(outcome, "9 points (max 8)", { code: "INVALID_INPUT" });
}
{
  // Out-of-order points (w decreasing) — never silently reordered.
  const outcome = runCalculation(proctorModule, {
    method: "STANDARD",
    points: [
      { moistureContent: 14, dryDensity: 1.97 },
      { moistureContent: 10, dryDensity: 1.86 },
      { moistureContent: 12, dryDensity: 1.94 },
    ],
  });
  expectError(outcome, "out-of-order points (w decreasing)", {
    code: "INVALID_INPUT",
    fieldPath: "points.1.moistureContent",
    messageHint: "non-decreasing",
  });
}
{
  const outcome = runCalculation(proctorModule, {
    method: "HEAVY", points: STD_POINTS,
  } as unknown as { method: string });
  expectError(outcome, "unknown method value", { code: "INVALID_INPUT" });
}
{
  // Gs outside the registry SPECIFIC_GRAVITY bound.
  const outcome = runCalculation(proctorModule, {
    method: "STANDARD", points: STD_POINTS, specificGravity: 3.1,
  });
  expectError(outcome, "Gs 3.1 out of bound", { code: "INVALID_INPUT" });
}

// ---------------------------------------------------------------------------
// 6. Direct helper tests
// ---------------------------------------------------------------------------
{
  try {
    dryDensityFromWet(0, 10);
    no("dryDensityFromWet(0, …) — no throw");
  } catch (e) {
    ok(`dryDensityFromWet(0, …) — ArithmeticDomainError (${(e as { code?: string }).code})`);
  }
}
{
  try {
    zeroAirVoidsDensity(2.7, -40);
    no("zeroAirVoidsDensity(2.7, −40) — no throw (denominator ≤ 0)");
  } catch (e) {
    ok(`zeroAirVoidsDensity(2.7, −40) — ArithmeticDomainError (denominator)`);
  }
}
{
  try {
    fitCompactionParabola([{ x: 1, y: 1 }, { x: 1, y: 2 }, { x: 1, y: 3 }]);
    no("fitCompactionParabola single distinct x — no throw");
  } catch (e) {
    ok(`fitCompactionParabola single distinct x — ArithmeticDomainError`);
  }
}
{
  // ZAV monotonicity sanity: ZAV strictly decreases with w (Gs 2.7).
  const z10 = zeroAirVoidsDensity(2.7, 10);
  const z14 = zeroAirVoidsDensity(2.7, 14);
  if (z10 > z14) ok(`helper — ZAV(10%) > ZAV(14%) (${z10.toFixed(4)} > ${z14.toFixed(4)}) — monotone decreasing`);
  else no("helper — ZAV not monotone");
}
{
  // dryDensityFromWet identity: ρd = ρwet/(1+w/100) raw identity.
  const rd = dryDensityFromWet(2.2, 10);
  if (approx(rd, 2.0, 1e-12)) ok("helper — dryDensityFromWet(2.2, 10) = 2.0 exact");
  else no(`helper — dryDensityFromWet(2.2, 10) = ${rd}`);
}

// ---------------------------------------------------------------------------
// 7. Schema export parity (stripping behaviour)
// ---------------------------------------------------------------------------
{
  const parsed = proctorCalcInput.safeParse({
    method: "STANDARD", points: STD_POINTS, notes: "extra", unknownKey: 42,
  });
  if (parsed.success && !("notes" in parsed.data) && !("unknownKey" in parsed.data)) {
    ok("schema — unknown keys (notes, unknownKey) stripped (Zod default)");
  } else {
    no("schema — unknown keys not stripped");
  }
}

// ---------------------------------------------------------------------------
// 8. M5.1 registry compatibility — parity and documented divergences
// ---------------------------------------------------------------------------
{
  // Shared valid: the full registry-shaped payload with computed-consistent
  // finals passes BOTH the module and the registry result schema.
  const registryPayload = {
    method: "STANDARD" as const,
    points: STD_POINTS,
    maxDryDensity: 1.97,
    optimumMoisture: 13.5,
  };
  const moduleOutcome = runCalculation(proctorModule, registryPayload);
  const registryOutcome = parseLabTestResult("PROCTOR", registryPayload);
  const checks: Array<[boolean, string]> = [
    [moduleOutcome.status === "ok", "shared valid — module accepts the registry-shaped payload"],
    [registryOutcome.ok, "shared valid — registry result schema accepts it"],
  ];
  // Computed finals (MDD 1.971, OMC 13.75) revalidate through the registry.
  if (moduleOutcome.status === "ok") {
    const computedPayload = {
      method: "STANDARD" as const,
      points: moduleOutcome.results.points.map((p) => ({ moistureContent: p.moistureContent, dryDensity: p.dryDensity })),
      maxDryDensity: moduleOutcome.results.maxDryDensity ?? 0,
      optimumMoisture: moduleOutcome.results.optimumMoisture ?? 0,
    };
    const revalidated = parseLabTestResult("PROCTOR", computedPayload);
    checks.push([revalidated.ok, `computed finals (MDD 1.971, OMC 13.75) revalidate through the registry result schema${revalidated.ok ? "" : `: ${revalidated.error}`}`]);
    checks.push([moduleOutcome.results.maxDryDensity === 1.971 && moduleOutcome.results.optimumMoisture === 13.75, "computed values are the golden ones"]);
  }
  for (const [condition, label] of checks) {
    if (condition) ok(`parity — ${label}`);
    else no(`parity — ${label}`);
  }
}
{
  // Shared invalid (both reject): entered maxDryDensity below peak.
  const payload = { method: "STANDARD" as const, points: STD_POINTS, maxDryDensity: 1.95, optimumMoisture: 13.5 };
  const moduleOutcome = runCalculation(proctorModule, payload);
  const registryOutcome = parseLabTestResult("PROCTOR", payload);
  if (moduleOutcome.status === "error" && !registryOutcome.ok) {
    ok("shared invalid — entered maxDryDensity below peak: module INVALID_INPUT and registry both reject");
  } else {
    no(`shared invalid — maxDryDensity below peak: module ${moduleOutcome.status}, registry ok=${registryOutcome.ok}`);
  }
}
{
  // Shared invalid (both reject): optimumMoisture outside the tested range.
  const payload = { method: "STANDARD" as const, points: STD_POINTS, maxDryDensity: 1.97, optimumMoisture: 19.5 };
  const moduleOutcome = runCalculation(proctorModule, payload);
  const registryOutcome = parseLabTestResult("PROCTOR", payload);
  if (moduleOutcome.status === "error" && !registryOutcome.ok) {
    ok("shared invalid — optimumMoisture 19.5 outside range: both reject");
  } else {
    no(`shared invalid — optimumMoisture 19.5: module ${moduleOutcome.status}, registry ok=${registryOutcome.ok}`);
  }
}
{
  // Shared invalid (both reject): moisture 61 % / dryDensity 2.8 (bounds).
  const bad = { method: "STANDARD" as const, points: [{ moistureContent: 61, dryDensity: 1.86 }, { moistureContent: 12, dryDensity: 1.94 }, { moistureContent: 14, dryDensity: 1.97 }], maxDryDensity: 1.97, optimumMoisture: 13.5 };
  const m1 = runCalculation(proctorModule, bad);
  const r1 = parseLabTestResult("PROCTOR", bad);
  if (m1.status === "error" && !r1.ok) ok("shared invalid — moisture 61 %: both reject");
  else no(`shared invalid — moisture 61 %: module ${m1.status}, registry ok=${r1.ok}`);
  const bad2 = { method: "STANDARD" as const, points: [{ moistureContent: 10, dryDensity: 2.8 }, { moistureContent: 12, dryDensity: 1.94 }, { moistureContent: 14, dryDensity: 1.97 }], maxDryDensity: 2.8, optimumMoisture: 13.5 };
  const m2 = runCalculation(proctorModule, bad2);
  const r2 = parseLabTestResult("PROCTOR", bad2);
  if (m2.status === "error" && !r2.ok) ok("shared invalid — dryDensity 2.8: both reject");
  else no(`shared invalid — dryDensity 2.8: module ${m2.status}, registry ok=${r2.ok}`);
}
{
  // Documented divergence 1 — wet-density-only point: the registry result
  // schema REQUIRES dryDensity per point (it stores finals); the module
  // COMPUTES it from the wet measurement.
  const payload = {
    method: "STANDARD" as const,
    points: [
      { moistureContent: 10, wetDensityMgM3: 2.046 },
      { moistureContent: 13, wetDensityMgM3: 2.1922 },
      { moistureContent: 16, wetDensityMgM3: 2.2156 },
    ],
  };
  const moduleOutcome = runCalculation(proctorModule, payload);
  const registryOutcome = parseLabTestResult("PROCTOR", { ...payload, maxDryDensity: 1.94, optimumMoisture: 13 });
  if (moduleOutcome.status === "ok" && !registryOutcome.ok) {
    ok("divergence — wet-density-only points: module computes ρd; registry cannot store (dryDensity required)");
  } else {
    no(`divergence — wet-density-only: module ${moduleOutcome.status}, registry ok=${registryOutcome.ok}`);
  }
}
{
  // Documented divergence 2 — unordered points: registry stores any order;
  // the module rejects (never silently reorders — M5.2-b policy).
  const payload = {
    method: "STANDARD" as const,
    points: [
      { moistureContent: 14, dryDensity: 1.97 },
      { moistureContent: 10, dryDensity: 1.86 },
      { moistureContent: 12, dryDensity: 1.94 },
    ],
    maxDryDensity: 1.97,
    optimumMoisture: 13.5,
  };
  const moduleOutcome = runCalculation(proctorModule, payload);
  const registryOutcome = parseLabTestResult("PROCTOR", payload);
  if (moduleOutcome.status === "error" && registryOutcome.ok) {
    ok("divergence — unordered points: registry stores, module rejects (ordering rule)");
  } else {
    no(`divergence — unordered: module ${moduleOutcome.status}, registry ok=${registryOutcome.ok}`);
  }
}
{
  // Documented divergence 3 — ZAV: engine-side extension (Gs + ρw constant);
  // the registry proctorResult has no ZAV storage.
  const outcome = runCalculation(proctorModule, {
    method: "STANDARD", points: STD_POINTS, specificGravity: 2.8,
  });
  if (outcome.status === "ok" && outcome.results.zavCurve !== null) {
    ok("divergence — ZAV curve computed engine-side; the registry has no ZAV storage field");
  } else {
    no("divergence — ZAV not computed");
  }
}

// ---------------------------------------------------------------------------
// 9. Determinism, purity, envelope
// ---------------------------------------------------------------------------
{
  const payload = { method: "STANDARD" as const, points: STD_POINTS, specificGravity: 2.8, ...STD_ENTERED };
  let allEqual = true;
  const first = runCalculation(proctorModule, payload);
  for (let i = 0; i < 25; i++) {
    const next = runCalculation(proctorModule, payload);
    if (JSON.stringify(next) !== JSON.stringify(first)) allEqual = false;
  }
  if (allEqual) ok("determinism — 25 runs deeply identical (golden path)");
  else no("determinism — golden path outputs differ across runs");
}
{
  const payload = { method: "STANDARD" as const, points: STD_POINTS, specificGravity: 2.71 };
  const first = runCalculation(proctorModule, payload);
  let allEqual = true;
  for (let i = 0; i < 25; i++) {
    if (JSON.stringify(runCalculation(proctorModule, payload)) !== JSON.stringify(first)) allEqual = false;
  }
  if (allEqual) ok("determinism — 25 runs deeply identical (warning path)");
  else no("determinism — warning path outputs differ");
}
{
  // Purity — the input payload is never mutated.
  const payload = {
    method: "STANDARD" as const,
    points: [
      { moistureContent: 8, dryDensity: 1.72 },
      { moistureContent: 10, dryDensity: 1.86 },
      { moistureContent: 12, dryDensity: 1.94 },
      { moistureContent: 14, dryDensity: 1.97 },
      { moistureContent: 16, dryDensity: 1.92 },
      { moistureContent: 18, dryDensity: 1.84 },
    ],
    specificGravity: 2.8,
  };
  const snapshot = JSON.stringify(payload);
  runCalculation(proctorModule, payload);
  if (JSON.stringify(payload) === snapshot) ok("purity — input payload never mutated");
  else no("purity — input payload mutated");
}
{
  const outcome = runCalculation(proctorModule, BASE);
  if (outcome.status !== "ok") no(`envelope — failed: ${outcome.error.message}`);
  else {
    const checks: Array<[boolean, string]> = [
      [outcome.engineVersion === "1.0.0", "engineVersion = 1.0.0"],
      [outcome.moduleId === "proctor", "moduleId = proctor"],
      [outcome.moduleVersion === "1.0.0", "moduleVersion = 1.0.0"],
      [outcome.testType === "PROCTOR", "testType = PROCTOR"],
      [outcome.input === BASE || JSON.stringify(outcome.input) === JSON.stringify(BASE), "input echoed"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`envelope — ${label}`);
      else no(`envelope — ${label}`);
    }
  }
}

console.log(`\n================ M5.2-d PROCTOR TEST SUMMARY: ${pass} passed, ${fail} failed ================`);
process.exit(fail);
