#!/usr/bin/env bash
# M4 frontend browser test suite (semantic locators, agent-browser).
# Assumes: dev server ALREADY RUNNING at 127.0.0.1:3000 with freshly seeded DB.
# Run via scripts/m4-run-all.sh (single bash invocation — sandbox rule).
set -u
cd /home/z/my-project

BASE=http://127.0.0.1:3000
SHOTS=download/m4-screenshots
mkdir -p "$SHOTS"
PASS=0; FAIL=0
ok(){ echo "PASS: $1"; PASS=$((PASS+1)); }
no(){ echo "FAIL: $1"; FAIL=$((FAIL+1)); }
body(){ agent-browser eval "document.body.innerText" 2>/dev/null; }
shot(){ agent-browser screenshot "$SHOTS/$1" >/dev/null 2>&1 || echo "  (screenshot $1 failed)"; }
waitidle(){ agent-browser wait --load networkidle >/dev/null 2>&1; sleep 0.5; }

login(){
  agent-browser open "$BASE/login" >/dev/null 2>&1; waitidle
  agent-browser find label "Email" fill "$1" >/dev/null 2>&1
  agent-browser find label "Password" fill "$2" >/dev/null 2>&1
  agent-browser find role button click --name "Sign in" >/dev/null 2>&1
  agent-browser wait --url "/dashboard" --timeout 20000 >/dev/null 2>&1
  # Wait for the dashboard document to commit (URL commits before the DOM swap).
  for _i in $(seq 1 15); do
    agent-browser eval "document.querySelector('[data-slot=sidebar-inner]')!==null" 2>/dev/null | tr -d '"' | grep -q true && break
    sleep 1
  done
  sleep 0.5
}
logout(){
  # The dashboard carries a dedicated Sign out button (M1 contract).
  agent-browser open "$BASE/dashboard" >/dev/null 2>&1
  for _i in $(seq 1 15); do
    agent-browser eval "[...document.querySelectorAll('button')].some(b=>b.textContent.trim()==='Sign out')" 2>/dev/null | tr -d '"' | grep -q true && break
    sleep 1
  done
  agent-browser find role button click --name "Sign out" >/dev/null 2>&1
  agent-browser wait --url "/login" --timeout 15000 >/dev/null 2>&1
  waitidle
}
await_text(){ # $1 = text expected in body; bounded poll for client-side navigations
  for _i in $(seq 1 15); do
    agent-browser eval "document.body.innerText.includes('$1')" 2>/dev/null | tr -d '"' | grep -q true && return 0
    sleep 1
  done
  return 1
}
click_link_until(){ # $1 = link name, $2 = url fragment; retries across re-renders
  for _i in $(seq 1 6); do
    agent-browser find role link click --name "$1" >/dev/null 2>&1
    agent-browser wait --url "$2" --timeout 6000 >/dev/null 2>&1 && return 0
    sleep 1
  done
  return 1
}
svg_has(){ # $1 = text expected inside an SVG (recharts labels)
  agent-browser eval "[...document.querySelectorAll('svg text, svg tspan')].some(t=>(t.textContent||'').includes('$1'))" 2>/dev/null | tr -d '"'
}
stat_value(){ # $1 = stat card label
  agent-browser eval "(function(){const t=[...document.querySelectorAll('.text-sm.text-muted-foreground')].find(e=>e.textContent==='$1');return t?t.nextElementSibling.textContent:'missing';})()" 2>/dev/null | tr -d '"'
}

agent-browser close >/dev/null 2>&1 || true

echo "=== M4-01: login page renders ==="
agent-browser open "$BASE/login" >/dev/null 2>&1; waitidle
shot "01-login.png"
B=$(body)
echo "$B" | grep -q "GEODATA HUB" && ok "login page brand" || no "login page brand"
echo "$B" | grep -qi "sign in" && ok "login page sign-in form" || no "login page sign-in form"

echo "=== M4-02: login as org admin ==="
login admin@geodata.demo Demo1234!
URL=$(agent-browser get url 2>/dev/null)
case "$URL" in */dashboard) ok "admin login -> /dashboard";; *) no "admin login (got $URL)";; esac
B=$(body)
echo "$B" | grep -q "Ana Rivera" && ok "user identity in shell" || no "user identity in shell"
echo "$B" | grep -q "GeoStruct Consulting" && ok "organization name in shell" || no "organization name in shell"

echo "=== M4-03: dashboard real metrics (seeded data) ==="
shot "02-dashboard-light.png"
P=$(stat_value "Projects"); A=$(stat_value "Active projects"); S=$(stat_value "Pending shares")
echo "  stats: projects=$P active=$A pendingShares=$S"
[ "$P" = "5" ] && ok "dashboard projects = 5 (live API total)" || no "dashboard projects expected 5 got '$P'"
[ "$A" = "3" ] && ok "dashboard active projects = 3" || no "dashboard active expected 3 got '$A'"
[ "$S" = "2" ] && ok "dashboard pending shares = 2 (1 sent + 1 inbox)" || no "dashboard pending shares expected 2 got '$S'"
B=$(body)
echo "$B" | grep -q "Recent projects" && ok "dashboard recent projects section" || no "dashboard recent projects section"
echo "$B" | grep -q "A1-TEN-2025" && ok "dashboard recent project code from API" || no "dashboard recent project code"
echo "$B" | grep -q "Recent activity" && ok "dashboard recent activity section" || no "dashboard recent activity section"
echo "$B" | grep -q "Projects by status" && ok "dashboard status distribution" || no "dashboard status distribution"
echo "$B" | grep -q "Laboratory tests by status" && ok "dashboard lab test distribution" || no "dashboard lab test distribution"

echo "=== M4-04: sidebar navigation (admin sees all groups) ==="
NAV=$(agent-browser eval "(function(){return [...document.querySelectorAll('[data-slot=sidebar-inner] a')].map(a=>a.getAttribute('href')).join(',');})()" 2>/dev/null | tr -d '"')
echo "  nav: $NAV"
for item in /dashboard /projects /boreholes /samples /lab-tests /documents /reports /sharing /activity /users /settings; do
  case ",$NAV," in *",$item,"*) ok "nav $item";; *) no "nav $item missing";; esac
done

echo "=== M4-05: projects list + search ==="
agent-browser open "$BASE/projects" >/dev/null 2>&1; waitidle
shot "03-projects.png"
B=$(body)
echo "$B" | grep -q "A1-TEN-2025" && ok "projects list shows seeded project" || no "projects list seeded project"
echo "$B" | grep -q "METRO-ALG-EXT" && ok "projects list shows METRO project" || no "projects list METRO project"
agent-browser find label "Search" fill "METRO" >/dev/null 2>&1
agent-browser press Enter >/dev/null 2>&1; waitidle
B=$(body)
echo "$B" | grep -q "METRO-ALG-EXT" && ok "search narrows to METRO" || no "search METRO"
case "$(echo "$B" | grep -c "A1-TEN-2025")" in 0) ok "search excludes A1";; *) no "search should exclude A1";; esac
agent-browser open "$BASE/projects?status=ON_HOLD" >/dev/null 2>&1; waitidle
B=$(body)
echo "$B" | grep -q "PORT-ORN-TERM" && ok "status filter ON_HOLD shows PORT" || no "status filter ON_HOLD"
case "$(echo "$B" | grep -c "A1-TEN-2025")" in 0) ok "status filter excludes ACTIVE";; *) no "status filter should exclude ACTIVE";; esac

echo "=== M4-06: create project through dialog ==="
agent-browser open "$BASE/projects" >/dev/null 2>&1; waitidle
agent-browser find role button click --name "New project" >/dev/null 2>&1; sleep 0.5
agent-browser find label "Code" fill "M4-DEMO-01" >/dev/null 2>&1
agent-browser find label "Name" fill "M4 Verification Project" >/dev/null 2>&1
agent-browser find label "Client" fill "GEODATA HUB QA" >/dev/null 2>&1
agent-browser find label "Location" fill "Blida" >/dev/null 2>&1
agent-browser find label "Latitude" fill "36.47" >/dev/null 2>&1
agent-browser find label "Longitude" fill "2.83" >/dev/null 2>&1
agent-browser find role button click --name "Create project" >/dev/null 2>&1
agent-browser wait --url "/projects/" --timeout 20000 >/dev/null 2>&1
await_text "M4 Verification Project" || true
URL=$(agent-browser get url 2>/dev/null)
case "$URL" in */projects/cm*|*/projects/cl*|*/projects/m*) ok "create project redirects to detail";; *) no "create project redirect (got $URL)";; esac
B=$(body)
echo "$B" | grep -q "M4-DEMO-01" && ok "project detail shows new code" || no "project detail new code"
echo "$B" | grep -q "M4 Verification Project" && ok "project detail shows name" || no "project detail name"
echo "$B" | grep -q "GEODATA HUB QA" && ok "project detail shows client" || no "project detail client"

echo "=== M4-07: create borehole under new project ==="
shot "04-project-detail.png"
agent-browser find role button click --name "New borehole" >/dev/null 2>&1; sleep 0.5
agent-browser find label "Code" fill "BH-M4" >/dev/null 2>&1
agent-browser find label "Latitude *" fill "36.4701" >/dev/null 2>&1
agent-browser find label "Longitude *" fill "2.8301" >/dev/null 2>&1
agent-browser find label "Depth (m)" fill "10" >/dev/null 2>&1
agent-browser find role button click --name "Create borehole" >/dev/null 2>&1
agent-browser wait --url "/boreholes/" --timeout 20000 >/dev/null 2>&1
await_text "Drilling record" || true
URL=$(agent-browser get url 2>/dev/null)
case "$URL" in */boreholes/*) ok "borehole created, on detail page";; *) no "borehole detail (got $URL)";; esac
B=$(body)
echo "$B" | grep -q "BH-M4" && ok "borehole detail shows code" || no "borehole detail code"
echo "$B" | grep -q "10.00 m" && ok "borehole depth displayed" || no "borehole depth"

echo "=== M4-08: add geological layer + stratigraphy ==="
agent-browser find role button click --name "Add layer" >/dev/null 2>&1; sleep 0.5
agent-browser find label "Depth from (m) *" fill "0" >/dev/null 2>&1
agent-browser find label "Depth to (m) *" fill "2.5" >/dev/null 2>&1
agent-browser find label "Description *" fill "Brown sandy silty fill with gravel" >/dev/null 2>&1 || \
  agent-browser find label "Description" fill "Brown sandy silty fill with gravel" >/dev/null 2>&1
agent-browser find role button click --name "Save layer" >/dev/null 2>&1
await_text "Brown sandy silty fill" && ok "layer added and listed" || no "layer listed"
STRAT=$(agent-browser eval "document.querySelector('[aria-label^=Stratigraphic]')!==null" 2>/dev/null | tr -d '"')
[ "$STRAT" = "true" ] && ok "stratigraphy column rendered" || no "stratigraphy column rendered"

echo "=== M4-09: add sample ==="
agent-browser find role button click --name "New sample" >/dev/null 2>&1; sleep 0.5
agent-browser find label "Code" fill "S-M4" >/dev/null 2>&1
agent-browser find label "Depth from (m) *" fill "0.5" >/dev/null 2>&1
agent-browser find label "Depth to (m) *" fill "1.0" >/dev/null 2>&1
agent-browser find role button click --name "Create sample" >/dev/null 2>&1
await_text "S-M4" && ok "sample added and listed" || no "sample listed"

echo "=== M4-10: register lab test on sample ==="
click_link_until "S-M4" "/samples/" && ok "navigated to sample detail" || no "sample detail navigation"
await_text "Specimen record" && ok "sample detail page" || no "sample detail page"
for _i in $(seq 1 4); do
  agent-browser find role button click --name "Register test" >/dev/null 2>&1
  sleep 1
  agent-browser eval "document.querySelector('[role=dialog]')!==null" 2>/dev/null | tr -d '"' | grep -q true && break
done
agent-browser find label "Test type" click >/dev/null 2>&1; sleep 0.8
agent-browser find role option click --name "Water content" >/dev/null 2>&1; sleep 0.8
agent-browser find role button click --name "Create test" >/dev/null 2>&1
agent-browser wait --url "/lab-tests/" --timeout 20000 >/dev/null 2>&1
await_text "Test record" && ok "test registered, on test page" || no "test page"
B=$(body)
echo "$B" | grep -q "Water content" && ok "test detail shows type" || no "test detail type"
echo "$B" | grep -q "ASTM D2216" && ok "test detail shows standard" || no "test detail standard"

echo "=== M4-11: record water content result (Zod-validated) ==="
agent-browser find role button click --name "Record result" >/dev/null 2>&1; sleep 0.5
agent-browser find label "Depth from (m) *" fill "0.5" >/dev/null 2>&1 || agent-browser find label "Depth from" fill "0.5" >/dev/null 2>&1
agent-browser find label "Depth to" fill "1.0" >/dev/null 2>&1
agent-browser find label "Water content w (%)" fill "12.5" >/dev/null 2>&1
agent-browser find label "Summary (shown in lists)" fill "w = 12.5 %" >/dev/null 2>&1
agent-browser find role button click --name "Save result" >/dev/null 2>&1
await_text "Recorded result" && ok "result recorded section" || no "result recorded section"
B=$(body)
echo "$B" | grep -q "12.5" && ok "result value displayed" || no "result value"
echo "$B" | grep -q "w = 12.5" && ok "summary displayed" || no "summary"

echo "=== M4-12: Proctor chart (registry-driven) ==="
agent-browser open "$BASE/lab-tests?testType=PROCTOR&status=COMPLETED" >/dev/null 2>&1; waitidle
B=$(body)
echo "$B" | grep -q "Proctor" && ok "lab test filter by type" || no "lab test filter"
agent-browser find role link click --name "Proctor compaction" >/dev/null 2>&1
await_text "Test record" || true
B=$(body)
echo "$B" | grep -q "ASTM D698" && ok "proctor standard shown" || no "proctor standard"
echo "$B" | grep -q "Recorded result" && ok "proctor result present" || no "proctor result"
CHART=$(agent-browser eval "document.querySelector('svg.recharts-surface')!==null" 2>/dev/null | tr -d '"')
[ "$CHART" = "true" ] && ok "proctor chart rendered (recharts)" || no "proctor chart"
MDD=$(svg_has "MDD")
[ "$MDD" = "true" ] && ok "proctor MDD/OMC annotated in chart" || no "proctor MDD/OMC annotation"
shot "05-lab-test-proctor.png"

echo "=== M4-13: Granulometry chart ==="
agent-browser open "$BASE/lab-tests?testType=GRANULOMETRY&status=COMPLETED" >/dev/null 2>&1; waitidle
agent-browser find role link click --name "Granulometry" >/dev/null 2>&1
await_text "Test record" || true
B=$(body)
echo "$B" | grep -q "Recorded result" && ok "granulometry result present" || no "granulometry result"
CHART=$(agent-browser eval "document.querySelector('svg.recharts-surface')!==null" 2>/dev/null | tr -d '"')
[ "$CHART" = "true" ] && ok "granulometry chart rendered (recharts)" || no "granulometry chart"
shot "06-lab-test-granulometry.png"

echo "=== M4-14: Atterberg plasticity chart ==="
agent-browser open "$BASE/lab-tests?testType=ATTERBERG_LIMITS&status=COMPLETED" >/dev/null 2>&1; waitidle
agent-browser find role link click --name "Atterberg limits" >/dev/null 2>&1
await_text "Recorded result" || true
ALINE=$(svg_has "A-line")
[ "$ALINE" = "true" ] && ok "atterberg A-line reference in chart" || no "atterberg A-line"
CHART=$(agent-browser eval "document.querySelector('svg.recharts-surface')!==null" 2>/dev/null | tr -d '"')
[ "$CHART" = "true" ] && ok "atterberg chart rendered" || no "atterberg chart"

echo "=== M4-15: documents — upload via M3 endpoint ==="
echo "M4 field verification notes — uploaded through the browser." > /tmp/m4-upload.txt
agent-browser open "$BASE/documents" >/dev/null 2>&1; waitidle
B=$(body)
echo "$B" | grep -q "A1-TEN-2025" && ok "documents list shows seeded docs" || no "documents list seeded"
agent-browser find role button click --name "Upload document" >/dev/null 2>&1; sleep 0.5
agent-browser upload "input[type=file]" /tmp/m4-upload.txt >/dev/null 2>&1 || echo "  (upload cmd note)"
sleep 0.5
agent-browser find label "Project" click >/dev/null 2>&1; sleep 0.5
agent-browser find role option click --name "M4-DEMO-01" >/dev/null 2>&1; sleep 0.3
agent-browser find label "Title" fill "M4 Field Notes" >/dev/null 2>&1
agent-browser find role button click --name "Upload" --exact >/dev/null 2>&1 || agent-browser find role button click --name "Upload document" >/dev/null 2>&1
sleep 1.5; waitidle
B=$(body)
echo "$B" | grep -q "M4 Field Notes" && ok "uploaded document listed" || no "uploaded document listed"
DLINK=$(agent-browser eval "(function(){const a=[...document.querySelectorAll('a[href*=\"/download\"]')];return a.length;})()" 2>/dev/null | tr -d '"')
[ -n "$DLINK" ] && [ "$DLINK" -ge 1 ] && ok "download links present ($DLINK)" || no "download links"
agent-browser download "a[href*='/download']" /tmp/m4-download.txt >/dev/null 2>&1
sleep 1
if [ -f /tmp/m4-download.txt ] && grep -q "M4 field verification notes" /tmp/m4-download.txt 2>/dev/null; then
  ok "document downloads with correct content"
else
  no "document download content check"
fi
shot "07-documents.png"

echo "=== M4-16: sharing — approve seeded incoming request ==="
agent-browser open "$BASE/sharing" >/dev/null 2>&1; waitidle
shot "08-sharing.png"
B=$(body)
echo "$B" | grep -q "ANNABA-IND-2026" && ok "inbox shows seeded pending request" || no "inbox pending request"
agent-browser find role button click --name "Approve" >/dev/null 2>&1
sleep 1.5; waitidle
B=$(body)
APPROVED=$(agent-browser eval "(function(){const rows=[...document.querySelectorAll('li')];return rows.some(r=>r.textContent.includes('ANNABA-IND-2026')&&r.textContent.includes('Approved'));})()" 2>/dev/null | tr -d '"')
[ "$APPROVED" = "true" ] && ok "request approved, status updated" || no "approve status update"

echo "=== M4-17: sharing — create new outgoing request ==="
agent-browser find role button click --name "New sharing request" >/dev/null 2>&1; sleep 0.5
agent-browser find label "Your project" click >/dev/null 2>&1; sleep 0.5
agent-browser find role option click --name "M4-DEMO-01" >/dev/null 2>&1; sleep 0.3
agent-browser find label "Target organization" click >/dev/null 2>&1; sleep 0.5
agent-browser find role option click --name "RockWorks Laboratory" >/dev/null 2>&1; sleep 0.3
agent-browser find role button click --name "Send request" >/dev/null 2>&1
sleep 1; waitidle
agent-browser find role tab click --name "Sent" >/dev/null 2>&1
sleep 1
SENT=$(agent-browser eval "(function(){const rows=[...document.querySelectorAll('li')];return rows.some(r=>r.textContent.includes('M4-DEMO-01')&&r.textContent.includes('RockWorks')&&r.textContent.includes('Pending'));})()" 2>/dev/null | tr -d '"')
[ "$SENT" = "true" ] && ok "outgoing request created (pending)" || no "outgoing request created"

echo "=== M4-18: cross-org — RockWorks approves M4 request ==="
logout
login admin@rockworks.demo Demo1234!
agent-browser open "$BASE/sharing" >/dev/null 2>&1; waitidle
B=$(body)
echo "$B" | grep -q "M4-DEMO-01" && ok "RockWorks inbox shows new request" || no "RockWorks inbox request"
agent-browser find role button click --name "Approve" >/dev/null 2>&1
sleep 1.5; waitidle
APPROVED=$(agent-browser eval "(function(){const rows=[...document.querySelectorAll('li')];return rows.some(r=>r.textContent.includes('M4-DEMO-01')&&r.textContent.includes('Approved'));})()" 2>/dev/null | tr -d '"')
[ "$APPROVED" = "true" ] && ok "cross-org approval complete" || no "cross-org approval"
agent-browser open "$BASE/projects" >/dev/null 2>&1; waitidle
B=$(body)
echo "$B" | grep -q "M4-DEMO-01" && ok "shared project visible to partner org" || no "shared project visible"
SHARED=$(agent-browser eval "(function(){const t=[...document.querySelectorAll('span')].find(e=>e.textContent.trim()==='Shared'&&e.className.includes('bg-accent'));return !!t;})()" 2>/dev/null | tr -d '"')
[ "$SHARED" = "true" ] && ok "shared badge on cross-tenant project" || no "shared badge"
agent-browser find role link click --name "M4-DEMO-01" >/dev/null 2>&1; waitidle
B=$(body)
echo "$B" | grep -q "read-only" && ok "shared project marked read-only" || no "shared read-only marker"

echo "=== M4-19: RBAC — viewer navigation and guards ==="
logout
login viewer@geodata.demo Demo1234!
NAV=$(agent-browser eval "(function(){return [...document.querySelectorAll('[data-slot=sidebar-inner] a')].map(a=>a.getAttribute('href')).join(',');})()" 2>/dev/null | tr -d '"')
echo "  viewer nav: $NAV"
case ",$NAV," in *,/sharing,*) no "viewer should NOT see Sharing";; *) ok "viewer: sharing hidden";; esac
case ",$NAV," in *,/users,*) no "viewer should NOT see Users";; *) ok "viewer: users hidden";; esac
case ",$NAV," in *,/projects,*) ok "viewer: projects visible";; *) no "viewer: projects missing";; esac
PS=$(stat_value "Pending shares")
[ "$PS" = "—" ] && ok "viewer: pending shares shows dash (no permission)" || no "viewer pending shares got '$PS'"
agent-browser open "$BASE/sharing" >/dev/null 2>&1; waitidle
B=$(body)
echo "$B" | grep -q "Sharing requires management permission" && ok "viewer /sharing shows unauthorized state" || no "viewer unauthorized state"
agent-browser open "$BASE/projects" >/dev/null 2>&1; waitidle
NEWDATA=$(agent-browser eval "(function(){return [...document.querySelectorAll('button')].some(b=>b.textContent.includes('New project'));})()" 2>/dev/null | tr -d '"')
[ "$NEWDATA" = "false" ] && ok "viewer: no create-project button" || no "viewer create button hidden"

echo "=== M4-20: team management page (admin) ==="
logout
login admin@geodata.demo Demo1234!
agent-browser open "$BASE/users" >/dev/null 2>&1; waitidle
shot "09-users.png"
B=$(body)
echo "$B" | grep -q "Nadia Cherif" && ok "team directory lists users" || no "team directory"
echo "$B" | grep -q "You" && ok "self marker in directory" || no "self marker"

echo "=== M4-21: activity page ==="
agent-browser open "$BASE/activity" >/dev/null 2>&1; waitidle
B=$(body)
echo "$B" | grep -q "Audit trail" && ok "activity page header" || no "activity header"
ACT=$(echo "$B" | grep -c "recorded a laboratory test result\|created project\|approved a sharing request")
[ "$ACT" -ge 1 ] && ok "activity feed has real entries ($ACT matches)" || no "activity feed entries"

echo "=== M4-22: reports page ==="
agent-browser open "$BASE/reports" >/dev/null 2>&1; waitidle
B=$(body)
echo "$B" | grep -q "Report records\|No reports yet\|borehole log\|Borehole log\|reportType" && ok "reports page renders" || no "reports page"
echo "$B" | grep -q "Generate report" && ok "generate report button (admin)" || no "generate report button"

echo "=== M4-23: borehole detail with stratigraphy (seeded, rich) ==="
agent-browser open "$BASE/projects" >/dev/null 2>&1; waitidle
agent-browser find role link click --name "A1-TEN-2025" >/dev/null 2>&1; waitidle
agent-browser find role link click --name "BH-01" >/dev/null 2>&1; waitidle
shot "10-borehole-detail.png"
B=$(body)
echo "$B" | grep -q "Stratigraphy" && ok "borehole stratigraphy panel" || no "stratigraphy panel"
echo "$B" | grep -q "Sandstone" && ok "seeded layer descriptions visible" || no "seeded layers"
LAYERS=$(agent-browser eval "document.querySelectorAll('table tbody tr').length" 2>/dev/null | tr -d '"')
[ -n "$LAYERS" ] && [ "$LAYERS" -ge 4 ] && ok "layer + sample tables populated ($LAYERS rows visible)" || no "borehole tables"

echo "=== M4-24: dark theme ==="
agent-browser open "$BASE/dashboard" >/dev/null 2>&1; waitidle
BEFORE=$(agent-browser eval "document.documentElement.classList.contains('dark')" 2>/dev/null | tr -d '"')
agent-browser find role button click --name "Toggle theme" >/dev/null 2>&1; sleep 1
AFTER=$(agent-browser eval "document.documentElement.classList.contains('dark')" 2>/dev/null | tr -d '"')
[ "$BEFORE" != "$AFTER" ] && ok "theme toggle switches dark class" || no "theme toggle"
shot "11-dashboard-dark.png"
agent-browser find role button click --name "Toggle theme" >/dev/null 2>&1; sleep 0.5

echo "=== M4-25: mobile responsive (390px, no horizontal overflow) ==="
agent-browser set viewport 390 844 >/dev/null 2>&1
for PAGE in /dashboard /projects /boreholes /lab-tests /documents; do
  agent-browser open "$BASE$PAGE" >/dev/null 2>&1; waitidle
  SW=$(agent-browser eval "document.documentElement.scrollWidth" 2>/dev/null | tr -d '"')
  IW=$(agent-browser eval "window.innerWidth" 2>/dev/null | tr -d '"')
  if [ -n "$SW" ] && [ -n "$IW" ] && [ "$SW" -le "$IW" ]; then ok "mobile $PAGE no overflow ($SW<=$IW)"; else no "mobile $PAGE overflow ($SW>$IW)"; fi
done
agent-browser open "$BASE/projects" >/dev/null 2>&1; waitidle
shot "12-mobile-projects.png"
agent-browser find role button click --name "Toggle navigation" >/dev/null 2>&1; sleep 1
MOBILENAV=$(agent-browser eval "(function(){return [...document.querySelectorAll('a[href=\"/projects\"]')].some(a=>a.offsetParent!==null);})()" 2>/dev/null | tr -d '"')
[ "$MOBILENAV" = "true" ] && ok "mobile navigation sheet opens" || no "mobile navigation sheet"
agent-browser set viewport 1280 800 >/dev/null 2>&1

echo "=== M4-26: 404 record page ==="
agent-browser open "$BASE/projects/nonexistent-id-123456" >/dev/null 2>&1; waitidle
B=$(body)
echo "$B" | grep -q "Record not found" && ok "styled not-found page" || no "not-found page"

agent-browser close >/dev/null 2>&1 || true

echo ""
echo "============================================="
echo "M4 UI TEST SUMMARY: $PASS passed, $FAIL failed"
echo "============================================="
exit $((FAIL > 0 ? 1 : 0))
