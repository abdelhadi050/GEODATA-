/**
 * M5.2-g TEST — Ménard pressuremeter calculation module (pf / EM / PL).
 *
 * Golden values independently verified BEFORE being asserted here (60-digit
 * Decimal construction + IEEE-double probes mirroring the module's exact op
 * order — injected volumes, two-half creep lines, designated-section volume
 * reads, EM = 2(1+ν)(Vc+vm)Δp/Δv with the governed ν = 0.33, vL = Vc+2·v1,
 * interpolated PL — in scripts/m5.2-g-verify-goldens.py). Sources: M5.2-g
 * authorization §7, registry pressuremeterResult contract (NF P94-110-1/2 /
 * ASTM D4719), prisma/seed.ts fixtures PMT_CLAY_2M5 (pf 450, PL 950, EM
 * 12.4, ratio 13.05) and PMT_MARL_8M5 (pf 800, PL 1750, EM 24.8, 14.17).
 *
 * Coverage (authorization §9): normal valid cases (full Ménard analysis
 * golden: pf from the creep construction, EM from the designated section,
 * PL at the doubled-volume target, emPlRatio); invalid inputs (ordering,
 * bounds, V30 > V60, reference > reading, emRange ordering/range/section,
 * registry identity mirrors); missing measurements (no Vc, no emRange, no
 * creep pairs, fewer than 4 creep pairs); boundary conditions (entered
 * ratio ±0.5 both sides); unit consistency (kPa→MPa exact /1000, the
 * registry identity EM×1000/PL); insufficient experimental data (limit
 * state not reached — no extrapolation, creep construction out of range);
 * calculation accuracy (Decimal-agreed constructions); physical and
 * engineering consistency (p1 = pf cross-reference in raw, gross/net
 * pressure documentation); error and warning handling (INSUFFICIENT_DATA /
 * ENTERED_VALUE_DISCREPANCY codes); M5.1 registry parity with documented
 * divergences; determinism (25 runs × paths); purity; envelope provenance.
 *
 * Key verifier goldens (double probes; Decimal agrees to <1e-12):
 *   M1: pf = 600.0 kPa (creep slopes 0.0015 / 0.02), v1 = 150, v2 = 215 cm³,
 *       EM = 5872.461538461539 kPa (5.87 MPa), vL = 835 cm³,
 *       PL = 1340.4761904761904 kPa, ratio = 4.380877169012161.
 * Exit code = number of failures.
 */
import { runCalculation } from "../src/lib/calc/engine";
import type { CalculationOutcome } from "../src/lib/calc/types";
import {
  PRESSUREMETER_RATIO_TOLERANCE,
  creepPressureFromCreepCurve,
  injectedVolumeAtPressure,
  pressureAtInjectedVolume,
  pressuremeterCalcInput,
  pressuremeterModule,
  type PressuremeterInput,
  type PressuremeterRaw,
  type PressuremeterResults,
} from "../src/lib/calc/modules/pressuremeter";
import { parseLabTestResult } from "../src/lib/lab-tests/registry";

let pass = 0;
let fail = 0;
const ok = (m: string) => { console.log(`PASS: ${m}`); pass++; };
const no = (m: string) => { console.log(`FAIL: ${m}`); fail++; };

const approx = (actual: number, expected: number, tol: number): boolean =>
  Math.abs(actual - expected) <= tol;

type Outcome = CalculationOutcome<PressuremeterInput, PressuremeterRaw, PressuremeterResults>;

interface ExpectedError {
  code: string;
  fieldPath?: string;
  messageHint?: string;
}

function expectError(outcome: Outcome, label: string, expected: ExpectedError): void {
  if (outcome.status !== "error") {
    no(`${label} — expected ${expected.code}, got success`);
    return;
  }
  const { code, message, details } = outcome.error;
  if (code !== expected.code) {
    no(`${label} — expected ${expected.code}, got ${code}`);
    return;
  }
  if (expected.fieldPath !== undefined && details?.fieldPath !== expected.fieldPath) {
    no(`${label} — expected fieldPath ${expected.fieldPath}, got ${String(details?.fieldPath)}`);
    return;
  }
  if (expected.messageHint !== undefined && !message.includes(expected.messageHint)) {
    no(`${label} — message '${message}' lacks hint '${expected.messageHint}'`);
    return;
  }
  ok(`${label} — ${code}${expected.fieldPath ? ` @ ${expected.fieldPath}` : ""}`);
}

// ---------------------------------------------------------------------------
// Fixtures (independently verified in scripts/m5.2-g-verify-goldens.py)
// ---------------------------------------------------------------------------

/**
 * The full computable M1 fixture: 15 steps, creep pairs on 8 steps
 * (creep = V60 − V30), reference baseline 40 cm³, cell volume 535 cm³,
 * designated section [600, 800] kPa. Readings = injected + 40.
 */
const M1_POINTS = [
  { pressureKpa: 0, volumeCm3: 40 },
  { pressureKpa: 100, volumeCm3: 60 },
  { pressureKpa: 200, volumeCm3: 85, volumeAt30sCm3: 83 },
  { pressureKpa: 300, volumeCm3: 110, volumeAt30sCm3: 108 },
  { pressureKpa: 400, volumeCm3: 135, volumeAt30sCm3: 133 },
  { pressureKpa: 500, volumeCm3: 162, volumeAt30sCm3: 159.5 },
  { pressureKpa: 600, volumeCm3: 190, volumeAt30sCm3: 187 },
  { pressureKpa: 700, volumeCm3: 220, volumeAt30sCm3: 216 },
  { pressureKpa: 800, volumeCm3: 255, volumeAt30sCm3: 249 },
  { pressureKpa: 900, volumeCm3: 300, volumeAt30sCm3: 291 },
  { pressureKpa: 1000, volumeCm3: 370 },
  { pressureKpa: 1100, volumeCm3: 470 },
  { pressureKpa: 1200, volumeCm3: 610 },
  { pressureKpa: 1300, volumeCm3: 790 },
  { pressureKpa: 1400, volumeCm3: 1000 },
];

/** PMT_CLAY_2M5 seed shape (registry payload; no Vc / creep pairs / emRange). */
const CLAY_POINTS = [
  { pressureKpa: 0, volumeCm3: 45 },
  { pressureKpa: 50, volumeCm3: 55 },
  { pressureKpa: 100, volumeCm3: 68 },
  { pressureKpa: 150, volumeCm3: 82 },
  { pressureKpa: 200, volumeCm3: 97 },
  { pressureKpa: 250, volumeCm3: 113 },
  { pressureKpa: 300, volumeCm3: 130 },
  { pressureKpa: 350, volumeCm3: 148 },
  { pressureKpa: 400, volumeCm3: 168 },
  { pressureKpa: 450, volumeCm3: 190 },
  { pressureKpa: 500, volumeCm3: 215 },
  { pressureKpa: 600, volumeCm3: 268 },
  { pressureKpa: 700, volumeCm3: 330 },
  { pressureKpa: 800, volumeCm3: 410 },
];

// ---------------------------------------------------------------------------
// 1. Golden envelopes
// ---------------------------------------------------------------------------
{
  // M1 — the full analysis: pf = 600 (creep construction), EM = 5.87 MPa
  // (designated section), PL = 1340.5 (doubled-volume target), ratio 4.38.
  const outcome = runCalculation(pressuremeterModule, {
    probeType: "Ménard NB (74 mm)",
    testDepthM: 2.5,
    points: M1_POINTS,
    referenceVolumeCm3: 40,
    measuringCellVolumeCm3: 535,
    emRange: { p1Kpa: 600, p2Kpa: 800 },
  });
  if (outcome.status !== "ok") no(`golden M1 — failed: ${outcome.error.message}`);
  else {
    const checks: Array<[boolean, string]> = [
      [outcome.raw.creepCm3.length === 8, "8 creep pairs collected (V60 − V30)"],
      [outcome.raw.creepCm3[3].creepCm3 === 2.5, "creep at 500 kPa = 2.5 cm³"],
      [approx(outcome.raw.creepPressureKpa ?? 0, 600, 1e-9), "raw pf ≈ 600 kPa (two-line intersection, slopes 0.0015/0.02)"],
      [outcome.results.creepPressureKpa === 600, "results pf = 600.0 (1 dp)"],
      [outcome.results.analysisP1Kpa === 600, "analysis p1 = 600 (designated emRange.p1)"],
      [outcome.raw.v1Cm3 === 150, "raw v1 = 150 cm³ (exact hit at 600 kPa)"],
      [outcome.raw.v2Cm3 === 215, "raw v2 = 215 cm³ (exact hit at 800 kPa)"],
      [approx(outcome.raw.menardModulusKpa ?? 0, 5872.461538461539, 1e-9), "raw EM ≈ 5872.461538461539 kPa = 2.66 × 717.5 × 200/65"],
      [outcome.results.menardModulusMPa === 5.87, "results EM = 5.87 MPa (2 dp, exact /1000)"],
      [outcome.raw.limitVolumeCm3 === 835, "raw vL = Vc + 2·v1 = 835 cm³"],
      [approx(outcome.raw.limitPressureKpa ?? 0, 1340.4761904761904, 1e-9), "raw PL ≈ 1340.4761904761904 kPa (interpolated between 1300 and 1400 kPa)"],
      [outcome.results.limitPressureKpa === 1340.5, "results PL = 1340.5 (1 dp)"],
      [approx(outcome.raw.emPlRatio ?? 0, 4.380877169012161, 1e-9), "raw emPlRatio ≈ 4.380877169012161"],
      [outcome.results.emPlRatio === 4.38, "results emPlRatio = 4.38 (2 dp)"],
      [outcome.results.probeType === "Ménard NB (74 mm)", "probeType echoed"],
      [outcome.results.testDepthM === 2.5, "testDepthM echoed (bookkeeping only — no hydrostatic correction, documented)"],
      [outcome.results.curve.length === 15, "curve = 15 points as measured"],
      [outcome.results.curve[14].injectedVolumeCm3 === 960, "curve[14] injected volume = 960 cm³ (reading 1000 − reference 40)"],
      [outcome.warnings.length === 0, "no warnings (fully computable analysis)"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`golden M1 — ${label}`);
      else no(`golden M1 — ${label}`);
    }
  }
}
{
  // M1b — same fixture WITHOUT emRange: PL still computable (p1 = pf = 600);
  // EM null + INSUFFICIENT_DATA.
  const outcome = runCalculation(pressuremeterModule, {
    points: M1_POINTS,
    referenceVolumeCm3: 40,
    measuringCellVolumeCm3: 535,
  });
  if (outcome.status !== "ok") no(`golden M1b — failed: ${outcome.error.message}`);
  else {
    const insuff = outcome.warnings.filter((w) => w.code === "INSUFFICIENT_DATA");
    const checks: Array<[boolean, string]> = [
      [outcome.results.menardModulusMPa === null, "EM null (no designated section — never guessed)"],
      [outcome.results.limitPressureKpa === 1340.5, "PL = 1340.5 (p1 = computed pf = 600)"],
      [outcome.results.analysisP1Kpa === 600, "analysis p1 = 600 = pf"],
      [insuff.length === 1 && insuff[0].message.includes("emRange"), "one INSUFFICIENT_DATA warning (emRange)"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`golden M1b — ${label}`);
      else no(`golden M1b — ${label}`);
    }
  }
}
{
  // M5 — the limit state not reached: curve truncated at 1200 kPa
  // (max injected 570 < vL 835) → PL null + INSUFFICIENT_DATA (no extrapolation).
  const outcome = runCalculation(pressuremeterModule, {
    points: M1_POINTS.slice(0, 13),
    referenceVolumeCm3: 40,
    measuringCellVolumeCm3: 535,
    emRange: { p1Kpa: 600, p2Kpa: 800 },
  });
  if (outcome.status !== "ok") no(`golden M5 — failed: ${outcome.error.message}`);
  else {
    const insuff = outcome.warnings.filter((w) => w.code === "INSUFFICIENT_DATA");
    const checks: Array<[boolean, string]> = [
      [outcome.results.limitPressureKpa === null, "PL null (limit state not reached)"],
      [outcome.results.menardModulusMPa === 5.87, "EM still computable (5.87)"],
      [insuff.length === 1 && insuff[0].message.includes("limit-state volume"), "one INSUFFICIENT_DATA warning (vL beyond the measured range)"],
      [insuff[0].message.includes("extrapolation"), "warning names the no-extrapolation policy"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`golden M5 — ${label}`);
      else no(`golden M5 — ${label}`);
    }
  }
}
{
  // M2 — the PMT_CLAY_2M5 seed payload (registry shape): nothing computable
  // (no Vc, no creep pairs, no emRange); everything echoed; 3 advisories.
  const outcome = runCalculation(pressuremeterModule, {
    points: CLAY_POINTS,
    creepPressureKpa: 450,
    limitPressureKpa: 950,
    menardModulusMPa: 12.4,
    emPlRatio: 13.05,
  });
  if (outcome.status !== "ok") no(`golden M2 — failed: ${outcome.error.message}`);
  else {
    const insuff = outcome.warnings.filter((w) => w.code === "INSUFFICIENT_DATA");
    const checks: Array<[boolean, string]> = [
      [outcome.results.creepPressureKpa === null, "pf null (no 30 s readings)"],
      [outcome.results.menardModulusMPa === null, "EM null"],
      [outcome.results.limitPressureKpa === null, "PL null"],
      [outcome.results.emPlRatio === null, "emPlRatio null"],
      [insuff.length === 3, "3 INSUFFICIENT_DATA advisories (no 30 s readings / no Vc / no emRange)"],
      [insuff.some((w) => w.message.includes("30 s")), "advisory names the missing 30 s readings"],
      [insuff.some((w) => w.message.includes("measuringCellVolumeCm3")), "advisory names the missing Vc"],
      [outcome.results.enteredCreepPressureKpa === 450, "entered pf echoed (450)"],
      [outcome.results.enteredLimitPressureKpa === 950, "entered PL echoed (950)"],
      [outcome.results.enteredMenardModulusMPa === 12.4, "entered EM echoed (12.4)"],
      [outcome.results.enteredEmPlRatio === 13.05, "entered ratio echoed (13.05) — no comparison warnings for pf/PL/EM (no registry tolerance; documented divergence)"],
      [outcome.warnings.every((w) => w.code === "INSUFFICIENT_DATA"), "no ENTERED_VALUE_DISCREPANCY warnings (echo-only, documented)"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`golden M2 — ${label}`);
      else no(`golden M2 — ${label}`);
    }
  }
}
{
  // M3 — the PMT_MARL_8M5 seed: same echo-only treatment.
  const outcome = runCalculation(pressuremeterModule, {
    points: [
      { pressureKpa: 0, volumeCm3: 40 },
      { pressureKpa: 100, volumeCm3: 50 },
      { pressureKpa: 200, volumeCm3: 62 },
      { pressureKpa: 300, volumeCm3: 76 },
      { pressureKpa: 400, volumeCm3: 92 },
      { pressureKpa: 500, volumeCm3: 110 },
      { pressureKpa: 600, volumeCm3: 130 },
      { pressureKpa: 700, volumeCm3: 153 },
      { pressureKpa: 800, volumeCm3: 180 },
      { pressureKpa: 1000, volumeCm3: 240 },
      { pressureKpa: 1200, volumeCm3: 315 },
      { pressureKpa: 1400, volumeCm3: 405 },
      { pressureKpa: 1600, volumeCm3: 515 },
    ],
    creepPressureKpa: 800,
    limitPressureKpa: 1750,
    menardModulusMPa: 24.8,
    emPlRatio: 14.17,
  });
  if (outcome.status !== "ok") no(`golden M3 — failed: ${outcome.error.message}`);
  else {
    const checks: Array<[boolean, string]> = [
      [outcome.results.limitPressureKpa === null, "PL null (entered 1750 echoed, not verified against the raw curve)"],
      [outcome.results.enteredEmPlRatio === 14.17, "entered ratio echoed"],
      [outcome.warnings.filter((w) => w.code === "INSUFFICIENT_DATA").length === 3, "3 INSUFFICIENT_DATA advisories"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`golden M3 — ${label}`);
      else no(`golden M3 — ${label}`);
    }
  }
}
{
  // M4 — creep pairs present but fewer than 4 → pf null + advisory.
  // (Only the 200/300 kPa steps carry a 30 s reading; all others stripped.)
  const outcome = runCalculation(pressuremeterModule, {
    points: M1_POINTS.map((p, i) =>
      i === 2 || i === 3
        ? { pressureKpa: p.pressureKpa, volumeCm3: p.volumeCm3, volumeAt30sCm3: p.volumeCm3 - 2 }
        : { pressureKpa: p.pressureKpa, volumeCm3: p.volumeCm3 },
    ),
    measuringCellVolumeCm3: 535,
    emRange: { p1Kpa: 600, p2Kpa: 800 },
  });
  if (outcome.status !== "ok") no(`golden M4 — failed: ${outcome.error.message}`);
  else {
    const insuff = outcome.warnings.filter((w) => w.code === "INSUFFICIENT_DATA");
    const checks: Array<[boolean, string]> = [
      [outcome.results.creepPressureKpa === null, "pf null (only 2 creep pairs < 4)"],
      [insuff.some((w) => w.message.includes("30 s")), "advisory names the insufficient creep pairs"],
      [outcome.results.limitPressureKpa === 1359.5, "PL still computed from the designated p1 = 600 (volumes are zero-based here: v1 = 190, vL = 915 cm³ -> PL 1359.5)"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`golden M4 — ${label}`);
      else no(`golden M4 — ${label}`);
    }
  }
}
{
  // Entered-ratio comparison: computed ratio 4.3809 vs entered 4.38 → no
  // warning (|Δ| = 0.0009 ≤ 0.5); entered 6.0 → |Δ| = 1.62 > 0.5 → warning.
  const clean = runCalculation(pressuremeterModule, {
    points: M1_POINTS, referenceVolumeCm3: 40, measuringCellVolumeCm3: 535,
    emRange: { p1Kpa: 600, p2Kpa: 800 }, emPlRatio: 4.38,
  });
  if (clean.status === "ok" && !clean.warnings.some((w) => w.details?.field === "emPlRatio")) {
    ok("entered ratio 4.38 (|Δ| = 0.0009): no warning");
  } else {
    no("entered ratio 4.38 should not warn");
  }
  const dirty = runCalculation(pressuremeterModule, {
    points: M1_POINTS, referenceVolumeCm3: 40, measuringCellVolumeCm3: 535,
    emRange: { p1Kpa: 600, p2Kpa: 800 }, emPlRatio: 6.0,
  });
  if (dirty.status === "ok" && dirty.warnings.some((w) => w.details?.field === "emPlRatio" && w.code === "ENTERED_VALUE_DISCREPANCY")) {
    ok("entered ratio 6.0 (|Δ| = 1.62 > 0.5): ENTERED_VALUE_DISCREPANCY warning");
  } else {
    no("entered ratio 6.0 should warn");
  }
}

// ---------------------------------------------------------------------------
// 2. Validation — registry mirrors and module rules
// ---------------------------------------------------------------------------
{
  const outcome = runCalculation(pressuremeterModule, {
    points: [
      { pressureKpa: 500, volumeCm3: 215 },
      { pressureKpa: 400, volumeCm3: 168 },
      { pressureKpa: 300, volumeCm3: 130 },
      { pressureKpa: 200, volumeCm3: 97 },
      { pressureKpa: 100, volumeCm3: 68 },
    ],
  });
  expectError(outcome, "unordered pressures (registry mirror)", {
    code: "INVALID_INPUT",
    fieldPath: "points.1.pressureKpa",
    messageHint: "strictly increasing",
  });
}
{
  const outcome = runCalculation(pressuremeterModule, {
    points: [
      { pressureKpa: 100, volumeCm3: 68 },
      { pressureKpa: 200, volumeCm3: 60 },
      { pressureKpa: 300, volumeCm3: 130 },
      { pressureKpa: 400, volumeCm3: 168 },
      { pressureKpa: 500, volumeCm3: 215 },
    ],
  });
  expectError(outcome, "decreasing volumes (registry mirror)", {
    code: "INVALID_INPUT",
    fieldPath: "points.1.volumeCm3",
    messageHint: "non-decreasing",
  });
}
{
  const outcome = runCalculation(pressuremeterModule, {
    points: M1_POINTS.map((p, i) => (i === 5 ? { ...p, volumeAt30sCm3: p.volumeCm3 + 5 } : p)),
  });
  expectError(outcome, "V30 > V60 per point", {
    code: "INVALID_INPUT",
    fieldPath: "points.5.volumeAt30sCm3",
    messageHint: "cannot exceed",
  });
}
{
  const outcome = runCalculation(pressuremeterModule, {
    points: M1_POINTS,
    referenceVolumeCm3: 50,
  });
  expectError(outcome, "reference exceeds the first reading", {
    code: "INVALID_INPUT",
    fieldPath: "points.0.volumeCm3",
    messageHint: "injected volume would be negative",
  });
}
{
  const outcome = runCalculation(pressuremeterModule, {
    points: M1_POINTS, referenceVolumeCm3: 40, measuringCellVolumeCm3: 535,
    emRange: { p1Kpa: 800, p2Kpa: 600 },
  });
  expectError(outcome, "emRange p2 ≤ p1", {
    code: "INVALID_INPUT",
    fieldPath: "emRange.p2Kpa",
    messageHint: "must be greater than",
  });
}
{
  const outcome = runCalculation(pressuremeterModule, {
    points: M1_POINTS, referenceVolumeCm3: 40, measuringCellVolumeCm3: 535,
    emRange: { p1Kpa: 600, p2Kpa: 2000 },
  });
  expectError(outcome, "emRange above the measured range", {
    code: "INVALID_INPUT",
    fieldPath: "emRange",
    messageHint: "outside the measured pressure range",
  });
}
{
  // Designated section on the flat initial part (v2 == v1 — no expansion).
  const outcome = runCalculation(pressuremeterModule, {
    points: [
      { pressureKpa: 100, volumeCm3: 60 },
      { pressureKpa: 200, volumeCm3: 60 },
      { pressureKpa: 300, volumeCm3: 130 },
      { pressureKpa: 400, volumeCm3: 168 },
      { pressureKpa: 500, volumeCm3: 215 },
    ],
    measuringCellVolumeCm3: 535,
    emRange: { p1Kpa: 100, p2Kpa: 200 },
  });
  expectError(outcome, "designated section does not expand", {
    code: "INVALID_INPUT",
    fieldPath: "emRange",
    messageHint: "does not expand",
  });
}
{
  const outcome = runCalculation(pressuremeterModule, {
    points: CLAY_POINTS,
    creepPressureKpa: 950,
    limitPressureKpa: 950,
  });
  expectError(outcome, "entered pf ≥ PL (registry mirror)", {
    code: "INVALID_INPUT",
    fieldPath: "creepPressureKpa",
    messageHint: "must be lower than",
  });
}
{
  const outcome = runCalculation(pressuremeterModule, {
    points: CLAY_POINTS,
    limitPressureKpa: 950,
    menardModulusMPa: 12.4,
    emPlRatio: 20,
  });
  expectError(outcome, "entered emPlRatio identity violation (registry mirror)", {
    code: "INVALID_INPUT",
    fieldPath: "emPlRatio",
    messageHint: "must equal menardModulusMPa × 1000 / limitPressureKpa",
  });
}
{
  const outcome = runCalculation(pressuremeterModule, {
    points: CLAY_POINTS.slice(0, 4),
  });
  expectError(outcome, "4 points (min 5)", { code: "INVALID_INPUT" });
}
{
  const outcome = runCalculation(pressuremeterModule, {
    points: Array.from({ length: 31 }, (_, i) => ({ pressureKpa: i * 100, volumeCm3: 50 + i * 10 })),
  });
  expectError(outcome, "31 points (max 30)", { code: "INVALID_INPUT" });
}
{
  const outcome = runCalculation(pressuremeterModule, {
    points: [{ pressureKpa: 5001, volumeCm3: 100 }, { pressureKpa: 5100, volumeCm3: 150 }, { pressureKpa: 5200, volumeCm3: 200 }, { pressureKpa: 5300, volumeCm3: 250 }, { pressureKpa: 5400, volumeCm3: 300 }],
  });
  expectError(outcome, "pressure 5001 out of bounds", { code: "INVALID_INPUT", messageHint: "5000" });
}
{
  const outcome = runCalculation(pressuremeterModule, {
    points: [{ pressureKpa: 100, volumeCm3: 2001 }, { pressureKpa: 200, volumeCm3: 2002 }, { pressureKpa: 300, volumeCm3: 2003 }, { pressureKpa: 400, volumeCm3: 2004 }, { pressureKpa: 500, volumeCm3: 2005 }],
  });
  expectError(outcome, "volume 2001 out of bounds", { code: "INVALID_INPUT", messageHint: "2000" });
}
{
  const outcome = runCalculation(pressuremeterModule, {});
  expectError(outcome, "empty payload", { code: "MISSING_INPUT", messageHint: "points" });
}
{
  const outcome = runCalculation(pressuremeterModule, {
    points: CLAY_POINTS.map((p) => ({ ...p, volumeCm3: Number.NaN })),
  });
  expectError(outcome, "NaN volume", { code: "INVALID_INPUT" });
}

// ---------------------------------------------------------------------------
// 3. Direct helper tests
// ---------------------------------------------------------------------------
{
  const curve = [
    { pressureKpa: 0, injectedVolumeCm3: 0 },
    { pressureKpa: 100, injectedVolumeCm3: 20 },
    { pressureKpa: 200, injectedVolumeCm3: 45 },
  ];
  if (injectedVolumeAtPressure(curve, 100) === 20) ok("helper — exact-hit volume read");
  else no("helper — exact-hit failed");
  const interp = injectedVolumeAtPressure(curve, 150);
  if (interp !== undefined && approx(interp, 32.5, 1e-12)) ok("helper — interpolated volume read (32.5 at 150 kPa)");
  else no(`helper — interpolation wrong: ${String(interp)}`);
  try {
    injectedVolumeAtPressure(curve, 300);
    no("helper — above-range read no throw");
  } catch {
    ok("helper — above-range read throws (no extrapolation)");
  }
  if (pressureAtInjectedVolume(curve, 45) === 200) ok("helper — exact-hit pressure read");
  else no("helper — pressure exact-hit failed");
  if (pressureAtInjectedVolume(curve, 1000) === null) ok("helper — beyond-range pressure read returns null");
  else no("helper — beyond-range should be null");
  const pInterp = pressureAtInjectedVolume(curve, 32.5);
  if (pInterp !== null && approx(pInterp, 150, 1e-12)) ok("helper — interpolated pressure read (150 at 32.5 cm³)");
  else no(`helper — pressure interpolation wrong: ${String(pInterp)}`);
}
{
  const creep = [
    { pressureKpa: 200, creepCm3: 2 },
    { pressureKpa: 300, creepCm3: 2 },
    { pressureKpa: 400, creepCm3: 2 },
    { pressureKpa: 500, creepCm3: 2.5 },
    { pressureKpa: 600, creepCm3: 3 },
    { pressureKpa: 700, creepCm3: 4 },
    { pressureKpa: 800, creepCm3: 6 },
    { pressureKpa: 900, creepCm3: 9 },
  ];
  const r = creepPressureFromCreepCurve(creep);
  if (r.pressureKpa !== null && approx(r.pressureKpa, 600, 1e-9)) ok("helper — creep intersection = 600 kPa (mirror of the M1 golden)");
  else no(`helper — creep intersection wrong: ${String(r.pressureKpa)}`);
  if (approx(r.firstHalfSlope, 0.0015, 1e-15) && approx(r.secondHalfSlope, 0.02, 1e-15)) ok("helper — creep half slopes 0.0015 / 0.02");
  else no("helper — creep slopes wrong");
  const parallel = creepPressureFromCreepCurve([
    { pressureKpa: 100, creepCm3: 1 },
    { pressureKpa: 200, creepCm3: 2 },
    { pressureKpa: 300, creepCm3: 3 },
    { pressureKpa: 400, creepCm3: 4 },
  ]);
  if (parallel.pressureKpa === null) ok("helper — collinear creep curve (parallel halves) yields null");
  else no("helper — parallel creep lines should yield null");
}

// ---------------------------------------------------------------------------
// 4. Schema stripping
// ---------------------------------------------------------------------------
{
  const parsed = pressuremeterCalcInput.safeParse({
    points: CLAY_POINTS,
    membraneCalibration: [{ pressureKpa: 100, volumeCm3: 10 }],
    probeCalibration: [{ pressureKpa: 100, volumeCm3: 10 }],
    boreholeDiameterMm: 76,
    groundwaterPresent: true,
    notes: "extra",
  });
  if (
    parsed.success &&
    !("membraneCalibration" in parsed.data) &&
    !("probeCalibration" in parsed.data) &&
    !("boreholeDiameterMm" in parsed.data) &&
    !("notes" in parsed.data)
  ) {
    ok("schema — calibration arrays and registry input extras stripped (corrections not part of the calculable contract, D8)");
  } else {
    no("schema — stripping failed");
  }
}

// ---------------------------------------------------------------------------
// 5. M5.1 registry compatibility — parity and documented divergences
// ---------------------------------------------------------------------------
{
  // Shared valid: the seed payload passes both.
  const payload = {
    points: CLAY_POINTS,
    creepPressureKpa: 450,
    limitPressureKpa: 950,
    menardModulusMPa: 12.4,
    emPlRatio: 13.05,
  };
  const moduleOutcome = runCalculation(pressuremeterModule, payload);
  const registryOutcome = parseLabTestResult("PRESSUREMETER", payload);
  const checks: Array<[boolean, string]> = [
    [moduleOutcome.status === "ok", "shared valid — module accepts the registry-shaped payload"],
    [registryOutcome.ok, "shared valid — registry result schema accepts it"],
  ];
  if (moduleOutcome.status === "ok") {
    const revalidated = parseLabTestResult("PRESSUREMETER", {
      points: moduleOutcome.results.curve.map((c) => ({ pressureKpa: c.pressureKpa, volumeCm3: c.volumeCm3 })),
      creepPressureKpa: 600,
      limitPressureKpa: 1340.5,
      menardModulusMPa: moduleOutcome.results.menardModulusMPa ?? 5.87,
      emPlRatio: moduleOutcome.results.emPlRatio ?? 4.38,
    });
    checks.push([revalidated.ok, `computed M1 finals (EM 5.87, PL 1340.5, ratio 4.38, pf 600) revalidate through the registry${revalidated.ok ? "" : `: ${revalidated.error}`}`]);
  }
  for (const [condition, label] of checks) {
    if (condition) ok(`parity — ${label}`);
    else no(`parity — ${label}`);
  }
}
{
  // Shared invalid (both reject): unordered pressures; pf ≥ PL; ratio identity.
  const badOrder = {
    points: [
      { pressureKpa: 500, volumeCm3: 215 },
      { pressureKpa: 400, volumeCm3: 168 },
      { pressureKpa: 300, volumeCm3: 130 },
      { pressureKpa: 200, volumeCm3: 97 },
      { pressureKpa: 100, volumeCm3: 68 },
    ],
  };
  const badPf = { points: CLAY_POINTS, creepPressureKpa: 950, limitPressureKpa: 950 };
  const badRatio = { points: CLAY_POINTS, limitPressureKpa: 950, menardModulusMPa: 12.4, emPlRatio: 20 };
  for (const [payload, label] of [[badOrder, "unordered pressures"], [badPf, "pf ≥ PL"], [badRatio, "ratio identity"]] as const) {
    const m = runCalculation(pressuremeterModule, payload);
    const r = parseLabTestResult("PRESSUREMETER", payload);
    if (m.status === "error" && !r.ok) ok(`shared invalid — ${label}: both reject`);
    else no(`shared invalid — ${label}: module ${m.status}, registry ok=${r.ok}`);
  }
}
{
  // Documented divergence 1 — engine-side extensions (V30 readings, Vc,
  // emRange, reference volume): no registry storage; the M1 analysis is
  // engine-only.
  const m = runCalculation(pressuremeterModule, {
    points: M1_POINTS, referenceVolumeCm3: 40, measuringCellVolumeCm3: 535,
    emRange: { p1Kpa: 600, p2Kpa: 800 },
  });
  if (m.status === "ok" && m.results.menardModulusMPa === 5.87 && m.results.limitPressureKpa === 1340.5) {
    ok("divergence — V30/Vc/emRange/reference are engine-side extensions (the registry stores single readings + entered finals only)");
  } else {
    no("divergence — engine-side extensions failed");
  }
}
{
  // Documented divergence 2 — entered finals vs raw-curve construction: the
  // seed's entered PL (950) is NOT verifiable from the raw curve (the M5.1
  // seeds are explicitly entered values); the module echoes them without
  // comparison warnings (no registry tolerance for pf/PL/EM).
  const m = runCalculation(pressuremeterModule, {
    points: CLAY_POINTS, creepPressureKpa: 450, limitPressureKpa: 950, menardModulusMPa: 12.4, emPlRatio: 13.05,
  });
  if (m.status === "ok" && !m.warnings.some((w) => w.code === "ENTERED_VALUE_DISCREPANCY")) {
    ok("divergence — entered pf/PL/EM echoed without comparison (no registry tolerance; the raw curve cannot verify them)");
  } else {
    no("divergence — unexpected entered-comparison warnings");
  }
}
{
  // Documented divergence 3 — corrections: no equipment or hydrostatic
  // corrections are applied (D8-blocked); testDepthM is bookkeeping only.
  const m1 = runCalculation(pressuremeterModule, {
    points: M1_POINTS, referenceVolumeCm3: 40, measuringCellVolumeCm3: 535,
    emRange: { p1Kpa: 600, p2Kpa: 800 }, testDepthM: 2.5,
  });
  const m2 = runCalculation(pressuremeterModule, {
    points: M1_POINTS, referenceVolumeCm3: 40, measuringCellVolumeCm3: 535,
    emRange: { p1Kpa: 600, p2Kpa: 800 }, testDepthM: 100,
  });
  if (
    m1.status === "ok" && m2.status === "ok" &&
    m1.results.menardModulusMPa === m2.results.menardModulusMPa &&
    m1.results.limitPressureKpa === m2.results.limitPressureKpa
  ) {
    ok("divergence — depth never changes a number (no hydrostatic correction applied — D8-blocked, documented)");
  } else {
    no("divergence — depth affected the results");
  }
}

// ---------------------------------------------------------------------------
// 6. Determinism, purity, envelope
// ---------------------------------------------------------------------------
{
  const payload = {
    points: M1_POINTS, referenceVolumeCm3: 40, measuringCellVolumeCm3: 535,
    emRange: { p1Kpa: 600, p2Kpa: 800 },
  };
  const first = runCalculation(pressuremeterModule, payload);
  let allEqual = true;
  for (let i = 0; i < 25; i++) {
    if (JSON.stringify(runCalculation(pressuremeterModule, payload)) !== JSON.stringify(first)) allEqual = false;
  }
  if (allEqual) ok("determinism — 25 runs deeply identical (full-analysis path)");
  else no("determinism — full-analysis path outputs differ");
}
{
  const payload = { points: CLAY_POINTS, creepPressureKpa: 450, limitPressureKpa: 950, menardModulusMPa: 12.4, emPlRatio: 13.05 };
  const first = runCalculation(pressuremeterModule, payload);
  let allEqual = true;
  for (let i = 0; i < 25; i++) {
    if (JSON.stringify(runCalculation(pressuremeterModule, payload)) !== JSON.stringify(first)) allEqual = false;
  }
  if (allEqual) ok("determinism — 25 runs deeply identical (echo path)");
  else no("determinism — echo path outputs differ");
}
{
  const payload = {
    points: [
      { pressureKpa: 100, volumeCm3: 60 },
      { pressureKpa: 200, volumeCm3: 85 },
      { pressureKpa: 300, volumeCm3: 110 },
      { pressureKpa: 400, volumeCm3: 135 },
      { pressureKpa: 500, volumeCm3: 162 },
    ],
  };
  const snapshot = JSON.stringify(payload);
  runCalculation(pressuremeterModule, payload);
  if (JSON.stringify(payload) === snapshot) ok("purity — input payload never mutated");
  else no("purity — input payload mutated");
}
{
  const outcome = runCalculation(pressuremeterModule, { points: CLAY_POINTS });
  if (outcome.status !== "ok") no(`envelope — failed: ${outcome.error.message}`);
  else {
    const checks: Array<[boolean, string]> = [
      [outcome.engineVersion === "1.0.0", "engineVersion = 1.0.0"],
      [outcome.moduleId === "pressuremeter", "moduleId = pressuremeter"],
      [outcome.moduleVersion === "1.0.0", "moduleVersion = 1.0.0"],
      [outcome.testType === "PRESSUREMETER", "testType = PRESSUREMETER"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`envelope — ${label}`);
      else no(`envelope — ${label}`);
    }
  }
}
{
  // Unit consistency: EM[kPa]/PL[kPa] equals the registry identity
  // EM[MPa] × 1000 / PL[kPa] at full precision.
  const outcome = runCalculation(pressuremeterModule, {
    points: M1_POINTS, referenceVolumeCm3: 40, measuringCellVolumeCm3: 535,
    emRange: { p1Kpa: 600, p2Kpa: 800 },
  });
  if (outcome.status === "ok") {
    const identityKpa = (outcome.raw.menardModulusKpa ?? 0) / (outcome.raw.limitPressureKpa ?? 1);
    const identityMpa = ((outcome.raw.menardModulusKpa ?? 0) / 1000) * 1000 / (outcome.raw.limitPressureKpa ?? 1);
    if (approx(identityKpa, identityMpa, 1e-12) && approx(identityKpa, 4.380877169012161, 1e-9)) {
      ok("unit consistency — EM/PL identity holds in kPa and MPa×1000 forms (4.380877169012161)");
    } else {
      no("unit consistency — identity failed");
    }
  }
}

console.log(`\n================ M5.2-g PRESSUREMETER TEST SUMMARY: ${pass} passed, ${fail} failed ================`);
process.exit(fail);
