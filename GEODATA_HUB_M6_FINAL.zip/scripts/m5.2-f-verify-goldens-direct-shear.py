#!/usr/bin/env python3
"""M5.2-f golden-value independent verification (Direct shear: Mohr-Coulomb).

Run BEFORE writing the test expectations. Every expected value below is
computed independently of the TypeScript engine:

- high-precision Decimal (60 digits) for the regression truth,
- IEEE-754 double probes mirroring the exact JS operation order designed for
  the module (sequential sums, two-pass Sxy/Sxx, intercept = mean - slope*mean,
  phi = atan(slope)*180/pi, R^2 = 1 - SSres/SStot),
- half-away-from-zero rounding predictions with tie-distance guards.

Designed module arithmetic (M5.2-f, ASTM D3080 / NF P94-071-1):

  Mohr-Coulomb envelope (least squares over stages):
      slope     = Sxy / Sxx            (tan phi)
      intercept = mean(tau) - slope * mean(sigma_n)   (c)
      phi       = atan(slope) * 180 / pi   [deg]
      R^2       = 1 - SSres / SStot
  Peak envelope over all stages; residual envelope over the stages that
  report residual shear stress (>= 2 with distinct sigma_n).
  Entered-comparison tolerance: +/-1.0 (kPa / deg) — the M5.1 seed fixture's
  own consistency standard (DS_STAGES_PROGRAM: "tau ~ 20 + sigma*tan25
  consistent with c=20, phi=25" while the fit gives 19.67/25.17).
"""
from decimal import Decimal as D, getcontext
import math

getcontext().prec = 60


def round_to_double(x, dp):
    scaled = x * 10 ** dp
    if abs(scaled) > 2 ** 53:
        raise ValueError("out of safe range")
    corrected_abs = abs(scaled) * (1 + 2.220446049250313e-16)
    rounded = math.floor(corrected_abs + 0.5)
    signed = -rounded if scaled < 0 else rounded
    result = signed / 10 ** dp
    return 0.0 if result == 0 else result


def tie_guard(x, dp, label):
    scaled = abs(x) * 10 ** dp
    dist = abs(scaled - math.floor(scaled) - 0.5)
    if dist < 1e-9:
        print(f"  !! TIE WARNING {label}: {x} at {dp} dp (scaled {scaled})")


def show(label, value, dp):
    tie_guard(value, dp, label)
    print(f"  {label:<52} = {value!r:<24} -> {dp} dp: {round_to_double(value, dp)}")
    return round_to_double(value, dp)


def js_envelope(pts):
    """Mirror of fitMohrCoulombEnvelope double op order. pts: [(sigma, tau)]."""
    n = len(pts)
    sx = 0.0
    sy = 0.0
    for x, y in pts:
        sx += x
        sy += y
    xm = sx / n
    ym = sy / n
    sxy = 0.0
    sxx = 0.0
    sstot = 0.0
    for x, y in pts:
        dx = x - xm
        dy = y - ym
        sxy += dx * dy
        sxx += dx * dx
        sstot += dy * dy
    slope = sxy / sxx
    c = ym - slope * xm
    phi = (math.atan(slope) * 180) / math.pi
    ssres = 0.0
    for x, y in pts:
        r = y - (c + slope * x)
        ssres += r * r
    r2 = 1.0 if sstot == 0 else 1 - ssres / sstot
    return slope, c, phi, r2


def analyze(label, pts, entered=None):
    print("=" * 100)
    print(f"FIXTURE {label}")
    print("=" * 100)
    print(f"  stages: {pts}")
    slope, c, phi, r2 = js_envelope(pts)
    # Decimal truth
    n = len(pts)
    sx = sum((D(str(x)) for x, _ in pts), D(0))
    sy = sum((D(str(y)) for _, y in pts), D(0))
    xm, ym = sx / n, sy / n
    sxy = sum((D(str(x)) - xm) * (D(str(y)) - ym) for x, y in pts)
    sxx = sum((D(str(x)) - xm) ** 2 for x, _ in pts)
    dslope = sxy / sxx
    dc = ym - dslope * xm
    print(f"  Decimal truth: slope = {dslope}, c = {dc}")
    show("slope (tan phi)", slope, 6)
    show("c [kPa]", c, 2)
    show("phi [deg]", phi, 2)
    show("R^2", r2, 4)
    if entered:
        dc_ent = c - entered[0]
        dphi = phi - entered[1]
        print(f"  |c - {entered[0]}| = {abs(dc_ent)} -> warn? {abs(dc_ent) > 1.0}")
        print(f"  |phi - {entered[1]}| = {abs(dphi)} -> warn? {abs(dphi) > 1.0}")
    print()
    return slope, c, phi, r2


# D1 - DS_STAGES_PROGRAM seed: (50,43),(100,67),(150,90) with entered (20, 25)
p1 = analyze("D1 - DS_STAGES_PROGRAM (seed; entered c=20, phi=25 -> no warning)",
             [(50, 43), (100, 67), (150, 90)], entered=(20, 25))

# D2 - exact linear envelope: c = 10, slope = 0.5 (phi = atan 0.5)
p2 = analyze("D2 - exact linear (c=10, tan phi=0.5, R^2=1)", [(50, 35), (100, 60), (200, 110)])

# D3 - residual envelope: (33, 48, 66) at (50, 100, 150)
p3 = analyze("D3 - residual envelope (33/48/66 at 50/100/150)", [(50, 33), (100, 48), (150, 66)])

# D4 - negative cohesion fixture: (100,20),(200,60),(300,130)
p4 = analyze("D4 - negative cohesion (curved strength envelope)", [(100, 20), (200, 60), (300, 130)])

# D5 - two-stage exact fit (R^2 = 1 by construction)
p5 = analyze("D5 - two-stage program (50,30),(150,80)", [(50, 30), (150, 80)])

print("=" * 100)
print("VALIDATION-CASE NUMBERS")
print("=" * 100)
print("  stages + scalars both supplied -> INVALID_INPUT (either-or rule)")
print("  neither stages nor scalars -> MISSING_INPUT (aggregated)")
print("  duplicate normalStressKpa -> INVALID_INPUT (registry rule)")
print("  residual > peak per stage -> INVALID_INPUT (registry rule)")
print("  normalStressKpa 2001 > 2000 -> INVALID_INPUT (bounds)")
print("  frictionAngleDeg entered 46 > 45 -> INVALID_INPUT (bounds)")
print("  9 stages -> INVALID_INPUT (max 8); 1 stage in stages[] -> INVALID_INPUT (min 2)")
print("  single distinct sigma_n among >=2 stages -> impossible (uniqueness); residual subset with 1 distinct -> INSUFFICIENT_DATA")
print()
print("ALL GOLDENS VERIFIED - values above are the independent expectations for")
print("scripts/m5.2-test-direct-shear.ts")
