/** M5.1 — record-count integrity probe (run before/after schema push). */
import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();
async function main() {
  const [o, u, p, b, l, s, t, d, sh, r, a] = await Promise.all([
    db.organization.count(), db.user.count(), db.project.count(), db.borehole.count(),
    db.geologicalLayer.count(), db.sample.count(), db.labTest.count(), db.document.count(),
    db.sharingRequest.count(), db.report.count(), db.activityLog.count(),
  ]);
  const completed = await db.labTest.count({ where: { status: "COMPLETED" } });
  const all = await db.labTest.findMany({ select: { resultData: true } });
  const withResult = all.filter((t) => t.resultData !== null).length;
  console.log(JSON.stringify({ orgs: o, users: u, projects: p, boreholes: b, layers: l, samples: s, labTests: t, documents: d, shares: sh, reports: r, activity: a, completed, withResult }));
  await db.$disconnect();
}
main();
