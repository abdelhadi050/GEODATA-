/**
 * M5.2-a TEST — Water content calculation module.
 *
 * Golden values independently verified beforehand (exact rational arithmetic in
 * scripts/m5.2-verify-goldens.py; sources: docs/13 §7.1 corrected fixture and
 * prisma/seed.ts mass-bookkeeping comments). Covers: golden envelopes, the
 * ±0.5 tolerance boundary on both sides, every missing-field and
 * invalid-combination rejection, present-but-null vs absent distinction,
 * full-precision raw vs rounded results, the entered-value warning without
 * overwriting, M5.1 registry compatibility parity (with the two documented
 * divergences), determinism and input purity.
 * Exit code = number of failures.
 */
import { z } from "zod";
import { runCalculation } from "../src/lib/calc/engine";
import type { CalculationOutcome } from "../src/lib/calc/types";
import {
  waterContentCalcInput,
  waterContentModule,
  type WaterContentInput,
  type WaterContentRaw,
  type WaterContentResults,
} from "../src/lib/calc/modules/water-content";
import { parseLabTestResult } from "../src/lib/lab-tests/registry";

let pass = 0;
let fail = 0;
const ok = (m: string) => { console.log(`PASS: ${m}`); pass++; };
const no = (m: string) => { console.log(`FAIL: ${m}`); fail++; };

const approx = (actual: number, expected: number, tol: number): boolean =>
  Math.abs(actual - expected) <= tol;

type Outcome = CalculationOutcome<WaterContentInput, WaterContentRaw, WaterContentResults>;

interface ExpectedError {
  code: string;
  fieldPath?: string;
  messageHint?: string;
}

function expectError(outcome: Outcome, label: string, expected: ExpectedError): void {
  if (outcome.status !== "error") {
    no(`${label} — expected ${expected.code}, got success`);
    return;
  }
  const { code, message, details } = outcome.error;
  if (code !== expected.code) {
    no(`${label} — expected ${expected.code}, got ${code}`);
    return;
  }
  if (expected.fieldPath !== undefined && details?.fieldPath !== expected.fieldPath) {
    no(`${label} — expected fieldPath ${expected.fieldPath}, got ${String(details?.fieldPath)}`);
    return;
  }
  if (expected.messageHint !== undefined && !message.includes(expected.messageHint)) {
    no(`${label} — message '${message}' lacks hint '${expected.messageHint}'`);
    return;
  }
  ok(`${label} — ${code}${expected.fieldPath ? ` @ ${expected.fieldPath}` : ""}`);
}

// ---------------------------------------------------------------------------
// 1. Golden envelopes
// ---------------------------------------------------------------------------
{
  // Golden A — the independently verified example (docs/14 §6.1, docs/13 §7.1):
  // input  { entered 18.5 %, wet 112.0, dry 101.6, tare 45.2 }
  // exact  m_w = 10.4 g, m_s = 56.4 g, w = 2600/141 = 18.4397163120567375… %
  const outcome = runCalculation(waterContentModule, {
    waterContentPercent: 18.5, wetMassG: 112.0, dryMassG: 101.6, containerMassG: 45.2,
  });
  if (outcome.status !== "ok") {
    no(`golden A — failed: ${outcome.error.message}`);
  } else {
    const checks: Array<[boolean, string]> = [
      [outcome.results.waterContentPercent === 18.44, "results.waterContentPercent = 18.44 (2 dp)"],
      [outcome.results.waterMassG === 10.4, "results.waterMassG = 10.4 (3 dp)"],
      [outcome.results.drySoilMassG === 56.4, "results.drySoilMassG = 56.4 (3 dp)"],
      [outcome.results.enteredWaterContentPercent === 18.5, "entered value echoed unchanged"],
      [outcome.results.discrepancyPercent === -0.06, "discrepancy = −0.06 (2 dp)"],
      [outcome.warnings.length === 0, "no warning (|Δ| = 0.0603 ≤ 0.5)"],
      [approx(outcome.raw.waterContentPercent, 2600 / 141, 1e-9), "raw.waterContentPercent full precision ≈ 18.4397163120567376"],
      [approx(outcome.raw.waterMassG, 10.4, 1e-9), "raw.waterMassG full precision ≈ 10.4"],
      [approx(outcome.raw.drySoilMassG, 56.4, 1e-9), "raw.drySoilMassG full precision ≈ 56.4"],
      [outcome.raw.waterContentPercent !== outcome.results.waterContentPercent, "raw NOT rounded (raw ≠ results value)"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`golden A — ${label}`);
      else no(`golden A — ${label}`);
    }
  }
}
{
  // Golden B — seed fixture WC_18_5: exact w = 3775/204 = 18.5049019607843 %
  const outcome = runCalculation(waterContentModule, {
    waterContentPercent: 18.5, wetMassG: 235.5, dryMassG: 205.3, containerMassG: 42.1,
  });
  if (outcome.status !== "ok") no(`golden B — failed: ${outcome.error.message}`);
  else {
    if (outcome.results.waterContentPercent === 18.5) ok("golden B (seed WC_18_5) — results w = 18.50");
    else no(`golden B — w = ${outcome.results.waterContentPercent}`);
    if (outcome.results.waterMassG === 30.2 && outcome.results.drySoilMassG === 163.2) {
      ok("golden B — waterMass 30.2 g, drySoil 163.2 g");
    } else no("golden B — masses wrong");
    if (outcome.results.discrepancyPercent === 0 && outcome.warnings.length === 0) {
      ok("golden B — discrepancy rounds to 0.00, no warning");
    } else no("golden B — discrepancy/warning wrong");
  }
}
{
  // Golden C — seed fixture WC_11_9: exact w = 17400/1463 = 11.8933697881066 %
  const outcome = runCalculation(waterContentModule, {
    waterContentPercent: 11.9, wetMassG: 203.5, dryMassG: 186.1, containerMassG: 39.8,
  });
  if (outcome.status !== "ok") no(`golden C — failed: ${outcome.error.message}`);
  else {
    if (outcome.results.waterContentPercent === 11.89) ok("golden C (seed WC_11_9) — results w = 11.89");
    else no(`golden C — w = ${outcome.results.waterContentPercent}`);
    if (outcome.results.discrepancyPercent === -0.01) ok("golden C — discrepancy = −0.01 (rounds away from zero)");
    else no(`golden C — discrepancy = ${outcome.results.discrepancyPercent}`);
    if (outcome.warnings.length === 0) ok("golden C — no warning");
    else no("golden C — unexpected warning");
  }
}
{
  // Golden D — warning case: masses (100, 90, 40) → exact w = 20 %, entered 21.0
  const outcome = runCalculation(waterContentModule, {
    waterContentPercent: 21.0, wetMassG: 100.0, dryMassG: 90.0, containerMassG: 40.0,
  });
  if (outcome.status !== "ok") no(`golden D — failed: ${outcome.error.message}`);
  else {
    if (outcome.results.waterContentPercent === 20 && outcome.results.waterMassG === 10 && outcome.results.drySoilMassG === 50) {
      ok("golden D — w = 20.00 %, waterMass 10 g, drySoil 50 g");
    } else no("golden D — computed values wrong");
    if (outcome.warnings.length === 1) {
      const w = outcome.warnings[0];
      const detailsOk =
        w.details?.enteredWaterContentPercent === 21 &&
        w.details?.computedWaterContentPercent === 20 &&
        w.details?.discrepancyPercent === -1 &&
        w.details?.tolerancePercent === 0.5;
      if (w.code === "ENTERED_VALUE_DISCREPANCY" && detailsOk) {
        ok("golden D — ENTERED_VALUE_DISCREPANCY warning with correct details");
      } else no(`golden D — warning wrong: ${JSON.stringify(w)}`);
    } else no(`golden D — expected 1 warning, got ${outcome.warnings.length}`);
    // No overwriting: both values coexist in the results.
    if (outcome.results.enteredWaterContentPercent === 21 && outcome.results.waterContentPercent === 20) {
      ok("golden D — entered value NOT overwritten (echo 21 %, computed 20 %)");
    } else no("golden D — entered value was overwritten");
  }
}
{
  // High water content (> 100 %, organics): masses (140, 70, 20) → exact 140 %
  const outcome = runCalculation(waterContentModule, {
    waterContentPercent: 140.0, wetMassG: 140.0, dryMassG: 70.0, containerMassG: 20.0,
  });
  if (outcome.status === "ok" && outcome.results.waterContentPercent === 140 && outcome.warnings.length === 0) {
    ok("w > 100 % valid — 140.00 % computed, no clamp, no warning");
  } else no("w > 100 % case failed");
}
{
  // Storage-boundary: entered 300 (max), computed exactly 300.00.
  const outcome = runCalculation(waterContentModule, {
    waterContentPercent: 300, wetMassG: 120.0, dryMassG: 45.0, containerMassG: 20.0,
  });
  if (outcome.status === "ok" && outcome.results.waterContentPercent === 300 && outcome.warnings.length === 0) {
    ok("entered 300 % (contract bound) — computed 300.00 %, no warning");
  } else no("300 % boundary case failed");
}
{
  // Computed above the storage bound is NOT clamped (docs/14 §4.9): 300.1 %
  const outcome = runCalculation(waterContentModule, {
    waterContentPercent: 300, wetMassG: 120.025, dryMassG: 45.0, containerMassG: 20.0,
  });
  if (outcome.status === "ok" && outcome.results.waterContentPercent === 300.1 && outcome.raw.waterContentPercent > 300.1 - 1e-9) {
    ok("computed 300.1 % reported as-is — no clamp to the 300 % storage bound");
  } else no(`uncapped computation failed: ${outcome.status === "ok" ? outcome.results.waterContentPercent : outcome.error.message}`);
}

// ---------------------------------------------------------------------------
// 2. Tolerance boundary (inclusive at ±0.50, warning strictly beyond)
// ---------------------------------------------------------------------------
{
  const atBoundaryHigh = runCalculation(waterContentModule, {
    waterContentPercent: 20.5, wetMassG: 100.0, dryMassG: 90.0, containerMassG: 40.0, // Δ = −0.50
  });
  if (atBoundaryHigh.status === "ok" && atBoundaryHigh.warnings.length === 0) {
    ok("boundary |Δ| = 0.50 (entered 20.5) — within tolerance, NO warning");
  } else no("boundary 0.50 high — warning wrongly emitted");
}
{
  const atBoundaryLow = runCalculation(waterContentModule, {
    waterContentPercent: 19.5, wetMassG: 100.0, dryMassG: 90.0, containerMassG: 40.0, // Δ = +0.50
  });
  if (atBoundaryLow.status === "ok" && atBoundaryLow.warnings.length === 0) {
    ok("boundary |Δ| = 0.50 (entered 19.5) — within tolerance, NO warning");
  } else no("boundary 0.50 low — warning wrongly emitted");
}
{
  const beyondBoundary = runCalculation(waterContentModule, {
    waterContentPercent: 20.51, wetMassG: 100.0, dryMassG: 90.0, containerMassG: 40.0, // Δ = −0.51
  });
  if (beyondBoundary.status === "ok" && beyondBoundary.warnings.length === 1) {
    ok("boundary |Δ| = 0.51 — beyond tolerance, warning emitted");
  } else no("boundary 0.51 — warning missing");
}

// ---------------------------------------------------------------------------
// 3. Missing inputs
// ---------------------------------------------------------------------------
{
  const outcome = runCalculation(waterContentModule, {});
  expectError(outcome, "empty payload", { code: "MISSING_INPUT", messageHint: "waterContentPercent" });
  if (outcome.status === "error") {
    const issues = outcome.error.details?.issues;
    if (Array.isArray(issues) && issues.length === 4) ok("empty payload — all 4 fields reported as issues");
    else no(`empty payload — issue count ${String(issues?.length)} != 4`);
  }
}
{
  // Seed massless record WC_22_4: valid M5.1 storage, NOT calculable.
  const outcome = runCalculation(waterContentModule, { waterContentPercent: 22.4 });
  expectError(outcome, "massless seed record {22.4 %}", {
    code: "MISSING_INPUT",
    messageHint: "wetMassG",
  });
}
{
  const missingEach: Array<[string, Record<string, number>]> = [
    ["wetMassG", { waterContentPercent: 18.5, dryMassG: 101.6, containerMassG: 45.2 }],
    ["dryMassG", { waterContentPercent: 18.5, wetMassG: 112.0, containerMassG: 45.2 }],
    ["containerMassG", { waterContentPercent: 18.5, wetMassG: 112.0, dryMassG: 101.6 }],
    ["waterContentPercent", { wetMassG: 112.0, dryMassG: 101.6, containerMassG: 45.2 }],
  ];
  for (const [field, payload] of missingEach) {
    const outcome = runCalculation(waterContentModule, payload);
    expectError(outcome, `missing ${field}`, { code: "MISSING_INPUT", messageHint: field });
  }
}

// ---------------------------------------------------------------------------
// 4. Present-but-null vs absent, and non-object payloads
// ---------------------------------------------------------------------------
{
  const outcome = runCalculation(waterContentModule, {
    waterContentPercent: null, wetMassG: 112.0, dryMassG: 101.6, containerMassG: 45.2,
  });
  expectError(outcome, "null entered value (present but wrong type)", { code: "INVALID_INPUT", fieldPath: "waterContentPercent" });
}
{
  const outcome = runCalculation(waterContentModule, 42);
  expectError(outcome, "payload is a number", { code: "INVALID_INPUT", fieldPath: "(root)" });
}
{
  const outcome = runCalculation(waterContentModule, [18.5, 112.0, 101.6, 45.2]);
  expectError(outcome, "payload is an array", { code: "INVALID_INPUT", fieldPath: "(root)" });
}

// ---------------------------------------------------------------------------
// 5. Invalid inputs — physical ordering (M5.1 superRefine mirror)
// ---------------------------------------------------------------------------
{
  const outcome = runCalculation(waterContentModule, {
    waterContentPercent: 18.5, wetMassG: 100.0, dryMassG: 110.0, containerMassG: 40.0,
  });
  expectError(outcome, "wetMassG < dryMassG", { code: "INVALID_INPUT", fieldPath: "wetMassG", messageHint: "greater than" });
}
{
  const outcome = runCalculation(waterContentModule, {
    waterContentPercent: 0.1, wetMassG: 90.0, dryMassG: 90.0, containerMassG: 40.0,
  });
  expectError(outcome, "wetMassG == dryMassG (strict > per M5.1)", { code: "INVALID_INPUT", fieldPath: "wetMassG" });
}
{
  const outcome = runCalculation(waterContentModule, {
    waterContentPercent: 18.5, wetMassG: 100.0, dryMassG: 45.0, containerMassG: 45.0,
  });
  expectError(outcome, "dryMassG == containerMassG", { code: "INVALID_INPUT", fieldPath: "dryMassG", messageHint: "exceed" });
}
{
  const outcome = runCalculation(waterContentModule, {
    waterContentPercent: 18.5, wetMassG: 100.0, dryMassG: 40.0, containerMassG: 45.0,
  });
  expectError(outcome, "dryMassG < containerMassG", { code: "INVALID_INPUT", fieldPath: "dryMassG", messageHint: "exceed" });
}

// ---------------------------------------------------------------------------
// 6. Invalid inputs — contract bounds and types (registry mirror)
// ---------------------------------------------------------------------------
{
  const cases: Array<[string, Record<string, unknown>, ExpectedError]> = [
    ["containerMassG = 0 (positive required)", { waterContentPercent: 18.5, wetMassG: 112.0, dryMassG: 101.6, containerMassG: 0 }, { code: "INVALID_INPUT" }],
    ["negative wetMassG", { waterContentPercent: 18.5, wetMassG: -112.0, dryMassG: 101.6, containerMassG: 45.2 }, { code: "INVALID_INPUT" }],
    ["entered −0.1 % (min 0)", { waterContentPercent: -0.1, wetMassG: 112.0, dryMassG: 101.6, containerMassG: 45.2 }, { code: "INVALID_INPUT", fieldPath: "waterContentPercent" }],
    ["entered 300.5 % (max 300)", { waterContentPercent: 300.5, wetMassG: 112.0, dryMassG: 101.6, containerMassG: 45.2 }, { code: "INVALID_INPUT", fieldPath: "waterContentPercent" }],
    ["wetMassG 8001 (max 8000)", { waterContentPercent: 18.5, wetMassG: 8001, dryMassG: 101.6, containerMassG: 45.2 }, { code: "INVALID_INPUT", fieldPath: "wetMassG" }],
    ["containerMassG 2001 (max 2000)", { waterContentPercent: 18.5, wetMassG: 112.0, dryMassG: 101.6, containerMassG: 2001 }, { code: "INVALID_INPUT", fieldPath: "containerMassG" }],
    ["string mass", { waterContentPercent: 18.5, wetMassG: "112.0", dryMassG: 101.6, containerMassG: 45.2 }, { code: "INVALID_INPUT", fieldPath: "wetMassG", messageHint: "expected number" }],
    ["NaN entered value", { waterContentPercent: Number.NaN, wetMassG: 112.0, dryMassG: 101.6, containerMassG: 45.2 }, { code: "INVALID_INPUT", fieldPath: "waterContentPercent" }],
    ["Infinity wetMassG", { waterContentPercent: 18.5, wetMassG: Number.POSITIVE_INFINITY, dryMassG: 101.6, containerMassG: 45.2 }, { code: "INVALID_INPUT", fieldPath: "wetMassG" }],
  ];
  for (const [label, payload, expected] of cases) {
    const outcome = runCalculation(waterContentModule, payload);
    expectError(outcome, label, expected);
  }
}

// ---------------------------------------------------------------------------
// 7. Rounding boundary — raw full precision, results rounded
// ---------------------------------------------------------------------------
{
  const payload = { waterContentPercent: 18.5, wetMassG: 112.0, dryMassG: 101.6, containerMassG: 45.2 };
  const outcome = runCalculation(waterContentModule, payload);
  if (outcome.status !== "ok") no("rounding boundary — run failed");
  else {
    const rawDecimals = String(outcome.raw.waterContentPercent).split(".")[1]?.length ?? 0;
    if (rawDecimals > 2 && String(outcome.results.waterContentPercent) === "18.44") {
      ok(`rounding boundary — raw keeps ${rawDecimals} decimals, results rounded to 2 dp`);
    } else no("rounding boundary — precision policy violated");
    // input echo is the parsed payload, unchanged
    if (JSON.stringify(outcome.input) === JSON.stringify(payload)) ok("input echo — parsed input echoed verbatim");
    else no("input echo — altered");
  }
}

// ---------------------------------------------------------------------------
// 8. M5.1 registry compatibility (behavioral parity + documented divergences)
// ---------------------------------------------------------------------------
{
  // Shared domain: module-accepted payloads must be accepted by the M5.1
  // result schema too (parseLabTestResult), and module-rejected schema/bounds
  // cases must be rejected there as well.
  const sharedValid: Array<[string, Record<string, number>]> = [
    ["golden A", { waterContentPercent: 18.5, wetMassG: 112.0, dryMassG: 101.6, containerMassG: 45.2 }],
    ["seed WC_18_5", { waterContentPercent: 18.5, wetMassG: 235.5, dryMassG: 205.3, containerMassG: 42.1 }],
    ["seed WC_11_9", { waterContentPercent: 11.9, wetMassG: 203.5, dryMassG: 186.1, containerMassG: 39.8 }],
    ["w = 140 %", { waterContentPercent: 140, wetMassG: 140.0, dryMassG: 70.0, containerMassG: 20.0 }],
    ["w = 300 %", { waterContentPercent: 300, wetMassG: 120.0, dryMassG: 45.0, containerMassG: 20.0 }],
  ];
  for (const [label, payload] of sharedValid) {
    // Module acceptance = full engine run (schema + physical rules + tolerance).
    const moduleOutcome = runCalculation(waterContentModule, payload);
    const moduleOk = moduleOutcome.status === "ok" && moduleOutcome.warnings.length === 0;
    const registryOk = parseLabTestResult("WATER_CONTENT", payload).ok;
    if (moduleOk && registryOk) ok(`parity — ${label}: module AND M5.1 registry both accept`);
    else no(`parity — ${label}: module=${moduleOk}, registry=${registryOk}`);
  }

  const sharedInvalid: Array<[string, Record<string, unknown>]> = [
    ["wet ≤ dry", { waterContentPercent: 18.5, wetMassG: 100.0, dryMassG: 110.0, containerMassG: 40.0 }],
    ["wet == dry", { waterContentPercent: 0.1, wetMassG: 90.0, dryMassG: 90.0, containerMassG: 40.0 }],
    ["dry ≤ tare", { waterContentPercent: 18.5, wetMassG: 100.0, dryMassG: 45.0, containerMassG: 45.0 }],
    ["entered 500 %", { waterContentPercent: 500, wetMassG: 112.0, dryMassG: 101.6, containerMassG: 45.2 }],
    ["wetMassG 9000", { waterContentPercent: 18.5, wetMassG: 9000, dryMassG: 101.6, containerMassG: 45.2 }],
    ["string mass", { waterContentPercent: 18.5, wetMassG: "x", dryMassG: 101.6, containerMassG: 45.2 }],
  ];
  for (const [label, payload] of sharedInvalid) {
    // Module rejection = full engine run (schema + physical ordering rules).
    const moduleRejects = runCalculation(waterContentModule, payload).status === "error";
    const registryRejects = !parseLabTestResult("WATER_CONTENT", payload).ok;
    if (moduleRejects && registryRejects) ok(`parity — ${label}: module AND M5.1 registry both reject`);
    else no(`parity — ${label}: module rejects=${moduleRejects}, registry rejects=${registryRejects}`);
  }

  // Extra keys: both schemas strip unknown keys (Zod default) — golden A + extra.
  const withExtra = { ...sharedValid[0][1], extraKey: "not part of the contract" };
  const moduleStrips = waterContentCalcInput.safeParse(withExtra);
  const registryStrips = parseLabTestResult("WATER_CONTENT", withExtra);
  if (
    moduleStrips.success && registryStrips.ok &&
    !("extraKey" in (moduleStrips.data as Record<string, unknown>))
  ) {
    ok("parity — unknown keys stripped by both module and registry schemas");
  } else {
    no("parity — unknown-key handling differs");
  }

  // Documented divergence 1 (docs/14 §5): beyond-tolerance payload — registry
  // REJECTS at write time; module ACCEPTS and warns.
  const beyondTolerance = { waterContentPercent: 21.0, wetMassG: 100.0, dryMassG: 90.0, containerMassG: 40.0 };
  const registryRejects = !parseLabTestResult("WATER_CONTENT", beyondTolerance).ok;
  const moduleOutcome = runCalculation(waterContentModule, beyondTolerance);
  const moduleAcceptsWithWarning =
    moduleOutcome.status === "ok" && moduleOutcome.warnings.length === 1;
  if (registryRejects && moduleAcceptsWithWarning) {
    ok("divergence 1 — registry rejects |Δ| > 0.5 at write time; module accepts + warns (documented)");
  } else {
    no(`divergence 1 — registry rejects=${registryRejects}, module accepts+warns=${moduleAcceptsWithWarning}`);
  }

  // Documented divergence 2 (docs/14 §5): massless record — registry ACCEPTS
  // (masses optional); module rejects MISSING_INPUT (not calculable).
  const massless = { waterContentPercent: 22.4 };
  const registryAccepts = parseLabTestResult("WATER_CONTENT", massless).ok;
  const moduleOutcome2 = runCalculation(waterContentModule, massless);
  if (registryAccepts && moduleOutcome2.status === "error" && moduleOutcome2.error.code === "MISSING_INPUT") {
    ok("divergence 2 — registry accepts massless record; module rejects MISSING_INPUT (never invents masses)");
  } else {
    no("divergence 2 — behavior does not match the documented contract");
  }

  // Module metadata matches the registry code.
  if (waterContentModule.testType === "WATER_CONTENT" && waterContentModule.id === "water-content") {
    ok("module metadata — testType 'WATER_CONTENT' matches the registry code");
  } else {
    no("module metadata — testType mismatch");
  }
}

// ---------------------------------------------------------------------------
// 9. Determinism and purity
// ---------------------------------------------------------------------------
{
  const payload = { waterContentPercent: 18.5, wetMassG: 112.0, dryMassG: 101.6, containerMassG: 45.2 };
  const before = JSON.stringify(payload);
  const signatures = new Set<string>();
  for (let i = 0; i < 25; i++) signatures.add(JSON.stringify(runCalculation(waterContentModule, payload)));
  if (signatures.size === 1) ok("determinism — 25 runs deeply identical (incl. key order)");
  else no("determinism — runs diverged");
  if (JSON.stringify(payload) === before) ok("purity — input payload not mutated");
  else no("purity — input payload mutated");
}
{
  const payload = { waterContentPercent: 21.0, wetMassG: 100.0, dryMassG: 90.0, containerMassG: 40.0 };
  const signatures = new Set<string>();
  for (let i = 0; i < 25; i++) signatures.add(JSON.stringify(runCalculation(waterContentModule, payload)));
  if (signatures.size === 1) ok("determinism — 25 warning-case runs deeply identical");
  else no("determinism — warning-case runs diverged");
}

// ---------------------------------------------------------------------------
// 10. Envelope provenance
// ---------------------------------------------------------------------------
{
  const outcome = runCalculation(waterContentModule, {
    waterContentPercent: 18.5, wetMassG: 112.0, dryMassG: 101.6, containerMassG: 45.2,
  });
  if (outcome.status === "ok") {
    if (
      outcome.moduleId === "water-content" &&
      outcome.moduleVersion === "1.0.0" &&
      outcome.testType === "WATER_CONTENT" &&
      typeof outcome.engineVersion === "string" && outcome.engineVersion.length > 0
    ) {
      ok("envelope — moduleId/moduleVersion/testType/engineVersion present");
    } else no("envelope — provenance incomplete");
  } else {
    no("envelope — run failed");
  }
}

console.log(`\n================ M5.2-a WATER CONTENT TEST SUMMARY: ${pass} passed, ${fail} failed ================`);
process.exit(fail);
