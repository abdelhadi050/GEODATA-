#!/usr/bin/env bash
# M6 perf probe runner — dev server + probe in a single bash invocation.
set -u
cd /home/z/my-project

stop_dev(){ pkill -f "next dev" 2>/dev/null || true; sleep 1; }
trap stop_dev EXIT

stop_dev
nohup bun run dev < /dev/null > /tmp/m6-dev.out 2>&1 &
DEV_PID=$!
for i in $(seq 1 30); do
  curl -sf http://localhost:3000/api/health > /dev/null 2>&1 && break
  sleep 1
done
if ! curl -sf http://localhost:3000/api/health > /dev/null 2>&1; then
  echo "Dev server failed"; tail -30 /tmp/m6-dev.out; exit 1
fi
echo "Dev server ready"

bun run scripts/m6-perf-probe.ts
RC=$?

stop_dev
exit $RC
