/**
 * M6 — performance probe.
 *
 * Measures the response time of key API endpoints to identify slow queries.
 * Runs against the live dev server. Reports the p50/p95 latency per endpoint.
 */
const API = "http://localhost:3000/api";
const PASSWORD = "Demo1234!";

function cookieFrom(setCookies: string[], name: string): string | null {
  for (const c of setCookies) {
    const [pair] = c.split(";");
    const eq = pair.indexOf("=");
    if (pair.slice(0, eq) === name) return pair.slice(eq + 1);
  }
  return null;
}

async function login(email: string): Promise<string> {
  const r1 = await fetch(`${API}/auth/csrf`);
  const { csrfToken } = (await r1.json()) as { csrfToken: string };
  const csrfCookie = cookieFrom(r1.headers.getSetCookie(), "next-auth.csrf-token");
  const r2 = await fetch(`${API}/auth/callback/credentials`, {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
      Cookie: `next-auth.csrf-token=${csrfCookie}`,
    },
    body: new URLSearchParams({
      csrfToken,
      email,
      password: PASSWORD,
      callbackUrl: "http://localhost:3000/",
      json: "true",
    }),
    redirect: "manual",
  });
  const session = cookieFrom(r2.headers.getSetCookie(), "next-auth.session-token");
  return session ? `next-auth.session-token=${session}` : "";
}

interface ProbeSpec {
  name: string;
  path: string;
  iterations: number;
}

const probes: ProbeSpec[] = [
  { name: "GET /api/health (no auth)", path: "/api/health", iterations: 20 },
  { name: "GET /api/projects (list)", path: "/projects?pageSize=100", iterations: 20 },
  { name: "GET /api/boreholes (list)", path: "/boreholes?pageSize=200", iterations: 20 },
  { name: "GET /api/samples (list)", path: "/samples?pageSize=200", iterations: 20 },
  { name: "GET /api/lab-tests (list)", path: "/lab-tests?pageSize=200", iterations: 20 },
  { name: "GET /api/reports (list)", path: "/reports", iterations: 20 },
  { name: "GET /api/classifications/engines", path: "/classifications/engines", iterations: 20 },
  { name: "GET /api/lab-tests/registry", path: "/lab-tests/registry", iterations: 20 },
  { name: "GET /api/calculations/engines", path: "/calculations/engines", iterations: 20 },
  { name: "GET /api/activity", path: "/activity?limit=50", iterations: 20 },
];

async function probe(spec: ProbeSpec, cookie: string): Promise<void> {
  const times: number[] = [];
  let errors = 0;
  // Warm-up (first request compiles routes in dev mode).
  await fetch(`${API}${spec.path}`, { headers: { cookie } });

  for (let i = 0; i < spec.iterations; i++) {
    const t0 = performance.now();
    const res = await fetch(`${API}${spec.path}`, { headers: { cookie } });
    const t1 = performance.now();
    if (!res.ok) errors++;
    times.push(t1 - t0);
  }
  times.sort((a, b) => a - b);
  const p50 = times[Math.floor(times.length * 0.5)].toFixed(1);
  const p95 = times[Math.floor(times.length * 0.95)].toFixed(1);
  const avg = (times.reduce((s, t) => s + t, 0) / times.length).toFixed(1);
  const max = times[times.length - 1].toFixed(1);
  const status = errors > 0 ? `(${errors} errors)` : "";
  console.log(`  ${spec.name.padEnd(40)} p50=${p50}ms  p95=${p95}ms  avg=${avg}ms  max=${max}ms  ${status}`);
}

const cookie = await login("engineer@geodata.demo");
if (!cookie) {
  console.error("Login failed");
  process.exit(1);
}

console.log("M6 Performance Probe — dev server (Turbopack)");
console.log("Note: dev mode includes route compilation overhead; production is ~3-5× faster.");
console.log("");
for (const spec of probes) {
  await probe(spec, cookie);
}
console.log("");
console.log("Acceptance criteria (dev mode):");
console.log("  - List endpoints p95 < 500ms (dev) / < 100ms (production)");
console.log("  - Health endpoint p95 < 100ms (dev) / < 30ms (production)");
console.log("  - No errors");
