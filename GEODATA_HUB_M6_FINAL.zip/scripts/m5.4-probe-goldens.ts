/**
 * M5.4 verification — probe the USCS and AASHTO modules against the seed
 * fixtures to determine the engine's actual output (for golden tests).
 */
import { runClassification } from "@/lib/classification/engine";
import { uscsModule } from "@/lib/classification/modules/uscs";
import { aashtoModule } from "@/lib/classification/modules/aashto";

const GRAN_SANDY_SILT = {
  points: [
    { diameterMm: 63, percentFiner: 100 },
    { diameterMm: 31.5, percentFiner: 99 },
    { diameterMm: 16, percentFiner: 97 },
    { diameterMm: 8, percentFiner: 93 },
    { diameterMm: 4, percentFiner: 87 },
    { diameterMm: 2, percentFiner: 78 },
    { diameterMm: 1, percentFiner: 66 },
    { diameterMm: 0.5, percentFiner: 52 },
    { diameterMm: 0.25, percentFiner: 38 },
    { diameterMm: 0.125, percentFiner: 27 },
    { diameterMm: 0.063, percentFiner: 20 },
    { diameterMm: 0.02, percentFiner: 13 },
    { diameterMm: 0.006, percentFiner: 8 },
    { diameterMm: 0.002, percentFiner: 5 },
  ].slice().sort((a, b) => a.diameterMm - b.diameterMm),
};

const GRAN_SILTY_CLAY = {
  points: [
    { diameterMm: 2, percentFiner: 100 },
    { diameterMm: 1, percentFiner: 99 },
    { diameterMm: 0.5, percentFiner: 98 },
    { diameterMm: 0.25, percentFiner: 96 },
    { diameterMm: 0.125, percentFiner: 93 },
    { diameterMm: 0.063, percentFiner: 88 },
    { diameterMm: 0.02, percentFiner: 62 },
    { diameterMm: 0.006, percentFiner: 41 },
    { diameterMm: 0.002, percentFiner: 27 },
    { diameterMm: 0.001, percentFiner: 21 },
  ].slice().sort((a, b) => a.diameterMm - b.diameterMm),
};

const GRAN_DUNE_SAND = {
  points: [
    { diameterMm: 4, percentFiner: 100 },
    { diameterMm: 2, percentFiner: 99 },
    { diameterMm: 1, percentFiner: 91 },
    { diameterMm: 0.5, percentFiner: 62 },
    { diameterMm: 0.25, percentFiner: 24 },
    { diameterMm: 0.125, percentFiner: 6 },
    { diameterMm: 0.063, percentFiner: 2 },
  ].slice().sort((a, b) => a.diameterMm - b.diameterMm),
};

const ATT_CLAY_42 = { liquidLimit: 42, plasticLimit: 19, plasticityIndex: 23 };
const ATT_CLAY_31 = { liquidLimit: 31, plasticLimit: 16, plasticityIndex: 15 };
const ATT_CLAY_55 = { liquidLimit: 55, plasticLimit: 24, plasticityIndex: 31, shrinkageLimit: 16 };

interface CaseSpec {
  name: string;
  module: typeof uscsModule | typeof aashtoModule;
  input: Record<string, unknown>;
}

const cases: CaseSpec[] = [
  // USCS cases — granulometry + Atterberg
  { name: "USCS GRAN_SANDY_SILT + ATT_CLAY_31 (expect SC, not lab-entered SM)",
    module: uscsModule, input: { ...GRAN_SANDY_SILT, atterberg: ATT_CLAY_31 } },
  { name: "USCS GRAN_SILTY_CLAY + ATT_CLAY_42 (expect CL)",
    module: uscsModule, input: { ...GRAN_SILTY_CLAY, atterberg: ATT_CLAY_42 } },
  { name: "USCS GRAN_DUNE_SAND no Atterberg (expect SP)",
    module: uscsModule, input: { ...GRAN_DUNE_SAND } },
  { name: "USCS GRAN_DUNE_SAND + ATT_CLAY_31 (clean sand < 5% fines, Atterberg ignored — expect SP)",
    module: uscsModule, input: { ...GRAN_DUNE_SAND, atterberg: ATT_CLAY_31 } },
  { name: "USCS GRAN_SILTY_CLAY + ATT_CLAY_55 (expect CH, LL=55 ≥ 50)",
    module: uscsModule, input: { ...GRAN_SILTY_CLAY, atterberg: ATT_CLAY_55 } },
  // AASHTO cases
  { name: "AASHTO GRAN_SANDY_SILT + ATT_CLAY_31 (expect A-2-6)",
    module: aashtoModule, input: { ...GRAN_SANDY_SILT, atterberg: ATT_CLAY_31 } },
  { name: "AASHTO GRAN_SILTY_CLAY + ATT_CLAY_42 (expect A-6 with GI)",
    module: aashtoModule, input: { ...GRAN_SILTY_CLAY, atterberg: ATT_CLAY_42 } },
  { name: "AASHTO GRAN_SILTY_CLAY + ATT_CLAY_55 (expect A-7-6)",
    module: aashtoModule, input: { ...GRAN_SILTY_CLAY, atterberg: ATT_CLAY_55 } },
  { name: "AASHTO GRAN_DUNE_SAND no Atterberg (expect A-3)",
    module: aashtoModule, input: { ...GRAN_DUNE_SAND } },
];

for (const c of cases) {
  const outcome = runClassification(c.module, c.input);
  console.log(`\n=== ${c.name} ===`);
  if (outcome.status === "ok") {
    if (c.module === uscsModule) {
      const r = outcome.results as Record<string, unknown>;
      console.log(`  symbol: ${r.symbol}`);
      console.log(`  groupName: ${r.groupName}`);
      console.log(`  category: ${r.category}`);
      console.log(`  %fines=${r.percentFines} %gravel=${r.percentGravel} %sand=${r.percentSand}`);
      console.log(`  D10=${r.d10} D30=${r.d30} D60=${r.d60} Cu=${r.uniformityCoefficient} Cc=${r.coefficientOfCurvature}`);
      console.log(`  A-line PI at LL=${r.aLinePiAtLl} | U-line PI at LL=${r.uLinePiAtLl}`);
      console.log(`  warnings: ${outcome.warnings.length}`);
      for (const w of outcome.warnings) {
        console.log(`    [${w.code}] ${w.message}`);
      }
    } else {
      const r = outcome.results as Record<string, unknown>;
      console.log(`  group: ${r.group}`);
      console.log(`  designation: ${r.designation}`);
      console.log(`  groupName: ${r.groupName}`);
      console.log(`  category: ${r.category}`);
      console.log(`  %pass#10=${r.percentPassingNo10} %pass#40=${r.percentPassingNo40} %pass#200=${r.percentPassingNo200}`);
      console.log(`  LL=${r.liquidLimit} PI=${r.plasticityIndex}`);
      console.log(`  GI=${r.groupIndex} (LL-partial=${r.giLlPartial} PI-partial=${r.giPiPartial})`);
      console.log(`  warnings: ${outcome.warnings.length}`);
      for (const w of outcome.warnings) {
        console.log(`    [${w.code}] ${w.message}`);
      }
    }
  } else {
    console.log(`  ERROR [${outcome.error.code}]: ${outcome.error.message}`);
    if (outcome.error.details) console.log(`  details: ${JSON.stringify(outcome.error.details)}`);
  }
}
