/**
 * M5.2-f TEST — Direct shear calculation module (Mohr–Coulomb c/φ).
 *
 * Golden values independently verified BEFORE being asserted here (60-digit
 * Decimal regression + IEEE-double probes mirroring the module's exact op
 * order — sequential sums, two-pass Sxy/Sxx, atan-degree conversion, R² — in
 * scripts/m5.2-f-verify-goldens-direct-shear.py). Sources: M5.2-f
 * authorization §6.B, registry directShearResult contract (ASTM D3080 /
 * NF P94-071-1), prisma/seed.ts fixture DS_STAGES_PROGRAM (stages
 * 50/100/150 kPa, entered c′ 20 kPa / φ′ 25°).
 *
 * Coverage (authorization §9): normal valid cases (multi-stage envelope
 * goldens, exact-linear fit, residual envelope, two-stage program); invalid
 * inputs (either-or rule, duplicates, residual > peak, bounds, 1/9 stages,
 * NaN/strings); missing measurements (empty payload, scalars-only without
 * envelope); boundary conditions (entered ±1.0 tolerance both sides);
 * insufficient experimental data (single-stage legacy record, single
 * residual value); unit consistency (kPa stresses throughout); calculation
 * accuracy (Decimal-agreed regressions); physical and engineering
 * consistency (negative cohesion reported unclamped with a warning, peak and
 * residual kept separate, R² transparency); error and warning handling
 * (registry mirrors, ENTERED_VALUE_DISCREPANCY / INSUFFICIENT_DATA /
 * PHYSICAL_CONSISTENCY codes, drainage echo); M5.1 registry parity with
 * documented divergences; determinism (25 runs × paths); purity; envelope
 * provenance.
 *
 * Key verifier goldens (double probes; Decimal agrees to <1e-13):
 *   D1 DS_STAGES_PROGRAM: slope 0.47, c = 19.66666666666667,
 *      φ = 25.173524524530166°, R² = 0.9998491249245625.
 *   D2 exact linear: c = 9.999999999999993, φ = 26.56505117707799°, R² = 1.
 *   D3 residual: c = 16.0, φ = 18.26288994219413°, R² = 0.9972527472527473.
 *   D4 negative cohesion: c = −40.000000000000014, φ = 28.81079374297307°.
 * Exit code = number of failures.
 */
import { runCalculation } from "../src/lib/calc/engine";
import type { CalculationOutcome } from "../src/lib/calc/types";
import {
  DIRECT_SHEAR_ENTERED_TOLERANCE,
  directShearCalcInput,
  directShearModule,
  fitMohrCoulombEnvelope,
  type DirectShearInput,
  type DirectShearRaw,
  type DirectShearResults,
} from "../src/lib/calc/modules/direct-shear";
import { parseLabTestResult } from "../src/lib/lab-tests/registry";

let pass = 0;
let fail = 0;
const ok = (m: string) => { console.log(`PASS: ${m}`); pass++; };
const no = (m: string) => { console.log(`FAIL: ${m}`); fail++; };

const approx = (actual: number, expected: number, tol: number): boolean =>
  Math.abs(actual - expected) <= tol;

type Outcome = CalculationOutcome<DirectShearInput, DirectShearRaw, DirectShearResults>;

interface ExpectedError {
  code: string;
  fieldPath?: string;
  messageHint?: string;
}

function expectError(outcome: Outcome, label: string, expected: ExpectedError): void {
  if (outcome.status !== "error") {
    no(`${label} — expected ${expected.code}, got success`);
    return;
  }
  const { code, message, details } = outcome.error;
  if (code !== expected.code) {
    no(`${label} — expected ${expected.code}, got ${code}`);
    return;
  }
  if (expected.fieldPath !== undefined && details?.fieldPath !== expected.fieldPath) {
    no(`${label} — expected fieldPath ${expected.fieldPath}, got ${String(details?.fieldPath)}`);
    return;
  }
  if (expected.messageHint !== undefined && !message.includes(expected.messageHint)) {
    no(`${label} — message '${message}' lacks hint '${expected.messageHint}'`);
    return;
  }
  ok(`${label} — ${code}${expected.fieldPath ? ` @ ${expected.fieldPath}` : ""}`);
}

// ---------------------------------------------------------------------------
// Fixtures (independently verified in scripts/m5.2-f-verify-goldens-direct-shear.py)
// ---------------------------------------------------------------------------

/** DS_STAGES_PROGRAM seed — peak τ follows τ ≈ 20 + σ·tan 25°. */
const DS_PROGRAM = [
  { normalStressKpa: 50, peakShearStressKpa: 43 },
  { normalStressKpa: 100, peakShearStressKpa: 67 },
  { normalStressKpa: 150, peakShearStressKpa: 90, residualShearStressKpa: 66 },
];

/** Full residual program (residual on every stage). */
const DS_RESIDUAL = [
  { normalStressKpa: 50, peakShearStressKpa: 43, residualShearStressKpa: 33 },
  { normalStressKpa: 100, peakShearStressKpa: 67, residualShearStressKpa: 48 },
  { normalStressKpa: 150, peakShearStressKpa: 90, residualShearStressKpa: 66 },
];

// ---------------------------------------------------------------------------
// 1. Golden envelopes
// ---------------------------------------------------------------------------
{
  // D1 — the seed program: c = 19.67 kPa, φ = 25.17°; single residual value
  // → residual envelope null + INSUFFICIENT_DATA; entered (20, 25) within
  // ±1.0 → no comparison warnings.
  const outcome = runCalculation(directShearModule, {
    stages: DS_PROGRAM, cohesionKpa: 20, frictionAngleDeg: 25,
  });
  if (outcome.status !== "ok") no(`golden D1 — failed: ${outcome.error.message}`);
  else {
    const insuff = outcome.warnings.filter((w) => w.code === "INSUFFICIENT_DATA");
    const checks: Array<[boolean, string]> = [
      [outcome.raw.peakEnvelope !== null, "peak envelope computed"],
      [approx(outcome.raw.peakEnvelope?.slopeTanPhi ?? 0, 0.47, 1e-12), "raw slope (tan φ) = 0.47 exactly"],
      [approx(outcome.raw.peakEnvelope?.cohesionKpa ?? 0, 19.66666666666667, 1e-12), "raw c ≈ 19.66666666666667 kPa"],
      [approx(outcome.raw.peakEnvelope?.frictionAngleDeg ?? 0, 25.173524524530166, 1e-12), "raw φ ≈ 25.173524524530166°"],
      [approx(outcome.raw.peakEnvelope?.rSquared ?? 0, 0.9998491249245625, 1e-12), "raw R² ≈ 0.9998491249245625"],
      [outcome.results.peakCohesionKpa === 19.67, "results c = 19.67 (2 dp)"],
      [outcome.results.peakFrictionAngleDeg === 25.17, "results φ = 25.17 (2 dp)"],
      [outcome.results.peakRSquared === 0.9998, "results R² = 0.9998 (4 dp)"],
      [outcome.results.peakPointCount === 3, "peak fit over 3 stages"],
      [outcome.raw.residualEnvelope === null && outcome.results.residualCohesionKpa === null, "residual envelope null (1 residual value)"],
      [insuff.length === 1 && insuff[0].message.includes("residual"), "one INSUFFICIENT_DATA warning (residual needs ≥ 2 stages)"],
      [outcome.warnings.length === 1, "exactly 1 warning (entered 20/25 within ±1.0 → no comparison warning)"],
      [outcome.results.enteredCohesionKpa === 20 && outcome.results.enteredFrictionAngleDeg === 25, "entered finals echoed"],
      [outcome.results.drainageCondition === null, "drainageCondition null when absent"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`golden D1 — ${label}`);
      else no(`golden D1 — ${label}`);
    }
  }
}
{
  // D2 — exact linear program: c = 10, tan φ = 0.5, R² = 1.
  const outcome = runCalculation(directShearModule, {
    stages: [
      { normalStressKpa: 50, peakShearStressKpa: 35 },
      { normalStressKpa: 100, peakShearStressKpa: 60 },
      { normalStressKpa: 200, peakShearStressKpa: 110 },
    ],
    drainageCondition: "DRAINED",
  });
  if (outcome.status !== "ok") no(`golden D2 — failed: ${outcome.error.message}`);
  else {
    const checks: Array<[boolean, string]> = [
      [approx(outcome.raw.peakEnvelope?.cohesionKpa ?? 0, 9.999999999999993, 1e-12), "raw c ≈ 9.999999999999993 (representation noise kept)"],
      [outcome.results.peakCohesionKpa === 10, "results c = 10 (2 dp)"],
      [approx(outcome.raw.peakEnvelope?.frictionAngleDeg ?? 0, 26.56505117707799, 1e-12), "raw φ ≈ 26.56505117707799°"],
      [outcome.results.peakFrictionAngleDeg === 26.57, "results φ = 26.57"],
      [outcome.results.peakRSquared === 1, "results R² = 1 (exact linear fit)"],
      [outcome.results.drainageCondition === "DRAINED", "drainageCondition echoed (DRAINED) — documentation only, numbers unchanged"],
      [outcome.warnings.length === 0, "no warnings (peak-only program, no entered values)"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`golden D2 — ${label}`);
      else no(`golden D2 — ${label}`);
    }
  }
}
{
  // D3 — residual envelope on all three stages: c_res = 16, φ_res = 18.26°;
  // peak and residual kept separate.
  const outcome = runCalculation(directShearModule, { stages: DS_RESIDUAL });
  if (outcome.status !== "ok") no(`golden D3 — failed: ${outcome.error.message}`);
  else {
    const checks: Array<[boolean, string]> = [
      [approx(outcome.raw.peakEnvelope?.cohesionKpa ?? 0, 19.66666666666667, 1e-12), "peak c ≈ 19.67 (same stages as D1)"],
      [outcome.raw.residualEnvelope !== null, "residual envelope computed"],
      [approx(outcome.raw.residualEnvelope?.cohesionKpa ?? 0, 16, 1e-12), "residual c = 16 exactly"],
      [approx(outcome.raw.residualEnvelope?.frictionAngleDeg ?? 0, 18.26288994219413, 1e-12), "residual φ ≈ 18.26288994219413°"],
      [outcome.results.residualCohesionKpa === 16, "results residual c = 16"],
      [outcome.results.residualFrictionAngleDeg === 18.26, "results residual φ = 18.26"],
      [outcome.results.residualRSquared === 0.9973, "results residual R² = 0.9973"],
      [outcome.results.residualPointCount === 3, "residual fit over 3 stages"],
      [outcome.results.peakCohesionKpa === 19.67 && outcome.results.residualCohesionKpa === 16, "peak and residual results separate"],
      [outcome.warnings.length === 0, "no warnings"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`golden D3 — ${label}`);
      else no(`golden D3 — ${label}`);
    }
  }
}
{
  // D4 — curved strength envelope: fitted c = −40 (negative) — reported
  // as-is with a PHYSICAL_CONSISTENCY warning, never clamped.
  const outcome = runCalculation(directShearModule, {
    stages: [
      { normalStressKpa: 100, peakShearStressKpa: 20 },
      { normalStressKpa: 200, peakShearStressKpa: 60 },
      { normalStressKpa: 300, peakShearStressKpa: 130 },
    ],
  });
  if (outcome.status !== "ok") no(`golden D4 — failed: ${outcome.error.message}`);
  else {
    const phys = outcome.warnings.filter((w) => w.code === "PHYSICAL_CONSISTENCY");
    const checks: Array<[boolean, string]> = [
      [approx(outcome.raw.peakEnvelope?.cohesionKpa ?? 0, -40.000000000000014, 1e-12), "raw c ≈ −40.000000000000014"],
      [outcome.results.peakCohesionKpa === -40, "results c = −40 (2 dp) — NEGATIVE, reported as-is"],
      [approx(outcome.raw.peakEnvelope?.frictionAngleDeg ?? 0, 28.81079374297307, 1e-12), "raw φ ≈ 28.81079374297307°"],
      [outcome.results.peakFrictionAngleDeg === 28.81, "results φ = 28.81"],
      [phys.length === 1, "one PHYSICAL_CONSISTENCY warning (negative parameter)"],
      [phys[0].message.includes("negative"), "warning names the negative parameter"],
      [outcome.warnings.length === 1, "exactly 1 warning"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`golden D4 — ${label}`);
      else no(`golden D4 — ${label}`);
    }
  }
}
{
  // D5 — two-stage program: exact two-point fit (R² = 1 by construction).
  const outcome = runCalculation(directShearModule, {
    stages: [
      { normalStressKpa: 50, peakShearStressKpa: 30 },
      { normalStressKpa: 150, peakShearStressKpa: 80 },
    ],
  });
  if (outcome.status !== "ok") no(`golden D5 — failed: ${outcome.error.message}`);
  else {
    const checks: Array<[boolean, string]> = [
      [outcome.results.peakCohesionKpa === 5, "results c = 5"],
      [outcome.results.peakFrictionAngleDeg === 26.57, "results φ = 26.57"],
      [outcome.results.peakRSquared === 1, "R² = 1 (two-point fit)"],
      [outcome.results.peakPointCount === 2, "2 points used"],
      [outcome.warnings.length === 0, "no warnings"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`golden D5 — ${label}`);
      else no(`golden D5 — ${label}`);
    }
  }
}
{
  // Entered-tolerance boundary on the EXACT two-point fit (D5: c = 5
  // exactly in doubles): entered 6.0 → |Δ| = 1.0 EXACTLY → no warning
  // (strict >); entered 6.01 → |Δ| = 1.01 → warning.
  const twoPoint = [
    { normalStressKpa: 50, peakShearStressKpa: 30 },
    { normalStressKpa: 150, peakShearStressKpa: 80 },
  ];
  const boundary = runCalculation(directShearModule, { stages: twoPoint, cohesionKpa: 6 });
  if (boundary.status === "ok" && !boundary.warnings.some((w) => w.details?.field === "cohesionKpa")) {
    ok("entered tolerance — c 6.0 (|Δ| = 1.0 exactly): no warning (strict >)");
  } else {
    no("entered tolerance — c 6.0 should not warn (boundary)");
  }
  const over = runCalculation(directShearModule, { stages: twoPoint, cohesionKpa: 6.01 });
  if (over.status === "ok" && over.warnings.some((w) => w.details?.field === "cohesionKpa" && w.code === "ENTERED_VALUE_DISCREPANCY")) {
    ok("entered tolerance — c 6.01 (|Δ| = 1.01 > 1.0): warning");
  } else {
    no("entered tolerance — c 6.01 should warn");
  }
}
{
  // Entered φ discrepancy: computed 25.17 vs entered 30 → |Δ| = 4.83 > 1.
  const outcome = runCalculation(directShearModule, { stages: DS_PROGRAM, frictionAngleDeg: 30 });
  if (outcome.status === "ok" && outcome.warnings.some((w) => w.details?.field === "frictionAngleDeg" && w.code === "ENTERED_VALUE_DISCREPANCY")) {
    ok("entered φ 30 vs computed 25.17 — ENTERED_VALUE_DISCREPANCY warning");
  } else {
    no("entered φ discrepancy warning missing");
  }
}

// ---------------------------------------------------------------------------
// 2. Insufficient data — no fabricated envelopes
// ---------------------------------------------------------------------------
{
  // Legacy single-stage record: one point cannot define an envelope.
  const outcome = runCalculation(directShearModule, {
    normalStressKpa: 100, peakShearStressKpa: 68, residualShearStressKpa: 45,
  });
  if (outcome.status !== "ok") no(`single-stage — failed: ${outcome.error.message}`);
  else {
    const insuff = outcome.warnings.filter((w) => w.code === "INSUFFICIENT_DATA");
    const checks: Array<[boolean, string]> = [
      [outcome.results.peakCohesionKpa === null && outcome.results.peakFrictionAngleDeg === null, "c/φ null (one point cannot define an envelope)"],
      [outcome.raw.peakEnvelope === null, "raw peak envelope null"],
      [outcome.results.singleStage !== null && outcome.results.singleStage.normalStressKpa === 100, "single-stage record echoed (100, 68, 45)"],
      [insuff.length === 1, "one INSUFFICIENT_DATA warning (never invents a second point)"],
      [outcome.results.stages.length === 0, "stages array empty for the scalar record"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`single-stage — ${label}`);
      else no(`single-stage — ${label}`);
    }
  }
}

// ---------------------------------------------------------------------------
// 3. Validation — registry mirrors and contract bounds
// ---------------------------------------------------------------------------
{
  const outcome = runCalculation(directShearModule, {
    stages: DS_PROGRAM, normalStressKpa: 100, peakShearStressKpa: 68,
  });
  expectError(outcome, "stages + scalars both supplied (either-or rule)", {
    code: "INVALID_INPUT",
    fieldPath: "stages",
    messageHint: "not both",
  });
}
{
  const outcome = runCalculation(directShearModule, {});
  expectError(outcome, "neither stages nor scalars", { code: "MISSING_INPUT", messageHint: "stages" });
}
{
  const outcome = runCalculation(directShearModule, {
    stages: [
      { normalStressKpa: 100, peakShearStressKpa: 68 },
      { normalStressKpa: 100, peakShearStressKpa: 70 },
    ],
  });
  expectError(outcome, "duplicate normalStressKpa (registry mirror)", {
    code: "INVALID_INPUT",
    fieldPath: "stages",
    messageHint: "unique",
  });
}
{
  const outcome = runCalculation(directShearModule, {
    stages: [
      { normalStressKpa: 100, peakShearStressKpa: 68, residualShearStressKpa: 75 },
      { normalStressKpa: 200, peakShearStressKpa: 118 },
    ],
  });
  expectError(outcome, "residual > peak per stage (registry mirror)", {
    code: "INVALID_INPUT",
    fieldPath: "stages.0.residualShearStressKpa",
    messageHint: "cannot exceed",
  });
}
{
  const outcome = runCalculation(directShearModule, {
    normalStressKpa: 100, peakShearStressKpa: 68, residualShearStressKpa: 80,
  });
  expectError(outcome, "legacy residual > peak (registry mirror)", {
    code: "INVALID_INPUT",
    fieldPath: "residualShearStressKpa",
    messageHint: "cannot exceed",
  });
}
{
  const outcome = runCalculation(directShearModule, {
    stages: [
      { normalStressKpa: 2001, peakShearStressKpa: 68 },
      { normalStressKpa: 2002, peakShearStressKpa: 70 },
    ],
  });
  expectError(outcome, "normalStressKpa 2001 out of bounds", { code: "INVALID_INPUT", messageHint: "2000" });
}
{
  const outcome = runCalculation(directShearModule, {
    stages: DS_PROGRAM, frictionAngleDeg: 46,
  });
  expectError(outcome, "entered frictionAngleDeg 46 out of bounds", { code: "INVALID_INPUT", messageHint: "45" });
}
{
  const outcome = runCalculation(directShearModule, {
    stages: Array.from({ length: 9 }, (_, i) => ({ normalStressKpa: 50 + i * 50, peakShearStressKpa: 40 + i * 30 })),
  });
  expectError(outcome, "9 stages (max 8)", { code: "INVALID_INPUT" });
}
{
  const outcome = runCalculation(directShearModule, {
    stages: [{ normalStressKpa: 100, peakShearStressKpa: 68 }],
  });
  expectError(outcome, "1 stage (min 2)", { code: "INVALID_INPUT" });
}
{
  const outcome = runCalculation(directShearModule, {
    stages: [
      { normalStressKpa: 100, peakShearStressKpa: Number.NaN },
      { normalStressKpa: 200, peakShearStressKpa: 118 },
    ],
  });
  expectError(outcome, "NaN shear stress", { code: "INVALID_INPUT" });
}
{
  const outcome = runCalculation(directShearModule, {
    stages: [
      { normalStressKpa: "100", peakShearStressKpa: 68 },
      { normalStressKpa: 200, peakShearStressKpa: 118 },
    ] as unknown as DirectShearInput["stages"],
  });
  expectError(outcome, "string normal stress", { code: "INVALID_INPUT" });
}
{
  const outcome = runCalculation(directShearModule, {
    stages: DS_PROGRAM, drainageCondition: "PARTIAL",
  } as unknown as { drainageCondition: string });
  expectError(outcome, "unknown drainage condition", { code: "INVALID_INPUT" });
}

// ---------------------------------------------------------------------------
// 4. Direct helper tests
// ---------------------------------------------------------------------------
{
  const env = fitMohrCoulombEnvelope([{ normalStressKpa: 50, shearStressKpa: 30 }, { normalStressKpa: 150, shearStressKpa: 80 }]);
  if (approx(env.cohesionKpa, 5, 1e-12) && approx(env.frictionAngleDeg, 26.56505117707799, 1e-12) && env.rSquared === 1) {
    ok("helper — two-point envelope (c 5, φ 26.565°, R² 1)");
  } else {
    no(`helper — two-point envelope wrong: ${JSON.stringify(env)}`);
  }
  try {
    fitMohrCoulombEnvelope([{ normalStressKpa: 100, shearStressKpa: 50 }, { normalStressKpa: 100, shearStressKpa: 60 }]);
    no("helper — single distinct σn no throw");
  } catch {
    ok("helper — single distinct σn throws (regression undefined)");
  }
}

// ---------------------------------------------------------------------------
// 5. Schema stripping
// ---------------------------------------------------------------------------
{
  const parsed = directShearCalcInput.safeParse({
    stages: DS_PROGRAM, specimenDiameterMm: 63.5, rateMmMin: 0.5, notes: "extra",
  });
  if (parsed.success && !("specimenDiameterMm" in parsed.data) && !("rateMmMin" in parsed.data) && !("notes" in parsed.data)) {
    ok("schema — registry input fields (specimenDiameterMm, rateMmMin, notes) stripped");
  } else {
    no("schema — stripping failed");
  }
}

// ---------------------------------------------------------------------------
// 6. M5.1 registry compatibility — parity and documented divergences
// ---------------------------------------------------------------------------
{
  // Shared valid: the seed program + entered finals passes both.
  const payload = {
    stages: DS_PROGRAM, cohesionKpa: 20, frictionAngleDeg: 25,
  };
  const moduleOutcome = runCalculation(directShearModule, payload);
  const registryOutcome = parseLabTestResult("DIRECT_SHEAR", payload);
  const checks: Array<[boolean, string]> = [
    [moduleOutcome.status === "ok", "shared valid — module accepts the registry-shaped payload"],
    [registryOutcome.ok, "shared valid — registry result schema accepts it"],
  ];
  if (moduleOutcome.status === "ok") {
    const computedPayload = {
      stages: DS_PROGRAM,
      cohesionKpa: moduleOutcome.results.peakCohesionKpa ?? 0,
      frictionAngleDeg: moduleOutcome.results.peakFrictionAngleDeg ?? 0,
    };
    const revalidated = parseLabTestResult("DIRECT_SHEAR", computedPayload);
    checks.push([revalidated.ok, `computed c′/φ′ (19.67/25.17) revalidate through the registry${revalidated.ok ? "" : `: ${revalidated.error}`}`]);
  }
  for (const [condition, label] of checks) {
    if (condition) ok(`parity — ${label}`);
    else no(`parity — ${label}`);
  }
}
{
  // Shared invalid (both reject): residual > peak; duplicate normals; bounds.
  const bad1 = {
    stages: [
      { normalStressKpa: 100, peakShearStressKpa: 68, residualShearStressKpa: 75 },
      { normalStressKpa: 200, peakShearStressKpa: 118 },
    ],
  };
  const bad2 = {
    stages: [
      { normalStressKpa: 100, peakShearStressKpa: 68 },
      { normalStressKpa: 100, peakShearStressKpa: 70 },
    ],
  };
  for (const [payload, label] of [[bad1, "residual > peak"], [bad2, "duplicate normals"]] as const) {
    const m = runCalculation(directShearModule, payload);
    const r = parseLabTestResult("DIRECT_SHEAR", payload);
    if (m.status === "error" && !r.ok) ok(`shared invalid — ${label}: both reject`);
    else no(`shared invalid — ${label}: module ${m.status}, registry ok=${r.ok}`);
  }
}
{
  // Documented divergence — single-stage legacy record: valid registry
  // STORAGE, but the module cannot fit an envelope from one point.
  const payload = { normalStressKpa: 100, peakShearStressKpa: 68 };
  const m = runCalculation(directShearModule, payload);
  const r = parseLabTestResult("DIRECT_SHEAR", payload);
  if (m.status === "ok" && m.results.peakCohesionKpa === null && r.ok) {
    ok("divergence — single-stage record: registry stores it; module echoes with null c/φ (no fabricated envelope)");
  } else {
    no(`divergence — single-stage: module ${m.status}, registry ok=${r.ok}`);
  }
}
{
  // Documented divergence — residual envelope: the registry result schema has
  // a single c′/φ′ pair (no residual storage); the module reports both.
  const m = runCalculation(directShearModule, { stages: DS_RESIDUAL });
  if (m.status === "ok" && m.results.residualCohesionKpa === 16 && m.results.peakCohesionKpa === 19.67) {
    ok("divergence — residual envelope (c 16, φ 18.26) is engine-side only; the registry stores a single c′/φ′ pair");
  } else {
    no("divergence — residual envelope missing");
  }
}
{
  // Documented divergence — negative fitted c: reported as-is; the registry
  // storage bound (cohesionKpa ≥ 0) rejects persisting it.
  const m = runCalculation(directShearModule, {
    stages: [
      { normalStressKpa: 100, peakShearStressKpa: 20 },
      { normalStressKpa: 200, peakShearStressKpa: 60 },
      { normalStressKpa: 300, peakShearStressKpa: 130 },
    ],
  });
  if (m.status === "ok") {
    const r = parseLabTestResult("DIRECT_SHEAR", {
      stages: m.results.stages.map((s) => ({ normalStressKpa: s.normalStressKpa, peakShearStressKpa: s.peakShearStressKpa })),
      cohesionKpa: m.results.peakCohesionKpa ?? 0,
      frictionAngleDeg: m.results.peakFrictionAngleDeg ?? 0,
    });
    if (m.results.peakCohesionKpa === -40 && !r.ok) {
      ok("divergence — negative fitted c (−40) reported unclamped; registry storage bound rejects it");
    } else {
      no(`divergence — negative c handling wrong (registry ok=${r.ok})`);
    }
  } else {
    no("divergence — negative-c run failed");
  }
}

// ---------------------------------------------------------------------------
// 7. Determinism, purity, envelope
// ---------------------------------------------------------------------------
{
  const payload = { stages: DS_PROGRAM, cohesionKpa: 20, frictionAngleDeg: 25 };
  const first = runCalculation(directShearModule, payload);
  let allEqual = true;
  for (let i = 0; i < 25; i++) {
    if (JSON.stringify(runCalculation(directShearModule, payload)) !== JSON.stringify(first)) allEqual = false;
  }
  if (allEqual) ok("determinism — 25 runs deeply identical (warning path)");
  else no("determinism — warning path outputs differ");
}
{
  const payload = { stages: DS_RESIDUAL };
  const first = runCalculation(directShearModule, payload);
  let allEqual = true;
  for (let i = 0; i < 25; i++) {
    if (JSON.stringify(runCalculation(directShearModule, payload)) !== JSON.stringify(first)) allEqual = false;
  }
  if (allEqual) ok("determinism — 25 runs deeply identical (residual path)");
  else no("determinism — residual path outputs differ");
}
{
  const payload = {
    stages: [
      { normalStressKpa: 50, peakShearStressKpa: 43 },
      { normalStressKpa: 100, peakShearStressKpa: 67 },
    ],
  };
  const snapshot = JSON.stringify(payload);
  runCalculation(directShearModule, payload);
  if (JSON.stringify(payload) === snapshot) ok("purity — input payload never mutated");
  else no("purity — input payload mutated");
}
{
  const outcome = runCalculation(directShearModule, { stages: DS_PROGRAM });
  if (outcome.status !== "ok") no(`envelope — failed: ${outcome.error.message}`);
  else {
    const checks: Array<[boolean, string]> = [
      [outcome.engineVersion === "1.0.0", "engineVersion = 1.0.0"],
      [outcome.moduleId === "direct-shear", "moduleId = direct-shear"],
      [outcome.moduleVersion === "1.0.0", "moduleVersion = 1.0.0"],
      [outcome.testType === "DIRECT_SHEAR", "testType = DIRECT_SHEAR"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`envelope — ${label}`);
      else no(`envelope — ${label}`);
    }
  }
}

console.log(`\n================ M5.2-f DIRECT SHEAR TEST SUMMARY: ${pass} passed, ${fail} failed ================`);
process.exit(fail);
