/**
 * M5.2-a TEST — Unit conversions and output-boundary rounding.
 *
 * Covers: exact integer factor tables (traceable to D8-verified governed
 * constants), mass/length conversions (both directions, identities), unknown
 * unit and non-finite rejection, and the full roundTo edge-case set
 * (half-away-from-zero, epsilon-corrected decimal ties, FP-noise masses,
 * safe-integer guard, invalid decimals).
 * Exit code = number of failures.
 */
import {
  LENGTH_UNITS,
  MASS_UNITS,
  convertLength,
  convertMass,
  roundTo,
  type LengthUnit,
  type MassUnit,
} from "../src/lib/calc/units";
import { requireVerifiedConstant } from "../src/lib/calc/constants/sources";

let pass = 0;
let fail = 0;
const ok = (m: string) => { console.log(`PASS: ${m}`); pass++; };
const no = (m: string) => { console.log(`FAIL: ${m}`); fail++; };

const approx = (actual: number, expected: number, tol: number): boolean =>
  Math.abs(actual - expected) <= tol;

function expectThrows(fn: () => unknown, label: string, code: string): void {
  try {
    fn();
    no(`${label} — did not throw`);
  } catch (error) {
    const e = error as { code?: string };
    if (e && e.code === code) ok(`${label} — throws ${code}`);
    else no(`${label} — wrong error code ${String(e && e.code)}`);
  }
}

// ---------------------------------------------------------------------------
// 1. Factor tables — exact integers, governed-constant traceability
// ---------------------------------------------------------------------------
{
  const t = MASS_UNITS;
  if (t.mg.factorToBase === 1 && t.g.factorToBase === 1000 && t.kg.factorToBase === 1000000) {
    ok("mass factors — mg=1, g=1000, kg=1000000 (exact integers)");
  } else no("mass factors — wrong values");
  const l = LENGTH_UNITS;
  if (l.mm.factorToBase === 1 && l.cm.factorToBase === 10 && l.m.factorToBase === 1000) {
    ok("length factors — mm=1, cm=10, m=1000 (exact integers)");
  } else no("length factors — wrong values");
}
{
  const traceable =
    MASS_UNITS.g.factorToBase === requireVerifiedConstant("si.mass.milligramsPerGram") &&
    MASS_UNITS.kg.factorToBase ===
      requireVerifiedConstant("si.mass.milligramsPerGram") * requireVerifiedConstant("si.mass.gramsPerKilogram") &&
    LENGTH_UNITS.cm.factorToBase === requireVerifiedConstant("si.length.millimetresPerCentimetre") &&
    LENGTH_UNITS.m.factorToBase === requireVerifiedConstant("si.length.millimetresPerMetre");
  if (traceable) ok("governance — every factor equals its D8-verified governed constant");
  else no("governance — factor/constant mismatch");
}
{
  const sourcesOk =
    MASS_UNITS.g.source.includes("governed constant") &&
    LENGTH_UNITS.m.source.includes("governed constant") &&
    MASS_UNITS.mg.source.includes("base unit");
  if (sourcesOk) ok("unit definitions — provenance source notes present");
  else no("unit definitions — missing provenance notes");
}

// ---------------------------------------------------------------------------
// 2. Mass conversions (goldens: exact decimal arithmetic, see m5.2-verify-goldens.py)
// ---------------------------------------------------------------------------
{
  const cases: Array<[number, MassUnit, MassUnit, number, string]> = [
    [112, "g", "kg", 0.112, "112 g → 0.112 kg"],
    [1500, "mg", "g", 1.5, "1500 mg → 1.5 g"],
    [2500, "mg", "kg", 0.0025, "2500 mg → 0.0025 kg"],
    [2.5, "kg", "g", 2500, "2.5 kg → 2500 g"],
    [1.5, "g", "mg", 1500, "1.5 g → 1500 mg"],
    [123.456, "g", "g", 123.456, "identity: g → g"],
    [7, "kg", "kg", 7, "identity: kg → kg"],
  ];
  for (const [value, from, to, expected, label] of cases) {
    const got = convertMass(value, from, to);
    if (got === expected) ok(`convertMass ${label} (exact)`);
    else if (approx(got, expected, 1e-12)) ok(`convertMass ${label} (within 1e-12)`);
    else no(`convertMass ${label} — got ${got}, expected ${expected}`);
  }
  // 0.112 kg → g is 112 with FP representation noise: assert against the exact
  // arithmetic expression, tolerance-checked (docs/14 §9 R4).
  const roundTrip = convertMass(0.112, "kg", "g");
  if (approx(roundTrip, 112, 1e-9)) ok("convertMass 0.112 kg → 112 g (within 1e-9)");
  else no(`convertMass 0.112 kg → g — got ${roundTrip}`);
}

// ---------------------------------------------------------------------------
// 3. Length conversions
// ---------------------------------------------------------------------------
{
  const cases: Array<[number, LengthUnit, LengthUnit, number, string]> = [
    [2500, "mm", "m", 2.5, "2500 mm → 2.5 m"],
    [3.5, "m", "mm", 3500, "3.5 m → 3500 mm"],
    [12, "cm", "mm", 120, "12 cm → 120 mm"],
    [1, "m", "cm", 100, "1 m → 100 cm"],
    [0.5, "cm", "m", 0.005, "0.5 cm → 0.005 m"],
    [9.99, "mm", "mm", 9.99, "identity: mm → mm"],
  ];
  for (const [value, from, to, expected, label] of cases) {
    const got = convertLength(value, from, to);
    if (got === expected) ok(`convertLength ${label} (exact)`);
    else if (approx(got, expected, 1e-12)) ok(`convertLength ${label} (within 1e-12)`);
    else no(`convertLength ${label} — got ${got}, expected ${expected}`);
  }
}

// ---------------------------------------------------------------------------
// 4. Conversion error handling
// ---------------------------------------------------------------------------
expectThrows(() => convertMass(Number.NaN, "g", "kg"), "convertMass NaN value", "UNIT_CONVERSION_ERROR");
expectThrows(() => convertMass(Number.POSITIVE_INFINITY, "g", "kg"), "convertMass +Infinity value", "UNIT_CONVERSION_ERROR");
expectThrows(() => convertMass(1, "stone" as MassUnit, "g"), "convertMass unknown 'from' unit", "UNIT_CONVERSION_ERROR");
expectThrows(() => convertMass(1, "g", "lb" as MassUnit), "convertMass unknown 'to' unit", "UNIT_CONVERSION_ERROR");
expectThrows(() => convertLength(Number.NaN, "m", "mm"), "convertLength NaN value", "UNIT_CONVERSION_ERROR");
expectThrows(() => convertLength(1, "ft" as LengthUnit, "m"), "convertLength unknown unit", "UNIT_CONVERSION_ERROR");

// ---------------------------------------------------------------------------
// 5. roundTo — full edge-case set (verified independently before writing)
// ---------------------------------------------------------------------------
{
  const cases: Array<[number, number, number, string]> = [
    [18.439716312056749, 2, 18.44, "golden A w% 2 dp"],
    [2.675, 2, 2.68, "decimal tie 2.675 (binary sits below .5)"],
    [-2.675, 2, -2.68, "negative tie −2.675 (half away from zero)"],
    [1.005, 2, 1.01, "decimal tie 1.005"],
    [0.145, 2, 0.15, "decimal tie 0.145"],
    [0.125, 2, 0.13, "exact binary tie 0.125"],
    [12.5, 0, 13, "half away from zero at 0 dp (12.5 → 13)"],
    [-12.5, 0, -13, "half away from zero at 0 dp (−12.5 → −13)"],
    [0.5, 0, 1, "0.5 → 1"],
    [-0.5, 0, -1, "−0.5 → −1"],
    [10.400000000000006, 3, 10.4, "FP-noise water mass at 3 dp"],
    [56.39999999999999, 3, 56.4, "FP-noise dry soil mass at 3 dp"],
    [-0.060283687943262, 2, -0.06, "golden A discrepancy 2 dp"],
    [-0.006630211893368, 2, -0.01, "golden C discrepancy 2 dp"],
    [18.504901960784306, 2, 18.5, "golden B w% 2 dp"],
    [300.1, 2, 300.1, "value already at target precision"],
    [11.893369788106632, 2, 11.89, "golden C w% 2 dp"],
    [0.0001, 2, 0, "below resolution → 0"],
    [-0.0001, 2, 0, "below resolution → 0 (−0 normalized)"],
    [1234.5678, 3, 1234.568, "3 dp general case"],
  ];
  for (const [value, decimals, expected, label] of cases) {
    const got = roundTo(value, decimals);
    if (got === expected) ok(`roundTo ${label}`);
    else no(`roundTo ${label} — got ${got}, expected ${expected}`);
  }
  // A value genuinely below the tie must NOT be corrected upward.
  if (roundTo(2.6749999, 2) === 2.67) ok("roundTo 2.6749999 → 2.67 (epsilon does not overcorrect)");
  else no(`roundTo overcorrected 2.6749999 → ${roundTo(2.6749999, 2)}`);
  // Negative zero normalization.
  const zero = roundTo(-0.0001, 2);
  if (zero === 0 && Math.sign(zero) === 0) ok("roundTo −0 normalized to +0");
  else no("roundTo −0 not normalized");
}
expectThrows(() => roundTo(Number.NaN, 2), "roundTo NaN value", "ARITHMETIC_DOMAIN_ERROR");
expectThrows(() => roundTo(Number.NEGATIVE_INFINITY, 2), "roundTo −Infinity value", "ARITHMETIC_DOMAIN_ERROR");
expectThrows(() => roundTo(1.5, -1), "roundTo decimals = −1", "ARITHMETIC_DOMAIN_ERROR");
expectThrows(() => roundTo(1.5, 1.5), "roundTo non-integer decimals", "ARITHMETIC_DOMAIN_ERROR");
expectThrows(() => roundTo(1.5, 13), "roundTo decimals = 13 (max 12)", "ARITHMETIC_DOMAIN_ERROR");
expectThrows(() => roundTo(1e14, 2), "roundTo exceeds safe integer range", "ARITHMETIC_DOMAIN_ERROR");

console.log(`\n================ M5.2-a UNITS TEST SUMMARY: ${pass} passed, ${fail} failed ================`);
process.exit(fail);
