import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();
async function main() {
  const t = await db.labTest.findFirstOrThrow({
    where: { testType: "DIRECT_SHEAR", summary: { contains: "Multi-stage" } },
    select: { id: true, sample: { select: { code: true, borehole: { select: { project: { select: { code: true } } } } } } },
  });
  console.log(`/lab-tests/${t.id} (${t.sample.borehole.project.code}/${t.sample.code})`);
  await db.$disconnect();
}
main();
