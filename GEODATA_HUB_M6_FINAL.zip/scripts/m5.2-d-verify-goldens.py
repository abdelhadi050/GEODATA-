#!/usr/bin/env python3
"""M5.2-d golden-value independent verification (Proctor: MDD / OMC / ZAV).

Run BEFORE writing the test expectations. Every expected value below is
computed independently of the TypeScript engine:

- high-precision Decimal (60 digits) for the true compaction-parabola values,
- IEEE-754 double probes mirroring the exact JS operation order designed for
  the module (sequential sums; orthogonalized centered basis
  u = w - mean(w), phi2 = u^2 - Suu/n; 2x2 Cramer solve; one-step vertex),
- half-away-from-zero rounding predictions for the output boundary, with a
  tie-distance guard (no golden value may sit on a .5 tie).

Designed module arithmetic (M5.2-d, ASTM D698 / ASTM D1557 / NF P94-093):

  Water content (from masses, M5.1 F2 semantics):
      w  = 100 * (wet - dry) / (dry - tare)
  Wet density (mold bookkeeping):  rho_wet = wetMassG / moldVolumeCm3   [g/cm3 = Mg/m3]
  Dry density (definitional):      rho_d   = rho_wet / (1 + w/100)
  Compaction parabola (CREST WINDOW: the 3 consecutive points containing the
  measured peak; ALL points when the window carries < 3 distinct w):
      basis u = w - wmean, phi2 = u^2 - Suu/n  (constant term = ymean exact)
      [Suu Suuu; Suuu Suuuu - Suu^2/n] [B; C] = [Suy; SuuyRaw - (Suu/n)*Sy]
      c2 = C;  c1 = B - 2*C*wmean;  c0 = ymean - B*wmean + C*(wmean^2 - Suu/n)
      OMC = -c1 / (2*c2);   MDD = c0 - c1^2 / (4*c2)      (vertex, c2 < 0)
      (reported only when c2 < 0 and minW < OMC < maxW - no fabrication)
  Zero air voids (100 % saturation):  rho_zav = Gs * rho_w / (1 + w*Gs/100)
      with rho_w = 1 Mg/m3 (governed VERIFIED constant).
  Entered-comparison tolerances: densities +/-0.01 Mg/m3 (registry proctor
  tolerance), moisture +/-1.0 pp (registry proctor tolerance), per-point
  water content +/-0.5 (registry WC identity) - project tolerances.
"""
from decimal import Decimal as D, getcontext
import math

getcontext().prec = 60


# --- exact-double mirror helpers (JS op order designed for the module) ------

def js_w_from_masses(wet, dry, tare):
    """Mirror of phase-relations waterContentPercent(waterMass, drySoilMass)."""
    mw = wet - dry                       # waterMassFromTareMasses
    ms = dry - tare                      # drySoilMassFromTareMasses
    return (100.0 * mw) / ms             # waterContentPercent


def js_fit_parabola(pts):
    """Mirror of the designed fitCompactionParabola() double op order
    (orthogonalized centered basis, 2x2 Cramer solve)."""
    n = len(pts)
    sx = 0.0
    sy = 0.0
    for x, y in pts:
        sx += x
        sy += y
    x_mean = sx / n
    y_mean = sy / n
    suu = suuu = suuuu = suy = suuy_raw = 0.0
    for x, y in pts:
        u = x - x_mean
        suu += u * u
        suuu += u * u * u
        suuuu += u * u * u * u
        suy += u * y
        suuy_raw += u * u * y
    m22 = suuuu - (suu * suu) / n
    det = suu * m22 - suuu * suuu
    rhs2 = suuy_raw - (suu / n) * sy
    B = (suy * m22 - suuu * rhs2) / det
    C = (suu * rhs2 - suuu * suy) / det
    c2 = C
    c1 = B - 2 * C * x_mean
    c0 = y_mean - B * x_mean + C * (x_mean * x_mean - suu / n)
    return {"c0": c0, "c1": c1, "c2": c2, "B": B, "C": C, "det": det}


def js_window(pts):
    """Mirror of the designed crest-window selection."""
    n = len(pts)
    peak = 0
    for i in range(1, n):
        if pts[i][1] > pts[peak][1]:
            peak = i
    lo = 0 if peak == 0 else peak - 1
    hi = n - 1 if peak == n - 1 else peak + 1
    distinct = len({p[0] for p in pts[lo:hi + 1]})
    if distinct < 3 and n > hi - lo + 1:
        lo, hi = 0, n - 1
    return pts[lo:hi + 1], lo, hi


def js_vertex(c0, c1, c2):
    """Mirror of the designed vertex computation."""
    omc = -c1 / (2 * c2)
    mdd = c0 - (c1 * c1) / (4 * c2)
    return omc, mdd


def js_dry_from_wet(rho_wet, w):
    return rho_wet / (1 + w / 100.0)


def js_zav(gs, w):
    return (gs * 1.0) / (1 + (w * gs) / 100.0)


def round_to_double(x, dp):
    """Mirror of units.ts roundTo: half away from zero, epsilon-corrected."""
    scaled = x * 10 ** dp
    if abs(scaled) > 2 ** 53:
        raise ValueError("out of safe range")
    corrected_abs = abs(scaled) * (1 + 2.220446049250313e-16)
    rounded = math.floor(corrected_abs + 0.5)  # round half away from zero
    signed = -rounded if scaled < 0 else rounded
    result = signed / 10 ** dp
    return 0.0 if result == 0 else result


# --- Decimal truth helpers ---------------------------------------------------

def dec_fit_parabola(pts):
    n = len(pts)
    sx = sum((D(str(x)) for x, _ in pts), D(0))
    sy = sum((D(str(y)) for _, y in pts), D(0))
    x_mean = sx / n
    y_mean = sy / n
    suu = suuu = suuuu = D(0)
    suy = suuy_raw = D(0)
    for x, y in pts:
        u = D(str(x)) - x_mean
        suu += u * u
        suuu += u * u * u
        suuuu += u * u * u * u
        suy += u * D(str(y))
        suuy_raw += u * u * D(str(y))
    m22 = suuuu - (suu * suu) / n
    det = suu * m22 - suuu * suuu
    rhs2 = suuy_raw - (suu / n) * sy
    B = (suy * m22 - suuu * rhs2) / det
    C = (suu * rhs2 - suuu * suy) / det
    c2 = C
    c1 = B - 2 * C * x_mean
    c0 = y_mean - B * x_mean + C * (x_mean * x_mean - suu / n)
    return c0, c1, c2


def tie_guard(x, dp, label):
    scaled = abs(x) * 10 ** dp
    dist = abs(scaled - math.floor(scaled) - 0.5)
    if dist < 1e-9:
        print(f"  !! TIE WARNING {label}: {x} at {dp} dp (scaled {scaled})")


def show(label, value, dp):
    tie_guard(value, dp, label)
    print(f"  {label:<48} = {value!r:<26} -> {dp} dp: {round_to_double(value, dp)}")
    return round_to_double(value, dp)


def analyze(label, pts, entered_mdd=None, entered_omc=None, gs=None):
    print("=" * 100)
    print(f"FIXTURE {label}")
    print("=" * 100)
    win, lo, hi = js_window(pts)
    print(f"  points: {pts}")
    print(f"  crest window indices [{lo}, {hi}]: {win}")
    fit = js_fit_parabola(win)
    d0, d1, d2 = dec_fit_parabola(win)
    print(f"  Decimal truth: c0 = {d0}\n  c1 = {d1}\n  c2 = {d2}")
    show("c0", fit["c0"], 6)
    show("c1", fit["c1"], 6)
    show("c2", fit["c2"], 6)
    if fit["c2"] < 0:
        omc, mdd = js_vertex(fit["c0"], fit["c1"], fit["c2"])
        domc = -d1 / (2 * d2)
        dmdd = d0 - (d1 * d1) / (4 * d2)
        print(f"  Decimal vertex: OMC = {domc}, MDD = {dmdd}")
        show("OMC", omc, 2)
        show("MDD", mdd, 3)
        wmin = min(p[0] for p in pts)
        wmax = max(p[0] for p in pts)
        print(f"  vertex strictly inside [{wmin}, {wmax}]: {wmin < omc < wmax}")
        if entered_mdd is not None:
            print(f"  |MDD - {entered_mdd}| = {abs(mdd - entered_mdd)} (tol 0.01 -> warn? {abs(mdd - entered_mdd) > 0.01})")
        if entered_omc is not None:
            print(f"  |OMC - {entered_omc}| = {abs(omc - entered_omc)} (tol 1.0 -> warn? {abs(omc - entered_omc) > 1.0})")
        if gs is not None:
            show("ZAV(OMC)", js_zav(gs, omc), 3)
            print(f"  MDD > ZAV(OMC)? {mdd > js_zav(gs, omc)}")
    else:
        print(f"  c2 >= 0 -> no maximum -> MDD/OMC null + INSUFFICIENT_DATA warning")
    if gs is not None:
        print(f"  ZAV curve (Gs = {gs}):")
        for w, rho in pts:
            zav = js_zav(gs, w)
            show(f"  ZAV({w}%)", zav, 3)
            print(f"      point rho_d={rho} exceeded={rho > zav}")
    print()
    return fit


# ---------------------------------------------------------------------------
# P1 - PROCTOR_STD (registry seed shape; dryDensity per point; Gs = 2.80)
# ---------------------------------------------------------------------------
fit1 = analyze(
    "P1 - PROCTOR_STD + Gs 2.80 (clean: no ZAV exceedance)",
    [(8, 1.72), (10, 1.86), (12, 1.94), (14, 1.97), (16, 1.92), (18, 1.84)],
    entered_mdd=1.97, entered_omc=13.5, gs=2.80,
)
print(f"  registry mirror: peak measured = 1.97; entered maxDryDensity 1.97 >= 1.96 OK; 1.97 <= 2.17 OK")
print(f"  entered optimumMoisture 13.5 within [8-1, 18+1] OK")

# P1b - same curve, Gs = 2.71: points at w=14,16,18 exceed ZAV (warnings)
analyze("P1b - PROCTOR_STD + Gs 2.71 (3 ZAV-exceeded points -> PHYSICAL_CONSISTENCY x3)",
        [(8, 1.72), (10, 1.86), (12, 1.94), (14, 1.97), (16, 1.92), (18, 1.84)],
        gs=2.71)

# ---------------------------------------------------------------------------
# P2 - PROCTOR_MOD (wetDensity per point; rho_d = rho/(1+w/100))
# ---------------------------------------------------------------------------
print("=" * 100)
print("FIXTURE P2 - PROCTOR_MOD (wetDensity per point; rho_d derived)")
print("=" * 100)
P2 = [(6, 2.014, 1.9), (8, 2.182, 2.02), (10, 2.299, 2.09), (12, 2.352, 2.1), (14, 2.337, 2.05), (16, 2.274, 1.96)]
derived = []
for w, rwet, rdry in P2:
    rd = js_dry_from_wet(rwet, w)
    show(f"rho_d(w={w}%) from rho_wet={rwet}", rd, 3)
    print(f"    vs entered dryDensity {rdry}: |delta| = {abs(rd - rdry)} (tol 0.01 -> warn? {abs(rd - rdry) > 0.01})")
    derived.append((w, rd))
win2, lo2, hi2 = js_window(derived)
print(f"  crest window indices [{lo2}, {hi2}]: {win2}")
fit2 = js_fit_parabola(win2)
e0, e1, e2 = dec_fit_parabola(win2)
print(f"  Decimal truth: c0 = {e0}\n  c1 = {e1}\n  c2 = {e2}")
show("c0", fit2["c0"], 6)
show("c1", fit2["c1"], 6)
show("c2", fit2["c2"], 6)
omc2, mdd2 = js_vertex(fit2["c0"], fit2["c1"], fit2["c2"])
show("OMC", omc2, 2)
show("MDD", mdd2, 3)
print(f"  vertex strictly inside [6, 16]: {6 < omc2 < 16}")
print(f"  peak derived rho_d = {max(rd for _, rd in derived)}")
print(f"  |MDD - 2.1| = {abs(mdd2 - 2.1)} (tol 0.01 -> warn? {abs(mdd2 - 2.1) > 0.01})")
print(f"  |OMC - 11.5| = {abs(omc2 - 11.5)} (tol 1.0 -> warn? {abs(omc2 - 11.5) > 1.0})")
print(f"  registry mirror: entered MDD 2.1 >= peak - 0.01 = {max(rd for _, rd in derived) - 0.01}? {2.1 >= max(rd for _, rd in derived) - 0.01}")
print(f"                   entered MDD 2.1 <= peak + 0.2 = {max(rd for _, rd in derived) + 0.2}? {2.1 <= max(rd for _, rd in derived) + 0.2}")
print()

# ---------------------------------------------------------------------------
# P3 - mass-based points (mold bookkeeping + oven-dry w) - PEAKED fixture
# ---------------------------------------------------------------------------
print("=" * 100)
print("FIXTURE P3 - mass-based points (mold 944 cm3, tare included)")
print("=" * 100)
VOL = 944.0
TARE = 45.0
# Target points (w, rho_d): (10, 1.86), (13, 1.94), (16, 1.91), (19, 1.84)
# masses: m_s = rho_d * VOL (dry soil); net wet = m_s * (1 + w/100)
P3 = []
for (w, rd) in [(10.0, 1.86), (13.0, 1.94), (16.0, 1.91), (19.0, 1.84)]:
    ms = rd * VOL
    netwet = ms * (1 + w / 100.0)
    P3.append((w, netwet, ms))
    rw = netwet / VOL
    rd_js = js_dry_from_wet(rw, w)
    print(f"  w={w}% target rho_d={rd}: wetMassG={netwet!r} (dryMassG={ms!r})")
    show(f"    rho_wet = wetMassG/V", rw, 3)
    show(f"    rho_d", rd_js, 3)
P3pts = [(w, js_dry_from_wet(nw / VOL, w)) for (w, nw, _) in P3]
print(f"  derived points: {[(w, repr(rd)) for w, rd in P3pts]}")
win3, lo3, hi3 = js_window(P3pts)
print(f"  crest window indices [{lo3}, {hi3}]: {win3}")
fit3 = js_fit_parabola(win3)
f0, f1, f2 = dec_fit_parabola(win3)
print(f"  Decimal truth: c0 = {f0}\nc1 = {f1}\nc2 = {f2}")
show("c0", fit3["c0"], 6)
show("c1", fit3["c1"], 6)
show("c2", fit3["c2"], 6)
omc3, mdd3 = js_vertex(fit3["c0"], fit3["c1"], fit3["c2"])
show("OMC", omc3, 2)
show("MDD", mdd3, 3)
print(f"  vertex strictly inside [10, 19]: {10 < omc3 < 19}")
print()

# ---------------------------------------------------------------------------
# P4 - rising-only curve (vertex outside range -> MDD/OMC null)
# ---------------------------------------------------------------------------
fit4 = analyze("P4 - rising-only curve (peak NOT bracketed -> MDD/OMC null)",
               [(8, 1.60), (10, 1.72), (12, 1.80), (14, 1.86)])

# ---------------------------------------------------------------------------
# P5 - convex window (c2 >= 0 -> null + INSUFFICIENT_DATA)
# ---------------------------------------------------------------------------
analyze("P5 - convex crest (c2 >= 0, no maximum -> null + INSUFFICIENT_DATA)",
        [(10, 1.90), (13, 1.84), (16, 1.82), (19, 1.86)])

# ---------------------------------------------------------------------------
# P7 - replicate-at-peak window fallback (window has 2 distinct w -> ALL points)
# ---------------------------------------------------------------------------
analyze("P7 - replicates at the peak moisture (window fallback to all points)",
        [(10, 1.86), (13, 1.94), (13, 1.93), (16, 1.90), (19, 1.83)])

# ---------------------------------------------------------------------------
# Validation-case numbers
# ---------------------------------------------------------------------------
print("=" * 100)
print("VALIDATION-CASE NUMBERS")
print("=" * 100)
print(f"  P1 peak measured rho_d = 1.97; entered maxDryDensity 1.95 -> 1.95 < 1.96 -> REJECT")
print(f"  P1 moisture range [8, 18]; entered optimumMoisture 19.5 -> 19.5 > 19 -> REJECT; 19.0 -> boundary ACCEPT")
print(f"  distinct w = 2 (replicates at 2 moistures) -> ARITHMETIC_DOMAIN_ERROR")
print(f"  distinct w = 1 -> ARITHMETIC_DOMAIN_ERROR")
print(f"  out-of-order points (w decreasing) -> INVALID_INPUT (ordering rule)")
print(f"  partial mass triple (wetMassG only) -> INVALID_INPUT")
print(f"  wetMassG without moldVolumeCm3 and without wetDensityMgM3 -> INVALID_INPUT")
rwet, w, rdry = 2.20, 10.0, 2.05
rd = js_dry_from_wet(rwet, w)
print(f"  per-point identity: rho_wet={rwet}, w={w}% -> rho_d={rd!r} vs entered {rdry}: |delta|={abs(rd - rdry)} -> warn? {abs(rd - rdry) > 0.01}")
wet, dry, tare = 1013.0, 910.0, 100.0
w_js = js_w_from_masses(wet, dry, tare)
print(f"  w identity: masses (1013, 910, 100) -> w = {w_js!r} vs entered 15.0: |delta| = {abs(w_js - 15.0)} -> warn? {abs(w_js - 15.0) > 0.5}")

print()
print("=" * 100)
print("RAW DOUBLE PROBES (assert at 1e-9 in the test suite)")
print("=" * 100)
print(f"  P1 window c0={fit1['c0']!r} c1={fit1['c1']!r} c2={fit1['c2']!r}")
if fit1["c2"] < 0:
    omc1, mdd1 = js_vertex(fit1["c0"], fit1["c1"], fit1["c2"])
    print(f"  P1 OMC={omc1!r} MDD={mdd1!r}")
print(f"  P2 derived rho_d doubles: {[repr(rd) for _, rd in derived]}")
print(f"  P2 window c0={fit2['c0']!r} c1={fit2['c1']!r} c2={fit2['c2']!r}")
print(f"  P2 OMC={omc2!r} MDD={mdd2!r}")
print(f"  P3 derived rho_d doubles: {[repr(rd) for _, rd in P3pts]}")
print(f"  P3 window c0={fit3['c0']!r} c1={fit3['c1']!r} c2={fit3['c2']!r}")
print(f"  P3 OMC={omc3!r} MDD={mdd3!r}")
print()
print("ALL GOLDENS VERIFIED - values above are the independent expectations for")
print("scripts/m5.2-test-proctor.ts")
