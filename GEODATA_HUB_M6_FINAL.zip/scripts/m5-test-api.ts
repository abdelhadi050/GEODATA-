/**
 * M5.1 TEST — API integration: input persistence (POST/PATCH /api/lab-tests),
 * inputData on detail, the input editability rule, the opt-in include=resultData
 * query parameter, PRESSUREMETER end-to-end, registry endpoint with 13 types,
 * RBAC, tenant isolation, strict-body behavior and envelope shapes.
 *
 * Runs against a LIVE dev server (BASE, default http://127.0.0.1:3000) with
 * the freshly seeded demo database. Exit code = number of failures. Direct
 * Prisma access is used ONLY for test setup/teardown.
 */
import { PrismaClient } from "@prisma/client";

const BASE = process.env.BASE ?? "http://127.0.0.1:3000";
const PASSWORD = "Demo1234!";
const db = new PrismaClient();

let pass = 0;
let fail = 0;
const ok = (m: string) => { console.log(`PASS: ${m}`); pass++; };
const no = (m: string) => { console.log(`FAIL: ${m}`); fail++; };

// ---------- HTTP / session helpers (M3 pattern) ----------

function cookieFrom(setCookies: string[], name: string): string | null {
  for (const c of setCookies) {
    const [pair] = c.split(";");
    const eq = pair.indexOf("=");
    if (pair.slice(0, eq) === name) return pair.slice(eq + 1);
  }
  return null;
}

async function login(email: string, password = PASSWORD): Promise<string | null> {
  try {
    const r1 = await fetch(`${BASE}/api/auth/csrf`);
    const { csrfToken } = (await r1.json()) as { csrfToken: string };
    const csrfCookie = cookieFrom(r1.headers.getSetCookie(), "next-auth.csrf-token");
    if (!csrfCookie) return null;
    const r2 = await fetch(`${BASE}/api/auth/callback/credentials`, {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        Cookie: `next-auth.csrf-token=${csrfCookie}`,
      },
      body: new URLSearchParams({
        csrfToken,
        email,
        password,
        callbackUrl: `${BASE}/`,
        json: "true",
      }),
      redirect: "manual",
    });
    const session = cookieFrom(r2.headers.getSetCookie(), "next-auth.session-token");
    return session ? `next-auth.session-token=${session}` : null;
  } catch {
    return null;
  }
}

interface ApiResult {
  status: number;
  body: any;
  text: string;
}

const envelopeViolations: string[] = [];
const leakScans: string[] = [];
const LEAK_PATTERNS = [
  "storage/uploads",
  "passwordHash",
  "prisma://",
  "PrismaClientKnownRequestError",
  "/home/z/",
  "NEXTAUTH_SECRET",
];

async function api(
  cookie: string | null,
  method: string,
  path: string,
  opts: { json?: unknown; origin?: string } = {},
): Promise<ApiResult> {
  const headers: Record<string, string> = {};
  if (cookie) headers.Cookie = cookie;
  if (opts.json !== undefined) headers["Content-Type"] = "application/json";
  if (opts.origin) headers.Origin = opts.origin;
  const body = opts.json !== undefined ? JSON.stringify(opts.json) : undefined;
  const res = await fetch(BASE + path, { method, headers, body, redirect: "manual" });
  const text = await res.text();
  let parsed: any = null;
  try { parsed = JSON.parse(text); } catch { /* empty */ }
  if (parsed && typeof parsed === "object") {
    if (parsed.success === false) {
      const e = parsed.error;
      if (!e || typeof e.code !== "string" || typeof e.message !== "string") {
        envelopeViolations.push(`${method} ${path} → malformed error envelope`);
      }
    }
    for (const pat of LEAK_PATTERNS) {
      if (text.includes(pat)) leakScans.push(`${method} ${path} → contains "${pat}"`);
    }
  }
  return { status: res.status, body: parsed, text };
}

function expectStatus(r: ApiResult, status: number, label: string) {
  if (r.status === status) ok(`${label} (HTTP ${status})`);
  else no(`${label} — expected HTTP ${status}, got ${r.status}: ${r.text.slice(0, 160)}`);
}

function expectError(r: ApiResult, status: number, code: string, label: string) {
  if (r.status === status && r.body?.error?.code === code) ok(`${label} (HTTP ${status} ${code})`);
  else no(`${label} — expected ${status}/${code}, got ${r.status}: ${r.text.slice(0, 160)}`);
}

// ---------- fixtures ----------

const WC_INPUT = { containerId: "TIN-API-1", ovenTemperatureC: 110, notes: "M5.1 API fixture" };
const WC_INPUT_ALT = { containerId: "TIN-API-2", ovenTemperatureC: 105 };
const PMT_INPUT = { probeType: "Ménard NB (74 mm)", testDepthM: 6.0, boreholeDiameterMm: 76, groundwaterPresent: true };
const PMT_RESULT = {
  points: [
    { pressureKpa: 0, volumeCm3: 42 },
    { pressureKpa: 50, volumeCm3: 52 },
    { pressureKpa: 100, volumeCm3: 64 },
    { pressureKpa: 200, volumeCm3: 92 },
    { pressureKpa: 400, volumeCm3: 160 },
    { pressureKpa: 600, volumeCm3: 255 },
  ],
  creepPressureKpa: 400,
  limitPressureKpa: 900,
  menardModulusMPa: 11.2,
  emPlRatio: 12.44,
};

async function main() {
  const managerCookie = await login("manager@geodata.demo");
  const engineerCookie = await login("engineer@geodata.demo");
  const viewerCookie = await login("viewer@geodata.demo");
  const rockAdminCookie = await login("admin@rockworks.demo");
  if (!managerCookie || !engineerCookie || !viewerCookie || !rockAdminCookie) {
    console.log("LOGIN FAILED — is the dev server running with seeded data?");
    process.exit(1);
  }
  ok("all four role sessions established");

  // Host sample: TRAM CS-02 / SPT-02 (seeded with only an SPT test).
  const hostSample = await db.sample.findFirstOrThrow({
    where: { code: "SPT-02", borehole: { code: "CS-02", project: { code: "TRAM-CNS-2025" } } },
  });
  // Idempotency: clear leftover API fixtures.
  await db.labTest.deleteMany({
    where: { sampleId: hostSample.id, testType: { in: ["WATER_CONTENT", "PRESSUREMETER"] } },
  });
  const a1 = await db.project.findFirstOrThrow({ where: { code: "A1-TEN-2025" } });
  const rockOrg = await db.organization.findUniqueOrThrow({ where: { slug: "rockworks" } });
  await db.sharingRequest.updateMany({
    where: { projectId: a1.id, targetOrganizationId: rockOrg.id },
    data: { status: "APPROVED" },
  });

  console.log("=== A. POST /api/lab-tests with input ===");
  const rCreate = await api(managerCookie, "POST", "/api/lab-tests", {
    json: { sampleId: hostSample.id, testType: "WATER_CONTENT", input: WC_INPUT },
  });
  expectStatus(rCreate, 201, "create with input → 201");
  const created = rCreate.body?.data;
  if (created?.inputData?.containerId === "TIN-API-1") ok("created test echoes validated inputData");
  else no(`create inputData wrong: ${JSON.stringify(created?.inputData)}`);

  expectError(
    await api(managerCookie, "POST", "/api/lab-tests", {
      // UCS does not exist on the host sample (avoids the duplicate 409 firing
      // before input validation); the input is schema-invalid (height missing).
      json: { sampleId: hostSample.id, testType: "UCS", input: { specimenDiameterMm: 54 } },
    }),
    400, "VALIDATION_ERROR", "create with invalid input → 400 VALIDATION_ERROR",
  );
  expectError(
    await api(managerCookie, "POST", "/api/lab-tests", {
      json: { sampleId: hostSample.id, testType: "PRESSUREMETER", input: PMT_INPUT, sneakyKey: true },
    }),
    400, "VALIDATION_ERROR", "strict body still rejects unknown keys → 400",
  );

  console.log("=== B. GET detail returns inputData (A3) ===");
  const rDetail = await api(viewerCookie, "GET", `/api/lab-tests/${created.id}`);
  expectStatus(rDetail, 200, "detail readable by viewer");
  if (rDetail.body?.data?.inputData?.containerId === "TIN-API-1" && rDetail.body?.data?.resultData === null) {
    ok("detail includes inputData; resultData null before a result");
  } else no(`detail shape wrong: ${rDetail.text.slice(0, 160)}`);

  console.log("=== C. Editability rule through the API (D2) ===");
  const rPatchInput = await api(managerCookie, "PATCH", `/api/lab-tests/${created.id}`, {
    json: { input: WC_INPUT_ALT },
  });
  expectStatus(rPatchInput, 200, "PATCH input while pending → 200");
  if (rPatchInput.body?.data?.inputData?.containerId === "TIN-API-2") ok("input edit stored");
  else no("input edit not stored");

  const rResult = await api(engineerCookie, "PUT", `/api/lab-tests/${created.id}/result`, {
    json: { result: { waterContentPercent: 20.4 }, summary: "w = 20.4%" },
  });
  expectStatus(rResult, 200, "record result → 200");
  expectError(
    await api(managerCookie, "PATCH", `/api/lab-tests/${created.id}`, { json: { input: WC_INPUT } }),
    409, "CONFLICT", "PATCH input with a result present → 409 CONFLICT (locked)",
  );
  const rReopenWithInput = await api(managerCookie, "PATCH", `/api/lab-tests/${created.id}`, {
    json: { status: "IN_PROGRESS", input: WC_INPUT },
  });
  expectStatus(rReopenWithInput, 200, "single PATCH reopen + input → 200");
  if (
    rReopenWithInput.body?.data?.status === "IN_PROGRESS" &&
    rReopenWithInput.body?.data?.resultData === null &&
    rReopenWithInput.body?.data?.inputData?.containerId === "TIN-API-1"
  ) {
    ok("reopen cleared result and stored the new input in one request");
  } else no(`reopen+input wrong: ${rReopenWithInput.text.slice(0, 160)}`);
  expectError(
    await api(managerCookie, "PATCH", `/api/lab-tests/${created.id}`, { json: { input: { containerId: 7 } } }),
    400, "VALIDATION_ERROR", "PATCH invalid input → 400",
  );

  console.log("=== D. Opt-in include=resultData on GET /api/lab-tests (D3) ===");
  const rListDefault = await api(managerCookie, "GET", `/api/lab-tests?sampleId=${hostSample.id}&pageSize=50`);
  expectStatus(rListDefault, 200, "list default → 200");
  const itemsDefault = rListDefault.body?.data ?? [];
  const firstDefault = itemsDefault[0];
  if ("resultData" in firstDefault && !("inputData" in firstDefault)) {
    ok("default list: resultData present (unchanged), inputData NOT exposed");
  } else no(`default list shape wrong: keys=${Object.keys(firstDefault).join(",")}`);
  const rListInclude = await api(managerCookie, "GET", `/api/lab-tests?sampleId=${hostSample.id}&include=resultData`);
  expectStatus(rListInclude, 200, "include=resultData accepted → 200");
  const itemsInclude = rListInclude.body?.data ?? [];
  if (
    itemsInclude.length === itemsDefault.length &&
    "resultData" in itemsInclude[0] && !("inputData" in itemsInclude[0])
  ) {
    ok("include=resultData: identical payload shape to default (documented no-op)");
  } else no("include=resultData changed the payload");
  expectError(
    await api(managerCookie, "GET", "/api/lab-tests?include=secretData"),
    400, "VALIDATION_ERROR", "unknown include value → 400 (strict query)",
  );

  console.log("=== E. PRESSUREMETER end-to-end (new test type) ===");
  const rPmtCreate = await api(managerCookie, "POST", "/api/lab-tests", {
    json: { sampleId: hostSample.id, testType: "PRESSUREMETER", input: PMT_INPUT },
  });
  expectStatus(rPmtCreate, 201, "create PRESSUREMETER with input → 201");
  const pmt = rPmtCreate.body?.data;
  expectError(
    await api(engineerCookie, "PUT", `/api/lab-tests/${pmt.id}/result`, {
      json: { result: { ...PMT_RESULT, emPlRatio: 99 } },
    }),
    400, "VALIDATION_ERROR", "invalid PRESSUREMETER result → 400",
  );
  const rPmtResult = await api(engineerCookie, "PUT", `/api/lab-tests/${pmt.id}/result`, {
    json: { result: PMT_RESULT, summary: "EM 11.2 MPa" },
  });
  expectStatus(rPmtResult, 200, "PRESSUREMETER result recorded → 200");
  const rPmtDetail = await api(managerCookie, "GET", `/api/lab-tests/${pmt.id}`);
  if (
    rPmtDetail.body?.data?.status === "COMPLETED" &&
    rPmtDetail.body?.data?.inputData?.probeType === "Ménard NB (74 mm)" &&
    rPmtDetail.body?.data?.registry?.label === "Pressuremeter (Ménard)" &&
    rPmtDetail.body?.data?.registry?.chart?.kind === "pressuremeterCurve"
  ) {
    ok("PMT detail: input + result + registry metadata + chart contract");
  } else no(`PMT detail wrong: ${rPmtDetail.text.slice(0, 200)}`);

  console.log("=== F. Registry endpoint: 13 types ===");
  const rReg = await api(viewerCookie, "GET", "/api/lab-tests/registry");
  expectStatus(rReg, 200, "GET registry → 200");
  const reg = rReg.body?.data;
  if (Array.isArray(reg) && reg.length === 13) {
    ok("registry lists 13 test types (12 + PRESSUREMETER)");
  } else no(`registry count wrong: ${reg?.length}`);
  const pmtEntry = reg?.find((t: any) => t.code === "PRESSUREMETER");
  if (
    pmtEntry?.standard?.includes("NF P94-110-1") &&
    pmtEntry?.chart?.kind === "pressuremeterCurve" &&
    Array.isArray(pmtEntry?.validationNotes)
  ) {
    ok("PRESSUREMETER registry entry complete (standard, chart, notes)");
  } else no(`PRESSUREMETER registry entry wrong: ${JSON.stringify(pmtEntry)?.slice(0, 160)}`);
  const cptEntry = reg?.find((t: any) => t.code === "CPT");
  if (cptEntry?.standard?.includes("NF P94-113") && !cptEntry?.standard?.includes("NF P94-119")) {
    ok("CPT standard citation corrected (NF P94-113 / NF EN ISO 22476-1)");
  } else no(`CPT standard wrong: ${cptEntry?.standard}`);

  console.log("=== G. RBAC ===");
  expectError(
    await api(viewerCookie, "POST", "/api/lab-tests", {
      json: { sampleId: hostSample.id, testType: "WATER_CONTENT", input: WC_INPUT },
    }),
    403, "FORBIDDEN", "viewer cannot create with input → 403",
  );
  expectError(
    await api(viewerCookie, "PATCH", `/api/lab-tests/${created.id}`, { json: { input: WC_INPUT } }),
    403, "FORBIDDEN", "viewer cannot edit inputs → 403",
  );

  console.log("=== H. Tenant isolation (shared project read-only) ===");
  const a1All = await db.labTest.findMany({
    where: { sample: { borehole: { project: { code: "A1-TEN-2025" } } } },
    select: { id: true, inputData: true },
  });
  const sharedTest = a1All.find((t) => t.inputData !== null);
  if (!sharedTest) throw new Error("fixture missing: no A1 test with inputData");
  const rSharedRead = await api(rockAdminCookie, "GET", `/api/lab-tests/${sharedTest.id}`);
  expectStatus(rSharedRead, 200, "shared-project test readable by partner org");
  if (rSharedRead.body?.data?.accessSource === "shared" && rSharedRead.body?.data?.inputData !== null) {
    ok("shared read exposes inputData (read-only share)");
  } else no("shared read shape wrong");
  expectError(
    await api(rockAdminCookie, "PATCH", `/api/lab-tests/${sharedTest.id}`, { json: { input: WC_INPUT } }),
    404, "NOT_FOUND", "partner org cannot edit inputs on shared test → 404",
  );
  expectError(
    await api(rockAdminCookie, "PATCH", `/api/lab-tests/${created.id}`, { json: { status: "IN_PROGRESS" } }),
    404, "NOT_FOUND", "partner org cannot modify a non-shared test → 404",
  );

  console.log("=== I. CSRF guard on the new input surface ===");
  expectError(
    await api(managerCookie, "PATCH", `/api/lab-tests/${created.id}`, {
      json: { input: WC_INPUT },
      origin: "https://evil.example.com",
    }),
    403, "CROSS_ORIGIN_REJECTED", "cross-origin PATCH with input → 403 (CSRF)",
  );

  console.log("=== J. Cleanup + cross-suite invariants ===");
  const rDel1 = await api(managerCookie, "DELETE", `/api/lab-tests/${created.id}`);
  const rDel2 = await api(managerCookie, "DELETE", `/api/lab-tests/${pmt.id}`);
  expectStatus(rDel1, 200, "cleanup: delete WATER_CONTENT fixture");
  expectStatus(rDel2, 200, "cleanup: delete PRESSUREMETER fixture");

  if (envelopeViolations.length === 0) ok("envelope shape valid on every error response");
  else no(`envelope violations: ${envelopeViolations.join("; ")}`);
  if (leakScans.length === 0) ok("leak scan clean (no paths/hashes/internals)");
  else no(`leaks: ${leakScans.join("; ")}`);

  console.log(`\n================ M5.1 API TEST SUMMARY: ${pass} passed, ${fail} failed ================`);
  process.exit(fail);
}

main()
  .catch((e) => {
    console.error("API TEST CRASHED:", e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
