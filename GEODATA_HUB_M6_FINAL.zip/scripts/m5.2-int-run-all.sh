#!/usr/bin/env bash
# M5.2 Integration full run protocol.
#
#   Part 1 — static checks + all 13 calculation-engine suites (M5.2-a..g)
#   Part 2 — fresh seed → integration SERVICE suite → fresh seed → integration
#            API suite (live dev server) → re-seed
#   Part 3 — the established M5.1 project regression protocol, phases 1 and 2
#            (unchanged — ends with a pristine re-seed + integrity check)
#   Part 4 — extended integrity check (pristine baseline + zero calculation
#            records + referential integrity of the new table)
#
# Each phase is one bash invocation (sandbox process-group rule).
set -u
cd /home/z/my-project

BASE=http://127.0.0.1:3000
PART="${1:-all}"
PASS=0; FAIL=0
step(){ echo ""; echo "###############################################"; echo "### $1"; echo "###############################################"; }

stop_dev(){ pkill -f "next dev" 2>/dev/null || true; sleep 1; }
start_dev(){
  nohup bun run dev < /dev/null > /tmp/m52-dev.out 2>&1 &
  DEV_PID=$!
  for i in $(seq 1 90); do
    curl -sf "$BASE/api/health" >/dev/null 2>&1 && break
    sleep 1
  done
  if curl -sf "$BASE/api/health" >/dev/null 2>&1; then echo "dev server up (pid $DEV_PID)"; else echo "DEV SERVER FAILED"; tail -40 /tmp/m52-dev.out; exit 1; fi
}

if [ "$PART" = "1" ] || [ "$PART" = "all" ]; then

step "1. Static checks"
bunx tsc --noEmit && { echo "tsc: PASS"; PASS=$((PASS+1)); } || { echo "tsc: FAIL"; FAIL=$((FAIL+1)); }
bun run lint && { echo "lint: PASS"; PASS=$((PASS+1)); } || { echo "lint: FAIL"; FAIL=$((FAIL+1)); }

step "2. Engine suites (M5.2-a..g, unchanged)"
ENGINE_RC=0
for suite in engine units formulas constants water-content granulometry atterberg-limits proctor cbr oedometer direct-shear pressuremeter; do
  bun "scripts/m5.2-test-${suite}.ts" > "/tmp/m52-engine-${suite}.txt" 2>&1
  RC=$?
  TAIL=$(tail -1 "/tmp/m52-engine-${suite}.txt")
  echo "  ${suite}: ${TAIL} (rc=${RC})"
  [ $RC -eq 0 ] && PASS=$((PASS+1)) || { FAIL=$((FAIL+1)); ENGINE_RC=1; }
done
[ $ENGINE_RC -eq 0 ] && echo "all engine suites green" || echo "ENGINE SUITE FAILURE"

echo ""
echo "============================================="
echo "M5.2-INTEGRATION PART 1 SUMMARY: $PASS steps passed, $FAIL failed"
echo "============================================="
exit $((FAIL > 0 ? 1 : 0))
fi

if [ "$PART" = "2" ] || [ "$PART" = "all" ]; then

stop_dev

step "3. Fresh seed → integration SERVICE suite"
bun run db:seed >/dev/null 2>&1 && echo "seed: done" && PASS=$((PASS+1)) || FAIL=$((FAIL+1))
bun scripts/m5.2-int-test-service.ts > /tmp/m52-int-service.txt 2>&1
SV_RC=$?
tail -1 /tmp/m52-int-service.txt
[ $SV_RC -eq 0 ] && PASS=$((PASS+1)) || FAIL=$((FAIL+1))

step "4. Fresh seed → integration API suite (live dev server)"
bun run db:seed >/dev/null 2>&1 && echo "seed: done" && PASS=$((PASS+1)) || FAIL=$((FAIL+1))
start_dev
bun scripts/m5.2-int-test-api.ts > /tmp/m52-int-api.txt 2>&1
API_RC=$?
tail -1 /tmp/m52-int-api.txt
grep -c "^FAIL" /tmp/m52-int-api.txt | sed 's/^/  FAIL lines: /'
[ $API_RC -eq 0 ] && PASS=$((PASS+1)) || FAIL=$((FAIL+1))
stop_dev

step "5. Re-seed after integration suites"
bun run db:seed >/dev/null 2>&1 && echo "re-seed: done" && PASS=$((PASS+1)) || FAIL=$((FAIL+1))

echo ""
echo "============================================="
echo "M5.2-INTEGRATION PARTS 1-2 SUMMARY: $PASS steps passed, $FAIL failed"
echo "============================================="
exit $((FAIL > 0 ? 1 : 0))
fi

if [ "$PART" = "3" ] || [ "$PART" = "all" ]; then

step "6. Established project regression — phase 1 (unchanged protocol)"
bash scripts/m5-run-all.sh 1
P1=$?
[ $P1 -eq 0 ] && PASS=$((PASS+1)) || FAIL=$((FAIL+1))

step "7. Established project regression — phase 2 (unchanged protocol)"
bash scripts/m5-run-all.sh 2
P2=$?
[ $P2 -eq 0 ] && PASS=$((PASS+1)) || FAIL=$((FAIL+1))

fi

if [ "$PART" = "4" ] || [ "$PART" = "all" ]; then

step "8. Extended integrity check (pristine baseline + new table)"
bun scripts/m5.2-int-check-db.ts && PASS=$((PASS+1)) || FAIL=$((FAIL+1))

echo ""
echo "============================================="
echo "M5.2-INTEGRATION FULL PROTOCOL SUMMARY: $PASS steps passed, $FAIL failed"
echo "============================================="
exit $((FAIL > 0 ? 1 : 0))
fi

echo "usage: bash scripts/m5.2-int-run-all.sh [1|2|3|4|all]"
exit 1
