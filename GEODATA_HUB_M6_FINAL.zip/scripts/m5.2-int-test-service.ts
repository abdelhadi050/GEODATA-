/**
 * M5.2 INTEGRATION TEST — Service layer.
 *
 * Covers the calculation service (persistence, idempotency, duplicate
 * suppression, dry runs, explicit inputs, invalidation, activity logging,
 * RBAC and tenant isolation) plus the engine registry and fingerprinting
 * primitives. Runs directly against the seeded demo database (no dev server
 * required). Exit code = number of failures. Direct Prisma access is used
 * ONLY for test setup/teardown and assertions.
 */
import { PrismaClient } from "@prisma/client";
import {
  CALC_MODULES,
  getCalcModuleById,
  getCalcModuleForTestType,
} from "../src/lib/calc/registry";
import {
  calculateLabTest,
  canonicalJson,
  fingerprintInput,
  getCalculation,
  getLatestValidCalculation,
  listLabTestCalculations,
  listProjectCalculations,
} from "../src/lib/services/calculations";
import { recordLabTestResult, updateLabTest } from "../src/lib/services/lab-tests";
import { AppError, Errors } from "../src/lib/errors";
const db = new PrismaClient();

let pass = 0;
let fail = 0;
const ok = (m: string) => { console.log(`PASS: ${m}`); pass++; };
const no = (m: string) => { console.log(`FAIL: ${m}`); fail++; };

type Actor = { id: string; email: string; name: string; role: string; isActive: boolean; organizationId: string };

async function actorByEmail(email: string): Promise<Actor> {
  const u = await db.user.findUniqueOrThrow({ where: { email } });
  return { id: u.id, email: u.email, name: u.name, role: u.role, isActive: u.isActive, organizationId: u.organizationId };
}

async function expectAppError(
  code: string,
  label: string,
  fn: () => Promise<unknown>,
  status?: number,
) {
  try {
    await fn();
    no(`${label} — expected ${code} but call SUCCEEDED`);
  } catch (e) {
    if (e instanceof AppError && e.code === code) {
      if (status !== undefined && e.status !== status) {
        no(`${label} — code ok but status ${e.status}, expected ${status}`);
      } else {
        ok(`${label} — ${code}${status !== undefined ? ` ${status}` : ""} as expected`);
      }
    } else if (e instanceof AppError) {
      no(`${label} — got ${e.code} (${e.message}), expected ${code}`);
    } else {
      no(`${label} — non-AppError thrown: ${(e as Error).message}`);
    }
  }
}

// fixture resolution ---------------------------------------------------------

interface Fixtures {
  wcFullId: string;        // WATER_CONTENT with complete masses (calculable)
  wcMasslessId: string;    // WATER_CONTENT entered percentage only (NOT calculable)
  sptId: string;           // SPT (no engine)
  proctorId: string;       // PROCTOR STANDARD (calculable)
  proctorProjectId: string; // project of the Proctor test
  a1ProjectId: string;     // GeoStruct project shared (APPROVED) with RockWorks
  a1LabTestId: string;     // any lab test inside the shared A1 project
  portProjectId: string;   // GeoStruct project shared PENDING with RockWorks
  nonSharedProjectId: string; // GeoStruct project with no share to RockWorks
  nonSharedLabTestId: string; // lab test in the PENDING-share project (NOT readable by RockWorks)
}

async function resolveFixtures(): Promise<Fixtures> {
  const wcTests = await db.labTest.findMany({
    where: { testType: "WATER_CONTENT" },
    include: { sample: { include: { borehole: { include: { project: true } } } } },
  });
  const calculable = wcTests.find(
    (t) => (t.resultData as Record<string, unknown> | null)?.wetMassG !== undefined,
  );
  const massless = wcTests.find(
    (t) =>
      (t.resultData as Record<string, unknown> | null)?.waterContentPercent !== undefined &&
      (t.resultData as Record<string, unknown> | null)?.wetMassG === undefined,
  );
  if (!calculable || !massless) throw new Error("seed fixtures not found (water content)");
  const spt = await db.labTest.findFirst({ where: { testType: "SPT" } });
  if (!spt) throw new Error("seed fixture not found (SPT)");
  const proctor = await db.labTest.findFirst({
    where: { testType: "PROCTOR" },
    include: { sample: { include: { borehole: { include: { project: true } } } } },
  });
  if (!proctor) throw new Error("seed fixture not found (Proctor)");
  const a1 = await db.project.findFirstOrThrow({ where: { code: "A1-TEN-2025" } });
  const port = await db.project.findFirstOrThrow({ where: { code: "PORT-ORN-TERM" } });
  const other = await db.project.findFirstOrThrow({
    where: { code: { notIn: ["A1-TEN-2025", "PORT-ORN-TERM"] } },
  });
  const a1Test = await db.labTest.findFirst({
    where: { sample: { borehole: { projectId: a1.id } } },
  });
  if (!a1Test) throw new Error("seed fixture not found (A1 lab test)");
  const portTest = await db.labTest.findFirst({
    where: {
      sample: { borehole: { projectId: port.id } },
      testType: {
        in: [
          "GRANULOMETRY",
          "ATTERBERG_LIMITS",
          "PROCTOR",
          "CBR",
          "OEDOMETER",
          "DIRECT_SHEAR",
          "PRESSUREMETER",
        ],
      },
    },
    orderBy: { createdAt: "asc" },
  });
  if (!portTest) throw new Error("seed fixture not found (PORT calculable lab test)");
  return {
    wcFullId: calculable.id,
    wcMasslessId: massless.id,
    sptId: spt.id,
    proctorId: proctor.id,
    proctorProjectId: proctor.sample.borehole.project.id,
    a1ProjectId: a1.id,
    a1LabTestId: a1Test.id,
    portProjectId: port.id,
    nonSharedProjectId: other.id,
    nonSharedLabTestId: portTest.id,
  };
}

// cleanup bookkeeping ---------------------------------------------------------

const touchedLabTestIds = new Set<string>();
const createdActivityIds: string[] = [];
const baselineActivityCount = await db.activityLog.count();

async function countCalcRecords(): Promise<number> {
  return db.calculationRecord.count();
}

async function activitySnapshot(): Promise<number> {
  return db.activityLog.count();
}

async function calcActivities() {
  return db.activityLog.findMany({
    where: { action: { startsWith: "CALCULATION_" } },
    orderBy: { createdAt: "asc" },
  });
}

// ----------------------------------------------------------------------------
async function main() {
  const geoEngineer = await actorByEmail("engineer@geodata.demo");
  const geoViewer = await actorByEmail("viewer@geodata.demo");
  const rockEngineer = await actorByEmail("engineer@rockworks.demo");
  const fx = await resolveFixtures();
  touchedLabTestIds.add(fx.wcFullId);
  touchedLabTestIds.add(fx.wcMasslessId);
  touchedLabTestIds.add(fx.proctorId);
  touchedLabTestIds.add(fx.nonSharedLabTestId);
  touchedLabTestIds.add(fx.sptId);

  // ===== A. Engine registry =====
  console.log("=== A. Engine registry ===");
  if (CALC_MODULES.length === 8) ok("registry exposes all 8 registered modules");
  else no(`registry has ${CALC_MODULES.length} modules, expected 8`);
  const ids = CALC_MODULES.map((m) => m.id);
  if (new Set(ids).size === ids.length) ok("module ids unique");
  else no("duplicate module ids");
  const types = CALC_MODULES.map((m) => m.testType);
  if (new Set(types).size === types.length) ok("module test types unique (1:1)");
  else no("duplicate module test types");
  if (getCalcModuleForTestType("PROCTOR")?.id === "proctor") ok("test type → module resolution");
  else no("test type → module resolution failed");
  if (getCalcModuleForTestType("SPT") === null && getCalcModuleById("nope") === null) {
    ok("unregistered test type / module id → null");
  } else no("unregistered lookups must return null");

  // ===== B. Fingerprinting =====
  console.log("=== B. Fingerprinting (canonical JSON) ===");
  if (canonicalJson({ a: 1, b: 2 }) === canonicalJson({ b: 2, a: 1 })) {
    ok("key order does not change the canonical form");
  } else no("key order changed canonical JSON");
  if (
    canonicalJson({ x: { z: 1, y: [1, 2] }, w: "s" }) ===
    canonicalJson({ w: "s", x: { y: [1, 2], z: 1 } })
  ) {
    ok("nested key order independence");
  } else no("nested key order changed canonical JSON");
  if (canonicalJson([1, 2]) !== canonicalJson([2, 1])) ok("array order is significant");
  else no("array order was normalized (must not be)");
  if (fingerprintInput({ a: 1 }) === fingerprintInput({ a: 1 })) ok("fingerprints stable");
  else no("fingerprint unstable for identical values");
  if (fingerprintInput({ a: 1 }) !== fingerprintInput({ a: 2 })) ok("fingerprints distinguish values");
  else no("fingerprint collision on different values");

  // ===== C. Successful calculation + persistence (water content) =====
  console.log("=== C. Successful calculation & persistence ===");
  const before = await countCalcRecords();
  const r1 = await calculateLabTest(geoEngineer, fx.wcFullId);
  if (r1.record?.status === "COMPLETED") ok("water-content calculation COMPLETED");
  else no(`expected COMPLETED, got ${r1.record?.status}`);
  if (r1.outcome && (r1.outcome as { status: string }).status === "ok") ok("engine outcome envelope ok");
  else no("engine outcome not ok");
  if (r1.record?.moduleId === "water-content" && r1.record.moduleVersion && r1.record.engineVersion) {
    ok(`provenance stored (module ${r1.record.moduleId} v${r1.record.moduleVersion}, engine ${r1.record.engineVersion})`);
  } else no("provenance incomplete");
  if (r1.record?.inputSource === "RESULT_DATA") ok("input source RESULT_DATA");
  else no(`input source ${r1.record?.inputSource}`);
  const snap = r1.record?.inputSnapshot as Record<string, unknown> | null;
  if (snap && snap.wetMassG === 235.5 && snap.waterContentPercent === 18.5) {
    ok("input snapshot is the module-parsed payload");
  } else no("input snapshot wrong");
  const out = r1.record?.output as { results?: Record<string, unknown> } | null;
  if (out?.results?.waterContentPercent === 18.5) ok("computed w = 18.5 % (golden 18.5049… → 2 dp)");
  else no(`computed waterContentPercent = ${out?.results?.waterContentPercent}`);
  if (out?.results?.waterMassG === 30.2 && out?.results?.drySoilMassG === 163.2) {
    ok("phase masses 30.2 g water / 163.2 g dry solids (goldens)");
  } else no("phase masses wrong");
  if (typeof r1.record?.inputFingerprint === "string" && /^[0-9a-f]{64}$/.test(r1.record.inputFingerprint)) {
    ok("input fingerprint is sha256 hex");
  } else no("input fingerprint malformed");
  if (r1.record?.standard && r1.record.units && typeof r1.record.units === "object") {
    ok("registry standard + units snapshot stored");
  } else no("standard/units snapshot missing");
  if (r1.record?.createdBy?.id === geoEngineer.id) ok("created-by attribution");
  else no("created-by wrong");
  if (r1.record?.method === null || r1.record?.method === undefined) {
    ok("water content has no method selection (null as designed)");
  } else no("water content unexpectedly reports a method");
  const after = await countCalcRecords();
  if (after === before + 1) ok("exactly one record persisted");
  else no(`expected ${before + 1} records, found ${after}`);

  // duplicate suppression (deterministic engine ⇒ identical input replays)
  const r2 = await calculateLabTest(geoEngineer, fx.wcFullId);
  if (r2.deduplicated === true && r2.record?.id === r1.record?.id) {
    ok("identical stored-data calculation deduplicated (same record replayed)");
  } else no("dedup failed");
  const r3 = await calculateLabTest(geoEngineer, fx.wcFullId, { idempotencyKey: "service-key-0001" });
  if (r3.deduplicated === true && r3.record?.id === r1.record?.id) {
    ok("dedup is key-independent for RESULT_DATA source");
  } else no("dedup should replay even with a fresh idempotency key");
  if ((await countCalcRecords()) === after) ok("no duplicate records created");
  else no("duplicate records leaked");

  // ===== D. Failed calculation persisted, never discarded =====
  console.log("=== D. Failed calculations ===");
  const rf = await calculateLabTest(geoEngineer, fx.wcMasslessId);
  if (rf.record?.status === "FAILED" && rf.record.errorCode === "MISSING_INPUT") {
    ok("massless record → FAILED/MISSING_INPUT persisted");
  } else no(`massless record → ${rf.record?.status}/${rf.record.errorCode}`);
  if (rf.record?.errorMessage && rf.record?.errorDetails) ok("failure message + details stored");
  else no("failure details missing");
  const fsnap = rf.record?.inputSnapshot as Record<string, unknown> | null;
  if (fsnap && fsnap.waterContentPercent === 22.4) ok("failure snapshot is the submitted payload");
  else no("failure snapshot wrong");
  const rfo = rf.outcome as { status: string; error?: { code: string } };
  if (rfo.status === "error" && rfo.error?.code === "MISSING_INPUT") ok("outcome envelope carries the engine failure");
  else no("outcome envelope missing failure");
  await expectAppError("NOT_FOUND", "latest valid → 404 when only FAILED records exist", () =>
    getLatestValidCalculation(geoEngineer, fx.wcMasslessId),
  );

  // ===== E. Dry runs =====
  console.log("=== E. Dry runs ===");
  const dryBefore = await countCalcRecords();
  const rd = await calculateLabTest(geoEngineer, fx.wcFullId, { dryRun: true });
  if (rd.dryRun === true && rd.record === null && (rd.outcome as { status: string }).status === "ok") {
    ok("dry run executes and persists nothing");
  } else no("dry run semantics wrong");
  if ((await countCalcRecords()) === dryBefore) ok("dry run left no record");
  else no("dry run persisted a record");
  const rdb = await calculateLabTest(geoEngineer, fx.wcMasslessId, { dryRun: true });
  if ((rdb.outcome as { status: string }).status === "error" && (await countCalcRecords()) === dryBefore) {
    ok("dry run on invalid input: failure returned, nothing persisted");
  } else no("dry run on invalid input misbehaved");

  // ===== F. Idempotency keys =====
  console.log("=== F. Idempotency keys ===");
  const exInput = {
    waterContentPercent: 20,
    wetMassG: 240,
    dryMassG: 208.3,
    containerMassG: 45,
  };
  const rk1 = await calculateLabTest(geoEngineer, fx.wcFullId, {
    input: exInput,
    idempotencyKey: "idem-aaaaaaaa",
  });
  if (rk1.record?.inputSource === "EXPLICIT" && rk1.record.status === "COMPLETED") {
    ok("explicit input → EXPLICIT source, COMPLETED");
  } else no("explicit input calculation failed");
  const rk2 = await calculateLabTest(geoEngineer, fx.wcFullId, {
    input: exInput,
    idempotencyKey: "idem-aaaaaaaa",
  });
  if (rk2.replayed === true && rk2.record?.id === rk1.record?.id) {
    ok("same idempotency key → original record replayed");
  } else no("idempotency replay failed");
  const rk3 = await calculateLabTest(geoEngineer, fx.wcFullId, {
    input: exInput,
    idempotencyKey: "idem-bbbbbbbb",
  });
  if (rk3.replayed === false && rk3.record?.id !== rk1.record?.id) {
    ok("explicit payloads are deliberate — a different key creates a fresh record");
  } else no("explicit inputs must never be deduplicated");
  // concurrent identical keys collapse onto one record
  const conc = await Promise.all(
    Array.from({ length: 4 }, () =>
      calculateLabTest(geoEngineer, fx.wcFullId, {
        input: exInput,
        idempotencyKey: "idem-concurrent",
      }).catch((e) => e),
    ),
  );
  const concRecords = await db.calculationRecord.findMany({
    where: { labTestId: fx.wcFullId, idempotencyKey: "idem-concurrent" },
  });
  if (concRecords.length === 1 && conc.every((r) => !(r instanceof Error))) {
    ok("4 concurrent same-key requests → exactly 1 record, no errors");
  } else no(`concurrency: ${concRecords.length} records, errors: ${conc.filter((r) => r instanceof Error).length}`);

  // ===== G. Explicit inputs: not invalidated, bad input persisted =====
  console.log("=== G. Explicit inputs ===");
  const badExplicit = await calculateLabTest(geoEngineer, fx.wcFullId, {
    input: { waterContentPercent: 5, wetMassG: -10, dryMassG: -20, containerMassG: 1 },
    idempotencyKey: "idem-badinput",
  });
  if (badExplicit.record?.status === "FAILED" && badExplicit.record.errorCode) {
    ok(`physically invalid explicit input → FAILED/${badExplicit.record.errorCode} persisted`);
  } else no("invalid explicit input not recorded as failure");

  // ===== H. Unsupported engine =====
  console.log("=== H. Unsupported engines ===");
  const sptBefore = await countCalcRecords();
  await expectAppError(
    "UNSUPPORTED_CALCULATION_ENGINE",
    "SPT test → 422 UNSUPPORTED_CALCULATION_ENGINE",
    () => calculateLabTest(geoEngineer, fx.sptId),
    422,
  );
  if ((await countCalcRecords()) === sptBefore) ok("no record created for unsupported engine");
  else no("unsupported engine created a record");

  // ===== I. RBAC + tenant isolation =====
  console.log("=== I. RBAC & tenant isolation ===");
  await expectAppError("FORBIDDEN", "VIEWER cannot run calculations", () =>
    calculateLabTest(geoViewer, fx.wcFullId),
  );
  const denial = await db.activityLog.findFirst({
    where: { action: "CALCULATION_ACCESS_DENIED", userId: geoViewer.id },
  });
  if (denial && denial.organizationId === geoViewer.organizationId) {
    ok("denial event logged with correct user + org attribution");
  } else no("CALCULATION_ACCESS_DENIED not logged");
  await expectAppError("NOT_FOUND", "cross-org calculate → NOT_FOUND (no existence leak)", () =>
    calculateLabTest(rockEngineer, fx.wcFullId),
  );
  // a record on a NON-shared GeoStruct project must be invisible to RockWorks
  const ns = await calculateLabTest(geoEngineer, fx.nonSharedLabTestId);
  if (ns.record?.status === "COMPLETED") ok("calculation created on the non-shared project");
  else no(`non-shared project calculation failed (${ns.record?.errorCode})`);
  await expectAppError("NOT_FOUND", "cross-org calculation detail (non-shared) → NOT_FOUND", () =>
    getCalculation(rockEngineer, ns.record!.id),
  );
  await expectAppError("NOT_FOUND", "cross-org project listing (not shared) → NOT_FOUND", () =>
    listProjectCalculations(rockEngineer, fx.nonSharedProjectId, {}),
  );
  await expectAppError("NOT_FOUND", "cross-org project listing (share PENDING) → NOT_FOUND", () =>
    listProjectCalculations(rockEngineer, fx.portProjectId, {}),
  );
  // approved share on A1 → reads allowed, writes denied
  const sharedList = await listProjectCalculations(rockEngineer, fx.a1ProjectId, {});
  if (Array.isArray(sharedList.items)) ok("APPROVED share → project calculations readable");
  else no("shared project listing failed");
  const sharedDetail = await getCalculation(rockEngineer, r1.record!.id);
  if (sharedDetail.calculation.id === r1.record!.id && sharedDetail.accessSource === "shared") {
    ok("shared access reaches the calculation detail (source: shared)");
  } else no("shared detail read failed");
  await expectAppError("NOT_FOUND", "shared project is read-only: calculate → NOT_FOUND", () =>
    calculateLabTest(rockEngineer, fx.wcFullId),
  );

  // ===== J. Invalidation lifecycle (Proctor golden) =====
  console.log("=== J. Calculation invalidation ===");
  const proctorOriginal = await db.labTest.findUniqueOrThrow({ where: { id: fx.proctorId } });
  // First-ever calculation issued as 4 concurrent keyless requests: the
  // in-transaction dedup must collapse them onto exactly one record.
  const concKeyless = await Promise.all(
    Array.from({ length: 4 }, () =>
      calculateLabTest(geoEngineer, fx.proctorId).catch((e) => e),
    ),
  );
  const proctorCount = await db.calculationRecord.count({ where: { labTestId: fx.proctorId } });
  const keylessOk = concKeyless.filter(
    (r) => !(r instanceof Error) && (r as { record?: { status?: string } }).record?.status === "COMPLETED",
  );
  if (proctorCount === 1 && keylessOk.length === 4) {
    ok("4 concurrent keyless identical calculations → exactly 1 COMPLETED record");
  } else {
    no(`concurrent keyless dedup: ${proctorCount} records, ${keylessOk.length}/4 succeeded`);
  }
  const p1 = keylessOk[0] as Awaited<ReturnType<typeof calculateLabTest>>;
  if (p1.record?.status === "COMPLETED") ok("Proctor calculation COMPLETED");
  else no("Proctor calculation failed");
  const pOut = p1.record?.output as { results?: Record<string, unknown> } | null;
  if (pOut?.results?.maxDryDensity === 1.971 && pOut?.results?.optimumMoisture === 13.75) {
    ok("Proctor goldens: MDD 1.971 Mg/m³ @ OMC 13.75 % (crest-window parabola)");
  } else no(`Proctor goldens wrong: ${pOut?.results?.maxDryDensity} @ ${pOut?.results?.optimumMoisture}`);
  if (p1.record?.method === "STANDARD effort") ok("method column extracted (STANDARD effort)");
  else no(`method extraction: ${p1.record?.method}`);

  // re-record a CHANGED (registry-valid) result → previous RESULT_DATA records invalidated
  const changedResult = JSON.parse(JSON.stringify(proctorOriginal.resultData));
  (changedResult.points[0] as { dryDensity: number }).dryDensity = 1.7;
  await recordLabTestResult(geoEngineer, fx.proctorId, changedResult, { summary: "re-measured point 1" });
  const p1After = await db.calculationRecord.findUniqueOrThrow({ where: { id: p1.record!.id } });
  if (p1After.isValid === false && p1After.invalidatedReason === "LAB_TEST_RESULT_UPDATED" && p1After.invalidatedAt) {
    ok("input change → previous result invalidated (reason + timestamp)");
  } else no(`invalidation failed: valid=${p1After.isValid}`);
  const invActivity = await db.activityLog.findFirst({
    where: { action: "CALCULATION_INVALIDATED", entityId: fx.proctorId },
  });
  if (invActivity && (invActivity.details as { count?: number })?.count === 1) {
    ok("CALCULATION_INVALIDATED activity row (count 1, correct attribution)");
  } else no("invalidation activity missing/wrong");

  // history preserved; latest valid 404 until recalculation
  const hist1 = await listLabTestCalculations(geoEngineer, fx.proctorId, {});
  if (hist1.items.some((i) => i.id === p1.record!.id && i.isValid === false)) {
    ok("invalidated record preserved in history");
  } else no("history lost the invalidated record");
  await expectAppError("NOT_FOUND", "latest valid → 404 after invalidation (no stale results served)", () =>
    getLatestValidCalculation(geoEngineer, fx.proctorId),
  );

  // recalculate → RECALCULATED activity; latest valid flips to the new record
  const p2 = await calculateLabTest(geoEngineer, fx.proctorId);
  if (p2.record?.id !== p1.record?.id && p2.record?.status === "COMPLETED") {
    ok("recalculation creates a fresh record");
  } else no("recalculation did not create a new record");
  const recalcActivity = await db.activityLog.findFirst({
    where: { action: "CALCULATION_RECALCULATED", entityId: p2.record!.id },
  });
  if (recalcActivity) ok("recalculation logged as CALCULATION_RECALCULATED");
  else no("CALCULATION_RECALCULATED missing");
  const latest = await getLatestValidCalculation(geoEngineer, fx.proctorId);
  if (latest.calculation.id === p2.record!.id) ok("latest valid result is the recalculated record");
  else no("latest valid did not flip");

  // identical re-record → fingerprint match → NO invalidation
  await recordLabTestResult(geoEngineer, fx.proctorId, changedResult, { summary: "identical re-record" });
  const p2After = await db.calculationRecord.findUniqueOrThrow({ where: { id: p2.record!.id } });
  if (p2After.isValid === true) ok("identical result re-record → still valid (fingerprint match)");
  else no("identical data wrongly invalidated");

  // EXPLICIT records are never auto-invalidated
  const wcOriginal = await db.labTest.findUniqueOrThrow({ where: { id: fx.wcFullId } });
  const wcChanged = JSON.parse(JSON.stringify(wcOriginal.resultData));
  // keep the registry write-time consistency (w within ±0.5 of the masses):
  // w = 100 × (240.5 − 205.3) / (205.3 − 42.1) = 21.5686… %
  (wcChanged as { wetMassG: number }).wetMassG = 240.5;
  (wcChanged as { waterContentPercent: number }).waterContentPercent = 21.57;
  await recordLabTestResult(geoEngineer, fx.wcFullId, wcChanged, { summary: "changed masses" });
  const explAfter = await db.calculationRecord.findFirstOrThrow({
    where: { labTestId: fx.wcFullId, idempotencyKey: "idem-aaaaaaaa" },
  });
  if (explAfter.isValid === true) ok("EXPLICIT snapshots survive result changes by design");
  else no("explicit record wrongly invalidated");

  // re-opening the test clears the result → invalidates RESULT_DATA records
  // (first recalculate so a valid RESULT_DATA record exists to invalidate)
  const wcRecalc = await calculateLabTest(geoEngineer, fx.wcFullId);
  if (wcRecalc.record?.status !== "COMPLETED") {
    no("recalculation of changed WC data failed");
  }
  const wcLatest = await getLatestValidCalculation(geoEngineer, fx.wcFullId);
  if (wcLatest.calculation.id === wcRecalc.record?.id) {
    ok("latest valid reflects the recalculated (current-data) record");
  } else no("latest valid is not the recalculated record");
  await updateLabTest(geoEngineer, fx.wcFullId, { status: "IN_PROGRESS" });
  const wcLatestAfter = await db.calculationRecord.findUniqueOrThrow({
    where: { id: wcLatest.calculation.id },
  });
  if (wcLatestAfter.isValid === false && wcLatestAfter.invalidatedReason === "LAB_TEST_RESULT_CLEARED") {
    ok("re-opening (result cleared) → invalidated with LAB_TEST_RESULT_CLEARED");
  } else no(`clear-invalidation failed: ${wcLatestAfter.invalidatedReason}`);
  await expectAppError("NOT_FOUND", "latest valid → 404 after result cleared", () =>
    getLatestValidCalculation(geoEngineer, fx.wcFullId),
  );

  // multi-record invalidation (direct seeded state — the API surface dedups
  // RESULT_DATA duplicates, so multiple valid records are created directly)
  const multi = await db.calculationRecord.createMany({
    data: [1, 2].map((i) => ({
      organizationId: geoEngineer.organizationId,
      projectId: fx.proctorProjectId,
      labTestId: fx.proctorId,
      testType: "PROCTOR",
      moduleId: "proctor",
      moduleVersion: "1.0.0",
      engineVersion: "1.0.0",
      status: "COMPLETED",
      inputSource: "RESULT_DATA",
      inputSnapshot: { synthetic: i },
      inputFingerprint: `synthetic-fingerprint-${i}`,
      output: { synthetic: i },
      warnings: [],
      createdById: geoEngineer.id,
    })),
  });
  if (multi.count === 2) ok("two synthetic valid records seeded for multi-invalidation");
  else no("multi-invalidation setup failed");
  const changedAgain = JSON.parse(JSON.stringify(changedResult));
  (changedAgain.points[1] as { dryDensity: number }).dryDensity = 1.8;
  await recordLabTestResult(geoEngineer, fx.proctorId, changedAgain, { summary: "second change" });
  const syntheticAfter = await db.calculationRecord.findMany({
    where: { labTestId: fx.proctorId, inputFingerprint: { startsWith: "synthetic-fingerprint-" } },
  });
  if (syntheticAfter.length === 2 && syntheticAfter.every((r) => r.isValid === false)) {
    ok("multiple affected calculations invalidated consistently (no partial state)");
  } else no("multi-record invalidation inconsistent");

  // changing a result on a test type WITHOUT an engine is a no-op (no error)
  const sptTest = await db.labTest.findUniqueOrThrow({ where: { id: fx.sptId } });
  await recordLabTestResult(geoEngineer, fx.sptId, sptTest.resultData, { summary: "SPT re-record" });
  ok("result change on engine-less test type → no error (no-op invalidation)");

  // ===== K. Rollback + referential integrity =====
  console.log("=== K. Transactions & referential integrity =====");
  const rbBefore = await countCalcRecords();
  let rbThrew = false;
  try {
    await db.$transaction(async (tx) => {
      await tx.calculationRecord.create({
        data: {
          organizationId: geoEngineer.organizationId,
          projectId: fx.proctorProjectId,
          labTestId: fx.proctorId,
          testType: "PROCTOR",
          moduleId: "proctor",
          moduleVersion: "1.0.0",
          engineVersion: "1.0.0",
          status: "COMPLETED",
          inputSource: "RESULT_DATA",
          inputSnapshot: { rollback: true },
          inputFingerprint: "rollback-test",
          createdById: geoEngineer.id,
        },
      });
      throw new Error("intentional rollback");
    });
  } catch {
    rbThrew = true;
  }
  if (rbThrew && (await countCalcRecords()) === rbBefore) {
    ok("failed transaction leaves no record (rollback verified)");
  } else no("transaction rollback failed");

  // cascade: deleting a lab test removes its calculations (no orphans)
  const delSample = await db.sample.create({
    data: {
      boreholeId: (await db.borehole.findFirstOrThrow({ where: { project: { organizationId: geoEngineer.organizationId } } })).id,
      code: "SVC-CLEANUP",
      type: "DISTURBED",
      depthFrom: 0,
      depthTo: 1,
    },
  });
  const delTest = await db.labTest.create({
    data: { sampleId: delSample.id, testType: "WATER_CONTENT", status: "PENDING" },
  });
  // registry-consistent masses (w = 100 × (235.5−205.3)/(205.3−42.1) = 18.505 %)
  await recordLabTestResult(
    geoEngineer,
    delTest.id,
    { waterContentPercent: 18.5, wetMassG: 235.5, dryMassG: 205.3, containerMassG: 42.1 },
    { summary: "cleanup fixture" },
  );
  const delCalc = await calculateLabTest(geoEngineer, delTest.id);
  if (delCalc.record?.status === "COMPLETED") ok("calculation on temporary test COMPLETED");
  else no("temporary test calculation failed");
  const delCalcId = delCalc.record!.id;
  await db.labTest.delete({ where: { id: delTest.id } });
  const orphan = await db.calculationRecord.findUnique({ where: { id: delCalcId } });
  if (orphan === null) ok("deleting the lab test cascades to its calculations (no orphans)");
  else no("orphaned calculation record survived lab-test deletion");
  await db.sample.delete({ where: { id: delSample.id } });

  // ===== L. Activity logging =====
  console.log("=== L. Activity logging ===");
  const acts = await calcActivities();
  const actMap = new Map(acts.map((a) => [a.action, a]));
  if (actMap.has("CALCULATION_CREATED") && actMap.has("CALCULATION_COMPLETED")) {
    ok("CALCULATION_CREATED + CALCULATION_COMPLETED events recorded");
  } else no("created/completed events missing");
  if (actMap.has("CALCULATION_FAILED")) ok("CALCULATION_FAILED event recorded");
  else no("failed event missing");
  if (actMap.has("CALCULATION_INVALIDATED")) ok("CALCULATION_INVALIDATED event recorded");
  else no("invalidated event missing");
  if (actMap.has("CALCULATION_RECALCULATED")) ok("CALCULATION_RECALCULATED event recorded");
  else no("recalculated event missing");
  const wrongOrg = acts.filter((a) => a.organizationId !== geoEngineer.organizationId);
  if (wrongOrg.length === 0) ok("all calculation events attributed to the owning organization");
  else no("calculation events leaked to a foreign org");
  const detailsBlob = JSON.stringify(acts.map((a) => a.details));
  if (!detailsBlob.includes("wetMassG") && !detailsBlob.includes("inputSnapshot") && !detailsBlob.includes("points")) {
    ok("activity details contain no input/output payloads (lean audit)");
  } else no("activity details leaked payload data");
  if (!detailsBlob.includes("password") && !detailsBlob.includes("token")) {
    ok("no passwords/tokens/secrets in activity details");
  } else no("sensitive data in activity details");

  // ===== M. Listing / pagination / filters =====
  console.log("=== M. Listing & pagination ===");
  const histAll = await listLabTestCalculations(geoEngineer, fx.wcFullId, {});
  if (histAll.items.length >= 3 && histAll.total >= 3) ok(`history lists records (total ${histAll.total})`);
  else no("history incomplete");
  const histPaged = await listLabTestCalculations(geoEngineer, fx.wcFullId, { page: 1, pageSize: 1 });
  if (histPaged.items.length === 1 && histPaged.total === histAll.total) {
    ok("pagination bounded (pageSize honored, total preserved)");
  } else no("pagination broken");
  const histFailed = await listLabTestCalculations(geoEngineer, fx.wcMasslessId, { status: "FAILED" });
  if (histFailed.items.every((i) => i.status === "FAILED")) ok("status filter works");
  else no("status filter broken");
  const histInvalid = await listLabTestCalculations(geoEngineer, fx.proctorId, { isValid: false });
  if (histInvalid.items.length >= 3 && histInvalid.items.every((i) => i.isValid === false)) {
    ok("isValid=false filter returns the invalidated history");
  } else no("isValid filter broken");
  if (!("output" in histAll.items[0]) && !("inputSnapshot" in histAll.items[0]) && "warningCount" in histAll.items[0]) {
    ok("list items are lean (no snapshots) with warningCount");
  } else no("list items carry unexpected payload fields");
  const projList = await listProjectCalculations(geoEngineer, fx.a1ProjectId, {});
  const a1TestIds = (
    await db.labTest.findMany({
      where: { sample: { borehole: { projectId: fx.a1ProjectId } } },
      select: { id: true },
    })
  ).map((t) => t.id);
  if (
    projList.items.length >= 1 &&
    projList.items.every((i) => a1TestIds.includes(i.labTestId))
  ) {
    ok(`project listing returns records (total ${projList.total}), strictly project-scoped`);
  } else no("project listing broken or leaked foreign records");
  const projFiltered = await listProjectCalculations(geoEngineer, fx.a1ProjectId, {
    testType: "PROCTOR",
  });
  if (projFiltered.items.every((i) => i.testType === "PROCTOR")) ok("project listing testType filter works");
  else no("project testType filter broken");

  // per-record detail completeness
  const detail = await getCalculation(geoEngineer, p2.record!.id);
  if (
    detail.calculation.inputSnapshot &&
    detail.calculation.output &&
    detail.calculation.labTest.sample.code &&
    detail.calculation.labTest.sample.borehole.project.code
  ) {
    ok("detail payload: full snapshots + lab-test context chain");
  } else no("detail payload incomplete");

  // engine-less module id never appears in records
  const badModuleRecords = await db.calculationRecord.count({ where: { moduleId: "spt" } });
  if (badModuleRecords === 0) ok("no records reference engine-less test types");
  else no("engine-less records exist");

  await db.$disconnect();
}

// resolve the proctor project id at module scope for the cleanup helpers
let proctorProjectId: string | null = null;
async function resolveProjectId() {
  const proctor = await db.labTest.findFirst({
    where: { testType: "PROCTOR" },
    include: { sample: { include: { borehole: true } } },
  });
  proctorProjectId = proctor?.sample.borehole.projectId ?? null;
}

// resolve the proctor project id at module scope for the cleanup helpers
async function mainWrapper() {
  await main();
}

mainWrapper()
  .catch(async (e) => {
    console.error("SUITE ERROR:", e);
    fail++;
    await db.$disconnect();
    process.exit(1);
  })
  .then(async () => {
    // ---- cleanup: remove test records (the protocol re-seeds the database
    // right after this suite — mutated seed data is restored by the re-seed,
    // documented in the run-all script) ----
    try {
      await db.calculationRecord.deleteMany({
        where: { labTestId: { in: [...touchedLabTestIds] } },
      });
      await db.activityLog.deleteMany({
        where: { action: { startsWith: "CALCULATION_" } },
      });
    } catch {
      /* cleanup is best-effort; the protocol re-seeds anyway */
    }
    await db.$disconnect();
    console.log(`\nM5.2-INTEGRATION SERVICE SUITE: ${pass} passed, ${fail} failed`);
    process.exit(fail > 0 ? 1 : 0);
  });
