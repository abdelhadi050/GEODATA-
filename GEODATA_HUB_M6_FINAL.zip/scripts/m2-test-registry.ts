/**
 * M2 TEST — Laboratory registry validation for all 12 test types.
 * Each type is exercised with one VALID payload (must pass) and one or more
 * INVALID payloads (must fail with the expected rule).
 * Exit code = number of failures.
 */
import {
  parseLabTestResult,
  parseLabTestInput,
  LAB_TEST_TYPES,
  LAB_TEST_REGISTRY,
} from "../src/lib/lab-tests/registry";

let pass = 0;
let fail = 0;
const ok = (m: string) => { console.log(`PASS: ${m}`); pass++; };
const no = (m: string) => { console.log(`FAIL: ${m}`); fail++; };

function expectValid(type: string, label: string, payload: unknown) {
  const r = parseLabTestResult(type, payload);
  if (r.ok) ok(`${label} — valid accepted`); else no(`${label} — valid REJECTED (${r.error})`);
}
function expectInvalid(type: string, label: string, payload: unknown, hint?: string) {
  const r = parseLabTestResult(type, payload);
  if (!r.ok) {
    const matched = !hint || r.error.includes(hint);
    if (matched) ok(`${label} — invalid rejected (${hint ?? r.error})`);
    else no(`${label} — rejected but wrong rule (${r.error}, expected ${hint})`);
  } else no(`${label} — invalid payload ACCEPTED`);
}

// 1. GRANULOMETRY
const gran = {
  points: [
    { diameterMm: 0.002, percentFiner: 5 }, { diameterMm: 0.063, percentFiner: 20 },
    { diameterMm: 0.5, percentFiner: 52 }, { diameterMm: 2, percentFiner: 78 },
    { diameterMm: 63, percentFiner: 100 },
  ],
  d10: 0.05, d30: 0.25, d60: 1.5, uniformityCoefficient: 30, coefficientOfCurvature: 0.83,
};
expectValid("GRANULOMETRY", "granulometry", gran);
expectInvalid("GRANULOMETRY", "granulometry decreasing %finer with diameter", {
  ...gran,
  points: [
    { diameterMm: 0.002, percentFiner: 50 }, { diameterMm: 0.063, percentFiner: 40 },
    { diameterMm: 0.5, percentFiner: 30 }, { diameterMm: 63, percentFiner: 20 },
  ],
}, "non-decreasing");
expectInvalid("GRANULOMETRY", "granulometry bad Cu", { ...gran, uniformityCoefficient: 99 }, "uniformityCoefficient");
expectInvalid("GRANULOMETRY", "granulometry too few points", {
  points: [{ diameterMm: 1, percentFiner: 50 }, { diameterMm: 2, percentFiner: 60 }],
});

// 2. ATTERBERG_LIMITS
expectValid("ATTERBERG_LIMITS", "atterberg", { liquidLimit: 42, plasticLimit: 19, plasticityIndex: 23 });
expectInvalid("ATTERBERG_LIMITS", "atterberg PI mismatch", { liquidLimit: 42, plasticLimit: 19, plasticityIndex: 30 }, "plasticityIndex");
expectInvalid("ATTERBERG_LIMITS", "atterberg PL >= LL", { liquidLimit: 20, plasticLimit: 25, plasticityIndex: 5 }, "plasticLimit");

// 3. PROCTOR
const proctor = {
  method: "STANDARD",
  points: [
    { moistureContent: 8, dryDensity: 1.72 }, { moistureContent: 12, dryDensity: 1.94 },
    { moistureContent: 14, dryDensity: 1.97 }, { moistureContent: 18, dryDensity: 1.84 },
  ],
  maxDryDensity: 1.97, optimumMoisture: 13.5,
};
expectValid("PROCTOR", "proctor", proctor);
expectInvalid("PROCTOR", "proctor maxDD below peak", { ...proctor, maxDryDensity: 1.9 }, "maxDryDensity");
expectInvalid("PROCTOR", "proctor OMC outside range", { ...proctor, optimumMoisture: 40 }, "optimumMoisture");
expectInvalid("PROCTOR", "proctor dry density out of range", {
  method: "STANDARD",
  points: [{ moistureContent: 10, dryDensity: 5.0 }, { moistureContent: 12, dryDensity: 1.9 }, { moistureContent: 14, dryDensity: 1.8 }],
  maxDryDensity: 5.0, optimumMoisture: 12,
});

// 4. CBR
const cbr = {
  condition: "SOAKED",
  points: [
    { penetrationMm: 0.5, loadKn: 1.6 }, { penetrationMm: 2.5, loadKn: 8.9 },
    { penetrationMm: 5, loadKn: 17.2 }, { penetrationMm: 10, loadKn: 26.5 },
  ],
  cbrAt2_5: 18, cbrAt5_0: 21, cbrValue: 21, swellPercent: 1.2,
};
expectValid("CBR", "cbr", cbr);
expectInvalid("CBR", "cbr value != max(2.5, 5.0)", { ...cbr, cbrValue: 50 }, "cbrValue");
expectInvalid("CBR", "cbr duplicate penetrations", {
  ...cbr,
  points: [
    { penetrationMm: 2.5, loadKn: 8.9 }, { penetrationMm: 2.5, loadKn: 9.1 },
    { penetrationMm: 5, loadKn: 17.2 },
  ],
}, "unique");

// 5. SPT
expectValid("SPT", "spt", {
  depthFrom: 2, depthTo: 2.45, hammerType: "SAFETY",
  blows1st150: 6, blows2nd150: 8, blows3rd150: 9, nValue: 17, energyRatio: 60, n60: 17,
});
expectInvalid("SPT", "spt N != blows2+blows3", {
  depthFrom: 2, depthTo: 2.45, hammerType: "SAFETY",
  blows1st150: 6, blows2nd150: 8, blows3rd150: 9, nValue: 20,
}, "nValue");
expectInvalid("SPT", "spt bad n60", {
  depthFrom: 2, depthTo: 2.45, hammerType: "SAFETY",
  blows1st150: 6, blows2nd150: 8, blows3rd150: 9, nValue: 17, energyRatio: 60, n60: 30,
}, "n60");
expectInvalid("SPT", "spt depthTo <= depthFrom", {
  depthFrom: 3, depthTo: 3, hammerType: "SAFETY",
  blows1st150: 1, blows2nd150: 1, blows3rd150: 1, nValue: 2,
}, "depthTo");

// 6. CPT
const cpt = {
  finalDepth: 3,
  points: [
    { depth: 0.5, coneResistanceMpa: 4.2, sleeveFrictionKpa: 32 },
    { depth: 1.0, coneResistanceMpa: 5.1, sleeveFrictionKpa: 41 },
    { depth: 2.0, coneResistanceMpa: 7.8, sleeveFrictionKpa: 55 },
  ],
};
expectValid("CPT", "cpt", cpt);
expectInvalid("CPT", "cpt non-increasing depths", {
  finalDepth: 3,
  points: [
    { depth: 1.0, coneResistanceMpa: 4.2, sleeveFrictionKpa: 32 },
    { depth: 0.5, coneResistanceMpa: 5.1, sleeveFrictionKpa: 41 },
    { depth: 2.0, coneResistanceMpa: 7.8, sleeveFrictionKpa: 55 },
  ],
}, "strictly increasing");
expectInvalid("CPT", "cpt finalDepth below deepest", { ...cpt, finalDepth: 1 }, "finalDepth");

// 7. UCS
expectValid("UCS", "ucs", { specimenDiameterMm: 54, peakStressKpa: 4200, strainAtFailurePercent: 0.9, failurePattern: "SHEAR" });
expectInvalid("UCS", "ucs strain out of range", { specimenDiameterMm: 54, peakStressKpa: 4200, strainAtFailurePercent: 50 });

// 8. TRIAXIAL
expectValid("TRIAXIAL", "triaxial", {
  type: "UU",
  stages: [
    { confiningPressureKpa: 100, peakDeviatorStressKpa: 95 },
    { confiningPressureKpa: 200, peakDeviatorStressKpa: 130 },
    { confiningPressureKpa: 400, peakDeviatorStressKpa: 178 },
  ],
  cohesionKpa: 38, frictionAngleDeg: 14,
});
expectInvalid("TRIAXIAL", "triaxial duplicate confinements", {
  type: "UU",
  stages: [
    { confiningPressureKpa: 100, peakDeviatorStressKpa: 95 },
    { confiningPressureKpa: 100, peakDeviatorStressKpa: 130 },
  ],
}, "unique");
expectInvalid("TRIAXIAL", "triaxial Mohr-Coulomb with 1 stage", {
  type: "CU",
  stages: [{ confiningPressureKpa: 100, peakDeviatorStressKpa: 95 }],
  cohesionKpa: 30, frictionAngleDeg: 15,
}, "at least 2 stages");

// 9. OEDOMETER
expectValid("OEDOMETER", "oedometer", {
  stages: [
    { verticalPressureKpa: 25, voidRatio: 0.912 }, { verticalPressureKpa: 50, voidRatio: 0.898 },
    { verticalPressureKpa: 100, voidRatio: 0.876 },
  ],
  compressionIndexCc: 0.155,
});
expectInvalid("OEDOMETER", "oedometer non-increasing pressures", {
  stages: [
    { verticalPressureKpa: 100, voidRatio: 0.9 }, { verticalPressureKpa: 50, voidRatio: 0.88 },
  ],
}, "strictly increasing");

// 10. DIRECT_SHEAR
expectValid("DIRECT_SHEAR", "direct shear", { normalStressKpa: 100, peakShearStressKpa: 68, cohesionKpa: 20, frictionAngleDeg: 25 });
expectInvalid("DIRECT_SHEAR", "direct shear residual > peak", {
  normalStressKpa: 100, peakShearStressKpa: 68, residualShearStressKpa: 90,
}, "residual");

// 11. WATER_CONTENT
expectValid("WATER_CONTENT", "water content", { waterContentPercent: 18.5, wetMassG: 245.6, dryMassG: 205.3 });
expectInvalid("WATER_CONTENT", "water content wet <= dry", { waterContentPercent: 18.5, wetMassG: 100, dryMassG: 205.3 }, "wetMassG");
expectInvalid("WATER_CONTENT", "water content out of range", { waterContentPercent: 400 });

// 12. SPECIFIC_GRAVITY
expectValid("SPECIFIC_GRAVITY", "specific gravity", { specificGravity: 2.67, method: "PYCNOMETER", temperatureC: 20 });
expectInvalid("SPECIFIC_GRAVITY", "specific gravity out of range", { specificGravity: 3.4 });

// Unknown type + input schemas
{
  const r = parseLabTestResult("NOT_A_TEST", {});
  if (!r.ok && r.error.includes("Unknown")) ok("unknown test type rejected"); else no("unknown test type accepted");
}
{
  const r = parseLabTestInput("CBR", { condition: "SOAKED", soakingDays: 3 });
  if (r.ok) ok("CBR input schema valid accepted"); else no(`CBR input rejected (${(r as { error: string }).error})`);
}
{
  const r = parseLabTestInput("CBR", { condition: "WET" });
  if (!r.ok) ok("CBR input schema invalid rejected"); else no("CBR input invalid accepted");
}
{
  const missing = LAB_TEST_TYPES.filter((t) => !LAB_TEST_REGISTRY[t]);
  if (missing.length === 0) ok(`registry defines all ${LAB_TEST_TYPES.length} test types`); else no(`registry missing: ${missing}`);
}
{
  const noChart = LAB_TEST_REGISTRY.SPECIFIC_GRAVITY.chart.kind;
  if (noChart === "none") ok("specific gravity correctly has no chart"); else no("specific gravity chart misconfigured");
}

console.log(`\n================ REGISTRY TEST SUMMARY: ${pass} passed, ${fail} failed ================`);
process.exit(fail);
