/**
 * M3 TEST — API integration suite.
 *
 * Runs against a LIVE dev server (BASE, default http://127.0.0.1:3000)
 * with the freshly seeded demo database. Covers:
 *   - envelope consistency + cache headers + health
 *   - unauthenticated / authenticated access
 *   - role-based authorization (all four roles)
 *   - tenant isolation (Tenant B cannot read or write Tenant A)
 *   - approved sharing grants READ-ONLY cross-org access
 *   - pending / rejected / revoked / expired shares grant nothing
 *   - validation of bodies, queries, ids, JSON, multipart
 *   - pagination and filtering
 *   - document upload security (size, type, magic bytes, traversal)
 *   - authorized / unauthorized downloads, no path exposure
 *   - activity logging of mutations
 *   - CSRF (cross-origin mutation rejection)
 *
 * Exit code = number of failures. Direct Prisma access is used ONLY for
 * test setup/teardown (fetching seeded ids, simulating share expiry).
 */
import { PrismaClient } from "@prisma/client";
import fs from "node:fs/promises";

const BASE = process.env.BASE ?? "http://127.0.0.1:3000";
const PASSWORD = "Demo1234!";
const db = new PrismaClient();

let pass = 0;
let fail = 0;
const ok = (m: string) => { console.log(`PASS: ${m}`); pass++; };
const no = (m: string) => { console.log(`FAIL: ${m}`); fail++; };

// ---------- HTTP / session helpers ----------

function cookieFrom(setCookies: string[], name: string): string | null {
  for (const c of setCookies) {
    const [pair] = c.split(";");
    const eq = pair.indexOf("=");
    if (pair.slice(0, eq) === name) return pair.slice(eq + 1);
  }
  return null;
}

/** NextAuth credentials login → session cookie value (or null). */
async function login(email: string, password = PASSWORD): Promise<string | null> {
  try {
    const r1 = await fetch(`${BASE}/api/auth/csrf`);
    const { csrfToken } = (await r1.json()) as { csrfToken: string };
    const csrfCookie = cookieFrom(r1.headers.getSetCookie(), "next-auth.csrf-token");
    if (!csrfCookie) return null;
    const r2 = await fetch(`${BASE}/api/auth/callback/credentials`, {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        Cookie: `next-auth.csrf-token=${csrfCookie}`,
      },
      body: new URLSearchParams({
        csrfToken,
        email,
        password,
        callbackUrl: `${BASE}/`,
        json: "true",
      }),
      redirect: "manual",
    });
    const session = cookieFrom(r2.headers.getSetCookie(), "next-auth.session-token");
    return session ? `next-auth.session-token=${session}` : null;
  } catch {
    return null;
  }
}

interface ApiResult {
  status: number;
  body: any;
  headers: Headers;
  text: string;
}

const envelopeViolations: string[] = [];
const leakScans: string[] = [];
const LEAK_PATTERNS = [
  "storage/uploads",
  "passwordHash",
  "prisma://",
  "PrismaClientKnownRequestError",
  "/home/z/",
  "NEXTAUTH_SECRET",
];

async function api(
  cookie: string | null,
  method: string,
  path: string,
  opts: { json?: unknown; form?: FormData; origin?: string; raw?: string; contentType?: string } = {},
): Promise<ApiResult> {
  const headers: Record<string, string> = {};
  if (cookie) headers.Cookie = cookie;
  if (opts.json !== undefined) headers["Content-Type"] = "application/json";
  if (opts.origin) headers.Origin = opts.origin;
  if (opts.contentType) headers["Content-Type"] = opts.contentType;
  let body: string | FormData | undefined;
  if (opts.json !== undefined) body = JSON.stringify(opts.json);
  else if (opts.form !== undefined) body = opts.form;
  else if (opts.raw !== undefined) body = opts.raw;
  const res = await fetch(BASE + path, { method, headers, body, redirect: "manual" });
  const text = await res.text();
  let parsed: any = null;
  try { parsed = JSON.parse(text); } catch { /* binary or empty */ }
  if (parsed && typeof parsed === "object") {
    if (parsed.success === false) {
      const e = parsed.error;
      if (!e || typeof e.code !== "string" || typeof e.message !== "string") {
        envelopeViolations.push(`${method} ${path} → malformed error envelope`);
      }
    }
    for (const pat of LEAK_PATTERNS) {
      if (text.includes(pat)) leakScans.push(`${method} ${path} → contains "${pat}"`);
    }
  }
  return { status: res.status, body: parsed, headers: res.headers, text };
}

function expectStatus(r: ApiResult, status: number, label: string) {
  if (r.status === status) ok(`${label} (HTTP ${status})`);
  else no(`${label} — expected HTTP ${status}, got ${r.status}: ${r.text.slice(0, 160)}`);
}

function expectError(r: ApiResult, status: number, code: string, label: string) {
  const good =
    r.status === status &&
    r.body?.success === false &&
    r.body?.error?.code === code &&
    typeof r.body?.error?.message === "string";
  if (good) ok(`${label} (${status} ${code})`);
  else no(`${label} — expected ${status} ${code}, got ${r.status} ${r.text.slice(0, 160)}`);
}

function expectSuccess(r: ApiResult, label: string): any {
  if (r.status < 400 && r.body?.success === true && "data" in r.body) {
    ok(`${label} (HTTP ${r.status})`);
    return r.body.data;
  }
  no(`${label} — expected success envelope, got ${r.status}: ${r.text.slice(0, 160)}`);
  return null;
}

/** Retry helper for the rare SQLite busy window (dev server + test share the DB). */
async function withRetry<T>(fn: () => Promise<T>, tries = 4): Promise<T> {
  for (let i = 0; ; i++) {
    try { return await fn(); } catch (e) {
      if (i >= tries - 1) throw e;
      await new Promise((r) => setTimeout(r, 400));
    }
  }
}

// ---------- fixtures ----------

async function main() {
  const SFX = Date.now().toString(36).toUpperCase().slice(-6);
  const TEST_CODE = `TST-${SFX}`;

  const [geoAdminUser, geoManagerUser, geoEngineerUser, geoViewerUser, rockAdminUser, rockEngineerUser] =
    await Promise.all([
      db.user.findUniqueOrThrow({ where: { email: "admin@geodata.demo" } }),
      db.user.findUniqueOrThrow({ where: { email: "manager@geodata.demo" } }),
      db.user.findUniqueOrThrow({ where: { email: "engineer@geodata.demo" } }),
      db.user.findUniqueOrThrow({ where: { email: "viewer@geodata.demo" } }),
      db.user.findUniqueOrThrow({ where: { email: "admin@rockworks.demo" } }),
      db.user.findUniqueOrThrow({ where: { email: "engineer@rockworks.demo" } }),
    ]);
  const byCode = async (code: string) =>
    db.project.findFirstOrThrow({ where: { code } });

  console.log(`\n=== M3 API INTEGRATION TESTS (base ${BASE}) ===\n`);

  // ============================================================
  console.log("--- Suite 1: envelope, health, cache headers ---");
  // ============================================================
  {
    const r = await api(null, "GET", "/api/health");
    const data = expectSuccess(r, "GET /api/health unauthenticated envelope");
    if (data?.status === "ok" && data.db === "reachable") ok("health payload ok");
    else no("health payload unexpected");

    const r2 = await api(null, "GET", "/api/health");
    const cc = r2.headers.get("cache-control") ?? "";
    if (cc.includes("private") && cc.includes("no-store")) ok("health carries private no-store");
    else no(`health cache header: "${cc}"`);
  }

  // ============================================================
  console.log("--- Suite 2: unauthenticated requests → 401 ---");
  // ============================================================
  let adminCookie: string | null = null;
  {
    for (const [method, path, opts] of [
      ["GET", "/api/projects", {}],
      ["POST", "/api/projects", { json: { code: TEST_CODE, name: "Xyz project" } }],
      ["GET", "/api/documents", {}],
      ["GET", "/api/activity", {}],
      ["GET", "/api/users", {}],
      ["GET", "/api/organizations/current", {}],
      ["GET", "/api/lab-tests/registry", {}],
      ["DELETE", "/api/projects/cmxxxxxxxxxxxxxxxxxxxxx0", {}],
    ] as const) {
      const r = await api(null, method, path, opts as any);
      expectError(r, 401, "UNAUTHENTICATED", `unauth ${method} ${path}`);
    }
  }

  // ============================================================
  console.log("--- Suite 3: authentication + organization identity ---");
  // ============================================================
  {
    const bad = await login("admin@geodata.demo", "wrong-password");
    if (bad === null) ok("wrong password rejected by NextAuth");
    else no("wrong password unexpectedly produced a session");

    adminCookie = await login("admin@geodata.demo");
    if (adminCookie) ok("admin login via credentials flow");
    else no("admin login failed");

    const r = await api(adminCookie, "GET", "/api/organizations/current");
    const org = expectSuccess(r, "GET /api/organizations/current");
    if (org?.slug === "geostruct" && !("passwordHash" in (org ?? {}))) {
      ok("current org = geostruct (session-derived)");
    } else no(`unexpected org payload: ${JSON.stringify(org).slice(0, 120)}`);
  }

  // Sessions for all roles
  const managerCookie = await login("manager@geodata.demo");
  const engineerCookie = await login("engineer@geodata.demo");
  const viewerCookie = await login("viewer@geodata.demo");
  const rockAdminCookie = await login("admin@rockworks.demo");
  const rockEngineerCookie = await login("engineer@rockworks.demo");
  for (const [name, c] of [
    ["manager", managerCookie],
    ["engineer", engineerCookie],
    ["viewer", viewerCookie],
    ["rockAdmin", rockAdminCookie],
    ["rockEngineer", rockEngineerCookie],
  ] as const) {
    if (c) ok(`login ${name}`);
    else no(`login ${name} failed`);
  }

  // ============================================================
  console.log("--- Suite 4: pagination, filtering, query validation ---");
  // ============================================================
  {
    const r = await api(adminCookie, "GET", "/api/projects");
    const data = expectSuccess(r, "list projects (geostruct)");
    const items = data ?? [];
    if (r.body?.meta?.total === 5 && items.length === 5) ok("geostruct sees exactly its 5 seeded projects");
    else no(`expected total 5 / items 5, got ${r.body?.meta?.total}/${items.length}`);
    if (items.every((p: any) => p.organizationId === geoAdminUser.organizationId && p.sharedWithYou === false)) {
      ok("all listed projects owned + not flagged shared");
    } else no("list contains unexpected rows");

    const r2 = await api(adminCookie, "GET", "/api/projects?page=1&pageSize=2");
    if (r2.body?.data?.length === 2 && r2.body?.meta?.totalPages === 3 && r2.body?.meta?.page === 1) {
      ok("pagination page=1 pageSize=2 → 2 items, totalPages=3");
    } else no(`pagination meta unexpected: ${JSON.stringify(r2.body?.meta)}`);

    const r3 = await api(adminCookie, "GET", "/api/projects?page=2&pageSize=2");
    const firstPageIds = (r2.body?.data ?? []).map((p: any) => p.id);
    const secondPageIds = (r3.body?.data ?? []).map((p: any) => p.id);
    if (r3.body?.meta?.page === 2 && !secondPageIds.some((id: string) => firstPageIds.includes(id))) {
      ok("page=2 returns disjoint items");
    } else no("pagination pages overlap or wrong page");

    expectError(
      await api(adminCookie, "GET", "/api/projects?pageSize=101"),
      400, "VALIDATION_ERROR", "pageSize over per-domain cap (101 > 100) rejected",
    );
    expectError(
      await api(adminCookie, "GET", "/api/projects?pageSize=abc"),
      400, "VALIDATION_ERROR", "non-numeric pageSize rejected",
    );
    expectError(
      await api(adminCookie, "GET", "/api/projects?foo=1"),
      400, "VALIDATION_ERROR", "unknown query parameter rejected (strict)",
    );

    const rAct = await api(adminCookie, "GET", "/api/projects?status=ACTIVE");
    const active = rAct.body?.data ?? [];
    if (rAct.body?.meta?.total === 3 && active.every((p: any) => p.status === "ACTIVE")) {
      ok("status=ACTIVE filter → exactly the 3 active projects");
    } else no(`status filter unexpected total ${rAct.body?.meta?.total}`);

    const rSearch = await api(adminCookie, "GET", "/api/projects?search=TRAM");
    if (rSearch.body?.meta?.total === 1 && rSearch.body?.data?.[0]?.code === "TRAM-CNS-2025") {
      ok("search=TRAM finds the tramway project");
    } else no(`search filter unexpected: ${JSON.stringify(rSearch.body?.meta)}`);

    const rSort = await api(adminCookie, "GET", "/api/projects?sortBy=name&sortOrder=asc");
    const names = (rSort.body?.data ?? []).map((p: any) => p.name);
    if (JSON.stringify(names) === JSON.stringify([...names].sort())) {
      ok("sortBy=name&sortOrder=asc ordering respected");
    } else no("sort order not respected");
  }

  // ============================================================
  console.log("--- Suite 5: project create/update/boundary + RBAC + validation ---");
  // ============================================================
  let testProjectId = "";
  {
    expectError(
      await api(viewerCookie, "POST", "/api/projects", { json: { code: TEST_CODE, name: "Viewer project" } }),
      403, "FORBIDDEN", "VIEWER cannot create projects",
    );
    expectError(
      await api(engineerCookie, "POST", "/api/projects", { json: { code: TEST_CODE, name: "Engineer project" } }),
      403, "FORBIDDEN", "ENGINEER cannot create projects (PROJECT_CREATE is PM+)",
    );

    const r = await api(managerCookie, "POST", "/api/projects", {
      json: {
        code: TEST_CODE,
        name: `API Test Project ${SFX}`,
        description: "Created by the M3 integration suite",
        client: "Test Client",
        status: "ACTIVE",
        locationName: "Algiers, Algeria",
        latitude: 36.7538,
        longitude: 3.0588,
      },
    });
    const created = expectSuccess(r, "PROJECT_MANAGER creates project");
    if (created) {
      testProjectId = created.id;
      if (created.organizationId === geoManagerUser.organizationId) {
        ok("organizationId derived from session (geostruct)");
      } else no("organizationId not session-derived!");
    }

    expectError(
      await api(managerCookie, "POST", "/api/projects", {
        json: { code: TEST_CODE, name: "Dup", organizationId: rockAdminUser.organizationId },
      }),
      400, "VALIDATION_ERROR", "organizationId in body rejected (strict schema, spoof attempt)",
    );

    expectError(
      await api(managerCookie, "POST", "/api/projects", { json: { code: TEST_CODE, name: "Dup" } }),
      409, "CONFLICT", "duplicate project code → 409",
    );

    expectError(
      await api(managerCookie, "POST", "/api/projects", { json: { code: "bad code!", name: "Bad" } }),
      400, "VALIDATION_ERROR", "invalid code format → 400 with details",
    );
    const badCode = await api(managerCookie, "POST", "/api/projects", { json: { code: "bad code!", name: "Bad" } });
    if (Array.isArray(badCode.body?.error?.details)) ok("validation details array present");
    else no("validation details missing");

    const rMalformed = await api(managerCookie, "POST", "/api/projects", {
      raw: "{not json",
      contentType: "application/json",
    });
    expectError(rMalformed, 400, "VALIDATION_ERROR", "malformed JSON body → 400");

    const rGet = await api(managerCookie, "GET", `/api/projects/${testProjectId}`);
    const detail = expectSuccess(rGet, "GET project detail");
    if (detail && Array.isArray(detail.boreholes) && detail.accessSource === "own") {
      ok("project detail includes boreholes + accessSource=own");
    } else no("project detail shape unexpected");

    const rPatch = await api(managerCookie, "PATCH", `/api/projects/${testProjectId}`, {
      json: { status: "ON_HOLD" },
    });
    if (rPatch.body?.data?.status === "ON_HOLD") ok("PATCH project status");
    else no("PATCH project failed");

    const boundary = {
      type: "Polygon",
      coordinates: [[[3.04, 36.74], [3.07, 36.74], [3.07, 36.77], [3.04, 36.77], [3.04, 36.74]]],
    };
    const rBound = await api(managerCookie, "PUT", `/api/projects/${testProjectId}/boundary`, { json: boundary });
    if (rBound.status === 200 && rBound.body?.data?.boundary?.type === "Polygon") ok("PUT boundary (valid polygon)");
    else no(`boundary set failed: ${rBound.status}`);

    const openRing = { type: "Polygon", coordinates: [[[0, 0], [1, 0], [1, 1], [0, 1]]] };
    expectError(
      await api(managerCookie, "PUT", `/api/projects/${testProjectId}/boundary`, { json: openRing }),
      400, "VALIDATION_ERROR", "unclosed polygon ring rejected",
    );

    expectError(
      await api(engineerCookie, "PATCH", `/api/projects/${testProjectId}`, { json: { status: "ACTIVE" } }),
      403, "FORBIDDEN", "ENGINEER cannot edit projects (PROJECT_EDIT is PM+)",
    );
    expectError(
      await api(engineerCookie, "DELETE", `/api/projects/${testProjectId}`),
      403, "FORBIDDEN", "ENGINEER cannot delete projects (PROJECT_DELETE admin-only)",
    );
  }

  // ============================================================
  console.log("--- Suite 6: tenant isolation + sharing boundaries ---");
  // ============================================================
  {
    const A1 = await byCode("A1-TEN-2025");
    const TRAM = await byCode("TRAM-CNS-2025");
    const PORT = await byCode("PORT-ORN-TERM");
    const METRO = await byCode("METRO-ALG-EXT");

    // Approved share: read works, marked shared
    const rShared = await api(rockAdminCookie, "GET", `/api/projects/${A1.id}`);
    const shared = expectSuccess(rShared, "rockworks reads A1 via APPROVED share");
    if (shared?.accessSource === "shared" && shared?.sharedWithYou === true) {
      ok("A1 detail marked accessSource=shared");
    } else no("A1 share marker missing");
    if (
      Array.isArray(shared?.documents) &&
      shared.documents.length === 2 &&
      shared.documents.every((d: any) => !("filePath" in d))
    ) {
      ok("project detail embeds documents WITHOUT filePath");
    } else no("embedded documents leak filePath or are missing");

    // List view: rockworks sees own ANNABA + shared A1
    const rList = await api(rockAdminCookie, "GET", "/api/projects");
    const listCodes = (rList.body?.data ?? []).map((p: any) => p.code);
    if (rList.body?.meta?.total === 2 && listCodes.includes("ANNABA-IND-2026") && listCodes.includes("A1-TEN-2025")) {
      const a1 = (rList.body?.data ?? []).find((p: any) => p.code === "A1-TEN-2025");
      if (a1?.sharedWithYou === true) ok("rockworks list = ANNABA + shared A1 (flagged)");
      else no("shared flag missing in list");
    } else no(`rockworks list unexpected: ${JSON.stringify(listCodes)}`);

    // Shared → READ-ONLY: writes blocked as NOT_FOUND (existence not leaked)
    expectError(
      await api(rockAdminCookie, "PATCH", `/api/projects/${A1.id}`, { json: { name: "Hacked" } }),
      404, "NOT_FOUND", "cross-tenant PATCH on shared project → 404 (read-only)",
    );
    expectError(
      await api(rockAdminCookie, "DELETE", `/api/projects/${A1.id}`),
      404, "NOT_FOUND", "cross-tenant DELETE → 404",
    );
    expectError(
      await api(rockAdminCookie, "POST", "/api/boreholes", {
        json: { projectId: A1.id, code: "EVIL-1", type: "AUGER", latitude: 36.7, longitude: 3.0 },
      }),
      404, "NOT_FOUND", "cross-tenant borehole create on shared project → 404",
    );

    // No share at all → 404
    expectError(
      await api(rockAdminCookie, "GET", `/api/projects/${TRAM.id}`),
      404, "NOT_FOUND", "unshared project (TRAM) invisible to tenant B",
    );
    // PENDING share → 404
    expectError(
      await api(rockAdminCookie, "GET", `/api/projects/${PORT.id}`),
      404, "NOT_FOUND", "PENDING share does not grant access (PORT)",
    );
    // REJECTED share → 404
    expectError(
      await api(rockAdminCookie, "GET", `/api/projects/${METRO.id}`),
      404, "NOT_FOUND", "REJECTED share does not grant access (METRO)",
    );

    // Expired share → 404 (simulate expiry directly in the DB, then restore)
    const shareA1 = await db.sharingRequest.findFirstOrThrow({
      where: { projectId: A1.id, targetOrganizationId: rockAdminUser.organizationId },
    });
    const originalExpiry = shareA1.expiresAt;
    await withRetry(() =>
      db.sharingRequest.update({
        where: { id: shareA1.id },
        data: { expiresAt: new Date(Date.now() - 86_400_000) },
      }),
    );
    expectError(
      await api(rockAdminCookie, "GET", `/api/projects/${A1.id}`),
      404, "NOT_FOUND", "EXPIRED share does not grant access (A1)",
    );
    await withRetry(() =>
      db.sharingRequest.update({ where: { id: shareA1.id }, data: { expiresAt: originalExpiry } }),
    );
    const rAgain = await api(rockAdminCookie, "GET", `/api/projects/${A1.id}`);
    expectStatus(rAgain, 200, "A1 readable again after expiry restore");

    // Shared chain reads: boreholes / samples / lab tests / documents of A1
    const rBh = await api(rockAdminCookie, "GET", `/api/boreholes?projectId=${A1.id}`);
    if (rBh.status === 200 && rBh.body?.meta?.total >= 3) ok("shared borehole list via projectId filter");
    else no(`shared boreholes: ${rBh.status} ${JSON.stringify(rBh.body?.meta)}`);

    const rSamp = await api(rockAdminCookie, "GET", `/api/samples?projectId=${A1.id}`);
    if (rSamp.status === 200 && (rSamp.body?.data ?? []).length > 0) ok("shared samples readable");
    else no("shared samples failed");

    const rTests = await api(rockAdminCookie, "GET", `/api/lab-tests?projectId=${A1.id}`);
    if (rTests.status === 200 && (rTests.body?.data ?? []).length > 0) ok("shared lab tests readable");
    else no("shared lab tests failed");

    const rDocs = await api(rockAdminCookie, "GET", `/api/documents?projectId=${A1.id}`);
    const docItems = rDocs.body?.data ?? [];
    if (rDocs.status === 200 && docItems.length === 2 && docItems.every((d: any) => !("filePath" in d))) {
      ok("shared documents listed without filePath");
    } else no(`shared docs unexpected: ${rDocs.status} len=${docItems.length}`);

    // Download a shared document (approved share allows read)
    const a1Doc = docItems[0];
    if (!a1Doc) {
      no("cannot test shared download — fixture document missing");
    } else {
      const rDown = await api(rockAdminCookie, "GET", `/api/documents/${a1Doc.id}/download`);
      if (rDown.status === 200 && rDown.text.length > 0 && (rDown.headers.get("content-disposition") ?? "").includes("attachment")) {
        ok("cross-tenant download of shared document works (attachment)");
      } else no(`shared download failed: ${rDown.status}`);
    }

    // Private (unshared) document of geostruct → 404 for rockworks
    const metroDoc = await db.document.findFirstOrThrow({
      where: { project: { code: "METRO-ALG-EXT" } },
    });
    expectError(
      await api(rockAdminCookie, "GET", `/api/documents/${metroDoc.id}/download`),
      404, "NOT_FOUND", "cross-tenant download of PRIVATE document → 404",
    );
    expectError(
      await api(rockAdminCookie, "GET", `/api/documents/${metroDoc.id}`),
      404, "NOT_FOUND", "cross-tenant document metadata → 404",
    );
  }

  // ============================================================
  console.log("--- Suite 7: sharing request lifecycle (create→approve→revoke) ---");
  // ============================================================
  {
    const TRAM = await byCode("TRAM-CNS-2025");

    const rOrgs = await api(managerCookie, "GET", "/api/sharing/organizations");
    const orgs = expectSuccess(rOrgs, "list shareable organizations");
    if (Array.isArray(orgs) && orgs.length === 1 && orgs[0].slug === "rockworks") {
      ok("only the partner org is shareable (own org excluded)");
    } else no(`shareable orgs unexpected: ${JSON.stringify(orgs)}`);

    expectError(
      await api(viewerCookie, "GET", "/api/sharing/requests"),
      403, "FORBIDDEN", "VIEWER cannot list sharing requests (SHARING_MANAGE)",
    );

    const rCreate = await api(managerCookie, "POST", "/api/sharing/requests", {
      json: {
        projectId: TRAM.id,
        targetOrganizationId: rockAdminUser.organizationId,
        message: "M3 integration test share",
      },
    });
    const share = expectSuccess(rCreate, "PM creates share request for TRAM");
    if (share?.status === "PENDING") ok("new share starts PENDING");
    // Safe fallback keeps the suite runnable even if the fixture create failed.
    const shareId = share?.id ?? "cmsharefallback0000000000000";

    expectError(
      await api(managerCookie, "POST", "/api/sharing/requests", {
        json: { projectId: TRAM.id, targetOrganizationId: rockAdminUser.organizationId },
      }),
      409, "CONFLICT", "duplicate pending share → 409",
    );
    expectError(
      await api(managerCookie, "POST", "/api/sharing/requests", {
        json: { projectId: TRAM.id, targetOrganizationId: geoManagerUser.organizationId },
      }),
      400, "VALIDATION_ERROR", "share with own organization → 400",
    );
    expectError(
      await api(engineerCookie, "POST", "/api/sharing/requests", {
        json: { projectId: TRAM.id, targetOrganizationId: rockAdminUser.organizationId },
      }),
      403, "FORBIDDEN", "ENGINEER cannot create share requests",
    );

    // Only the TARGET org decides; ENGINEER lacks SHARING_DECIDE
    expectError(
      await api(rockEngineerCookie, "POST", `/api/sharing/requests/${shareId}/decision`, { json: { decision: "APPROVE" } }),
      403, "FORBIDDEN", "target-org ENGINEER cannot decide (SHARING_DECIDE)",
    );
    expectError(
      await api(managerCookie, "POST", `/api/sharing/requests/${shareId}/decision`, { json: { decision: "APPROVE" } }),
      403, "FORBIDDEN", "owning org cannot decide its own request",
    );

    const rDecide = await api(rockAdminCookie, "POST", `/api/sharing/requests/${shareId}/decision`, {
      json: { decision: "APPROVE" },
    });
    if (rDecide.body?.data?.status === "APPROVED") ok("target org admin approves share");
    else no(`approve failed: ${rDecide.status}`);

    const rTram = await api(rockAdminCookie, "GET", `/api/projects/${TRAM.id}`);
    expectStatus(rTram, 200, "TRAM readable by rockworks after approval");

    const rInbox = await api(rockAdminCookie, "GET", "/api/sharing/requests");
    const inbox = rInbox.body?.data?.inbox ?? [];
    if (Array.isArray(inbox) && inbox.some((s: any) => s.id === shareId && s.status === "APPROVED")) {
      ok("approved request visible in rockworks inbox");
    } else no("inbox missing approved request");

    const rRevoke = await api(managerCookie, "DELETE", `/api/sharing/requests/${shareId}`);
    if (rRevoke.body?.data?.status === "REVOKED") ok("owner revokes share");
    else no(`revoke failed: ${rRevoke.status}`);

    expectError(
      await api(rockAdminCookie, "GET", `/api/projects/${TRAM.id}`),
      404, "NOT_FOUND", "REVOKED share no longer grants access",
    );
    expectError(
      await api(rockAdminCookie, "POST", `/api/sharing/requests/${shareId}/decision`, { json: { decision: "APPROVE" } }),
      409, "CONFLICT", "decision on non-pending request → 409",
    );
    expectError(
      await api(rockAdminCookie, "DELETE", `/api/sharing/requests/${shareId}`),
      403, "FORBIDDEN", "target org cannot revoke (owner-only)",
    );
  }

  // ============================================================
  console.log("--- Suite 8: boreholes, layers, samples, lab tests ---");
  // ============================================================
  let testBoreholeId = "";
  let testSampleId = "";
  {
    expectError(
      await api(viewerCookie, "POST", "/api/boreholes", {
        json: { projectId: testProjectId, code: "BH-T1", type: "ROTARY_CORE", latitude: 36.75, longitude: 3.06 },
      }),
      403, "FORBIDDEN", "VIEWER cannot create boreholes",
    );

    const rBh = await api(managerCookie, "POST", "/api/boreholes", {
      json: {
        projectId: testProjectId,
        code: "BH-T1",
        type: "ROTARY_CORE",
        latitude: 36.7525,
        longitude: 3.0575,
        elevation: 42,
        depth: 25,
        drilledBy: "Forages Algérie",
        status: "PLANNED",
      },
    });
    const bh = expectSuccess(rBh, "PM creates borehole");
    if (bh) testBoreholeId = bh.id;

    expectError(
      await api(managerCookie, "POST", "/api/boreholes", {
        json: { projectId: testProjectId, code: "BH-T1", type: "AUGER", latitude: 36.7, longitude: 3.0 },
      }),
      409, "CONFLICT", "duplicate borehole code in project → 409",
    );
    expectError(
      await api(managerCookie, "POST", "/api/boreholes", {
        json: { projectId: "cm foreign proj id 12345", code: "BH-X", type: "AUGER", latitude: 36.7, longitude: 3.0 },
      }),
      404, "NOT_FOUND", "malformed/unknown parent projectId in body → 404 (existence not leaked)",
    );

    const rDetail = await api(engineerCookie, "GET", `/api/boreholes/${testBoreholeId}`);
    const bhDetail = expectSuccess(rDetail, "ENGINEER reads borehole detail");
    if (bhDetail && Array.isArray(bhDetail.layers) && Array.isArray(bhDetail.samples)) {
      ok("borehole detail embeds layers + samples");
    } else no("borehole detail shape unexpected");

    const rPatchBh = await api(engineerCookie, "PATCH", `/api/boreholes/${testBoreholeId}`, {
      json: { depth: 25, status: "DRILLED" },
    });
    if (rPatchBh.body?.data?.status === "DRILLED") ok("ENGINEER updates borehole (BOREHOLE_MANAGE)");
    else no("borehole PATCH failed");

    // Layers
    const rLayer = await api(engineerCookie, "POST", "/api/layers", {
      json: {
        boreholeId: testBoreholeId,
        depthFrom: 0,
        depthTo: 2,
        materialType: "FILL",
        description: "Sandy fill with construction debris",
        uscs: "SM",
      },
    });
    const layer = expectSuccess(rLayer, "ENGINEER creates layer 0–2 m");

    expectError(
      await api(engineerCookie, "POST", "/api/layers", {
        json: {
          boreholeId: testBoreholeId,
          depthFrom: 1,
          depthTo: 3,
          materialType: "SOIL",
          description: "Overlapping silty clay",
        },
      }),
      400, "VALIDATION_ERROR", "overlapping layer interval → 400",
    );

    const rLayerC = await api(engineerCookie, "POST", "/api/layers", {
      json: {
        boreholeId: testBoreholeId,
        depthFrom: 2,
        depthTo: 12,
        materialType: "SOIL",
        description: "Stiff silty clay (treated as native soil)",
        uscs: "CL",
      },
    });
    const layerC = expectSuccess(rLayerC, "adjacent (touching) layer 2–12 m accepted");

    const rLayersList = await api(viewerCookie, "GET", `/api/boreholes/${testBoreholeId}/layers`);
    if (rLayersList.body?.meta?.total === 2) ok("VIEWER lists borehole layers (2)");
    else no(`layers list unexpected: ${JSON.stringify(rLayersList.body?.meta)}`);

    if (layer) {
      const rPatchLayer = await api(engineerCookie, "PATCH", `/api/layers/${layer.id}`, {
        json: { description: "Sandy fill, revised" },
      });
      expectStatus(rPatchLayer, 200, "PATCH layer description");
      const rDelLayer = await api(engineerCookie, "DELETE", `/api/layers/${layer.id}`);
      expectStatus(rDelLayer, 200, "DELETE layer 0–2 (leaves the 2–12 layer)");
    }

    // Samples
    expectError(
      await api(viewerCookie, "POST", "/api/samples", {
        json: { boreholeId: testBoreholeId, code: "S-T1", type: "DISTURBED", depthFrom: 0.5, depthTo: 1.0 },
      }),
      403, "FORBIDDEN", "VIEWER cannot create samples",
    );
    const rSample = await api(engineerCookie, "POST", "/api/samples", {
      json: {
        boreholeId: testBoreholeId,
        code: "S-T1",
        type: "DISTURBED",
        depthFrom: 0.5,
        depthTo: 1.0,
        notes: "M3 test sample",
      },
    });
    const sample = expectSuccess(rSample, "ENGINEER creates sample");
    if (sample) testSampleId = sample.id;

    expectError(
      await api(engineerCookie, "POST", "/api/samples", {
        json: { boreholeId: testBoreholeId, code: "S-T1", type: "DISTURBED", depthFrom: 2, depthTo: 3 },
      }),
      409, "CONFLICT", "duplicate sample code → 409",
    );
    expectError(
      await api(engineerCookie, "POST", "/api/samples", {
        json: { boreholeId: testBoreholeId, code: "S-T2", type: "DISTURBED", depthFrom: 1.0, depthTo: 0.5 },
      }),
      400, "VALIDATION_ERROR", "depthTo < depthFrom → 400",
    );

    const rPatchSample = await api(engineerCookie, "PATCH", `/api/samples/${testSampleId}`, {
      json: { labStatus: "SENT" },
    });
    if (rPatchSample.body?.data?.labStatus === "SENT") ok("PATCH sample labStatus");
    else no("sample PATCH failed");

    // Lab tests
    const rTest = await api(managerCookie, "POST", "/api/lab-tests", {
      json: { sampleId: testSampleId, testType: "WATER_CONTENT", notes: "M3 test" },
    });
    const labTest = expectSuccess(rTest, "PM creates WATER_CONTENT test");
    expectError(
      await api(managerCookie, "POST", "/api/lab-tests", {
        json: { sampleId: testSampleId, testType: "WATER_CONTENT" },
      }),
      409, "CONFLICT", "duplicate (sample, testType) → 409",
    );

    expectError(
      await api(viewerCookie, "PUT", `/api/lab-tests/${labTest.id}/result`, {
        json: { result: { waterContentPercent: 10 } },
      }),
      403, "FORBIDDEN", "VIEWER cannot record results (LAB_TEST_RESULT)",
    );

    expectError(
      await api(engineerCookie, "PUT", `/api/lab-tests/${labTest.id}/result`, {
        json: { result: { waterContentPercent: 500 } },
      }),
      400, "VALIDATION_ERROR", "result outside registry bounds (500% > 300%) → 400",
    );

    const rResult = await api(engineerCookie, "PUT", `/api/lab-tests/${labTest.id}/result`, {
      json: {
        result: { waterContentPercent: 18.5, wetMassG: 112.0, dryMassG: 101.6, containerMassG: 45.2 },
        summary: "w = 18.5%",
      },
    });
    const withResult = expectSuccess(rResult, "ENGINEER records valid structured result");
    if (withResult?.status === "COMPLETED" && withResult?.performedBy === "Karim Bouzidi") {
      ok("recording result → COMPLETED + performer stamped");
    } else no(`result status unexpected: ${withResult?.status}/${withResult?.performedBy}`);

    const rTestDetail = await api(viewerCookie, "GET", `/api/lab-tests/${labTest.id}`);
    const testDetail = expectSuccess(rTestDetail, "VIEWER reads lab test detail");
    if (testDetail?.registry?.label && testDetail?.resultData?.waterContentPercent === 18.5) {
      ok("detail embeds registry metadata + validated resultData");
    } else no("lab test detail shape unexpected");

    const rReg = await api(viewerCookie, "GET", "/api/lab-tests/registry");
    const reg = expectSuccess(rReg, "GET registry (authenticated)");
    if (Array.isArray(reg) && reg.length === 13 && reg.some((t: any) => t.code === "GRANULOMETRY" && t.units)) {
      ok("registry lists all 13 test types with units");
    } else no(`registry unexpected: ${reg?.length}`);

    expectError(
      await api(managerCookie, "GET", "/api/lab-tests?testType=NOT_A_TYPE"),
      400, "VALIDATION_ERROR", "unknown testType filter → 400",
    );

    const rPatchTest = await api(managerCookie, "PATCH", `/api/lab-tests/${labTest.id}`, {
      json: { notes: "Rechecked" },
    });
    expectStatus(rPatchTest, 200, "PATCH lab test notes");

    const rDelTest = await api(managerCookie, "DELETE", `/api/lab-tests/${labTest.id}`);
    expectStatus(rDelTest, 200, "DELETE lab test");
  }

  // ============================================================
  console.log("--- Suite 9: document upload & download security ---");
  // ============================================================
  {
    const pdfBytes = new Uint8Array([
      0x25, 0x50, 0x44, 0x46, 0x2d, 0x31, 0x2e, 0x34, 0x0a, 0x25, 0xe2, 0xe3, 0xcf, 0xd3, 0x0a,
      ...new Array(64).fill(0x41),
    ]);

    function pdfForm(extra: Record<string, string> = {}, name = "site-investigation.pdf", bytes = pdfBytes) {
      const form = new FormData();
      form.append("file", new File([bytes], name, { type: "application/pdf" }));
      for (const [k, v] of Object.entries(extra)) form.append(k, v);
      return form;
    }

    // RBAC before accepting the file
    expectError(
      await api(viewerCookie, "POST", "/api/documents/upload", {
        form: pdfForm({ projectId: testProjectId, title: "Viewer upload", docType: "REPORT" }),
      }),
      403, "FORBIDDEN", "VIEWER cannot upload (rejected before file accepted)",
    );

    // Valid upload
    const rUp = await api(managerCookie, "POST", "/api/documents/upload", {
      form: pdfForm({
        projectId: testProjectId,
        title: "M3 Test Investigation Report",
        docType: "REPORT",
      }),
    });
    const doc = expectSuccess(rUp, "PM uploads valid PDF");
    if (doc && doc.fileName === "site-investigation.pdf" && !("filePath" in doc)) {
      ok("upload response has no filePath (storage path hidden)");
    } else no(`upload payload unexpected: ${JSON.stringify(doc).slice(0, 140)}`);

    // Authorized download + headers + byte equality
    const rDown = await api(managerCookie, "GET", `/api/documents/${doc.id}/download`);
    if (
      rDown.status === 200 &&
      rDown.headers.get("content-type") === "application/pdf" &&
      (rDown.headers.get("content-disposition") ?? "").includes("attachment") &&
      (rDown.headers.get("content-disposition") ?? "").includes("site-investigation.pdf")
    ) {
      const got = new Uint8Array(await (await fetch(`${BASE}/api/documents/${doc.id}/download`, {
        headers: { Cookie: managerCookie! },
      })).arrayBuffer());
      if (got.length === pdfBytes.length && got.every((b, i) => b === pdfBytes[i])) {
        ok("download streams exact original bytes (PDF)");
      } else no("downloaded bytes differ from upload");
    } else no(`download headers wrong: ${rDown.status} ${rDown.headers.get("content-type")}`);

    // Text upload with .txt extension
    const textForm = new FormData();
    textForm.append("file", new File(["Consolidation check notes\n"], "notes.txt", { type: "text/plain" }));
    textForm.append("projectId", testProjectId);
    textForm.append("title", "Field notes");
    textForm.append("docType", "LAB_DATA");
    const rTxt = await api(managerCookie, "POST", "/api/documents/upload", { form: textForm });
    const txtDoc = expectSuccess(rTxt, "upload text/plain with .txt");

    // Missing file field
    const noFileForm = new FormData();
    noFileForm.append("projectId", testProjectId);
    noFileForm.append("title", "No file");
    noFileForm.append("docType", "OTHER");
    expectError(
      await api(managerCookie, "POST", "/api/documents/upload", { form: noFileForm }),
      400, "VALIDATION_ERROR", "upload without file field → 400",
    );

    // Oversized (post-parse gate)
    const bigBytes = new Uint8Array(11 * 1024 * 1024);
    bigBytes.set([0x25, 0x50, 0x44, 0x46], 0);
    expectError(
      await api(managerCookie, "POST", "/api/documents/upload", {
        form: pdfForm({ projectId: testProjectId, title: "Big file", docType: "REPORT" }, "big.pdf", bigBytes),
      }),
      413, "PAYLOAD_TOO_LARGE", "11 MB upload → 413",
    );

    // Oversized (early Content-Length gate)
    const hugeBytes = new Uint8Array(15 * 1024 * 1024);
    hugeBytes.set([0x25, 0x50, 0x44, 0x46], 0);
    expectError(
      await api(managerCookie, "POST", "/api/documents/upload", {
        form: pdfForm({ projectId: testProjectId, title: "Huge file", docType: "REPORT" }, "huge.pdf", hugeBytes),
      }),
      413, "PAYLOAD_TOO_LARGE", "15 MB upload rejected by early size gate → 413",
    );

    // Magic-byte mismatch: text content declared as PDF
    const lyingForm = new FormData();
    lyingForm.append("file", new File(["just plain text, not a pdf"], "fake.pdf", { type: "application/pdf" }));
    lyingForm.append("projectId", testProjectId);
    lyingForm.append("title", "Fake PDF");
    lyingForm.append("docType", "REPORT");
    expectError(
      await api(managerCookie, "POST", "/api/documents/upload", { form: lyingForm }),
      415, "UNSUPPORTED_MEDIA_TYPE", "text bytes declared as PDF → 415 (content sniff)",
    );

    // Disallowed MIME type
    const exeForm = new FormData();
    exeForm.append("file", new File([new Uint8Array([0x4d, 0x5a, 0x90, 0x00, 0x03])], "payload.exe", {
      type: "application/x-msdownload",
    }));
    exeForm.append("projectId", testProjectId);
    exeForm.append("title", "Executable");
    exeForm.append("docType", "OTHER");
    expectError(
      await api(managerCookie, "POST", "/api/documents/upload", { form: exeForm }),
      415, "UNSUPPORTED_MEDIA_TYPE", "executable upload → 415 (allowlist)",
    );

    // Path traversal in filename
    expectError(
      await api(managerCookie, "POST", "/api/documents/upload", {
        form: pdfForm({ projectId: testProjectId, title: "Traversal", docType: "REPORT", fileName: "../../etc/passwd" }),
      }),
      400, "VALIDATION_ERROR", "path traversal filename → 400",
    );

    // Borehole from another project
    const METRO = await byCode("METRO-ALG-EXT");
    const metroBorehole = await db.borehole.findFirstOrThrow({ where: { projectId: METRO.id } });
    expectError(
      await api(managerCookie, "POST", "/api/documents/upload", {
        form: pdfForm({
          projectId: testProjectId,
          boreholeId: metroBorehole.id,
          title: "Wrong borehole",
          docType: "REPORT",
        }),
      }),
      400, "VALIDATION_ERROR", "boreholeId from another project → 400",
    );

    // Foreign project upload (shared) → 404
    const A1 = await byCode("A1-TEN-2025");
    expectError(
      await api(rockAdminCookie, "POST", "/api/documents/upload", {
        form: pdfForm({ projectId: A1.id, title: "Cross tenant upload", docType: "REPORT" }),
      }),
      404, "NOT_FOUND", "cross-tenant upload to shared project → 404 (own-org only)",
    );

    // Malformed multipart
    expectError(
      await api(managerCookie, "POST", "/api/documents/upload", {
        raw: "this is not multipart",
        contentType: "multipart/form-data; boundary=x",
      }),
      400, "VALIDATION_ERROR", "malformed multipart body → 400",
    );

    // Metadata patch + list without filePath
    const rPatchDoc = await api(managerCookie, "PATCH", `/api/documents/${doc.id}`, {
      json: { title: "M3 Test Investigation Report (rev 1)" },
    });
    if (rPatchDoc.status === 200 && !("filePath" in (rPatchDoc.body?.data ?? {}))) ok("PATCH document title (no filePath)");
    else no("document PATCH failed");

    const rList = await api(viewerCookie, "GET", `/api/documents?projectId=${testProjectId}`);
    const listItems = rList.body?.data ?? [];
    if (rList.status === 200 && listItems.length === 2 && listItems.every((d: any) => !("filePath" in d))) {
      ok("documents list filtered by project, no filePath");
    } else no(`documents list unexpected: ${rList.status} len=${listItems.length}`);

    // Download with missing backing file → 404, no path leak
    const dbDoc = await db.document.findUniqueOrThrow({ where: { id: txtDoc.id } });
    await fs.unlink(dbDoc.filePath);
    const rMissing = await api(managerCookie, "GET", `/api/documents/${txtDoc.id}/download`);
    if (rMissing.status === 404 && !rMissing.text.includes("storage")) {
      ok("missing backing file → 404 without path leak");
    } else no(`missing file download: ${rMissing.status} ${rMissing.text.slice(0, 120)}`);

    // Cleanup both test documents via API (delete works even if file is gone)
    const rDelTxt = await api(managerCookie, "DELETE", `/api/documents/${txtDoc.id}`);
    expectStatus(rDelTxt, 200, "DELETE text document (file already gone)");
    const rDelPdf = await api(managerCookie, "DELETE", `/api/documents/${doc.id}`);
    expectStatus(rDelPdf, 200, "DELETE pdf document");

    // Download deleted → 404; invalid id format → 400
    expectError(
      await api(managerCookie, "GET", `/api/documents/${doc.id}/download`),
      404, "NOT_FOUND", "download after delete → 404",
    );
    expectError(
      await api(managerCookie, "GET", "/api/documents/short/download"),
      400, "VALIDATION_ERROR", "malformed document id → 400",
    );
  }

  // ============================================================
  console.log("--- Suite 10: reports ---");
  // ============================================================
  {
    const rList = await api(viewerCookie, "GET", "/api/reports");
    if (rList.status === 200 && rList.body?.meta?.total === 3) ok("seeded reports visible (3 for geostruct)");
    else no(`reports list unexpected: ${JSON.stringify(rList.body?.meta)}`);

    const rCreate = await api(engineerCookie, "POST", "/api/reports", {
      json: { projectId: testProjectId, reportType: "TEST_SUMMARY", title: `M3 Test Summary ${SFX}` },
    });
    const report = expectSuccess(rCreate, "ENGINEER generates report record");
    if (report) {
      const rGet = await api(viewerCookie, "GET", `/api/reports/${report.id}`);
      expectStatus(rGet, 200, "VIEWER reads report detail");
    }

    expectError(
      await api(viewerCookie, "POST", "/api/reports", {
        json: { projectId: testProjectId, reportType: "TEST_SUMMARY", title: "Nope" },
      }),
      403, "FORBIDDEN", "VIEWER cannot generate reports",
    );

    const A1 = await byCode("A1-TEN-2025");
    expectError(
      await api(rockAdminCookie, "POST", "/api/reports", {
        json: { projectId: A1.id, reportType: "TEST_SUMMARY", title: "Foreign report" },
      }),
      404, "NOT_FOUND", "cross-tenant report creation → 404",
    );

    const rRockList = await api(rockAdminCookie, "GET", "/api/reports");
    const rockTitles = (rRockList.body?.data ?? []).map((x: any) => x.title);
    if (rockTitles.some((t: string) => t.includes("A1")) && !rockTitles.some((t: string) => t.includes(SFX))) {
      ok("rockworks sees shared A1 reports but NOT geostruct private ones");
    } else no(`rockworks report visibility wrong: ${JSON.stringify(rockTitles)}`);
  }

  // ============================================================
  console.log("--- Suite 11: team management (users) ---");
  // ============================================================
  {
    const rUsers = await api(adminCookie, "GET", "/api/users");
    const users = expectSuccess(rUsers, "admin lists team");
    if (Array.isArray(users) && users.length === 4 && users.every((u: any) => !("passwordHash" in u))) {
      ok("4 geostruct users, no passwordHash exposed");
    } else no(`team list unexpected: ${users?.length}`);

    const rSearch = await api(adminCookie, "GET", "/api/users?search=zzzznope");
    if (rSearch.status === 200 && rSearch.body?.data?.length === 0) ok("user search with no match → empty");
    else no("user search unexpected");

    expectError(
      await api(engineerCookie, "GET", "/api/users"),
      403, "FORBIDDEN", "ENGINEER cannot view team directory (TEAM_VIEW)",
    );

    expectError(
      await api(adminCookie, "PATCH", `/api/users/${geoViewerUser.id}/role`, { json: { role: "SUPERADMIN" } }),
      400, "VALIDATION_ERROR", "unknown role → 400",
    );
    expectError(
      await api(adminCookie, "PATCH", `/api/users/${geoAdminUser.id}/role`, { json: { role: "VIEWER" } }),
      400, "VALIDATION_ERROR", "admin cannot change own role",
    );
    expectError(
      await api(adminCookie, "PATCH", `/api/users/${rockEngineerUser.id}/role`, { json: { role: "VIEWER" } }),
      404, "NOT_FOUND", "foreign-org user → 404",
    );

    const rRole = await api(adminCookie, "PATCH", `/api/users/${geoViewerUser.id}/role`, { json: { role: "ENGINEER" } });
    if (rRole.body?.data?.role === "ENGINEER") ok("role change VIEWER→ENGINEER");
    else no("role change failed");
    const rRoleBack = await api(adminCookie, "PATCH", `/api/users/${geoViewerUser.id}/role`, { json: { role: "VIEWER" } });
    if (rRoleBack.body?.data?.role === "VIEWER") ok("role restored to VIEWER");
    else no("role restore failed");

    // Deactivation takes effect immediately (DB-fresh sessions)
    const rOff = await api(adminCookie, "PATCH", `/api/users/${geoViewerUser.id}/status`, { json: { isActive: false } });
    if (rOff.body?.data?.isActive === false) ok("viewer deactivated");
    else no("deactivation failed");
    expectError(
      await api(viewerCookie, "GET", "/api/projects"),
      401, "UNAUTHENTICATED", "deactivated user rejected on next request (DB-fresh)",
    );
    const rOn = await api(adminCookie, "PATCH", `/api/users/${geoViewerUser.id}/status`, { json: { isActive: true } });
    if (rOn.body?.data?.isActive === true) ok("viewer reactivated");
    else no("reactivation failed");
    const rBack = await api(viewerCookie, "GET", "/api/projects");
    expectStatus(rBack, 200, "reactivated user's session works again");

    expectError(
      await api(adminCookie, "PATCH", `/api/users/${geoAdminUser.id}/status`, { json: { isActive: false } }),
      400, "VALIDATION_ERROR", "admin cannot deactivate own account",
    );
  }

  // ============================================================
  console.log("--- Suite 12: activity logging ---");
  // ============================================================
  {
    const rAct = await api(adminCookie, "GET", "/api/activity?limit=100");
    const entries = expectSuccess(rAct, "admin reads activity feed");
    const actions = new Map((entries ?? []).map((e: any) => [e.action, e]));
    if (actions.has("PROJECT_CREATED")) {
      const ours = (entries ?? []).some(
        (e: any) => e.action === "PROJECT_CREATED" && e.details?.code === TEST_CODE,
      );
      if (ours) ok("PROJECT_CREATED logged for the API-created project");
      else no("PROJECT_CREATED entry for test project missing");
    } else no("no PROJECT_CREATED in feed");
    if (actions.has("DOCUMENT_UPLOADED")) ok("DOCUMENT_UPLOADED logged");
    else no("DOCUMENT_UPLOADED missing");
    if (actions.has("LAB_TEST_RESULT_RECORDED")) ok("LAB_TEST_RESULT_RECORDED logged");
    else no("LAB_TEST_RESULT_RECORDED missing");
    if (actions.has("SHARE_APPROVED")) ok("SHARE_APPROVED logged (both orgs see the event)");
    else no("SHARE_APPROVED missing");
    if ((entries ?? []).every((e: any) => e.organizationId === geoAdminUser.organizationId)) {
      ok("activity feed strictly own-organization");
    } else no("foreign activity leaked into feed");

    const rRockAct = await api(rockAdminCookie, "GET", "/api/activity?limit=100");
    const rockText = JSON.stringify(rRockAct.body?.data ?? []);
    if (!rockText.includes(TEST_CODE)) ok("tenant B's feed does not contain tenant A's test project");
    else no("activity leaked across tenants");

    const rViewAct = await api(viewerCookie, "GET", "/api/activity?limit=5");
    if (rViewAct.status === 200 && (rViewAct.body?.data ?? []).length === 5) ok("any role reads own feed (limit=5)");
    else no("viewer activity read failed");
    expectError(
      await api(adminCookie, "GET", "/api/activity?limit=1000"),
      400, "VALIDATION_ERROR", "activity limit over cap → 400",
    );
  }

  // ============================================================
  console.log("--- Suite 13: CSRF (same-origin enforcement) ---");
  // ============================================================
  {
    expectError(
      await api(managerCookie, "POST", "/api/projects", {
        json: { code: `CSRF-${SFX}`, name: "CSRF probe" },
        origin: "http://evil.example",
      }),
      403, "CROSS_ORIGIN_REJECTED", "mutation with foreign Origin → 403",
    );
    const rSame = await api(managerCookie, "POST", "/api/projects", {
      json: { code: `CSRF-${SFX}`, name: "Same-origin probe" },
      origin: BASE,
    });
    expectStatus(rSame, 201, "mutation with matching Origin accepted");
    const csrfProject = rSame.body?.data?.id;
    if (csrfProject) {
      await api(adminCookie, "DELETE", `/api/projects/${csrfProject}`);
      ok("CSRF probe project cleaned up (DELETE works)");
    }
  }

  // ============================================================
  console.log("--- Suite 14: 404 vs 400 ids + project deletion cascade ---");
  // ============================================================
  {
    expectError(
      await api(adminCookie, "GET", "/api/projects/cmnonexistentid1234567890"),
      404, "NOT_FOUND", "well-formed unknown id → 404",
    );
    expectError(
      await api(adminCookie, "GET", "/api/projects/xx"),
      400, "VALIDATION_ERROR", "malformed id → 400",
    );

    // Delete the test project (admin) — cascade wipes its children.
    const rDel = await api(adminCookie, "DELETE", `/api/projects/${testProjectId}`);
    expectStatus(rDel, 200, "admin deletes test project (cascade)");
    expectError(
      await api(managerCookie, "GET", `/api/projects/${testProjectId}`),
      404, "NOT_FOUND", "deleted project gone",
    );
    if (testBoreholeId) {
      expectError(
        await api(managerCookie, "GET", `/api/boreholes/${testBoreholeId}`),
        404, "NOT_FOUND", "cascaded borehole gone",
      );
    }
    if (testSampleId) {
      expectError(
        await api(managerCookie, "GET", `/api/samples/${testSampleId}`),
        404, "NOT_FOUND", "cascaded sample gone",
      );
    }
  }

  // ============================================================
  console.log("--- Suite 15: cross-suite invariants ---");
  // ============================================================
  {
    if (envelopeViolations.length === 0) ok("all error responses used the standard envelope");
    else { for (const v of envelopeViolations) no(`envelope: ${v}`); }

    if (leakScans.length === 0) ok("no response leaked storage paths / hashes / Prisma internals");
    else { for (const v of leakScans) no(`leak: ${v}`); }
  }

  await db.$disconnect();
  console.log(`\n=== M3 API TESTS COMPLETE: ${pass} passed, ${fail} failed ===`);
  process.exit(fail > 0 ? 1 : 0);
}

main().catch(async (e) => {
  console.error("SUITE CRASHED:", e);
  await db.$disconnect().catch(() => {});
  process.exit(1);
});
