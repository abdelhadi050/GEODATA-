#!/usr/bin/env python3
"""M5.2-a golden-value independent verification (exact decimal arithmetic).

Run BEFORE writing test expectations. Uses Python fractions/integers so every
expected value below is computed independently of the TypeScript engine.
"""
from fractions import Fraction as F
import math

def w(wet, dry, tare):
    """w (%) = 100 x (wet - dry) / (dry - tare)  — exact rational arithmetic."""
    return 100 * (F(wet) - F(dry)) / (F(dry) - F(tare))

def show(name, val, nd=12):
    print(f"{name:44s} = {float(val):.{nd}f}  (exact {val})")

print("=== Water content goldens (exact) ===")
# Golden A — architecture report / m3-test-api.ts fixture
a = w(F('112.0'), F('101.6'), F('45.2'))
show("A: waterMassG", F('112.0') - F('101.6'))
show("A: drySoilMassG", F('101.6') - F('45.2'))
show("A: w%", a)
print(f"A: w% rounded 2dp (half away from zero)  = {round(float(a), 2)}")
d = a - F('18.5')
show("A: discrepancy (computed - entered)", d)
print(f"A: |discrepancy| = {float(abs(d)):.6f}  <= 0.5 -> NO warning")

# Golden B — seed WC_18_5
b = w(F('235.5'), F('205.3'), F('42.1'))
show("B: waterMassG", F('235.5') - F('205.3'))
show("B: drySoilMassG", F('205.3') - F('42.1'))
show("B: w%", b)
db = b - F('18.5')
show("B: discrepancy", db)

# Golden C — seed WC_11_9
c = w(F('203.5'), F('186.1'), F('39.8'))
show("C: waterMassG", F('203.5') - F('186.1'))
show("C: drySoilMassG", F('186.1') - F('39.8'))
show("C: w%", c)
dc = c - F('11.9')
show("C: discrepancy", dc)

# Golden D — clean warning case: masses (100, 90, 40) -> 20.00% vs entered 21.0
g = w(F('100.0'), F('90.0'), F('40.0'))
show("D: w%", g)
print(f"D: discrepancy vs 21.0 = {float(g - F(21)):.2f}  -> |1.00| > 0.5 -> WARNING")

# Boundary: computed 20.00 entered 20.50 -> |d| = 0.50 -> NO warning
print(f"Boundary: |20.00 - 20.50| = {abs(F(20) - F('20.5'))} -> 0.5 is NOT > 0.5 -> NO warning")
print(f"Boundary: |20.00 - 20.51| = {abs(F(20) - F('20.51'))} -> 0.51 > 0.5 -> WARNING")

# High water content: (140, 70, 20) -> 140.00%
h = w(F('140.0'), F('70.0'), F('20.0'))
show("E: w%", h)
# 300% storage bound: (120, 45, 20) -> waterMass 75, drySoil 25 -> 300.00%
t = w(F('120.0'), F('45.0'), F('20.0'))
show("F: w% (300 exactly)", t)
# computed 300.1 (uncapped, entered 300 -> d=0.1 within tolerance)
t2 = w(F('120.025'), F('45.0'), F('20.0'))
show("G: w% (300.1, uncapped)", t2)

print()
print("=== Statistics goldens (exact) ===")
data1 = [2, 4, 4, 4, 5, 5, 7, 9]
n = len(data1)
mean1 = F(sum(data1), n)
ss = sum((F(x) - mean1) ** 2 for x in data1)
popvar = ss / n
sampvar = ss / (n - 1)
print(f"[2,4,4,4,5,5,7,9]: mean={float(mean1)} popVar={float(popvar)} popStd={math.sqrt(float(popvar)):.15f}")
print(f"                   sampleVar={float(sampvar)} ({sampvar}) sampleStd={math.sqrt(float(sampvar)):.15f}")
print(f"                   CV% = {100*math.sqrt(float(sampvar))/float(mean1):.15f}")

data2 = [F('18.44'), F('18.50'), F('18.62'), F('18.38')]
mean2 = sum(data2) / 4
ss2 = sum((x - mean2) ** 2 for x in data2)
print(f"[18.44,18.50,18.62,18.38]: mean={float(mean2)} sampleVar={float(ss2/3)} ({ss2/3})")
print(f"                   sampleStd={math.sqrt(float(ss2/3)):.15f} CV%={100*math.sqrt(float(ss2/3))/float(mean2):.15f}")

print()
print("=== Phase-relation goldens (exact) ===")
print(f"porosityFromVoidRatio(0.8) = e/(1+e) = {float(F(8,10)/(1+F(8,10))):.16f}")
print(f"voidRatioFromPorosity(4/9) = n/(1-n) = {float(F(4,9)/(1-F(4,9))):.16f}")
print(f"degreeOfSaturationPercent(e=0.8, w=25%, Gs=2.65) = w*Gs/e = {float(F(25)*F('2.65')/F('0.8'))}")
print(f"degreeOfSaturationPercent(e=0.8, w=40%, Gs=2.7)  = w*Gs/e = {float(F(40)*F('2.7')/F('0.8'))}")

print()
print("=== Unit conversions (exact decimal) ===")
print(f"112 g -> kg = {F(112)/1000} ; 0.112 kg -> g = {F('0.112')*1000}")
print(f"1500 mg -> g = {F(1500)/1000} ; 2500 mm -> m = {F(2500)/1000}")
print(f"3.5 m -> mm = {F('3.5')*1000} ; 12 cm -> mm = {F(12)*10}")
