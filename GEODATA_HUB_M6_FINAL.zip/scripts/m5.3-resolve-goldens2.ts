/**
 * M5.3 golden resolution — part 2.
 * - Full stored points of the first GRANULOMETRY test + the golden of its
 *   ASCENDING-sorted version (what the explicit form prefills).
 * - Atterberg explicit golden WITH the entered values the form prefills
 *   (55/24/31 from the recorded result of the first ATTERBERG test).
 * - Warnings emitted by the stored-data calculations used in the UI suite
 *   (proctor, CBR, oedometer, direct-shear multi-stage, pressuremeter, WC).
 */
import { PrismaClient } from "@prisma/client";
import { runCalculation } from "../src/lib/calc/engine";
import {
  adaptResultDataForModule,
  getCalcModuleForTestType,
} from "../src/lib/calc/registry";

const db = new PrismaClient();

async function main() {
  const geo = await db.organization.findUniqueOrThrow({ where: { slug: "geostruct" } });
  const projects = await db.project.findMany({
    where: { organizationId: geo.id },
    select: { id: true, code: true },
  });
  const projectIds = projects.map((p) => p.id);
  const codeOf = new Map(projects.map((p) => [p.id, p.code]));

  const first = async (testType: string) => {
    const t = await db.labTest.findFirstOrThrow({
      where: {
        testType,
        status: "COMPLETED",
        sample: { borehole: { projectId: { in: projectIds } } },
      },
      orderBy: { createdAt: "desc" },
      include: { sample: { select: { code: true, borehole: { select: { code: true, projectId: true } } } } },
    });
    return t;
  };
  const second = async (testType: string) => {
    const rows = await db.labTest.findMany({
      where: {
        testType,
        status: "COMPLETED",
        sample: { borehole: { projectId: { in: projectIds } } },
      },
      orderBy: { createdAt: "desc" },
      take: 2,
      include: { sample: { select: { code: true, borehole: { select: { code: true, projectId: true } } } } },
    });
    return rows[1];
  };

  // ---- Granulometry: first test, full points + sorted golden ----
  const gran = await first("GRANULOMETRY");
  const granPoints = (gran.resultData as { points: { diameterMm: number; percentFiner: number }[] }).points;
  console.log(`GRAN first test: ${gran.sample.borehole.code}/${gran.sample.code} (${codeOf.get(gran.sample.borehole.projectId)})`);
  console.log(`stored points (sieve order): ${JSON.stringify(granPoints)}`);
  const sorted = [...granPoints].sort((a, b) => a.diameterMm - b.diameterMm);
  console.log(`sorted points: ${JSON.stringify(sorted)}`);
  const granMod = getCalcModuleForTestType("GRANULOMETRY")!;
  const granOut = runCalculation(granMod, { points: sorted });
  console.log(
    `GRAN explicit-from-prefill golden: ${granOut.status === "ok" ? JSON.stringify(granOut.results) : `FAILED ${granOut.error.code}`}`,
  );
  console.log(`GRAN warnings: ${JSON.stringify(granOut.status === "ok" ? granOut.warnings : [])}\n`);

  // ---- Atterberg: first test + explicit golden with prefilled entered ----
  const att = await first("ATTERBERG_LIMITS");
  console.log(`ATT first test: ${att.sample.borehole.code}/${att.sample.code} (${codeOf.get(att.sample.borehole.projectId)})`);
  const attStored = (att.resultData ?? {}) as Record<string, unknown>;
  const attPayload = {
    method: "CASAGRANDE_CUP",
    liquidLimitPoints: [
      { blows: 15, waterContentPercent: 48.2 },
      { blows: 20, waterContentPercent: 45.6 },
      { blows: 30, waterContentPercent: 40.3 },
      { blows: 40, waterContentPercent: 36.8 },
    ],
    plasticLimitTrials: [18, 20],
    ...(attStored.liquidLimit !== undefined ? { liquidLimit: attStored.liquidLimit as number } : {}),
    ...(attStored.plasticLimit !== undefined ? { plasticLimit: attStored.plasticLimit as number } : {}),
    ...(attStored.plasticityIndex !== undefined ? { plasticityIndex: attStored.plasticityIndex as number } : {}),
  };
  const attMod = getCalcModuleForTestType("ATTERBERG_LIMITS")!;
  const attOut = runCalculation(attMod, attPayload);
  console.log(`ATT payload (with prefilled entered): ${JSON.stringify(attPayload)}`);
  console.log(
    `ATT golden: ${attOut.status === "ok" ? JSON.stringify(attOut.results) : `FAILED ${attOut.error.code}`}`,
  );
  console.log(`ATT warnings: ${JSON.stringify(attOut.status === "ok" ? attOut.warnings : [])}\n`);

  // ---- Warnings for the stored-data suite fixtures ----
  for (const [testType, pick] of [
    ["PROCTOR", first],
    ["CBR", first],
    ["OEDOMETER", first],
    ["PRESSUREMETER", first],
    ["WATER_CONTENT", first],
    ["DIRECT_SHEAR", second],
  ] as const) {
    const t = await pick(testType);
    const mod = getCalcModuleForTestType(testType)!;
    const outcome = runCalculation(mod, adaptResultDataForModule(mod.id, t.resultData ?? null));
    console.log(
      `${testType} (${t.sample.borehole.code}/${t.sample.code}): ${outcome.status === "ok" ? `OK warnings=${JSON.stringify(outcome.warnings.map((w) => w.code))}` : `FAILED ${outcome.error.code}`}`,
    );
  }

  // ---- Which project is APPROVED-shared to RockWorks ----
  const shares = await db.sharingRequest.findMany({
    where: { status: "APPROVED" },
    include: { project: { select: { code: true, organizationId: true } } },
  });
  for (const s of shares) console.log(`APPROVED share: ${s.project.code} (from org ${s.project.organizationId === geo.id ? "GeoStruct" : "other"})`);

  // ---- First test of the shared project (RockWorks read-only fixture) ----
  if (shares.length > 0) {
    const sharedProjectId = (shares[0] as unknown as { projectId: string }).projectId;
    const t = await db.labTest.findFirst({
      where: {
        sample: { borehole: { projectId: sharedProjectId } },
        testType: { in: ["PROCTOR", "CBR"] },
      },
      orderBy: { createdAt: "desc" },
      include: { sample: { select: { code: true, borehole: { select: { code: true } } } } },
    });
    if (t) console.log(`Shared-project test: ${t.sample.borehole.code}/${t.sample.code} (${t.testType})`);
  }

  await db.$disconnect();
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
