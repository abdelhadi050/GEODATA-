#!/usr/bin/env python3
"""M5.2-b golden-value independent verification (Granulometry / PSD).

Run BEFORE writing test expectations. Every expected value below is computed
independently of the TypeScript engine:

- high-precision Decimal (60 digits) for log-linear interpolation,
- exact Fractions for the rational (exact-hit) cases,
- IEEE-754 double probes mirroring the exact JS operation order, so raw-value
  expectations and warning-boundary arithmetic are predicted precisely,
- half-away-from-zero rounding predictions for the output boundary, with a
  tie-distance guard (no golden value may sit on a .5 tie).

Interpolation formula (authorization M5.2-b §3):
  log(Dx) = log(D1) + [(x - P1)/(P2 - P1)] * [log(D2) - log(D1)]
Inverse (percentage at a measured-interior diameter):
  P(d)   = P1 + [(log(d) - log(D1))/(log(D2) - log(D1))] * (P2 - P1)
"""
from decimal import Decimal as D, getcontext, ROUND_HALF_UP
from fractions import Fraction as F
import math

getcontext().prec = 60


def dxd(d1, p1, d2, p2, x):
    """High-precision diameter at percent x (log-linear)."""
    D1, P1, D2, P2, X = (D(str(v)) for v in (d1, p1, d2, p2, x))
    return (D1.ln() + (X - P1) / (P2 - P1) * (D2.ln() - D1.ln())).exp()


def pxd(d1, p1, d2, p2, d):
    """High-precision percent at diameter d (inverse log-linear)."""
    D1, P1, D2, P2, Dd = (D(str(v)) for v in (d1, p1, d2, p2, d))
    return P1 + (Dd.ln() - D1.ln()) / (D2.ln() - D1.ln()) * (P2 - P1)


def dxd_double(d1, p1, d2, p2, x):
    """Double-precision mirror of the module's exact JS op order."""
    log_d1 = math.log(d1)
    log_d2 = math.log(d2)
    t = (x - p1) / (p2 - p1)
    return math.exp(log_d1 + t * (log_d2 - log_d1))


def pxd_double(d1, p1, d2, p2, d):
    log_d1 = math.log(d1)
    w = math.log(d2) - log_d1
    t = (math.log(d) - log_d1) / w
    return p1 + t * (p2 - p1)


def round_to_double(x, dp):
    """Mirror of units.ts roundTo: half away from zero, epsilon-corrected."""
    scaled = x * 10 ** dp
    corrected = abs(scaled) * (1 + 2.220446049250313e-16)
    r = math.floor(corrected + 0.5)  # Math.round semantics (half up on abs)
    signed = -r if scaled < 0 else r
    v = signed / 10 ** dp
    return 0.0 if v == 0 else v


def tie_distance(x, dp):
    """Distance from x*10^dp to the nearest .5 tie (must be >> 0 for goldens)."""
    scaled = x * 10 ** dp
    frac = abs(scaled - math.floor(scaled))
    return min(frac, 1 - frac) if frac != 0 else 0.0


def show(name, val, dp=None):
    hi = float(val) if isinstance(val, D) else val
    extra = ""
    if dp is not None:
        extra = f"  -> {dp} dp: {round_to_double(hi, dp)!r}  (tie dist {tie_distance(hi, dp):.3e})"
    print(f"  {name:42s} = {hi:.15g}{extra}")


def deltas(computed, entered, tol=0.05):
    """Warning-boundary report for one quantity (double semantics)."""
    d = computed - entered
    flag = "WARNING" if abs(d) > tol else "no warning"
    return f"  Δ = {d!r}  |Δ| = {abs(d):.6f} -> {flag}"


print("=" * 78)
print("CURVE A — primary log-linear interpolation golden (no exact hits)")
print("=" * 78)
A = [(0.05, 5.0), (0.10, 14.0), (0.20, 30.5), (0.40, 46.0), (0.80, 58.0),
     (1.60, 68.0), (3.20, 79.0), (6.40, 90.0), (12.8, 100.0)]
d10 = dxd(0.05, 5.0, 0.10, 14.0, 10)
d30 = dxd(0.10, 14.0, 0.20, 30.5, 30)
d60 = dxd(0.80, 58.0, 1.60, 68.0, 60)
show("D10 (bracket 0.05/5 – 0.10/14)", d10, 4)
show("D30 (bracket 0.10/14 – 0.20/30.5)", d30, 4)
show("D60 (bracket 0.80/58 – 1.60/68)", d60, 4)
cu = d60 / d10
cc_prod = (d30 / d10) * (d30 / d60)
cc_lit = (d30 * d30) / (d10 * d60)
show("Cu = D60/D10", cu, 3)
show("Cc product form (D30/D10)(D30/D60)", cc_prod, 3)
print(f"    Cc literal vs product form relative diff: {abs(cc_lit - cc_prod) / cc_lit:.3e}")
show("P(0.075) (bracket 0.05/5 – 0.10/14)", pxd(0.05, 5.0, 0.10, 14.0, 0.075), 2)
p475 = pxd(3.20, 79.0, 6.40, 90.0, 4.75)
show("P(4.75) (bracket 3.20/79 – 6.40/90)", p475, 2)
show("coarser than 4.75 = 100 - P", 100 - p475, 2)
print("  double probes (module op order):")
show("  raw D10", dxd_double(0.05, 5.0, 0.10, 14.0, 10))
show("  raw D30", dxd_double(0.10, 14.0, 0.20, 30.5, 30))
show("  raw D60", dxd_double(0.80, 58.0, 1.60, 68.0, 60))
cu_d = dxd_double(0.80, 58.0, 1.60, 68.0, 60) / dxd_double(0.05, 5.0, 0.10, 14.0, 10)
d30_d = dxd_double(0.10, 14.0, 0.20, 30.5, 30)
d10_d = dxd_double(0.05, 5.0, 0.10, 14.0, 10)
d60_d = dxd_double(0.80, 58.0, 1.60, 68.0, 60)
show("  raw Cu", cu_d)
show("  raw Cc (product form)", (d30_d / d10_d) * (d30_d / d60_d))
show("  raw P(0.075)", pxd_double(0.05, 5.0, 0.10, 14.0, 0.075))
show("  raw P(4.75)", pxd_double(3.20, 79.0, 6.40, 90.0, 4.75))

print()
print("=" * 78)
print("CURVE B — exact measured hits (D10/D30/D60/P0.075/P4.75 all measured)")
print("=" * 78)
print("  points: (0.075,3)(0.106,10)(0.180,19)(0.250,30)(0.420,41)(0.850,60)(2.0,82)(4.75,92)(9.5,100)")
print("  D10 = 0.106 exact, D30 = 0.25 exact, D60 = 0.85 exact, P(0.075) = 3 exact, P(4.75) = 92 exact")
cu_b = F(85, 100) / F(106, 1000)  # 0.85/0.106
cc_b_lit = F(250, 1000) ** 2 / (F(85, 100) * F(106, 1000))
print(f"  Cu = 0.85/0.106 = {cu_b} = {float(cu_b):.15f}  -> 3 dp: {round_to_double(float(cu_b), 3)!r}")
print(f"  Cc literal = 0.25^2/(0.85*0.106) = {cc_b_lit} = {float(cc_b_lit):.15f}")
cc_b_prod = (F(250, 1000) / F(106, 1000)) * (F(250, 1000) / F(85, 100))
print(f"  Cc product = (0.25/0.106)*(0.25/0.85) = {cc_b_prod} = {float(cc_b_prod):.15f}  -> 3 dp: {round_to_double(float(cc_b_prod), 3)!r}")
print(f"  double probes: 0.85/0.106 = {0.85/0.106!r} | (0.25/0.106)*(0.25/0.85) = {(0.25/0.106)*(0.25/0.85)!r}")
print(f"  coarser than 4.75 = 100 - 92 = 8 exact")

print()
print("=" * 78)
print("CURVE P — power-of-two exact golden + tolerance boundaries")
print("=" * 78)
print("  points: (0.125,10)(0.25,30)(0.5,60)(1,85)(2,95)(4,100)")
print("  D10 = 0.125, D30 = 0.25, D60 = 0.5 (exact binary); Cu = 0.5/0.125 = 4 exact; Cc = (0.25/0.125)*(0.25/0.5) = 1 exact")
print("  P(0.075): 0.075 < 0.125 (min D) -> UNSUPPORTED (null) | P(4.75): 4.75 > 4 (max D) -> UNSUPPORTED (null)")
print("  boundary arithmetic (IEEE doubles, verified in JS too):")
for entered in (0.075, 0.074):
    d = 0.125 - entered
    print(f"    entered d10 = {entered}: Δ = {d!r}  |Δ| > 0.05 ? {abs(d) > 0.05}")
for entered in (3.95, 3.949):
    d = 4 - entered
    print(f"    entered Cu  = {entered}: Δ = {d!r}  |Δ| > 0.05 ? {abs(d) > 0.05}")

print()
print("=" * 78)
print("CURVE N — registry-noise tolerance (0.005 decrease accepted)")
print("=" * 78)
print("  points: (0.05,5.005)(0.10,5.000)(0.20,20)(0.40,45)(0.80,58)(1.60,68)(3.20,79)(6.40,90)")
show("D10 (bracket 0.10/5 – 0.20/20, t = 1/3)", dxd(0.10, 5.0, 0.20, 20.0, 10), 4)
show("D30 (bracket 0.20/20 – 0.40/45, t = 0.4)", dxd(0.20, 20.0, 0.40, 45.0, 30), 4)
show("D60 (bracket 0.80/58 – 1.60/68, t = 0.2)", dxd(0.80, 58.0, 1.60, 68.0, 60), 4)

print()
print("=" * 78)
print("SEED DUNE_SAND (ascending) — entered-value discrepancy warnings")
print("=" * 78)
print("  points: (0.063,2)(0.125,6)(0.25,24)(0.5,62)(1,91)(2,99)(4,100)")
print("  entered: d10=0.14 d30=0.21 d60=0.32 Cu=2.29 Cc=0.98")
d10_du = dxd(0.125, 6, 0.25, 24, 10)
d30_du = dxd(0.25, 24, 0.5, 62, 30)
d60_du = dxd(0.25, 24, 0.5, 62, 60)
show("D10 (t = 4/18 = 2/9)", d10_du, 4)
show("D30 (t = 6/38 = 3/19)", d30_du, 4)
show("D60 (t = 36/38 = 18/19)", d60_du, 4)
cu_du = d60_du / d10_du
cc_du = (d30_du / d10_du) * (d30_du / d60_du)
show("Cu", cu_du, 3)
show("Cc", cc_du, 3)
print("  deltas vs entered (double probes):")
d10_dud = dxd_double(0.125, 6, 0.25, 24, 10)
d30_dud = dxd_double(0.25, 24, 0.5, 62, 30)
d60_dud = dxd_double(0.25, 24, 0.5, 62, 60)
cu_dud = d60_dud / d10_dud
cc_dud = (d30_dud / d10_dud) * (d30_dud / d60_dud)
print(deltas(d10_dud, 0.14))
print(deltas(d30_dud, 0.21))
print(deltas(d60_dud, 0.32))
print(deltas(cu_dud, 2.29))
print(deltas(cc_dud, 0.98))
print("  expected warning detail values (4 dp):")
for nm, v in (("d10", d10_dud), ("d30", d30_dud), ("d60", d60_dud), ("Cu", cu_dud), ("Cc", cc_dud)):
    print(f"    {nm}: computed@4dp = {round_to_double(v, 4)!r}")
show("P(0.075) (bracket 0.063/2 – 0.125/6)", pxd(0.063, 2, 0.125, 6, 0.075), 2)
print("  P(4.75): 4.75 > 4 (max D) -> UNSUPPORTED (null)")
print("  registry identity margins for the entered values:")
print(f"    |2.29 - 0.32/0.14|      = {abs(2.29 - 0.32 / 0.14)!r} (<= 0.05 -> registry-valid)")
print(f"    |0.98 - 0.21^2/(0.32*0.14)| = {abs(0.98 - (0.21 * 0.21) / (0.32 * 0.14))!r} (<= 0.05 -> registry-valid)")

print()
print("=" * 78)
print("SEED SANDY_SILT (ascending) — warnings + interpolated indicators")
print("=" * 78)
print("  points: (0.002,5)(0.006,8)(0.02,13)(0.063,20)(0.125,27)(0.25,38)(0.5,52)(1,66)(2,78)(4,87)(8,93)(16,97)(31.5,99)(63,100)")
print("  entered: d10=0.05 d30=0.25 d60=1.5 Cu=30 Cc=0.83")
d10_si = dxd(0.006, 8, 0.02, 13, 10)
d30_si = dxd(0.125, 27, 0.25, 38, 30)
d60_si = dxd(0.5, 52, 1, 66, 60)
show("D10 (t = 2/5)", d10_si, 4)
show("D30 (t = 3/11)", d30_si, 4)
show("D60 (t = 8/14)", d60_si, 4)
cu_si = d60_si / d10_si
cc_si = (d30_si / d10_si) * (d30_si / d60_si)
show("Cu", cu_si, 3)
show("Cc", cc_si, 3)
d10_sid = dxd_double(0.006, 8, 0.02, 13, 10)
d30_sid = dxd_double(0.125, 27, 0.25, 38, 30)
d60_sid = dxd_double(0.5, 52, 1, 66, 60)
cu_sid = d60_sid / d10_sid
cc_sid = (d30_sid / d10_sid) * (d30_sid / d60_sid)
print("  deltas vs entered (double probes):")
print(deltas(d10_sid, 0.05))
print(deltas(d30_sid, 0.25))
print(deltas(d60_sid, 1.5))
print(deltas(cu_sid, 30))
print(deltas(cc_sid, 0.83))
p075_si = pxd(0.063, 20, 0.125, 27, 0.075)
p475_si = pxd(4, 87, 8, 93, 4.75)
show("P(0.075) (bracket 0.063/20 – 0.125/27)", p075_si, 2)
show("P(4.75) (bracket 4/87 – 8/93)", p475_si, 2)
show("coarser than 4.75", 100 - p475_si, 2)
print(f"  identity margins: |30 - 1.5/0.05| = {abs(30 - 1.5 / 0.05)!r} | |0.83 - 0.0625/0.075| = {abs(0.83 - 0.0625 / 0.075)!r}")

print()
print("=" * 78)
print("REJECTION CASES — ranges, overflow, ambiguity")
print("=" * 78)
print("SILTY_CLAY (ascending): min percentFiner = 21 > 10 -> D10 below measured range")
print("  points: (0.001,21)(0.002,27)(0.006,41)(0.02,62)(0.063,88)(0.125,93)(0.25,96)(0.5,98)(1,99)(2,100)")
print(f"  measured range [{min(21, 27, 41, 62, 88, 93, 96, 98, 99, 100)}, 100] — target 10 outside -> ARITHMETIC_DOMAIN_ERROR")
show("  (documentation) D30 would be", dxd(0.002, 27, 0.006, 41, 30), 4)
show("  (documentation) D60 would be", dxd(0.006, 41, 0.02, 62, 60), 4)
print()
print("RANGE_HIGH: max percentFiner = 48 < 60 -> D60 above measured range")
print("  points: (0.002,5)(0.006,8)(0.02,12)(0.063,18)(0.125,25)(0.25,33)(0.5,41)(1.0,48)")
show("  (documentation) D10 would be", dxd(0.006, 8, 0.02, 12, 10), 4)
show("  (documentation) D30 would be", dxd(0.125, 25, 0.25, 33, 30), 4)
print()
print("OVERFLOW: subnormal D10 -> Cu = D60/D10 overflows to Infinity")
print("  points: (5e-324,5)(1e-320,15)(0.001,30)(100,59)(200,61)(300,100)")
d10_ov = dxd_double(5e-324, 5, 1e-320, 15, 10)
d60_ov = dxd_double(100, 59, 200, 61, 60)
print(f"  raw D10 (double) = {d10_ov!r}  raw D60 (double) = {d60_ov!r}")
print(f"  Cu = D60/D10 = {d60_ov / d10_ov!r}  (math.isinf: {math.isinf(d60_ov / d10_ov)}) -> ARITHMETIC_DOMAIN_ERROR")
print()
print("SAFE-INTEGER: Cu ~ 1e13 -> roundTo(Cu, 3) leaves safe integer range")
print("  points: (1e-11,5)(2e-11,15)(0.01,30)(100,59)(200,61)(300,100)")
d10_si2 = dxd_double(1e-11, 5, 2e-11, 15, 10)
d60_si2 = dxd_double(100, 59, 200, 61, 60)
cu_si2 = d60_si2 / d10_si2
print(f"  raw D10 = {d10_si2!r}  raw D60 = {d60_si2!r}  Cu = {cu_si2!r}")
print(f"  Cu * 1000 = {cu_si2 * 1000!r} > MAX_SAFE_INTEGER (9007199254740991)? {cu_si2 * 1000 > 9007199254740991}")
print()
print("AMBIGUOUS exact duplicates: (0.063,10)(0.125,10)(0.25,30)(0.5,60)(2,90)")
print("  D10 target 10 -> TWO exact measured hits (0.063 and 0.125) -> INVALID_INPUT ambiguous")
print("MULTI-BRACKET noise: (0.063,9.995)(0.125,10.004)(0.25,9.996)(0.5,10.004)(2,40)")
print("  decreases 10.004->9.996 = 0.008 <= 0.01 (registry-tolerated); target 10:")
print("  brackets (0.063/9.995–0.125/10.004) and (0.25/9.996–0.5/10.004) -> TWO brackets -> INVALID_INPUT ambiguous")
print("NOISE GAP: (0.063,10.004)(0.125,9.995)(0.25,9.996)(0.5,9.997)")
print("  decrease 10.004->9.995: 10.004 - 0.01 = 9.994 (double) and 9.995 < 9.994 is False -> tolerated;")
print("  target 10 inside [9.995,10.004] but NO interval covers it -> ARITHMETIC_DOMAIN_ERROR (gap)")
print("  (NOTE: a decimal-exact 0.010 decrease like 10.005 -> 9.995 is REJECTED by the shared")
print("   expression in doubles: 10.005 - 0.01 = 9.995000000000001 > 9.995 — registry parity.)")
print("FLAT OK: (0.063,5)(0.125,5)(0.25,30)(0.5,60)(2,90)")
d10_fl = dxd(0.125, 5, 0.25, 30, 10)
show("  D10 (bracket 0.125/5 – 0.25/30, t = 0.2)", d10_fl, 4)
print("  D30 = 0.25 exact hit, D60 = 0.5 exact hit")
show("  Cu = D60/D10", dxd(0.5, 60, 0.5, 60, 60) / d10_fl if False else D(str(0.5)) / d10_fl, 3)
show("  Cc = (D30/D10)(D30/D60)", (D("0.25") / d10_fl) * (D("0.25") / D("0.5")), 3)
print("  P(0.075): bracket (0.063/5 – 0.125/5) is FLAT -> P = 5 exactly")

print()
print("=" * 78)
print("ZERO-LOG-WIDTH PAIR SEARCH (for the D->P NaN guard unit test)")
print("=" * 78)
for base in (1e-16, 1e-20, 1e-12, 1e-8, 0.075, 1.5):
    d1 = base
    d2 = d1 * (1 + 2 ** -52)
    w = math.log(d2) - math.log(d1)
    # is there a double strictly between? check d1*(1+2^-53) rounding
    dm = d1 * (1 + 2 ** -53)
    between = dm > d1 and dm < d2
    print(f"  base {base!r}: d2 = d1*(1+eps) = {d2!r}  log width = {w!r}  zero? {w == 0.0}  middle double exists? {between}")
    d2b = d1 * (1 + 2 * 2 ** -52)
    wb = math.log(d2b) - math.log(d1)
    dmb = d1 * (1 + 2 ** -52)
    between_b = dmb > d1 and dmb < d2b
    print(f"           d2b = d1*(1+2eps) = {d2b!r}  log width = {wb!r}  zero? {wb == 0.0}  middle double exists? {between_b}")
