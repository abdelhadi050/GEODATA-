/**
 * M5.3 fixture resolver — deterministic expectations for the browser suite.
 *
 * The seed is deterministic and the lab-test list orders by createdAt desc,
 * so "first test of type X in the filtered list" is a stable fixture. This
 * script prints, for every calculable test type of the GeoStruct org (the
 * admin@geodata.demo tenant):
 *   - the first COMPLETED test of that type (id, sample, borehole, project),
 *   - the engine outcome of its stored resultData (registry → adapter →
 *     runCalculation — the exact RESULT_DATA path the Calculate API takes),
 * so the UI assertions can be written against real engine outputs.
 *
 * Also resolves: a massless WATER_CONTENT test (FAILED fixture), an SPT test
 * (no-engine fixture), and the shared-project test for RockWorks.
 */
import { PrismaClient } from "@prisma/client";
import { runCalculation } from "../src/lib/calc/engine";
import {
  adaptResultDataForModule,
  getCalcModuleForTestType,
  CALC_MODULES,
} from "../src/lib/calc/registry";

const db = new PrismaClient();

function brief(v: unknown): string {
  if (v === null || typeof v !== "object") return String(v);
  const s = JSON.stringify(v);
  return s.length > 220 ? `${s.slice(0, 220)}…` : s;
}

function full(v: unknown): string {
  return JSON.stringify(v);
}

async function main() {
  const geostruct = await db.organization.findUnique({ where: { slug: "geostruct" } });
  const rockworks = await db.organization.findUnique({ where: { slug: "rockworks" } });
  if (!geostruct || !rockworks) throw new Error("seeded orgs missing");
  console.log(`GeoStruct: ${geostruct.id}\nRockWorks: ${rockworks.id}\n`);

  console.log(`Registered engines (${CALC_MODULES.length}):`);
  for (const m of CALC_MODULES) console.log(`  ${m.id} → ${m.testType} (v${m.version})`);
  console.log("");

  const geoProjects = await db.project.findMany({
    where: { organizationId: geostruct.id },
    select: { id: true, code: true, name: true },
  });
  const projectCodes = new Map(geoProjects.map((p) => [p.id, p.code]));

  for (const testType of [
    "PROCTOR",
    "CBR",
    "WATER_CONTENT",
    "GRANULOMETRY",
    "ATTERBERG_LIMITS",
    "OEDOMETER",
    "DIRECT_SHEAR",
    "PRESSUREMETER",
  ] as const) {
    const tests = await db.labTest.findMany({
      where: {
        testType,
        status: "COMPLETED",
        sample: { borehole: { projectId: { in: geoProjects.map((p) => p.id) } } },
      },
      orderBy: { createdAt: "desc" },
      take: 4,
      include: {
        sample: { select: { code: true, borehole: { select: { code: true, projectId: true } } } },
      },
    });
    console.log(`=== ${testType} (first ${tests.length} COMPLETED, GeoStruct, createdAt desc) ===`);
    for (const t of tests) {
      const mod = getCalcModuleForTestType(testType);
      let outcomeStr = "no engine";
      if (mod) {
        const payload = adaptResultDataForModule(mod.id, t.resultData ?? null);
        const outcome = runCalculation(mod, payload);
        outcomeStr =
          outcome.status === "ok"
            ? `OK ${brief(outcome.results)}`
            : `FAILED ${outcome.error.code}: ${outcome.error.message}`;
      }
      console.log(`  ${t.id} | ${t.sample.borehole.code}/${t.sample.code} | project ${projectCodes.get(t.sample.borehole.projectId)}`);
      console.log(`    resultData: ${brief(t.resultData)}`);
      console.log(`    engine: ${outcomeStr}`);
    }
    console.log("");
  }

  // A massless WATER_CONTENT test (validation-failure fixture) — GeoStruct.
  const massless = await db.labTest.findFirst({
    where: {
      testType: "WATER_CONTENT",
      status: "COMPLETED",
      sample: { borehole: { projectId: { in: geoProjects.map((p) => p.id) } } },
    },
    orderBy: { createdAt: "desc" },
    include: { sample: { select: { code: true, borehole: { select: { code: true } } } } },
  });
  if (massless) {
    const rd = (massless.resultData ?? {}) as Record<string, unknown>;
    console.log(
      `Massless-WC candidate (newest WC): ${massless.id} | ${massless.sample.borehole.code}/${massless.sample.code} | keys: ${Object.keys(rd).join(",")}`,
    );
  }

  // An SPT test (no-engine fixture).
  const spt = await db.labTest.findFirst({
    where: {
      testType: "SPT",
      sample: { borehole: { projectId: { in: geoProjects.map((p) => p.id) } } },
    },
    orderBy: { createdAt: "desc" },
    include: { sample: { select: { code: true, borehole: { select: { code: true } } } } },
  });
  if (spt) console.log(`SPT fixture: ${spt.id} | ${spt.sample.borehole.code}/${spt.sample.code}`);

  // The approved shared project visible to RockWorks + one of its tests.
  const shares = await db.sharingRequest.findMany({
    where: { status: "APPROVED" },
    include: { project: { select: { id: true, code: true, name: true, organizationId: true } } },
  });
  for (const s of shares) {
    console.log(`APPROVED share: project ${s.project.code} (${s.project.id}) → org ${s.project.organizationId === geostruct.id ? "GeoStruct→RockWorks" : s.project.organizationId}`);
  }
  const a1 = shares[0];
  if (a1) {
    const t = await db.labTest.findFirst({
      where: {
        sample: { borehole: { projectId: a1.project.id } },
        testType: { in: ["PROCTOR", "CBR", "WATER_CONTENT"] },
      },
      orderBy: { createdAt: "desc" },
      include: { sample: { select: { code: true, borehole: { select: { code: true } } } } },
    });
    if (t) console.log(`Shared-project test fixture: ${t.id} | ${t.sample.borehole.code}/${t.sample.code} (${t.testType})`);
  }

  await db.$disconnect();
  await goldens();
}

/** Full goldens for the UI assertions (first-of-type fixtures). */
async function goldens() {
  const db2 = new PrismaClient();
  const geo = await db2.organization.findUniqueOrThrow({ where: { slug: "geostruct" } });
  const projects = await db2.project.findMany({
    where: { organizationId: geo.id },
    select: { id: true },
  });
  const firstOfType = async (testType: string) =>
    db2.labTest.findFirstOrThrow({
      where: {
        testType,
        status: "COMPLETED",
        sample: { borehole: { projectId: { in: projects.map((p) => p.id) } } },
      },
      orderBy: { createdAt: "desc" },
      select: { id: true, testType: true, resultData: true },
    });

  console.log("\n########## UI GOLDENS ##########");
  for (const testType of ["PROCTOR", "CBR", "OEDOMETER", "PRESSUREMETER", "WATER_CONTENT", "DIRECT_SHEAR"]) {
    const t = await firstOfType(testType);
    const mod = getCalcModuleForTestType(testType)!;
    const payload = adaptResultDataForModule(mod.id, t.resultData ?? null);
    const outcome = runCalculation(mod, payload);
    console.log(`\n${testType} ${t.id}`);
    console.log(outcome.status === "ok" ? full(outcome.results) : `FAILED ${outcome.error.code}: ${outcome.error.message}`);
  }

  // Explicit-input goldens (payloads reused by the browser suite).
  const granMod = getCalcModuleForTestType("GRANULOMETRY")!;
  const granPayload = {
    points: [
      { diameterMm: 0.063, percentFiner: 2 },
      { diameterMm: 0.125, percentFiner: 6 },
      { diameterMm: 0.25, percentFiner: 24 },
      { diameterMm: 0.5, percentFiner: 62 },
      { diameterMm: 1, percentFiner: 91 },
      { diameterMm: 2, percentFiner: 99 },
      { diameterMm: 4, percentFiner: 100 },
    ],
  };
  const gran = runCalculation(granMod, granPayload);
  console.log(`\nGRANULOMETRY-EXPLICIT`);
  console.log(gran.status === "ok" ? full(gran.results) : `FAILED ${gran.error.code}: ${gran.error.message}`);

  const attMod = getCalcModuleForTestType("ATTERBERG_LIMITS")!;
  const attPayload = {
    method: "CASAGRANDE_CUP",
    liquidLimitPoints: [
      { blows: 15, waterContentPercent: 48.2 },
      { blows: 20, waterContentPercent: 45.6 },
      { blows: 30, waterContentPercent: 40.3 },
      { blows: 40, waterContentPercent: 36.8 },
    ],
    plasticLimitTrials: [18, 20],
  };
  const att = runCalculation(attMod, attPayload);
  console.log(`\nATTERBERG-EXPLICIT`);
  console.log(att.status === "ok" ? full(att.results) : `FAILED ${att.error.code}: ${att.error.message}`);

  await db2.$disconnect();
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
