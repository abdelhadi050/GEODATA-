#!/usr/bin/env bash
# M6 E2E test runner — dev server + tests in a single bash invocation.
set -u
cd /home/z/my-project

stop_dev(){ pkill -f "next dev" 2>/dev/null || true; sleep 1; }
trap stop_dev EXIT

stop_dev
echo "→ Starting dev server..."
nohup bun run dev < /dev/null > /tmp/m6-dev.out 2>&1 &
DEV_PID=$!

for i in $(seq 1 30); do
  if curl -sf http://localhost:3000/api/health > /dev/null 2>&1; then
    echo "✓ Dev server ready (pid $DEV_PID)"
    break
  fi
  sleep 1
done

if ! curl -sf http://localhost:3000/api/health > /dev/null 2>&1; then
  echo "✗ Dev server failed"; tail -30 /tmp/m6-dev.out; exit 1
fi

echo "→ Running M6 E2E tests..."
bun test ./scripts/m6-test-e2e.ts
TEST_RC=$?

echo "→ Stopping dev server..."
stop_dev
exit $TEST_RC
