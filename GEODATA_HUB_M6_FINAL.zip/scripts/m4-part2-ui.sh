#!/usr/bin/env bash
# M4 phase 2: fresh seed → M4 browser UI suite + screenshots → error scan →
# final pristine re-seed. Single bash invocation (sandbox process-group rule).
set -u
cd /home/z/my-project

BASE=http://127.0.0.1:3000
PASS=0; FAIL=0
step(){ echo ""; echo "###############################################"; echo "### $1"; echo "###############################################"; }

stop_dev(){ pkill -f "next dev" 2>/dev/null || true; sleep 1; }
start_dev(){
  nohup bun run dev < /dev/null > /tmp/m4-dev.out 2>&1 &
  DEV_PID=$!
  for i in $(seq 1 90); do
    curl -sf "$BASE/api/health" >/dev/null 2>&1 && break
    sleep 1
  done
  if curl -sf "$BASE/api/health" >/dev/null 2>&1; then echo "dev server up (pid $DEV_PID)"; else echo "DEV SERVER FAILED"; tail -40 /tmp/m4-dev.out; exit 1; fi
}

stop_dev

step "8. Fresh seed for M4 UI suite"
bun run db:seed >/dev/null 2>&1 && echo "seed for UI: done" && PASS=$((PASS+1)) || FAIL=$((FAIL+1))
start_dev

step "9. M4 browser UI suite + screenshots"
bash scripts/m4-test-ui.sh
M4_RC=$?
if [ $M4_RC -eq 0 ]; then PASS=$((PASS+1)); else FAIL=$((FAIL+1)); fi

step "10. Runtime error scan (dev log)"
if grep -aqiE "hydration|Module not found|unhandled promise" /tmp/m4-dev.out; then
  echo "  potential errors:"
  grep -aiE "hydration|Module not found|unhandled promise" /tmp/m4-dev.out | head -8
  FAIL=$((FAIL+1))
else
  echo "no hydration/module/unhandled errors in dev log"; PASS=$((PASS+1))
fi

step "11. Re-seed pristine demo data"
stop_dev
bun run db:seed >/dev/null 2>&1 && echo "final seed: done" && PASS=$((PASS+1)) || FAIL=$((FAIL+1))

echo ""
echo "=============================================="
echo "M4 PHASE 2 SUMMARY: $PASS steps passed, $FAIL failed"
echo "  (m4 ui rc=$M4_RC)"
echo "=============================================="
ls -la download/m4-screenshots/ 2>/dev/null | head -20
exit $((FAIL > 0 ? 1 : 0))
