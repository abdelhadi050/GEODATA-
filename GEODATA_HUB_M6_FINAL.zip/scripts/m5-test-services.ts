/**
 * M5.1 TEST — Service layer: input persistence (create/update/read), the
 * approved editability rule (inputs lock once a result exists; re-opening
 * clears the result and re-enables editing), per-type input validation,
 * new result shapes through the service, list-shape backward compatibility,
 * RBAC and tenant isolation for the new surface, and activity details.
 * Exit code = number of failures.
 */
import { PrismaClient } from "@prisma/client";
import {
  listLabTests,
  getLabTest,
  createLabTest,
  updateLabTest,
  recordLabTestResult,
  deleteLabTest,
} from "../src/lib/services/lab-tests";
import { AppError } from "../src/lib/errors";
const db = new PrismaClient();

let pass = 0;
let fail = 0;
const ok = (m: string) => { console.log(`PASS: ${m}`); pass++; };
const no = (m: string) => { console.log(`FAIL: ${m}`); fail++; };

type Actor = { id: string; email: string; name: string; role: string; isActive: boolean; organizationId: string };

async function actorByEmail(email: string): Promise<Actor> {
  const u = await db.user.findUniqueOrThrow({ where: { email } });
  return { id: u.id, email: u.email, name: u.name, role: u.role, isActive: u.isActive, organizationId: u.organizationId };
}

async function expectThrows(code: string, label: string, fn: () => Promise<unknown>) {
  try {
    await fn();
    no(`${label} — expected ${code} but call SUCCEEDED`);
  } catch (e) {
    if (e instanceof AppError && e.code === code) ok(`${label} — ${code} as expected`);
    else if (e instanceof AppError) no(`${label} — got ${e.code} (${e.message}), expected ${code}`);
    else no(`${label} — non-AppError thrown: ${(e as Error).message}`);
  }
}

const WC_INPUT = { containerId: "TIN-M5", ovenTemperatureC: 110, notes: "M5.1 service fixture" };
const WC_INPUT_ALT = { containerId: "TIN-M5B", ovenTemperatureC: 105 };
const PMT_INPUT = { probeType: "Ménard NB (74 mm)", testDepthM: 6.0, boreholeDiameterMm: 76, groundwaterPresent: true };
const PMT_RESULT = {
  points: [
    { pressureKpa: 0, volumeCm3: 42 },
    { pressureKpa: 50, volumeCm3: 52 },
    { pressureKpa: 100, volumeCm3: 64 },
    { pressureKpa: 200, volumeCm3: 92 },
    { pressureKpa: 400, volumeCm3: 160 },
    { pressureKpa: 600, volumeCm3: 255 },
  ],
  creepPressureKpa: 400,
  limitPressureKpa: 900,
  menardModulusMPa: 11.2,
  emPlRatio: 12.44,
};
const DS_STAGES_RESULT = {
  stages: [
    { normalStressKpa: 50, peakShearStressKpa: 43 },
    { normalStressKpa: 100, peakShearStressKpa: 67 },
  ],
  cohesionKpa: 20,
  frictionAngleDeg: 25,
};

async function main() {
  const geoManager = await actorByEmail("manager@geodata.demo");
  const geoEngineer = await actorByEmail("engineer@geodata.demo");
  const geoViewer = await actorByEmail("viewer@geodata.demo");
  const rockAdmin = await actorByEmail("admin@rockworks.demo");
  const rockEngineer = await actorByEmail("engineer@rockworks.demo");

  // Fixture host: TRAM CS-02 / SPT-02 (seeded with only an SPT test).
  const hostSample = await db.sample.findFirstOrThrow({
    where: { code: "SPT-02", borehole: { code: "CS-02", project: { code: "TRAM-CNS-2025" } } },
  });
  // Shared-project fixture: A1-TEN-2025 is seeded with an approved share to RockWorks.
  const a1 = await db.project.findFirstOrThrow({ where: { code: "A1-TEN-2025" } });

  // Idempotency reset: remove leftover M5 fixtures and restore the share state.
  await db.labTest.deleteMany({
    where: {
      sampleId: hostSample.id,
      testType: { in: ["WATER_CONTENT", "PRESSUREMETER", "DIRECT_SHEAR"] },
    },
  });
  await db.sharingRequest.updateMany({
    where: { projectId: a1.id, targetOrganizationId: rockAdmin.organizationId },
    data: { status: "APPROVED" },
  });
  console.log("(fixture state reset)\n");

  console.log("=== A. Input persistence on create ===");
  await expectThrows("VALIDATION_ERROR", "create with INVALID input rejected", () =>
    createLabTest(geoManager, {
      sampleId: hostSample.id, testType: "WATER_CONTENT",
      input: { ovenTemperatureC: 500 }, // out of the 100–120 range
    }),
  );
  const created = await createLabTest(geoManager, {
    sampleId: hostSample.id, testType: "WATER_CONTENT", input: WC_INPUT,
  });
  if (created.inputData != null && (created.inputData as { containerId?: string }).containerId === "TIN-M5") {
    ok("create with input → inputData stored and returned");
  } else no(`create with input wrong: ${JSON.stringify(created.inputData)}`);

  const createdBare = await createLabTest(geoManager, {
    sampleId: hostSample.id, testType: "DIRECT_SHEAR",
  });
  if (createdBare.inputData === null) ok("create without input → inputData null");
  else no(`bare create inputData not null: ${JSON.stringify(createdBare.inputData)}`);

  const detail = await getLabTest(geoManager, created.id);
  if (detail.inputData != null && (detail.inputData as { containerId?: string }).containerId === "TIN-M5") {
    ok("getLabTest returns inputData on detail");
  } else no("detail inputData missing");

  console.log("=== B. Activity details (approved D7: reuse, no vocabulary growth) ===");
  {
    const acts = await db.activityLog.findMany({
      where: { entityType: "LabTest", entityId: created.id, action: "LAB_TEST_CREATED" },
      orderBy: { createdAt: "desc" }, take: 1,
    });
    const d = acts[0]?.details as { inputRecorded?: boolean } | null;
    if (d?.inputRecorded === true) ok("LAB_TEST_CREATED details note inputRecorded (existing action reused)");
    else no(`LAB_TEST_CREATED details wrong: ${JSON.stringify(acts[0]?.details)}`);
  }

  console.log("=== C. Editability rule (approved D2) ===");
  const patched = await updateLabTest(geoManager, created.id, { input: WC_INPUT_ALT });
  if ((patched.inputData as { containerId?: string }).containerId === "TIN-M5B") {
    ok("input editable while PENDING (no result yet)");
  } else no("input edit while pending failed");
  {
    const acts = await db.activityLog.findMany({
      where: { entityType: "LabTest", entityId: created.id, action: "LAB_TEST_STATUS_UPDATED" },
      orderBy: { createdAt: "desc" },
    });
    const noted = acts.some((a) => (a.details as { inputUpdated?: boolean } | null)?.inputUpdated === true);
    if (noted) ok("LAB_TEST_STATUS_UPDATED details note inputUpdated");
    else no("inputUpdated not logged in activity details");
  }

  await recordLabTestResult(geoEngineer, created.id, { waterContentPercent: 21.3 }, { summary: "w = 21.3%" });
  await expectThrows("CONFLICT", "input locked once a result exists", () =>
    updateLabTest(geoManager, created.id, { input: WC_INPUT }),
  );

  const reopened = await updateLabTest(geoManager, created.id, { status: "IN_PROGRESS" });
  if (reopened.resultData === null && reopened.status === "IN_PROGRESS") {
    ok("re-opening clears the result (existing rule intact)");
  } else no(`reopen wrong: status=${reopened.status} result=${JSON.stringify(reopened.resultData)}`);

  const editedAfterReopen = await updateLabTest(geoManager, created.id, { input: WC_INPUT });
  if ((editedAfterReopen.inputData as { containerId?: string }).containerId === "TIN-M5") {
    ok("re-opening re-enables input editing");
  } else no("input edit after reopen failed");

  // Record a result again, then reopen + edit input in a SINGLE PATCH.
  await recordLabTestResult(geoEngineer, created.id, { waterContentPercent: 22.1 });
  const reopenWithInput = await updateLabTest(geoManager, created.id, {
    status: "IN_PROGRESS", input: WC_INPUT_ALT,
  });
  if (
    reopenWithInput.status === "IN_PROGRESS" &&
    reopenWithInput.resultData === null &&
    (reopenWithInput.inputData as { containerId?: string }).containerId === "TIN-M5B"
  ) {
    ok("single PATCH: reopen + input edit (lock released in the same request)");
  } else no(`reopen+input wrong: ${JSON.stringify({ s: reopenWithInput.status, r: reopenWithInput.resultData, i: reopenWithInput.inputData })}`);

  await expectThrows("VALIDATION_ERROR", "input edit with INVALID payload rejected", () =>
    updateLabTest(geoManager, created.id, { input: { containerId: 42 } }),
  );

  console.log("=== D. New result shapes through the service ===");
  await recordLabTestResult(geoEngineer, createdBare.id, DS_STAGES_RESULT, { summary: "stages format" });
  const dsDetail = await getLabTest(geoManager, createdBare.id);
  if ((dsDetail.resultData as { stages?: unknown[] }).stages?.length === 2) {
    ok("DIRECT_SHEAR stages[] result recordable through the service");
  } else no("DS stages result not stored");

  const pmt = await createLabTest(geoManager, {
    sampleId: hostSample.id, testType: "PRESSUREMETER", input: PMT_INPUT,
  });
  await expectThrows("VALIDATION_ERROR", "invalid PRESSUREMETER result rejected", () =>
    recordLabTestResult(geoEngineer, pmt.id, { ...PMT_RESULT, emPlRatio: 99 }),
  );
  await recordLabTestResult(geoEngineer, pmt.id, PMT_RESULT, { summary: "EM 11.2 MPa" });
  const pmtDetail = await getLabTest(geoManager, pmt.id);
  const pmtResult = pmtDetail.resultData as { limitPressureKpa?: number; points?: unknown[] } | null;
  if (pmtDetail.status === "COMPLETED" && pmtResult?.limitPressureKpa === 900 && pmtResult?.points?.length === 6) {
    ok("PRESSUREMETER end-to-end: input + validated result through the service");
  } else no(`PMT round-trip wrong: ${JSON.stringify(pmtDetail.resultData)?.slice(0, 120)}`);
  if (pmtDetail.registry?.label === "Pressuremeter (Ménard)") {
    ok("detail embeds PRESSUREMETER registry metadata");
  } else no("PMT registry metadata missing");

  console.log("=== E. List shape backward compatibility (approved D3) ===");
  const listDefault = await listLabTests(geoManager, { sampleId: hostSample.id, pageSize: 50 });
  const itemsDefault = listDefault.items as Record<string, unknown>[];
  if (itemsDefault.length >= 3) {
    const first = itemsDefault[0];
    if ("resultData" in first) ok("list items still include resultData (default unchanged)");
    else no("list items lost resultData");
    if (!("inputData" in first)) ok("list items do NOT expose inputData (detail-only field)");
    else no("list items leak inputData — default response changed");
  } else no(`list unexpected length: ${itemsDefault.length}`);

  const listInclude = await listLabTests(geoManager, { sampleId: hostSample.id, include: "resultData" });
  const itemsInclude = listInclude.items as Record<string, unknown>[];
  if (itemsInclude.length === itemsDefault.length && "resultData" in itemsInclude[0] && !("inputData" in itemsInclude[0])) {
    ok("include=resultData accepted; payload shape identical to default");
  } else no("include=resultData changed the payload shape");

  console.log("=== F. RBAC on the new surface ===");
  await expectThrows("FORBIDDEN", "viewer cannot create a test with input", () =>
    createLabTest(geoViewer, {
      sampleId: hostSample.id, testType: "WATER_CONTENT", input: WC_INPUT,
    }),
  );
  await expectThrows("FORBIDDEN", "viewer cannot edit inputs", () =>
    updateLabTest(geoViewer, created.id, { input: WC_INPUT }),
  );
  const viewerRead = await getLabTest(geoViewer, created.id);
  if ((viewerRead.inputData as { containerId?: string } | null)?.containerId === "TIN-M5B") {
    ok("viewer can READ inputData (view capability unchanged)");
  } else no("viewer read of inputData failed");

  console.log("=== G. Tenant isolation on the new surface ===");
  await expectThrows("NOT_FOUND", "foreign org cannot edit inputs on a shared-project test", () =>
    updateLabTest(rockAdmin, created.id, { input: WC_INPUT }),
  );
  await expectThrows("NOT_FOUND", "foreign org cannot create a test with input on another org's sample", () =>
    createLabTest(rockAdmin, {
      sampleId: hostSample.id, testType: "WATER_CONTENT", input: WC_INPUT,
    }),
  );
  {
    // Read-only shared access: RockWorks reads a GeoStruct test inside the
    // approved-share project — inputData readable, writes rejected.
    const a1Tests = await db.labTest.findMany({
      where: { sample: { borehole: { project: { code: "A1-TEN-2025" } } } },
      select: { id: true, inputData: true },
    });
    const sharedTest = a1Tests.find((t) => t.inputData !== null);
    if (!sharedTest) throw new Error("fixture missing: no A1 test with inputData");
    const shared = await getLabTest(rockEngineer, sharedTest.id);
    if (shared.accessSource === "shared" && shared.inputData !== null) {
      ok("shared-project read includes inputData (read-only share)");
    } else no(`shared read wrong: source=${shared.accessSource} input=${shared.inputData === null ? "null" : "present"}`);
    await expectThrows("NOT_FOUND", "shared-project test stays read-only for inputs", () =>
      updateLabTest(rockEngineer, sharedTest.id, { input: WC_INPUT }),
    );
  }

  console.log("=== H. Cleanup ===");
  await deleteLabTest(geoManager, created.id);
  await deleteLabTest(geoManager, createdBare.id);
  await deleteLabTest(geoManager, pmt.id);
  const leftover = await db.labTest.count({
    where: { sampleId: hostSample.id, testType: { in: ["WATER_CONTENT", "PRESSUREMETER", "DIRECT_SHEAR"] } },
  });
  if (leftover === 0) ok("M5 fixtures cleaned up");
  else no(`cleanup left ${leftover} fixtures`);

  console.log(`\n================ M5.1 SERVICES TEST SUMMARY: ${pass} passed, ${fail} failed ================`);
  process.exit(fail);
}

main()
  .catch((e) => {
    console.error("SERVICES TEST CRASHED:", e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
