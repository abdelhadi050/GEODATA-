#!/usr/bin/env bash
# M5.3 frontend integration browser suite (agent-browser, semantic locators).
# Assumes: dev server ALREADY RUNNING at 127.0.0.1:3000 with freshly seeded DB
# (the run protocol starts both in the SAME bash invocation — the sandbox
# process-group rule kills background servers between invocations).
# Fixtures are deterministic (seed + createdAt-desc list order); navigation is
# done through the rendered UI (entity ids are NOT stable across seeds).
set -u
cd /home/z/my-project

BASE=http://127.0.0.1:3000
SHOTS=download/m5.3-screenshots
mkdir -p "$SHOTS"
PASS=0; FAIL=0
ok(){ echo "PASS: $1"; PASS=$((PASS+1)); }
no(){ echo "FAIL: $1"; FAIL=$((FAIL+1)); }
body(){ agent-browser eval "document.body.innerText" 2>/dev/null; }
shot(){ agent-browser screenshot "$SHOTS/$1" >/dev/null 2>&1 || echo "  (screenshot $1 failed)"; }
waitidle(){ agent-browser wait --load networkidle >/dev/null 2>&1; sleep 1; }
evaljs(){ agent-browser eval "$1" 2>/dev/null | tr -d '"'; }

# Verified React-compatible fill (native setter + input event); retries while
# hydration races could reset values.
vfill(){
  # $1 = CSS selector (attribute values in DOUBLE quotes), $2 = value
  for _i in $(seq 1 10); do
    agent-browser eval "(function(){const el=document.querySelector('$1');if(!el)return 'missing';const s=Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,'value').set;s.call(el,'$2');el.dispatchEvent(new Event('input',{bubbles:true}));return el.value==='$2'?'filled':el.value;})()" 2>/dev/null | tr -d '"' | grep -q '^filled$' && return 0
    sleep 1
  done
  return 1
}

login(){
  agent-browser close >/dev/null 2>&1 || true
  agent-browser open "$BASE/login" >/dev/null 2>&1; waitidle
  vfill "#email" "$1" || no "login email fill ($1)"
  vfill "#password" "$2" || no "login password fill"
  agent-browser find role button click --name "Sign in" >/dev/null 2>&1
  agent-browser wait --url "/dashboard" --timeout 25000 >/dev/null 2>&1
  for _i in $(seq 1 15); do
    agent-browser eval "document.querySelector('[data-slot=sidebar-inner]')!==null" 2>/dev/null | tr -d '"' | grep -q true && break
    sleep 1
  done
  sleep 0.5
}
logout(){
  agent-browser open "$BASE/dashboard" >/dev/null 2>&1; waitidle
  for _i in $(seq 1 15); do
    agent-browser eval "[...document.querySelectorAll('button')].some(b=>b.textContent.trim()==='Sign out')" 2>/dev/null | tr -d '"' | grep -q true && break
    sleep 1
  done
  agent-browser find role button click --name "Sign out" >/dev/null 2>&1
  agent-browser wait --url "/login" --timeout 15000 >/dev/null 2>&1
  waitidle
}
await_text(){ # $1 = text expected in body; bounded poll for client refreshes
  for _i in $(seq 1 25); do
    agent-browser eval "document.body.innerText.includes('$1')" 2>/dev/null | tr -d '"' | grep -q true && return 0
    sleep 1
  done
  return 1
}
await_selector(){ # $1 = CSS selector; bounded poll for its appearance
  for _i in $(seq 1 25); do
    agent-browser eval "document.querySelector('$1')!==null" 2>/dev/null | tr -d '"' | grep -q true && return 0
    sleep 1
  done
  return 1
}
await_hist_count(){ # $1 = expected count of history rows
  for _i in $(seq 1 25); do
    N=$(evaljs "document.querySelectorAll('[data-testid=calculation-history-row]').length")
    [ "$N" = "$1" ] && return 0
    sleep 1
  done
  return 1
}
calc_and_wait(){ # click Calculate from recorded data (retries across hydration races)
  for _i in $(seq 1 6); do
    agent-browser find role button click --name "Calculate from recorded data" >/dev/null 2>&1
    for _j in $(seq 1 5); do
      agent-browser eval "document.querySelector('[data-testid=calculate-result]')!==null" 2>/dev/null | tr -d '"' | grep -q true && return 0
      sleep 1
    done
  done
  return 1
}
open_explicit_form(){ # open the explicit-input form (retries across hydration races)
  for _i in $(seq 1 8); do
    agent-browser find role button click --name "Explicit analyst input" >/dev/null 2>&1
    sleep 1
    agent-browser eval "document.querySelector('[id^=x-]')!==null" 2>/dev/null | tr -d '"' | grep -q true && return 0
  done
  return 1
}
select_casagrande(){ # pick CASAGRANDE_CUP in the atterberg method select (with verification)
  for _i in $(seq 1 6); do
    agent-browser click "#x-method" >/dev/null 2>&1; sleep 0.8
    agent-browser find role option click --name "Casagrande cup" >/dev/null 2>&1; sleep 0.8
    agent-browser eval "(function(){const t=document.querySelector('#x-method');return !!t&&t.textContent.includes('Casagrande');})()" 2>/dev/null | tr -d '"' | grep -q true && return 0
  done
  return 1
}
run_explicit_and_wait(){ # click Run with explicit input; result box OR validation error
  for _i in $(seq 1 6); do
    agent-browser find role button click --name "Run with explicit input" >/dev/null 2>&1
    for _j in $(seq 1 5); do
      agent-browser eval "document.querySelector('[data-testid=calculate-result],[data-testid=calculate-form-error]')!==null" 2>/dev/null | tr -d '"' | grep -q true && return 0
      sleep 1
    done
  done
  return 1
}
nth_test_href(){ # $1 = index (0-based) of a[href^="/lab-tests/"] link on the current list page
  evaljs "(function(){return [...document.querySelectorAll('a[href^=\"/lab-tests/\"]')][$1]?.getAttribute('href')||'';})()"
}
hist_count(){ evaljs "document.querySelectorAll('[data-testid=calculation-history-row]').length"; }
latest_empty(){ evaljs "document.querySelector('[data-testid=no-latest-calculation]')!==null"; }
chart_present(){ evaljs "document.querySelector('[data-testid=calculation-output] svg.recharts-surface')!==null"; }
open_test(){ # $1 = testType filter value, $2 = link name, $3 = 0-based index (default 0)
  agent-browser open "$BASE/lab-tests?testType=$1&status=COMPLETED" >/dev/null 2>&1; waitidle
  local IDX="${3:-0}"
  local HREF
  if [ "$IDX" = "0" ]; then
    agent-browser find role link click --name "$2" >/dev/null 2>&1
  else
    HREF=$(nth_test_href "$IDX")
    agent-browser open "$BASE$HREF" >/dev/null 2>&1
  fi
  await_text "Test record" || true
  waitidle
}
add_array_row(){ # $1 = data-testid of the array block
  agent-browser eval "(function(){const b=document.querySelector('[data-testid=$1]');if(!b)return 'missing';const btn=[...b.querySelectorAll('button')].find(x=>x.textContent.trim()==='Row');if(!btn)return 'nobtn';btn.click();return 'added';})()" >/dev/null 2>&1
  sleep 0.4
}
fill_row(){ # $1 = array aria-label prefix, $2 = row number, $3 = field aria suffix, $4 = value
  vfill "[aria-label=\"$1 row $2 $3\"]" "$4" || true
}

agent-browser close >/dev/null 2>&1 || true

echo "=== M5.3-01: engineer login ==="
login engineer@geodata.demo Demo1234!
URL=$(agent-browser get url 2>/dev/null)
case "$URL" in */dashboard*) ok "engineer login";; *) no "engineer login (got $URL)";; esac
B=$(body)
echo "$B" | grep -q "Karim Bouzidi" && ok "engineer identity in shell" || no "engineer identity"

# ---------------------------------------------------------------------------
echo "=== M5.3-02: proctor test page — calculation section, engine info, empty states ==="
open_test PROCTOR "Proctor compaction"
PROCTOR_URL=$(agent-browser get url 2>/dev/null)
case "$PROCTOR_URL" in */lab-tests/*) ok "opened first PROCTOR test";; *) no "proctor navigation";; esac
B=$(body)
echo "$B" | grep -q "Latest valid calculation" && ok "latest-valid card present" || no "latest-valid card"
echo "$B" | grep -q "Run calculation" && ok "run-calculation card present" || no "run-calculation card"
echo "$B" | grep -q "Calculation history" && ok "history card present" || no "history card"
echo "$B" | grep -q "module proctor v1.0.0" && ok "engine discovery line (module proctor v1.0.0)" || no "engine discovery line"
echo "$B" | grep -q "MDD/OMC" && ok "engine description shown (moisture–density curve label)" || no "engine description"
[ "$(latest_empty)" = "true" ] && ok "latest empty state (no calculation yet)" || no "latest empty state"
echo "$B" | grep -q "No calculations recorded for this test yet" && ok "history empty state" || no "history empty state"
echo "$B" | grep -q "TRAM-CNS-2025" && ok "deterministic fixture (TRAM proctor CS-01)" || no "fixture project (TRAM expected)"

echo "=== M5.3-03: calculate from recorded data — proctor golden (MDD 1.971 @ 13.75) ==="
calc_and_wait && ok "calculation submitted (result box appeared)" || no "result box"
await_text "1.971" && ok "proctor golden MDD 1.971 displayed" || no "proctor MDD golden"
B=$(body)
echo "$B" | grep -q "Max dry density (fitted)" && ok "MDD labeled with unit (Mg/m³)" || no "MDD label"
echo "$B" | grep -q "13.75 %" && ok "proctor OMC 13.75 %" || no "proctor OMC"
echo "$B" | grep -q "1.97 Mg/m³" && ok "entered echo 1.97 shown (entered group)" || no "entered echo MDD"
echo "$B" | grep -q "13.5 %" && ok "entered echo 13.5 % shown" || no "entered echo OMC"
echo "$B" | grep -q "Laboratory-entered values" && ok "entered values visually separated" || no "entered group heading"
[ "$(chart_present)" = "true" ] && ok "proctor compaction chart rendered" || no "proctor chart"
shot "01-labtest-proctor-calculation.png"

echo "=== M5.3-04: history row (Completed / Valid / Recorded data) ==="
await_hist_count 1 && ok "history has 1 row (refresh landed)" || no "history row count $(hist_count)"
B=$(body)
echo "$B" | grep -q "Completed" && ok "history status Completed" || no "history status"
echo "$B" | grep -q "Valid" && ok "history validity Valid" || no "history validity"
echo "$B" | grep -q "Recorded data" && ok "history source Recorded data" || no "history source"

echo "=== M5.3-05: latest valid card filled after refresh ==="
for _i in $(seq 1 20); do [ "$(latest_empty)" = "false" ] && break; sleep 1; done
[ "$(latest_empty)" = "false" ] && ok "latest valid card filled" || no "latest valid card still empty"
B=$(body)
echo "$B" | grep -q "from the current recorded data" && ok "latest provenance line (current data)" || no "latest provenance"

echo "=== M5.3-06: calculation record detail page ==="
DETAIL_HREF=$(evaljs "(function(){const l=[...document.querySelectorAll('a')].find(a=>a.textContent.includes('View full record'));return l?l.getAttribute('href'):'';})()")
agent-browser open "$BASE$DETAIL_HREF" >/dev/null 2>&1; waitidle
await_text "Calculation — Proctor compaction" && ok "record detail page title" || no "record detail title"
B=$(body)
echo "$B" | grep -q "Provenance" && ok "provenance card" || no "provenance card"
echo "$B" | grep -q "Input snapshot (immutable)" && ok "input snapshot card" || no "input snapshot card"
echo "$B" | grep -q "Input fingerprint" && ok "input fingerprint shown" || no "input fingerprint"
echo "$B" | grep -q "STANDARD effort" && ok "method provenance (STANDARD effort)" || no "method provenance"
echo "$B" | grep -q "ASTM D698" && ok "standard citation (ASTM D698)" || no "standard citation"
echo "$B" | grep -q "Calculated output" && ok "calculated output card" || no "calculated output"
echo "$B" | grep -q "Back to test" && ok "back-to-test link" || no "back-to-test link"
shot "02-calculation-record-detail.png"
agent-browser open "$PROCTOR_URL" >/dev/null 2>&1; waitidle

echo "=== M5.3-07: duplicate submission safety — second identical run deduplicates ==="
agent-browser find role button click --name "Calculate from recorded data" >/dev/null 2>&1
await_selector '[data-testid=calculate-result]'
await_text "no change" && ok "dedup notice shown (no change — existing record returned)" || no "dedup notice"
N=$(hist_count)
[ "$N" = "1" ] && ok "no duplicate record created (history still 1)" || no "duplicate record (history $N)"

# ---------------------------------------------------------------------------
echo "=== M5.3-08: water content stored-data golden (w 18.5 %) ==="
open_test WATER_CONTENT "Water content"
calc_and_wait && ok "WC calculation submitted" || no "WC result box"
await_text "18.5 %" && ok "WC golden w = 18.5 %" || no "WC golden"
B=$(body)
echo "$B" | grep -q "30.2 g" && ok "WC water mass 30.2 g" || no "WC water mass"
echo "$B" | grep -q "163.2 g" && ok "WC dry soil mass 163.2 g" || no "WC dry soil mass"
WC_URL=$(agent-browser get url 2>/dev/null)

echo "=== M5.3-09: massless water content — FAILED record displayed, latest stays empty ==="
open_test WATER_CONTENT "Water content" 2
B=$(body)
echo "$B" | grep -q "Borehole PM-01" && ok "massless WC fixture (PM-01/S-01, borehole PM-01)" || no "massless WC fixture"
calc_and_wait && ok "massless WC calculation submitted" || no "massless WC result box"
await_text "Calculation failed" && ok "failure alert shown" || no "failure alert"
B=$(body)
echo "$B" | grep -q "MISSING_INPUT" && ok "engine error code MISSING_INPUT" || no "engine error code"
echo "$B" | grep -q "wetMassG, dryMassG, containerMassG" && ok "engine error message verbatim" || no "engine error message"
[ "$(latest_empty)" = "true" ] && ok "latest valid stays empty (failed never becomes current)" || no "latest after failure"
await_hist_count 1 && ok "FAILED record kept in history" || no "failed history row ($(hist_count))"
shot "03-labtest-watercontent-failed.png"

# ---------------------------------------------------------------------------
echo "=== M5.3-10: CBR stored-data golden (86.17 % @ 5.0 mm, warnings shown) ==="
open_test CBR "California Bearing Ratio"
calc_and_wait && ok "CBR calculation submitted" || no "CBR result box"
await_text "86.17 %" && ok "CBR golden 86.17 %" || no "CBR golden"
B=$(body)
echo "$B" | grep -q "5.0MM" && ok "CBR governing penetration 5.0MM" || no "CBR governing"
echo "$B" | grep -q "8.9 kN" && ok "CBR load at 2.5 mm (8.9 kN)" || no "CBR load 2.5"
echo "$B" | grep -q "REPORTING_RULE" && ok "CBR REPORTING_RULE warning displayed" || no "CBR reporting warning"
echo "$B" | grep -q "ENTERED_VALUE_DISCREPANCY" && ok "CBR entered-discrepancy warnings displayed" || no "CBR discrepancy warnings"
echo "$B" | grep -q "Entered CBR value" && ok "CBR entered echo group" || no "CBR entered echo"
[ "$(chart_present)" = "true" ] && ok "CBR curve chart rendered" || no "CBR chart"

echo "=== M5.3-11: oedometer stored-data golden via registry adapter (Cc 0.1545) ==="
open_test OEDOMETER "Oedometer consolidation"
calc_and_wait && ok "oedometer calculation submitted" || no "oedometer result box"
await_text "0.1545" && ok "oedometer golden Cc 0.1545 (stages→loadingStages adapter)" || no "oedometer Cc golden"
B=$(body)
echo "$B" | grep -q "129.4 kPa" && ok "oedometer σ′p 129.4 kPa (Casagrande)" || no "oedometer σ′p"
echo "$B" | grep -q "Casagrande" && ok "oedometer method provenance" || no "oedometer method"
echo "$B" | grep -q "0.155" && ok "oedometer entered Cc echo 0.155" || no "oedometer entered Cc"
echo "$B" | grep -q "INSUFFICIENT_DATA" && ok "oedometer INSUFFICIENT_DATA warning shown (Cv not derivable)" || no "oedometer warning"
[ "$(chart_present)" = "true" ] && ok "oedometer e–log p chart rendered" || no "oedometer chart"
shot "04-labtest-oedometer.png"

# ---------------------------------------------------------------------------
echo "=== M5.3-12: direct shear multi-stage golden (c′ 19.67 kPa, φ′ 25.17°) ==="
open_test DIRECT_SHEAR "Direct shear" 1
B=$(body)
echo "$B" | grep -q "Sample S-04" && ok "multi-stage DS fixture (BH-01/S-04, sample S-04)" || no "multi-stage DS fixture"
calc_and_wait && ok "DS calculation submitted" || no "DS result box"
await_text "19.67 kPa" && ok "DS golden c′ 19.67 kPa" || no "DS c′ golden"
B=$(body)
echo "$B" | grep -q "25.17 °" && ok "DS golden φ′ 25.17°" || no "DS φ′ golden"
echo "$B" | grep -q "0.9998" && ok "DS fit R² 0.9998" || no "DS R²"
echo "$B" | grep -q "Shear stages" && ok "DS stages table" || no "DS stages table"
[ "$(chart_present)" = "true" ] && ok "DS envelope chart rendered" || no "DS chart"

echo "=== M5.3-13: pressuremeter stored-data run (completed, echoes + curve) ==="
open_test PRESSUREMETER "Pressuremeter"
calc_and_wait && ok "PMT calculation submitted" || no "PMT result box"
B=$(body)
echo "$B" | grep -q "Calculation failed" && no "PMT engine failure (unexpected)" || ok "PMT engine completed"
echo "$B" | grep -q "Pressure–volume readings" && ok "PMT curve table" || no "PMT curve table"
echo "$B" | grep -q "24.8 MPa" && ok "PMT entered EM echo 24.8 MPa" || no "PMT EM echo"
echo "$B" | grep -q "1750 kPa" && ok "PMT entered PL echo 1750 kPa" || no "PMT PL echo"
[ "$(chart_present)" = "true" ] && ok "PMT curve chart rendered" || no "PMT chart"
shot "05-labtest-pressuremeter.png"

# ---------------------------------------------------------------------------
echo "=== M5.3-14: granulometry stored data fails (sieve order — no silent sorting) ==="
open_test GRANULOMETRY "Granulometry"
GRAN_URL=$(agent-browser get url 2>/dev/null)
calc_and_wait && ok "granulometry stored-data calculation submitted" || no "granulometry result box"
await_text "Calculation failed" && ok "granulometry stored-data failure shown" || no "granulometry failure"
B=$(body)
echo "$B" | grep -q "INVALID_INPUT" && ok "granulometry INVALID_INPUT code" || no "granulometry code"
echo "$B" | grep -q "strictly increasing diameterMm" && ok "granulometry ordering message verbatim" || no "granulometry message"

echo "=== M5.3-15: granulometry explicit input — prefill reorder + engine golden ==="
open_explicit_form && ok "explicit form opened" || no "explicit form open"
await_text "reordered by increasing diameter" && ok "prefill reorder notice (visible, not silent)" || no "prefill reorder notice"
FIRST_D=$(evaljs "(function(){const i=document.querySelector('[aria-label=\"Sieve / hydrometer points row 1 Diameter\"]');return i?i.value:'missing';})()")
LAST_D=$(evaljs "(function(){const rows=[...document.querySelectorAll('[aria-label^=\"Sieve / hydrometer points row\"]')].filter(i=>i.getAttribute('aria-label').includes('Diameter'));return rows.length?rows[rows.length-1].value:'missing';})()")
[ "$FIRST_D" = "0.002" ] && ok "prefilled first row diameter 0.002 (ascending)" || no "prefill first row ($FIRST_D)"
[ "$LAST_D" = "63" ] && ok "prefilled last row diameter 63" || no "prefill last row ($LAST_D)"
run_explicit_and_wait || no "granulometry explicit run"
await_text "76.504" && ok "granulometry explicit golden Cu 76.504" || no "granulometry Cu golden"
B=$(body)
echo "$B" | grep -q "0.0097 mm" && ok "granulometry d10 0.0097 mm" || no "granulometry d10"
echo "$B" | grep -q "0.151 mm" && ok "granulometry d30 0.151 mm" || no "granulometry d30"
echo "$B" | grep -q "0.743 mm" && ok "granulometry d60 0.743 mm" || no "granulometry d60"
echo "$B" | grep -q "3.16" && ok "granulometry Cc 3.16" || no "granulometry Cc"
echo "$B" | grep -q "21.78 %" && ok "granulometry passing 0.075 mm 21.78 %" || no "granulometry passing"
echo "$B" | grep -q "Explicit input" && ok "EXPLICIT source badge on result" || no "explicit badge"
[ "$(chart_present)" = "true" ] && ok "granulometry grading chart (from input snapshot)" || no "granulometry chart"
shot "06-labtest-granulometry-explicit.png"

echo "=== M5.3-16: explicit record never becomes the latest valid result ==="
[ "$(latest_empty)" = "true" ] && ok "latest still empty (EXPLICIT never current — M5.2 semantics)" || no "latest wrongly filled by explicit"
await_hist_count 2 && ok "history: 1 FAILED stored + 1 COMPLETED explicit" || no "granulometry history count ($(hist_count))"

# ---------------------------------------------------------------------------
echo "=== M5.3-17: atterberg stored data fails (entered finals only) ==="
open_test ATTERBERG_LIMITS "Atterberg limits"
ATT_URL=$(agent-browser get url 2>/dev/null)
calc_and_wait && ok "atterberg stored-data calculation submitted" || no "atterberg result box"
await_text "Calculation failed" && ok "atterberg stored-data failure shown" || no "atterberg failure"
B=$(body)
echo "$B" | grep -q "method, liquidLimitPoints" && ok "atterberg MISSING_INPUT lists engine fields" || no "atterberg missing fields"

echo "=== M5.3-18: atterberg explicit flow data — LL 42.48 golden + warnings ==="
open_explicit_form && ok "atterberg explicit form opened" || no "atterberg form open"
select_casagrande && ok "method Casagrande cup selected" || no "method selection"
# Flow-curve points: 3 prefilled rows + add a 4th
add_array_row "array-liquidLimitPoints"
fill_row "Flow-curve points" 1 "Blows N" "15"
fill_row "Flow-curve points" 1 "Water content" "48.2"
fill_row "Flow-curve points" 2 "Blows N" "20"
fill_row "Flow-curve points" 2 "Water content" "45.6"
fill_row "Flow-curve points" 3 "Blows N" "30"
fill_row "Flow-curve points" 3 "Water content" "40.3"
fill_row "Flow-curve points" 4 "Blows N" "40"
fill_row "Flow-curve points" 4 "Water content" "36.8"
# Plastic limit trials: 1 prefilled row + add a 2nd
add_array_row "array-plasticLimitTrials"
fill_row "Plastic limit trials" 1 "Trial water content" "18"
fill_row "Plastic limit trials" 2 "Trial water content" "20"
# Prefilled entered values (55 / 24 / 31) stay as-is — the golden includes them
run_explicit_and_wait || no "atterberg explicit run"
await_text "42.48 %" && ok "atterberg explicit golden LL 42.48 %" || no "atterberg LL golden"
B=$(body)
echo "$B" | grep -q "23.48 %" && ok "atterberg PI 23.48 %" || no "atterberg PI"
echo "$B" | grep -q "deviates by -12.52 percentage points" && ok "atterberg entered-discrepancy warning verbatim" || no "atterberg warning text"
echo "$B" | grep -q "55 %" && ok "atterberg entered LL 55 echo (prefilled, echoed)" || no "atterberg entered LL echo"
echo "$B" | grep -q "Flow curve" && ok "atterberg flow-curve chart" || no "atterberg flow chart"
echo "$B" | grep -q "Plasticity chart position" && ok "atterberg plasticity chart" || no "atterberg plasticity chart"
shot "07-labtest-atterberg-explicit.png"

# ---------------------------------------------------------------------------
echo "=== M5.3-19: client-side validation blocks submission, values preserved ==="
agent-browser open "$WC_URL" >/dev/null 2>&1; waitidle
open_explicit_form || no "WC explicit form open"
vfill "[aria-label=\"x Entered water content\"]" "20" || true
vfill "[aria-label=\"x Wet gross mass\"]" "100" || true
vfill "[aria-label=\"x Dry gross mass\"]" "200" || true
vfill "[aria-label=\"x Container (tare) mass\"]" "50" || true
run_explicit_and_wait || true
await_text "must be greater than dryMassG" && ok "client-side engine validation error shown" || no "client validation error"
V=$(evaljs "(function(){const i=document.querySelector('[aria-label=\"x Wet gross mass\"]');return i?i.value:'missing';})()")
[ "$V" = "100" ] && ok "entered values preserved after validation failure" || no "values preserved ($V)"
await_hist_count 1 && ok "no record created by blocked submission" || no "blocked submission created record ($(hist_count))"

# ---------------------------------------------------------------------------
echo "=== M5.3-20: invalidation — result edit marks the calculation stale ==="
agent-browser open "$PROCTOR_URL" >/dev/null 2>&1; waitidle
agent-browser find role button click --name "Edit result" >/dev/null 2>&1; sleep 1
vfill "#s-maxDryDensity" "1.98" || agent-browser find label "Max dry density (MDD)" fill "1.98" >/dev/null 2>&1 || true
agent-browser find role button click --name "Save result" >/dev/null 2>&1
await_text "Stale" && ok "history row flagged Stale after result change" || no "stale flag"
for _i in $(seq 1 20); do [ "$(latest_empty)" = "true" ] && break; sleep 1; done
[ "$(latest_empty)" = "true" ] && ok "latest valid cleared (stale not served as current)" || no "latest after invalidation"
shot "08-labtest-proctor-stale.png"

echo "=== M5.3-21: recalculation restores a valid latest (new immutable record) ==="
calc_and_wait && ok "recalculation submitted" || no "recalculation result box"
await_text "1.971" && ok "recalculation golden MDD 1.971 again" || no "recalculation golden"
for _i in $(seq 1 20); do [ "$(latest_empty)" = "false" ] && break; sleep 1; done
[ "$(latest_empty)" = "false" ] && ok "latest valid restored" || no "latest restored"
await_hist_count 2 && ok "history preserved: 2 records (valid + stale)" || no "history after recalc ($(hist_count))"

echo "=== M5.3-22: stale record detail — invalidation info ==="
STALE_HREF=$(evaljs "(function(){const rows=[...document.querySelectorAll('[data-testid=calculation-history-row]')];const l=rows[rows.length-1].querySelector('a[href^=\"/calculations/\"]');return l?l.getAttribute('href'):'';})()")
agent-browser open "$BASE$STALE_HREF" >/dev/null 2>&1; waitidle
B=$(body)
echo "$B" | grep -q "Stale record" && ok "stale notice on record page" || no "stale notice"
echo "$B" | grep -q "invalidated because the recorded laboratory result changed" && ok "invalidation reason displayed" || no "invalidation reason"
echo "$B" | grep -q "preserved as history" && ok "history-preservation note" || no "history note"

# ---------------------------------------------------------------------------
echo "=== M5.3-23: project Calculations tab (project-scoped listing) ==="
agent-browser open "$BASE/projects" >/dev/null 2>&1; waitidle
agent-browser find role link click --name "TRAM-CNS-2025" >/dev/null 2>&1; waitidle
B=$(body)
echo "$B" | grep -q "Calculations (5)" && ok "project tab shows record count (5)" || no "project tab count"
agent-browser find role tab click --name "Calculations" >/dev/null 2>&1
await_selector '[data-testid=project-calculations]' && ok "project calculations tab content loaded" || no "project tab content"
B=$(body)
ROWS=$(evaljs "document.querySelectorAll('[data-testid=project-calculations] tbody tr').length")
[ "$ROWS" = "5" ] && ok "project calculations table lists 5 records" || no "project table rows ($ROWS)"
echo "$B" | grep -q "PROCTOR" && ok "project listing shows PROCTOR records" || no "project proctor record"
echo "$B" | grep -q "ATTERBERG_LIMITS" && ok "project listing shows ATTERBERG_LIMITS records" || no "project atterberg record"
shot "09-project-calculations.png"

# ---------------------------------------------------------------------------
echo "=== M5.3-24: engine-less test type (SPT) ==="
agent-browser open "$BASE/lab-tests?testType=SPT&status=COMPLETED" >/dev/null 2>&1; waitidle
agent-browser find role link click --name "Standard Penetration Test" >/dev/null 2>&1
await_text "Test record" || true; waitidle
B=$(body)
echo "$B" | grep -q "No calculation engine is registered" && ok "no-engine notice for SPT" || no "no-engine notice"
BTN=$(evaljs "(function(){const b=document.querySelector('[data-testid=calculate-stored]');return b?String(b.disabled):'absent';})()")
[ "$BTN" = "absent" ] && ok "no calculate button rendered for engine-less type" || no "calculate button on engine-less ($BTN)"

# ---------------------------------------------------------------------------
echo "=== M5.3-25: RBAC — viewer cannot calculate, can read ==="
logout
login viewer@geodata.demo Demo1234!
agent-browser open "$PROCTOR_URL" >/dev/null 2>&1; waitidle
BTN=$(evaljs "(function(){const b=document.querySelector('[data-testid=calculate-stored]');return b?String(b.disabled):'absent';})()")
[ "$BTN" = "true" ] && ok "viewer: calculate button disabled" || no "viewer calculate button ($BTN)"
B=$(body)
echo "$B" | grep -q "does not include permission to run calculations" && ok "viewer: role-based disabled reason" || no "viewer reason"
N=$(hist_count)
[ "$N" = "2" ] && ok "viewer: history readable (2 rows)" || no "viewer history ($N)"
[ "$(latest_empty)" = "false" ] && ok "viewer: latest valid readable" || no "viewer latest"
echo "$B" | grep -q "Record result" && no "viewer should not see Record result" || ok "viewer: no Record result action"
shot "10-viewer-readonly.png"

# ---------------------------------------------------------------------------
echo "=== M5.3-26: cross-org — shared project is read-only for the partner org ==="
logout
login admin@rockworks.demo Demo1234!
agent-browser open "$BASE/projects" >/dev/null 2>&1; waitidle
B=$(body)
echo "$B" | grep -q "A1-TEN-2025" && ok "RockWorks sees the APPROVED shared project" || no "shared project visible"
echo "$B" | grep -q "TRAM-CNS-2025" && no "isolation failure: TRAM visible to RockWorks" || ok "isolation: TRAM project not visible"
agent-browser find role link click --name "A1-TEN-2025" >/dev/null 2>&1; waitidle
B=$(body)
echo "$B" | grep -q "read-only" && ok "shared project marked read-only" || no "shared read-only marker"
agent-browser find role tab click --name "Calculations" >/dev/null 2>&1
await_selector '[data-testid=project-calculations]' || await_text "No calculations yet" || true
B=$(body)
echo "$B" | grep -q "No calculations yet" && ok "shared project: empty calculation listing (readable, empty)" || no "shared project listing"
PROJ_URL=$(agent-browser get url 2>/dev/null)
PID=$(echo "$PROJ_URL" | sed 's|.*/projects/||')
agent-browser open "$BASE/lab-tests?projectId=$PID&testType=CBR" >/dev/null 2>&1; waitidle
agent-browser find role link click --name "California Bearing Ratio" >/dev/null 2>&1
await_text "Test record" || true; waitidle
B=$(body)
echo "$B" | grep -q "Read-only: this test belongs to a project shared" && ok "shared test: read-only notice" || no "shared test notice"
BTN=$(evaljs "(function(){const b=document.querySelector('[data-testid=calculate-stored]');return b?String(b.disabled):'absent';})()")
[ "$BTN" = "true" ] && ok "shared test: calculate disabled (server policy mirrored in UI)" || no "shared calculate button ($BTN)"
echo "$B" | grep -q "Record result" && no "shared test should not offer Record result" || ok "shared test: no Record result action"
echo "$B" | grep -q "module cbr v1.0.0" && ok "shared test: engine info still discoverable" || no "shared engine info"
shot "11-shared-readonly.png"

agent-browser close >/dev/null 2>&1 || true

echo ""
echo "============================================="
echo "M5.3 UI SUITE SUMMARY: $PASS passed, $FAIL failed"
echo "============================================="
exit $((FAIL > 0 ? 1 : 0))
