/**
 * M2 TEST — Service layer: tenant isolation, parent-child validation,
 * cross-organization access via sharing, RBAC enforcement, lab-result
 * validation through the service, and activity logging.
 * Exit code = number of failures.
 */
import { PrismaClient, Prisma } from "@prisma/client";
import { listProjects, getProject, createProject, updateProject, deleteProject, setProjectBoundary } from "../src/lib/services/projects";
import { listBoreholes, getBorehole, createBorehole, updateBorehole } from "../src/lib/services/boreholes";
import { createLayer, listLayersForBorehole } from "../src/lib/services/layers";
import { createSample, updateSample, listSamples } from "../src/lib/services/samples";
import { listLabTests, recordLabTestResult, getLabTest } from "../src/lib/services/lab-tests";
import { listDocuments, getDocument } from "../src/lib/services/documents";
import { listSharingRequests, createSharingRequest, decideSharingRequest, revokeSharingRequest } from "../src/lib/services/sharing";
import { listReports } from "../src/lib/services/reports";
import { listOrganizationUsers, changeUserRole } from "../src/lib/services/organizations";
import { listActivity } from "../src/lib/services/activity";
import { resolveStoragePath } from "../src/lib/services/documents";
import { AppError } from "../src/lib/errors";

const db = new PrismaClient();

let pass = 0;
let fail = 0;
const ok = (m: string) => { console.log(`PASS: ${m}`); pass++; };
const no = (m: string) => { console.log(`FAIL: ${m}`); fail++; };

type Actor = { id: string; email: string; name: string; role: string; isActive: boolean; organizationId: string };

async function actorByEmail(email: string): Promise<Actor> {
  const u = await db.user.findUniqueOrThrow({ where: { email } });
  return { id: u.id, email: u.email, name: u.name, role: u.role, isActive: u.isActive, organizationId: u.organizationId };
}

/** Assert a service call throws AppError with the expected code (prefix). */
async function expectThrows(code: string, label: string, fn: () => Promise<unknown>) {
  try {
    await fn();
    no(`${label} — expected ${code} but call SUCCEEDED`);
  } catch (e) {
    if (e instanceof AppError && e.code === code) ok(`${label} — ${code} as expected`);
    else if (e instanceof AppError) no(`${label} — got ${e.code} (${e.message}), expected ${code}`);
    else no(`${label} — non-AppError thrown: ${(e as Error).message}`);
  }
}

async function main() {
  const geoAdmin = await actorByEmail("admin@geodata.demo");
  const geoManager = await actorByEmail("manager@geodata.demo");
  const geoEngineer = await actorByEmail("engineer@geodata.demo");
  const geoViewer = await actorByEmail("viewer@geodata.demo");
  const rockAdmin = await actorByEmail("admin@rockworks.demo");
  const rockEngineer = await actorByEmail("engineer@rockworks.demo");

  const projects = await db.project.findMany({ select: { id: true, code: true, organizationId: true } });
  const byCode = (code: string) => projects.find((p) => p.code === code)!;
  const A1 = byCode("A1-TEN-2025");
  const METRO = byCode("METRO-ALG-EXT");
  const TRAM = byCode("TRAM-CNS-2025");
  const PORT = byCode("PORT-ORN-TERM");
  const ANNABA = byCode("ANNABA-IND-2026");

  // Fixture reset — the suite mutates sharing state; restore seeded statuses so
  // the test is idempotent across runs.
  const geoOrg = geoAdmin.organizationId;
  const rockOrg = rockAdmin.organizationId;
  await db.sharingRequest.deleteMany({ where: { project: { code: "TRAM-CNS-2025" }, targetOrganizationId: rockOrg } });
  await db.sharingRequest.updateMany({ where: { project: { code: "PORT-ORN-TERM" }, targetOrganizationId: rockOrg }, data: { status: "PENDING", decidedById: null, decidedAt: null } });
  await db.sharingRequest.updateMany({ where: { project: { code: "ANNABA-IND-2026" }, targetOrganizationId: geoOrg }, data: { status: "PENDING", decidedById: null, decidedAt: null } });
  await db.sharingRequest.updateMany({ where: { project: { code: "A1-TEN-2025" }, targetOrganizationId: rockOrg }, data: { status: "APPROVED" } });
  // Reset the UCS test this suite records (LB-03).
  const metroPend = await db.labTest.findFirst({ where: { testType: "UCS", status: "COMPLETED", sample: { borehole: { project: { code: "METRO-ALG-EXT" }, code: "LB-03" } } } });
  if (metroPend) {
    await db.labTest.update({ where: { id: metroPend.id }, data: { status: "PENDING", resultData: Prisma.DbNull, performedBy: null, performedAt: null, summary: null } });
  }
  console.log("(fixture state reset)");

  console.log("=== A. Tenant isolation (lists scoped to own org + approved shares) ===");
  const geoProjects = await listProjects(geoAdmin, { pageSize: 100 });
  const rockProjects = await listProjects(rockAdmin, { pageSize: 100 });
  if (geoProjects.total === 5 && geoProjects.items.every((p) => p.organizationId === geoAdmin.organizationId)) {
    ok("GeoStruct sees exactly its 5 projects");
  } else no(`GeoStruct project list wrong (total=${geoProjects.total})`);
  const rockOwn = rockProjects.items.filter((p) => p.organizationId === rockAdmin.organizationId);
  const rockShared = rockProjects.items.filter((p) => p.sharedWithYou);
  if (rockProjects.total === 2 && rockOwn.length === 1 && rockShared.length === 1 && rockShared[0].code === "A1-TEN-2025") {
    ok("RockWorks sees own project + shared A1 with sharedWithYou flag");
  } else no(`RockWorks project list wrong (total=${rockProjects.total}, shared=${rockShared.length})`);

  const search = await listProjects(geoManager, { search: "Ténès" });
  if (search.total === 1 && search.items[0].code === "A1-TEN-2025") ok("project search filter works"); else no("project search filter broken");
  const sorted = await listProjects(geoManager, { sortBy: "code", sortOrder: "asc", pageSize: 100 });
  if (sorted.items[0].code === "A1-TEN-2025") ok("project sorting works"); else no("project sorting broken");

  console.log("=== B. Cross-org reads: only via approved share ===");
  try {
    const shared = await getProject(rockEngineer, A1.id);
    if (shared.accessSource === "shared" && shared.sharedWithYou) ok("RockWorks reads shared A1 (source=shared)");
    else no("shared read lacks source flag");
    const a1Bh = await db.borehole.findFirstOrThrow({ where: { project: { code: "A1-TEN-2025" }, code: "BH-01" } });
    const bh = await getBorehole(rockEngineer, a1Bh.id);
    if (bh.project.organizationId === geoAdmin.organizationId && bh.code === "BH-01") ok("RockWorks reads borehole inside shared project"); else no("borehole read wrong");
  } catch (e) { no(`shared read failed unexpectedly: ${(e as Error).message}`); }
  await expectThrows("NOT_FOUND", "RockWorks reads METRO (rejected share)", () => getProject(rockAdmin, METRO.id));
  await expectThrows("NOT_FOUND", "RockWorks reads TRAM (no share at all)", () => getProject(rockAdmin, TRAM.id));
  const geoDocBdl = await db.document.findFirstOrThrow({ where: { project: { code: "BDL-HOSP-2024" } } });
  await expectThrows("NOT_FOUND", "RockWorks reads non-shared document", () => getDocument(rockAdmin, geoDocBdl.id));
  const a1Doc = await db.document.findFirstOrThrow({ where: { project: { code: "A1-TEN-2025" } } });
  try { const d = await getDocument(rockEngineer, a1Doc.id); if (d.accessSource === "shared") ok("RockWorks reads document inside shared project"); else no("doc shared read wrong"); }
  catch (e) { no(`shared document read failed: ${(e as Error).message}`); }

  console.log("=== C. Cross-org writes: always rejected (shared = read-only) ===");
  await expectThrows("NOT_FOUND", "RockWorks updates shared project", () => updateProject(rockAdmin, A1.id, { name: "Hacked" }));
  await expectThrows("NOT_FOUND", "RockWorks deletes shared project", () => deleteProject(rockAdmin, A1.id));
  await expectThrows("NOT_FOUND", "RockWorks updates foreign borehole", async () => {
    const bh = await db.borehole.findFirstOrThrow({ where: { project: { code: "A1-TEN-2025" }, code: "BH-01" } });
    return updateBorehole(rockAdmin, bh.id, { notes: "x" });
  });

  console.log("=== D. Parent-child validation (own org only) ===");
  await expectThrows("NOT_FOUND", "GeoStruct creates borehole in RockWorks project", () =>
    createBorehole(geoManager, {
      projectId: ANNABA.id, code: "XX-01", type: "SPT",
      latitude: 36.9, longitude: 7.77, depth: 5,
    }));
  const a1bh1 = await db.borehole.findFirstOrThrow({ where: { project: { code: "A1-TEN-2025" }, code: "BH-01" } });
  await expectThrows("VALIDATION_ERROR", "layer depthFrom > depthTo", () =>
    createLayer(geoEngineer, {
      boreholeId: a1bh1.id, depthFrom: 5, depthTo: 4,
      materialType: "SOIL", description: "invalid interval",
    }));
  await expectThrows("VALIDATION_ERROR", "layer overlaps existing interval", () =>
    createLayer(geoEngineer, {
      boreholeId: a1bh1.id, depthFrom: 1.0, depthTo: 2.0,
      materialType: "SOIL", description: "overlap test",
    }));
  await expectThrows("VALIDATION_ERROR", "layer exceeds borehole depth", () =>
    createLayer(geoEngineer, {
      boreholeId: a1bh1.id, depthFrom: 25, depthTo: 30,
      materialType: "ROCK", description: "too deep",
    }));
  await expectThrows("NOT_FOUND", "sample in foreign borehole", async () =>
    createSample(geoManager, {
      boreholeId: (await db.borehole.findFirstOrThrow({ where: { project: { code: "ANNABA-IND-2026" } } })).id,
      code: "XX-S1", type: "DISTURBED", depthFrom: 1, depthTo: 1.45,
    }));

  console.log("=== E. RBAC enforcement in services ===");
  await expectThrows("FORBIDDEN", "engineer creates project", () =>
    createProject(geoEngineer, { code: "TEST-NEW", name: "Should fail" }));
  await expectThrows("FORBIDDEN", "viewer creates borehole", () =>
    createBorehole(geoViewer, { projectId: A1.id, code: "V-01", type: "SPT", latitude: 36.17, longitude: 1.3, depth: 5 }));
  await expectThrows("FORBIDDEN", "viewer updates sample", async () => {
    const s = await db.sample.findFirstOrThrow({ where: { borehole: { project: { code: "A1-TEN-2025" } } } });
    return updateSample(geoViewer, s.id, { notes: "nope" });
  });
  await expectThrows("FORBIDDEN", "viewer lists team", () => listOrganizationUsers(geoViewer));
  const team = await listOrganizationUsers(geoManager);
  if (team.length === 4) ok("manager lists team (4 users)"); else no(`team list wrong (${team.length})`);

  console.log("=== F. Lab result validation through the service ===");
  const pendingUcs = await db.labTest.findFirstOrThrow({
    where: { status: "PENDING", testType: "UCS", sample: { borehole: { project: { code: "METRO-ALG-EXT" } } } },
  });
  await expectThrows("VALIDATION_ERROR", "invalid UCS result via service", () =>
    recordLabTestResult(geoEngineer, pendingUcs.id, { specimenDiameterMm: 54, peakStressKpa: 4200, strainAtFailurePercent: 99 }));
  await expectThrows("FORBIDDEN", "viewer records result", () =>
    recordLabTestResult(geoViewer, pendingUcs.id, { specimenDiameterMm: 54, peakStressKpa: 4200, strainAtFailurePercent: 1 }));
  const recorded = await recordLabTestResult(geoEngineer, pendingUcs.id, {
    specimenDiameterMm: 54, peakStressKpa: 5100, strainAtFailurePercent: 1.1, failurePattern: "AXIAL",
  }, { summary: "5.1 MPa, moderately strong" });
  if (recorded.status === "COMPLETED" && recorded.performedBy === geoEngineer.name) {
    ok("valid UCS result recorded -> COMPLETED with performer");
  } else no("valid result recording failed");
  const got = await getLabTest(geoEngineer, recorded.id);
  if (got.registry && got.registry.units) ok("getLabTest returns registry metadata (units/chart)"); else no("registry metadata missing");

  console.log("=== G. Sharing permission boundaries ===");
  await expectThrows("CONFLICT", "duplicate share request (already approved)", () =>
    createSharingRequest(geoManager, { projectId: A1.id, targetOrganizationId: rockAdmin.organizationId }));
  await expectThrows("FORBIDDEN", "engineer creates share request", () =>
    createSharingRequest(geoEngineer, { projectId: TRAM.id, targetOrganizationId: rockAdmin.organizationId }));
  await expectThrows("NOT_FOUND", "share request for a foreign project", () =>
    createSharingRequest(geoManager, { projectId: ANNABA.id, targetOrganizationId: rockAdmin.organizationId }));
  await expectThrows("VALIDATION_ERROR", "share with own organization", () =>
    createSharingRequest(geoManager, { projectId: TRAM.id, targetOrganizationId: geoAdmin.organizationId }));

  // Target org decides; requester org cannot.
  const portPending = await db.sharingRequest.findFirstOrThrow({
    where: { project: { code: "PORT-ORN-TERM" }, status: "PENDING" },
  });
  await expectThrows("FORBIDDEN", "owner org tries to decide its own request", () =>
    decideSharingRequest(geoManager, portPending.id, "APPROVE"));
  await expectThrows("FORBIDDEN", "engineer decides request", () =>
    decideSharingRequest(rockEngineer, portPending.id, "APPROVE"));
  const rejected = await decideSharingRequest(rockAdmin, portPending.id, "REJECT");
  if (rejected.status === "REJECTED" && rejected.decidedById === rockAdmin.id) ok("target org admin rejects pending request"); else no("rejection failed");

  // Approve the ANNABA request (rockworks -> geostruct), verify access granted then revoked.
  const annabaPending = await db.sharingRequest.findFirstOrThrow({
    where: { project: { code: "ANNABA-IND-2026" }, status: "PENDING" },
  });
  const approved = await decideSharingRequest(geoManager, annabaPending.id, "APPROVE");
  if (approved.status === "APPROVED") {
    ok("target org manager approves request");
    try {
      const p = await getProject(geoViewer, ANNABA.id);
      if (p.accessSource === "shared") ok("GeoStruct now reads ANNABA (shared)"); else no("ANNABA read wrong source");
    } catch (e) { no(`ANNABA read after approval failed: ${(e as Error).message}`); }
    const revoked = await revokeSharingRequest(rockAdmin, annabaPending.id);
    if (revoked.status === "REVOKED") ok("owner revokes the share");
    await expectThrows("NOT_FOUND", "access lost after revoke", () => getProject(geoViewer, ANNABA.id));
  } else no("ANNABA approval failed");

  // Expired share grants nothing.
  await db.sharingRequest.create({
    data: {
      projectId: TRAM.id, requesterId: geoManager.id, targetOrganizationId: rockAdmin.organizationId,
      permission: "VIEW", status: "APPROVED", expiresAt: new Date(Date.now() - 86400000),
    },
  });
  await expectThrows("NOT_FOUND", "expired share grants no access", () => getProject(rockAdmin, TRAM.id));

  // Revoke the seeded A1 share -> RockWorks loses access.
  const a1Share = await db.sharingRequest.findFirstOrThrow({
    where: { project: { code: "A1-TEN-2025" }, status: "APPROVED", targetOrganizationId: rockAdmin.organizationId },
  });
  await revokeSharingRequest(geoManager, a1Share.id);
  await expectThrows("NOT_FOUND", "A1 access lost after revoke", () => getProject(rockAdmin, A1.id));

  const shares = await listSharingRequests(rockAdmin);
  if (shares.inbox.length >= 3 && shares.sent.length === 1) ok("sharing inbox/sent split correct"); else no(`sharing split wrong (inbox=${shares.inbox.length}, sent=${shares.sent.length})`);

  console.log("=== H. Activity logging ===");
  const activity = await listActivity(geoAdmin, 10);
  const latest = activity[0];
  const recentActions = new Set(activity.map((a) => a.action));
  if (
    latest &&
    latest.organizationId === geoAdmin.organizationId &&
    recentActions.has("LAB_TEST_RESULT_RECORDED") &&
    recentActions.has("SHARE_REVOKED") &&
    recentActions.has("SHARE_APPROVED")
  ) {
    ok("activity logged for result recording + share decisions (own org only)");
  } else no(`activity logging wrong (latest=${latest?.action})`);
  const rockActivity = await listActivity(rockAdmin, 50);
  if (rockActivity.every((a) => a.organizationId === rockAdmin.organizationId)) ok("activity feed is tenant-scoped"); else no("activity leak across tenants");

  console.log("=== I. Misc: storage path traversal + reports + layers list ===");
  try { resolveStoragePath("../../etc/passwd"); no("path traversal accepted"); }
  catch (e) { if (e instanceof AppError) ok("path traversal rejected"); else no("path traversal threw wrong error"); }
  try { resolveStoragePath("subdir/../../x.txt"); no("nested traversal accepted"); }
  catch { ok("nested traversal rejected"); }
  const reports = await listReports(geoManager);
  if (reports.length === 3) ok("reports list scoped to own projects (3)"); else no(`reports list wrong (${reports.length})`);
  const layers = await listLayersForBorehole(geoEngineer, a1bh1.id);
  if (layers.length === 4 && layers[0].depthFrom === 0) ok("layers listed for borehole, ordered"); else no(`layers list wrong (${layers.length})`);
  const samplesList = await listSamples(geoEngineer, { labStatus: "COMPLETED", pageSize: 100 });
  if (samplesList.total > 0 && samplesList.items.every((s) => s.labStatus === "COMPLETED")) ok("sample list filter works"); else no("sample filter broken");
  const testsList = await listLabTests(geoEngineer, { testType: "PROCTOR", pageSize: 100 });
  // 5 Proctor tests exist in total, but one belongs to RockWorks' ANNABA project
  // which is outside geoEngineer's tenant scope — 4 is the CORRECT tenant-scoped count.
  if (testsList.total === 4 && testsList.items.every((t) => t.testType === "PROCTOR")) ok("lab test list filter works (4 proctor, tenant-scoped)"); else no(`lab test filter broken (${testsList.total})`);

  console.log("=== J. Cleanup (test artifacts) ===");
  const testProject = await db.project.findFirst({ where: { organizationId: geoAdmin.organizationId, code: "TEST-NEW" } });
  if (testProject) await deleteProject(geoAdmin, testProject.id);
  await db.sharingRequest.deleteMany({ where: { project: { code: "TRAM-CNS-2025" }, status: "APPROVED", expiresAt: { lt: new Date() } } });
  ok("cleanup done");

  console.log(`\n================ SERVICES TEST SUMMARY: ${pass} passed, ${fail} failed ================`);
  process.exit(fail);
}

main()
  .catch((e) => {
    console.error("SERVICES TEST CRASHED:", e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
