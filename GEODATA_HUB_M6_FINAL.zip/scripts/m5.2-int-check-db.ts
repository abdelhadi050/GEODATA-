/**
 * M5.2 Integration — extended database integrity check.
 *
 * Verifies, after the full protocol's final pristine re-seed:
 *   1. The established baseline counts are IDENTICAL to the M5.1/M5.2-a..g
 *      baseline in every pre-existing entity (orgs 2 · users 6 · projects 6 ·
 *      boreholes 26 · layers 83 · samples 45 · labTests 69 [63 completed/
 *      withResult] · documents 6 · shares 4 · reports 3 · activity 15).
 *   2. The new CalculationRecord table is EMPTY (the re-seed's
 *      labTest.deleteMany cascade removed every calculation record — proving
 *      the reset coverage of the new child table without touching seed.ts).
 *   3. Referential integrity: no calculation records reference missing lab
 *      tests / projects / organizations / users; fingerprints are well-formed.
 */
import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();

let failures = 0;
const check = (label: string, ok: boolean, detail = "") => {
  console.log(`${ok ? "PASS" : "FAIL"}: ${label}${ok ? "" : ` — ${detail}`}`);
  if (!ok) failures++;
};

async function main() {
  const [o, u, p, b, l, s, t, d, sh, r, a] = await Promise.all([
    db.organization.count(),
    db.user.count(),
    db.project.count(),
    db.borehole.count(),
    db.geologicalLayer.count(),
    db.sample.count(),
    db.labTest.count(),
    db.document.count(),
    db.sharingRequest.count(),
    db.report.count(),
    db.activityLog.count(),
  ]);
  const completed = await db.labTest.count({ where: { status: "COMPLETED" } });
  const withResult = (await db.labTest.findMany({ select: { resultData: true } })).filter(
    (x) => x.resultData !== null,
  ).length;

  check("baseline counts identical (orgs 2)", o === 2, `got ${o}`);
  check("users 6", u === 6, `got ${u}`);
  check("projects 6", p === 6, `got ${p}`);
  check("boreholes 26", b === 26, `got ${b}`);
  check("layers 83", l === 83, `got ${l}`);
  check("samples 45", s === 45, `got ${s}`);
  check("labTests 69", t === 69, `got ${t}`);
  check("completed 63", completed === 63, `got ${completed}`);
  check("withResult 63", withResult === 63, `got ${withResult}`);
  check("documents 6", d === 6, `got ${d}`);
  check("shares 4", sh === 4, `got ${sh}`);
  check("reports 3", r === 3, `got ${r}`);
  check("activity 15 (pristine baseline)", a === 15, `got ${a}`);

  // new table: empty after the protocol's final re-seed (cascade coverage)
  const calcCount = await db.calculationRecord.count();
  check(
    "CalculationRecord empty after re-seed (labTest cascade covers the reset)",
    calcCount === 0,
    `got ${calcCount}`,
  );

  // referential integrity (FKs guarantee it; asserted defense-in-depth —
  // meaningful when records exist in other contexts)
  const orphans = await db.$queryRaw<Array<{ n: bigint }>>`
    SELECT COUNT(*) AS n FROM CalculationRecord cr
    LEFT JOIN LabTest lt ON cr.labTestId = lt.id
    LEFT JOIN Project p ON cr.projectId = p.id
    LEFT JOIN Organization o ON cr.organizationId = o.id
    LEFT JOIN User u2 ON cr.createdById = u2.id
    WHERE lt.id IS NULL OR p.id IS NULL OR o.id IS NULL OR u2.id IS NULL`;
  check("no orphaned calculation records", Number(orphans[0]?.n ?? 0) === 0);

  const badFingerprints = await db.calculationRecord.count({
    where: { OR: [{ inputFingerprint: "" }] },
  });
  check("no empty fingerprints", badFingerprints === 0);

  await db.$disconnect();
  console.log(
    failures === 0
      ? "\nM5.2-INTEGRATION INTEGRITY: ALL CHECKS PASSED"
      : `\nM5.2-INTEGRATION INTEGRITY: ${failures} FAILURES`,
  );
  process.exit(failures > 0 ? 1 : 0);
}

main().catch(async (e) => {
  console.error("INTEGRITY CHECK ERROR:", e);
  await db.$disconnect();
  process.exit(1);
});
