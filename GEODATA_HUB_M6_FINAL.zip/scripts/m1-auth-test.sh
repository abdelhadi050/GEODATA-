#!/usr/bin/env bash
# M1 NextAuth v4 + Next.js 16 compatibility + security test (semantic locators).
set -u
cd /home/z/my-project

BASE=http://127.0.0.1:3000
PASS=0; FAIL=0
ok(){ echo "PASS: $1"; PASS=$((PASS+1)); }
no(){ echo "FAIL: $1"; FAIL=$((FAIL+1)); }

pkill -f "next dev" 2>/dev/null || true; sleep 1
echo "=== starting dev server ==="
bun run dev < /dev/null > /tmp/m1-dev.out 2>&1 &
DEV_PID=$!
trap 'kill $DEV_PID 2>/dev/null || true; pkill -f "next dev" 2>/dev/null || true' EXIT

for i in $(seq 1 45); do
  curl -sf "$BASE/api/health" >/dev/null 2>&1 && break
  sleep 1
done
if curl -sf "$BASE/api/health" >/dev/null 2>&1; then ok "dev server up + /api/health 200"; else no "dev server failed to start"; fi
echo "  health: $(curl -s "$BASE/api/health")"

agent-browser close >/dev/null 2>&1 || true

# --- TEST 1: root redirect (unauthenticated) ---
echo "=== TEST 1: root redirect (unauth) ==="
agent-browser open "$BASE/" >/dev/null 2>&1
agent-browser wait --load networkidle >/dev/null 2>&1
URL1=$(agent-browser get url 2>/dev/null)
echo "  url: $URL1"
case "$URL1" in */login) ok "unauth / -> /login";; *) no "unauth / -> /login (got $URL1)";; esac

# --- TEST 2: login with valid credentials ---
echo "=== TEST 2: login (valid creds) ==="
agent-browser open "$BASE/login" >/dev/null 2>&1
agent-browser wait --load networkidle >/dev/null 2>&1
agent-browser find label "Email" fill "admin@geodata.demo" >/dev/null 2>&1
agent-browser find label "Password" fill "Demo1234!" >/dev/null 2>&1
agent-browser find role button click --name "Sign in" >/dev/null 2>&1
agent-browser wait --url "/dashboard" --timeout 15000 >/dev/null 2>&1
URL2=$(agent-browser get url 2>/dev/null)
echo "  url after submit: $URL2"
case "$URL2" in */dashboard) ok "login -> /dashboard";; *) no "login -> /dashboard (got $URL2)";; esac

# --- TEST 3: dashboard shows authenticated user (DB-fresh identity) ---
echo "=== TEST 3: dashboard user identity ==="
# Poll briefly for the full page load to commit (login uses a full-page
# navigation; the URL can commit before the document swap). Assertions unchanged.
BODY=""
for _i in $(seq 1 15); do
  BODY=$(agent-browser eval "document.body.innerText" 2>/dev/null)
  echo "$BODY" | grep -q "Ana Rivera" && break
  sleep 1
done
echo "  body snippet: $(echo "$BODY" | head -c 200)"
if echo "$BODY" | grep -q "Ana Rivera" && echo "$BODY" | grep -q "Organization Admin"; then
  ok "dashboard shows fresh user (Ana Rivera / Organization Admin)"
else
  no "dashboard user identity not shown"
fi

# --- TEST 4: session cookie is httpOnly (invisible to document.cookie) ---
echo "=== TEST 4: session cookie httpOnly ==="
DC=$(agent-browser eval "document.cookie" 2>/dev/null)
echo "  document.cookie: \"$DC\""
if echo "$DC" | grep -q "next-auth.session-token"; then
  no "session token visible to JS -> NOT HttpOnly"
else
  ok "session cookie HttpOnly (absent from document.cookie)"
fi

# --- TEST 5: deactivation rejected on next request (DB-fresh authz) ---
echo "=== TEST 5: deactivated user rejected ==="
bun -e "import {PrismaClient} from '@prisma/client'; const db=new PrismaClient(); await db.user.update({where:{email:'admin@geodata.demo'},data:{isActive:false}}); console.log('deactivated'); await db.\$disconnect();" 2>/dev/null
agent-browser open "$BASE/dashboard" >/dev/null 2>&1
agent-browser wait --load networkidle >/dev/null 2>&1
URL5=$(agent-browser get url 2>/dev/null)
echo "  url after deactivate + /dashboard: $URL5"
case "$URL5" in */login) ok "deactivated user -> /login (DB-fresh authz)";; *) no "deactivated user not rejected (got $URL5)";; esac
bun -e "import {PrismaClient} from '@prisma/client'; const db=new PrismaClient(); await db.user.update({where:{email:'admin@geodata.demo'},data:{isActive:true}}); console.log('reactivated'); await db.\$disconnect();" 2>/dev/null

# --- TEST 6: re-login after reactivation ---
echo "=== TEST 6: re-login after reactivation ==="
agent-browser cookies clear >/dev/null 2>&1
agent-browser open "$BASE/login" >/dev/null 2>&1
agent-browser wait --load networkidle >/dev/null 2>&1
agent-browser find label "Email" fill "admin@geodata.demo" >/dev/null 2>&1
agent-browser find label "Password" fill "Demo1234!" >/dev/null 2>&1
agent-browser find role button click --name "Sign in" >/dev/null 2>&1
agent-browser wait --url "/dashboard" --timeout 15000 >/dev/null 2>&1
URL6=$(agent-browser get url 2>/dev/null)
case "$URL6" in */dashboard) ok "re-login -> /dashboard";; *) no "re-login failed (got $URL6)";; esac

# --- TEST 10: theme toggle (light/dark) ---
echo "=== TEST 10: theme toggle ==="
agent-browser wait --load networkidle >/dev/null 2>&1
BEFORE=$(agent-browser eval "document.documentElement.classList.contains('dark')" 2>/dev/null | tr -d '"')
agent-browser find role button click --name "Toggle theme" >/dev/null 2>&1
sleep 1
AFTER=$(agent-browser eval "document.documentElement.classList.contains('dark')" 2>/dev/null | tr -d '"')
echo "  html.dark before=$BEFORE after=$AFTER"
if [ "$BEFORE" != "$AFTER" ]; then
  ok "theme toggle switches html.dark class"
else
  no "theme toggle did not change html.dark class"
fi
# restore prior theme
agent-browser find role button click --name "Toggle theme" >/dev/null 2>&1

# --- TEST 11: mobile viewport (responsive, no overflow) ---
echo "=== TEST 11: mobile viewport ==="
agent-browser set viewport 390 844 >/dev/null 2>&1
agent-browser open "$BASE/dashboard" >/dev/null 2>&1
agent-browser wait --load networkidle >/dev/null 2>&1
SW=$(agent-browser eval "document.body.scrollWidth" 2>/dev/null | tr -d '"')
IW=$(agent-browser eval "window.innerWidth" 2>/dev/null | tr -d '"')
echo "  scrollWidth=$SW innerWidth=$IW"
BODYM=$(agent-browser eval "document.body.innerText" 2>/dev/null)
if echo "$BODYM" | grep -q "Dashboard"; then
  ok "mobile: dashboard content renders"
else
  no "mobile: dashboard content not visible"
fi
if [ -n "$SW" ] && [ -n "$IW" ] && [ "$SW" -le "$IW" ] 2>/dev/null; then
  ok "mobile: no horizontal overflow ($SW <= $IW)"
else
  no "mobile: horizontal overflow ($SW > $IW)"
fi
agent-browser set viewport 1280 800 >/dev/null 2>&1

# --- TEST 7: logout ---
echo "=== TEST 7: logout ==="
agent-browser wait --load networkidle >/dev/null 2>&1
agent-browser find role button click --name "Sign out" >/dev/null 2>&1
agent-browser wait --url "/login" --timeout 10000 >/dev/null 2>&1
URL7=$(agent-browser get url 2>/dev/null)
case "$URL7" in */login) ok "logout -> /login";; *) no "logout -> /login (got $URL7)";; esac

# --- TEST 8: protected route redirect (logged out) ---
echo "=== TEST 8: protected route redirect (logged out) ==="
agent-browser open "$BASE/dashboard" >/dev/null 2>&1
agent-browser wait --load networkidle >/dev/null 2>&1
URL8=$(agent-browser get url 2>/dev/null)
case "$URL8" in */login) ok "logged-out /dashboard -> /login";; *) no "logged-out /dashboard -> /login (got $URL8)";; esac

# --- TEST 9: no runtime/hydration errors ---
echo "=== TEST 9: dev log errors ==="
if grep -aqiE "hydration|unhandled|SyntaxError|TypeError|Module not found|Error:" /tmp/m1-dev.out; then
  echo "  potential errors:"
  grep -aiE "hydration|unhandled|SyntaxError|TypeError|Module not found|Error:" /tmp/m1-dev.out | head -5
  no "runtime errors detected"
else
  ok "no runtime/hydration errors in dev log"
fi

agent-browser close >/dev/null 2>&1 || true
echo ""
echo "=========================================="
echo "M1 AUTH TEST SUMMARY: $PASS passed, $FAIL failed"
echo "=========================================="
exit $FAIL
