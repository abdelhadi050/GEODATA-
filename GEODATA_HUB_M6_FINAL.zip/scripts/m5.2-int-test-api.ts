/**
 * M5.2 INTEGRATION TEST — API layer (live dev server).
 *
 * End-to-end coverage of the Calculate API: every registered engine through
 * the HTTP surface, persistence + retrieval endpoints, RBAC (authorized,
 * unauthorized, cross-organization, IDOR), unsupported engines, failed
 * calculations, idempotency + concurrency, invalidation lifecycle, activity
 * logging, envelope shapes and leak scans.
 *
 * Runs against BASE (default http://127.0.0.1:3000) with the freshly seeded
 * demo database. Exit code = number of failures. Direct Prisma access is
 * used ONLY for fixture resolution and assertions.
 */
import { PrismaClient } from "@prisma/client";

const BASE = process.env.BASE ?? "http://127.0.0.1:3000";
const PASSWORD = "Demo1234!";
const db = new PrismaClient();

let pass = 0;
let fail = 0;
const ok = (m: string) => { console.log(`PASS: ${m}`); pass++; };
const no = (m: string) => { console.log(`FAIL: ${m}`); fail++; };

// ---------- HTTP / session helpers (M3/M5.1 pattern) ----------

function cookieFrom(setCookies: string[], name: string): string | null {
  for (const c of setCookies) {
    const [pair] = c.split(";");
    const eq = pair.indexOf("=");
    if (pair.slice(0, eq) === name) return pair.slice(eq + 1);
  }
  return null;
}

async function login(email: string, password = PASSWORD): Promise<string | null> {
  try {
    const r1 = await fetch(`${BASE}/api/auth/csrf`, { signal: AbortSignal.timeout(30_000) });
    const { csrfToken } = (await r1.json()) as { csrfToken: string };
    const csrfCookie = cookieFrom(r1.headers.getSetCookie(), "next-auth.csrf-token");
    if (!csrfCookie) return null;
    const r2 = await fetch(`${BASE}/api/auth/callback/credentials`, {
      method: "POST",
      signal: AbortSignal.timeout(30_000),
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        Cookie: `next-auth.csrf-token=${csrfCookie}`,
      },
      body: new URLSearchParams({
        csrfToken,
        email,
        password,
        callbackUrl: `${BASE}/`,
        json: "true",
      }),
      redirect: "manual",
    });
    const session = cookieFrom(r2.headers.getSetCookie(), "next-auth.session-token");
    return session ? `next-auth.session-token=${session}` : null;
  } catch {
    return null;
  }
}

interface ApiResult {
  status: number;
  body: any;
  text: string;
}

const envelopeViolations: string[] = [];
const leakScans: string[] = [];
const LEAK_PATTERNS = [
  "storage/uploads",
  "passwordHash",
  "prisma://",
  "PrismaClientKnownRequestError",
  "/home/z/",
  "NEXTAUTH_SECRET",
  "at Object",
  "at async",
];

async function api(
  cookie: string | null,
  method: string,
  path: string,
  opts: { json?: unknown; raw?: string; origin?: string } = {},
): Promise<ApiResult> {
  const headers: Record<string, string> = {};
  if (cookie) headers.Cookie = cookie;
  if (opts.json !== undefined || opts.raw !== undefined) headers["Content-Type"] = "application/json";
  if (opts.origin) headers.Origin = opts.origin;
  const body = opts.json !== undefined ? JSON.stringify(opts.json) : opts.raw;
  let res: Response;
  try {
    res = await fetch(BASE + path, {
      method,
      headers,
      body,
      redirect: "manual",
      signal: AbortSignal.timeout(30_000),
    });
  } catch (e) {
    return {
      status: 0,
      body: null,
      text: `REQUEST FAILED: ${String((e as Error).message ?? e)}`,
    };
  }
  const text = await res.text();
  let parsed: any = null;
  try { parsed = JSON.parse(text); } catch { /* empty */ }
  if (parsed && typeof parsed === "object") {
    if (parsed.success === false) {
      const e = parsed.error;
      if (!e || typeof e.code !== "string" || typeof e.message !== "string") {
        envelopeViolations.push(`${method} ${path} → malformed error envelope`);
      }
    } else if (parsed.success !== true) {
      envelopeViolations.push(`${method} ${path} → missing success flag`);
    }
    for (const pat of LEAK_PATTERNS) {
      if (text.includes(pat)) leakScans.push(`${method} ${path} → contains "${pat}"`);
    }
  }
  return { status: res.status, body: parsed, text };
}

function expectStatus(r: ApiResult, status: number, label: string) {
  if (r.status === status) ok(`${label} (HTTP ${status})`);
  else no(`${label} — expected HTTP ${status}, got ${r.status}: ${r.text.slice(0, 160)}`);
}

function expectError(r: ApiResult, status: number, code: string, label: string) {
  if (r.status === status && r.body?.error?.code === code) ok(`${label} (HTTP ${status} ${code})`);
  else no(`${label} — expected ${status}/${code}, got ${r.status}: ${r.text.slice(0, 160)}`);
}

function expectSuccess(r: ApiResult, label: string): any {
  if (r.status === 200 && r.body?.success === true) { ok(label); return r.body.data; }
  no(`${label} — expected 200/success, got ${r.status}: ${r.text.slice(0, 160)}`);
  return null;
}

// ---------- fixtures ----------

const GRAN_ORDERED = {
  points: [
    { diameterMm: 0.02, percentFiner: 5 },
    { diameterMm: 0.075, percentFiner: 15 },
    { diameterMm: 0.15, percentFiner: 28 },
    { diameterMm: 0.3, percentFiner: 42 },
    { diameterMm: 0.6, percentFiner: 55 },
    { diameterMm: 1.18, percentFiner: 68 },
    { diameterMm: 2.36, percentFiner: 80 },
    { diameterMm: 4.75, percentFiner: 90 },
    { diameterMm: 9.5, percentFiner: 100 },
  ],
};

const ATT_EXPLICIT = {
  method: "CASAGRANDE_CUP",
  liquidLimitPoints: [
    { blows: 15, waterContentPercent: 48.2 },
    { blows: 20, waterContentPercent: 45.6 },
    { blows: 30, waterContentPercent: 40.3 },
    { blows: 40, waterContentPercent: 36.8 },
  ],
  plasticLimitTrials: [18, 20],
};

async function fixtures() {
  const a1 = await db.project.findFirstOrThrow({ where: { code: "A1-TEN-2025" } });
  const port = await db.project.findFirstOrThrow({ where: { code: "PORT-ORN-TERM" } });
  // WC_18_5 — the calculable mass triple (deterministic)
  const wcAll = await db.labTest.findMany({
    where: { testType: "WATER_CONTENT", resultData: { not: null } },
  });
  const wcFull = wcAll.find((t) => (t.resultData as any)?.wetMassG === 235.5)!;
  const wcMassless = wcAll.find(
    (t) =>
      (t.resultData as any)?.waterContentPercent !== undefined &&
      (t.resultData as any)?.wetMassG === undefined,
  )!;
  const spt = await db.labTest.findFirstOrThrow({ where: { testType: "SPT" } });
  // A1 Proctor STANDARD (the 1.971/13.75 golden fixture — deterministic)
  const proctors = await db.labTest.findMany({
    where: { testType: "PROCTOR", sample: { borehole: { projectId: a1.id } } },
  });
  const proctor = proctors.find((t) => (t.resultData as any)?.method === "STANDARD")!;
  const cbr = await db.labTest.findFirstOrThrow({ where: { testType: "CBR" } });
  // PORT oedometer (OEDO_CLAY) — also the cross-org 404 fixture (PENDING share)
  const oedo = await db.labTest.findFirstOrThrow({
    where: { testType: "OEDOMETER", sample: { borehole: { projectId: port.id } } },
  });
  // the multi-stage direct-shear program (deterministic)
  const dsAll = await db.labTest.findMany({ where: { testType: "DIRECT_SHEAR" } });
  const ds = dsAll.find((t) => Array.isArray((t.resultData as any)?.stages))!;
  const pmt = await db.labTest.findFirstOrThrow({
    where: { testType: "PRESSUREMETER", resultData: { not: null } },
  });
  const gran = await db.labTest.findFirstOrThrow({ where: { testType: "GRANULOMETRY" } });
  const att = await db.labTest.findFirstOrThrow({ where: { testType: "ATTERBERG_LIMITS" } });
  return { wcFull, wcMassless, spt, proctor, cbr, oedo, ds, pmt, gran, att, a1, port };
}

// ----------------------------------------------------------------------------
async function main() {
  const adminCookie = await login("admin@geodata.demo");
  const engineerCookie = await login("engineer@geodata.demo");
  const viewerCookie = await login("viewer@geodata.demo");
  const rockEngineerCookie = await login("engineer@rockworks.demo");
  if (adminCookie && engineerCookie && viewerCookie && rockEngineerCookie) {
    ok("all four session logins established");
  } else no("session login failed");
  const fx = await fixtures();

  // ===== 1. Engine registry endpoint =====
  console.log("--- Suite 1: engines endpoint ---");
  expectError(await api(null, "GET", "/api/calculations/engines"), 401, "UNAUTHENTICATED", "engines requires auth");
  const engines = expectSuccess(await api(viewerCookie, "GET", "/api/calculations/engines"), "viewer lists engines");
  const engineIds = (engines ?? []).map((e: any) => e.moduleId);
  const expectedIds = ["water-content", "granulometry", "atterberg-limits", "proctor", "cbr", "oedometer", "direct-shear", "pressuremeter"];
  if (JSON.stringify(engineIds.sort()) === JSON.stringify([...expectedIds].sort()) && engines.length === 8) {
    ok("all 8 registered engines exposed (no omissions)");
  } else no(`engines list wrong: ${engineIds.join(",")}`);
  if ((engines ?? []).every((e: any) => e.moduleVersion && e.engineVersion && e.testType && e.label)) {
    ok("engine metadata complete (versions, test types, labels)");
  } else no("engine metadata incomplete");
  if ((engines ?? []).every((e: any) => !("compute" in e || "validateInput" in e))) {
    ok("no engine references leaked (metadata only)");
  } else no("engine functions leaked into the API payload");

  // ===== 2. Calculate — all 8 engines end-to-end =====
  console.log("--- Suite 2: calculate (every registered engine) ---");
  // 2.1 water content from stored resultData (golden: 18.5 %)
  const wc = expectSuccess(await api(engineerCookie, "POST", `/api/lab-tests/${fx.wcFull.id}/calculate`, { json: {} }), "WC calculate (empty body → stored data)");
  if (wc?.record?.status === "COMPLETED" && wc?.outcome?.status === "ok") {
    ok("WC record COMPLETED + outcome envelope ok");
  } else no("WC calculation not completed");
  if (wc?.record?.output?.results?.waterContentPercent === 18.5) {
    ok("WC golden through the API: w = 18.5 %");
  } else no(`WC golden wrong: ${wc?.record?.output?.results?.waterContentPercent}`);
  if (wc?.record?.inputSource === "RESULT_DATA" && wc?.record?.standard && wc?.record?.units) {
    ok("WC provenance: source/standard/units stored");
  } else no("WC provenance incomplete");
  if (wc?.record?.labTest?.sample?.borehole?.project?.code) {
    ok("WC detail carries the lab-test context chain");
  } else no("WC detail missing context chain");
  const wcId = wc?.record?.id;

  // 2.2 proctor (golden: MDD 1.971 @ OMC 13.75)
  const pr = expectSuccess(await api(engineerCookie, "POST", `/api/lab-tests/${fx.proctor.id}/calculate`, { json: {} }), "Proctor calculate");
  if (pr?.record?.output?.results?.maxDryDensity === 1.971 && pr?.record?.output?.results?.optimumMoisture === 13.75) {
    ok("Proctor golden through the API: 1.971 Mg/m³ @ 13.75 %");
  } else no(`Proctor golden wrong: ${pr?.record?.output?.results?.maxDryDensity} @ ${pr?.record?.output?.results?.optimumMoisture}`);
  if (pr?.record?.method === "STANDARD effort") ok("Proctor method column populated");
  else no("Proctor method missing");

  // 2.3 CBR
  const cbr = expectSuccess(await api(engineerCookie, "POST", `/api/lab-tests/${fx.cbr.id}/calculate`, { json: {} }), "CBR calculate");
  if (cbr?.record?.status === "COMPLETED" && typeof cbr?.record?.output?.results?.cbrValue === "number") {
    ok(`CBR COMPLETED (reported CBR ${cbr.record.output.results.cbrValue} % from ${cbr.record.output.results.reportedFrom ?? "?"})`);
  } else no("CBR calculation failed");

  // 2.4 oedometer (registry `stages` → engine `loadingStages` adapter)
  const oedo = expectSuccess(await api(engineerCookie, "POST", `/api/lab-tests/${fx.oedo.id}/calculate`, { json: {} }), "Oedometer calculate (adapter path)");
  if (oedo?.record?.status === "COMPLETED" && typeof oedo?.record?.output?.results?.compressionIndexCc === "number") {
    ok(`Oedometer COMPLETED via adapter (Cc ${oedo.record.output.results.compressionIndexCc})`);
  } else no("Oedometer adapter calculation failed");
  if (Array.isArray(oedo?.record?.inputSnapshot?.loadingStages) && oedo?.record?.inputSnapshot?.stages === undefined) {
    ok("oedometer snapshot stored in the engine contract shape");
  } else no("oedometer snapshot shape wrong");

  // 2.5 direct shear (multi-stage program)
  const ds = expectSuccess(await api(engineerCookie, "POST", `/api/lab-tests/${fx.ds.id}/calculate`, { json: {} }), "Direct shear calculate");
  if (ds?.record?.status === "COMPLETED" && typeof ds?.record?.output?.results?.peakFrictionAngleDeg === "number") {
    ok(`Direct shear COMPLETED (φ′ = ${ds.record.output.results.peakFrictionAngleDeg}°)`);
  } else no("Direct shear calculation failed");

  // 2.6 pressuremeter
  const pmt = expectSuccess(await api(engineerCookie, "POST", `/api/lab-tests/${fx.pmt.id}/calculate`, { json: {} }), "Pressuremeter calculate");
  if (pmt?.record?.status === "COMPLETED") {
    ok("Pressuremeter COMPLETED (entered echoes + advisories by design)");
  } else no("Pressuremeter calculation failed");

  // 2.7 granulometry via explicit ordered input (seed stores sieve order —
  // the module rejects unordered data by design, M5.2-b policy)
  const granSeed = expectSuccess(
    await api(engineerCookie, "POST", `/api/lab-tests/${fx.gran.id}/calculate`, { json: {} }),
    "Granulometry on seed payload (sieve order)",
  );
  if (granSeed?.record?.status === "FAILED" && granSeed?.record?.errorCode === "INVALID_INPUT") {
    ok("granulometry seed payload → persisted FAILED/INVALID_INPUT (no silent sorting)");
  } else no("granulometry seed payload behavior wrong");
  const gran = expectSuccess(
    await api(engineerCookie, "POST", `/api/lab-tests/${fx.gran.id}/calculate`, {
      json: { input: GRAN_ORDERED, idempotencyKey: "api-gran-0001" },
    }),
    "Granulometry calculate (explicit ordered input)",
  );
  if (gran?.record?.status === "COMPLETED" && typeof gran?.record?.output?.results?.uniformityCoefficient === "number") {
    ok(`Granulometry COMPLETED (Cu = ${gran.record.output.results.uniformityCoefficient})`);
  } else no("granulometry explicit calculation failed");
  if (gran?.record?.inputSource === "EXPLICIT") ok("granulometry record marked EXPLICIT");
  else no("granulometry input source wrong");

  // 2.8 atterberg via explicit raw flow data
  const att = expectSuccess(
    await api(engineerCookie, "POST", `/api/lab-tests/${fx.att.id}/calculate`, {
      json: { input: ATT_EXPLICIT, idempotencyKey: "api-att-0001" },
    }),
    "Atterberg calculate (explicit flow data)",
  );
  if (att?.record?.status === "COMPLETED" && att?.record?.output?.results?.liquidLimit === 42.48) {
    ok("Atterberg golden through the API: LL = 42.48 %");
  } else no(`Atterberg golden wrong: ${att?.record?.output?.results?.liquidLimit}`);

  // ===== 3. Retrieval =====
  console.log("--- Suite 3: retrieval ---");
  const hist = expectSuccess(await api(engineerCookie, "GET", `/api/lab-tests/${fx.wcFull.id}/calculations`), "history list");
  if (Array.isArray(hist) && hist.length >= 1 && hist[0].warningCount !== undefined && !("output" in hist[0])) {
    ok("history items lean (no output snapshots) with warningCount");
  } else no("history item shape wrong");
  const histMeta = (await api(engineerCookie, "GET", `/api/lab-tests/${fx.wcFull.id}/calculations`)).body?.meta;
  if (histMeta?.total >= 1 && histMeta?.page === 1) ok("history pagination meta present");
  else no("history meta missing");
  const latest = expectSuccess(await api(viewerCookie, "GET", `/api/lab-tests/${fx.wcFull.id}/calculations/latest`), "viewer reads latest valid");
  if (latest?.id === wcId && latest?.output?.results?.waterContentPercent === 18.5) {
    ok("latest valid = the WC record with full output");
  } else no("latest valid wrong");
  const detail = expectSuccess(await api(engineerCookie, "GET", `/api/calculations/${wcId}`), "detail by record id");
  if (detail?.inputSnapshot?.wetMassG === 235.5 && detail?.accessSource === "own") {
    ok("detail: input snapshot + access source");
  } else no("detail payload wrong");
  const projList = expectSuccess(await api(engineerCookie, "GET", `/api/projects/${fx.a1.id}/calculations`), "project listing");
  if (Array.isArray(projList) && projList.length >= 2) ok(`project listing returns records (${projList.length})`);
  else no("project listing empty");
  const projFiltered = expectSuccess(
    await api(engineerCookie, "GET", `/api/projects/${fx.a1.id}/calculations?status=COMPLETED&isValid=true`),
    "project listing filtered",
  );
  if (projFiltered.every((i: any) => i.status === "COMPLETED" && i.isValid === true)) {
    ok("project listing filters (status + isValid) work");
  } else no("project listing filters broken");

  // ===== 4. RBAC / tenancy / IDOR =====
  console.log("--- Suite 4: RBAC & tenant isolation ---");
  expectError(await api(null, "POST", `/api/lab-tests/${fx.wcFull.id}/calculate`, { json: {} }), 401, "UNAUTHENTICATED", "calculate requires auth");
  expectError(await api(viewerCookie, "POST", `/api/lab-tests/${fx.wcFull.id}/calculate`, { json: {} }), 403, "FORBIDDEN", "VIEWER cannot calculate");
  expectError(await api(null, "GET", `/api/lab-tests/${fx.wcFull.id}/calculations`), 401, "UNAUTHENTICATED", "history requires auth");
  expectError(await api(null, "GET", `/api/calculations/${wcId}`), 401, "UNAUTHENTICATED", "detail requires auth");
  // cross-org / IDOR: the PORT project (PENDING share) is invisible to RockWorks
  expectError(await api(rockEngineerCookie, "POST", `/api/lab-tests/${fx.oedo.id}/calculate`, { json: {} }), 404, "NOT_FOUND", "cross-org calculate → 404 (no existence leak)");
  expectError(await api(rockEngineerCookie, "GET", `/api/lab-tests/${fx.oedo.id}/calculations`), 404, "NOT_FOUND", "cross-org history → 404");
  expectError(await api(rockEngineerCookie, "GET", `/api/calculations/${oedo?.record?.id}`), 404, "NOT_FOUND", "cross-org detail → 404 (IDOR)");
  expectError(await api(rockEngineerCookie, "GET", `/api/lab-tests/${fx.oedo.id}/calculations/latest`), 404, "NOT_FOUND", "cross-org latest → 404");
  // shared project: RockWorks may READ A1 calculations but not calculate
  const sharedHist = expectSuccess(await api(rockEngineerCookie, "GET", `/api/lab-tests/${fx.proctor.id}/calculations`), "shared-project history readable (APPROVED share)");
  if (sharedHist.length >= 1) ok("share recipient sees the shared project's calculations");
  else no("shared history empty");
  const sharedLatest = expectSuccess(await api(rockEngineerCookie, "GET", `/api/lab-tests/${fx.proctor.id}/calculations/latest`), "shared-project latest readable");
  if (sharedLatest?.accessSource === "shared") ok("latest marks accessSource=shared");
  else no("shared access source wrong");
  expectError(await api(rockEngineerCookie, "POST", `/api/lab-tests/${fx.proctor.id}/calculate`, { json: {} }), 404, "NOT_FOUND", "shared project is read-only (calculate → 404)");
  expectError(await api(rockEngineerCookie, "GET", `/api/projects/${fx.port.id}/calculations`), 404, "NOT_FOUND", "PENDING-share project listing → 404");
  // invalid id formats → 400 before any lookup
  expectError(await api(engineerCookie, "GET", "/api/lab-tests/short/calculations"), 400, "VALIDATION_ERROR", "malformed lab-test id → 400");
  expectError(await api(engineerCookie, "GET", "/api/calculations/%20%20%20%20%20%20%20%20"), 400, "VALIDATION_ERROR", "malformed calculation id → 400");
  // audit-history protection: no mutation endpoints exist
  const del = await api(engineerCookie, "DELETE", `/api/calculations/${wcId}`);
  if (del.status === 405) ok("calculation records are immutable (DELETE → 405)");
  else no(`DELETE on calculations returned ${del.status}`);
  const delAct = await api(engineerCookie, "DELETE", "/api/activity");
  if (delAct.status === 405) ok("audit history is append-only (DELETE /activity → 405)");
  else no(`DELETE /activity returned ${delAct.status}`);

  // ===== 5. Unsupported / missing / invalid =====
  console.log("--- Suite 5: unsupported, missing, invalid ---");
  expectError(await api(engineerCookie, "POST", `/api/lab-tests/${fx.spt.id}/calculate`, { json: {} }), 422, "UNSUPPORTED_CALCULATION_ENGINE", "SPT → 422 UNSUPPORTED_CALCULATION_ENGINE");
  expectError(await api(engineerCookie, "POST", "/api/lab-tests/clmnopqrstuvwx/calculate", { json: {} }), 404, "NOT_FOUND", "unknown lab test → 404");
  expectError(await api(engineerCookie, "POST", `/api/lab-tests/${fx.wcFull.id}/calculate`, { json: { unknownKey: true } }), 400, "VALIDATION_ERROR", "unknown body key → 400 (strict)");
  const malformed = await api(engineerCookie, "POST", `/api/lab-tests/${fx.wcFull.id}/calculate`, { raw: "{not json" });
  expectStatus(malformed, 400, "malformed JSON body → 400");
  expectError(await api(engineerCookie, "POST", `/api/lab-tests/${fx.wcFull.id}/calculate`, { json: { idempotencyKey: "short" } }), 400, "VALIDATION_ERROR", "idempotency key too short → 400");
  const bigPayload = { input: { junk: "x".repeat(300_000) } };
  expectError(await api(engineerCookie, "POST", `/api/lab-tests/${fx.wcFull.id}/calculate`, { json: bigPayload }), 400, "VALIDATION_ERROR", "oversized input → 400");
  const crossOrigin = await api(engineerCookie, "POST", `/api/lab-tests/${fx.wcFull.id}/calculate`, { json: {}, origin: "https://evil.example" });
  expectStatus(crossOrigin, 403, "cross-origin calculate rejected (CSRF guard)");

  // ===== 6. Failed calculations =====
  console.log("--- Suite 6: failed calculations ===");
  const massless = expectSuccess(await api(engineerCookie, "POST", `/api/lab-tests/${fx.wcMassless.id}/calculate`, { json: {} }), "massless WC calculate");
  if (massless?.record?.status === "FAILED" && massless?.record?.errorCode === "MISSING_INPUT") {
    ok("massless record → HTTP 200 + persisted FAILED/MISSING_INPUT (engine outcome ≠ infrastructure error)");
  } else no(`massless record → ${massless?.record?.status}/${massless?.record?.errorCode}`);
  expectError(await api(engineerCookie, "GET", `/api/lab-tests/${fx.wcMassless.id}/calculations/latest`), 404, "NOT_FOUND", "no valid result → 404 (never serves stale)");
  const badExplicit = expectSuccess(
    await api(engineerCookie, "POST", `/api/lab-tests/${fx.wcFull.id}/calculate`, {
      json: { input: { waterContentPercent: 5, wetMassG: -10, dryMassG: -20, containerMassG: 1 }, idempotencyKey: "api-badinput-1" },
    }),
    "physically invalid explicit input",
  );
  if (badExplicit?.record?.status === "FAILED" && badExplicit?.record?.errorDetails) {
    ok("invalid explicit input → FAILED record with structured error details");
  } else no("invalid explicit input not recorded");

  // ===== 7. Idempotency + concurrency =====
  console.log("--- Suite 7: idempotency & concurrency ---");
  const k1 = expectSuccess(
    await api(engineerCookie, "POST", `/api/lab-tests/${fx.wcFull.id}/calculate`, {
      json: { input: { waterContentPercent: 19.42, wetMassG: 240, dryMassG: 208.3, containerMassG: 45 }, idempotencyKey: "api-idem-0001" },
    }),
    "explicit calculation with idempotency key",
  );
  const k2 = expectSuccess(
    await api(engineerCookie, "POST", `/api/lab-tests/${fx.wcFull.id}/calculate`, {
      json: { input: { waterContentPercent: 19.42, wetMassG: 240, dryMassG: 208.3, containerMassG: 45 }, idempotencyKey: "api-idem-0001" },
    }),
    "retried request with the same key",
  );
  if (k1?.record?.id === k2?.record?.id) ok("idempotent replay returns the original record");
  else no("idempotency replay created a duplicate");
  // 5 concurrent same-key requests on already-calculated data → all replay
  // the SAME record (dedup precedence — no new records, no duplicates)
  const conc = await Promise.all(
    Array.from({ length: 5 }, () =>
      api(engineerCookie, "POST", `/api/lab-tests/${fx.ds.id}/calculate`, {
        json: { idempotencyKey: "api-conc-0001" },
      }),
    ),
  );
  const concOk = conc.filter((r) => r.status === 200 && r.body?.success === true);
  const concIds = new Set(concOk.map((r) => r.body?.data?.record?.id).filter(Boolean));
  const concCount = await db.calculationRecord.count({ where: { labTestId: fx.ds.id } });
  if (concOk.length === 5 && concIds.size === 1 && concCount === 1) {
    ok("5 concurrent same-key requests → all 200, one record, zero duplicates");
  } else no(`concurrency: ${concOk.length}/5 ok, ${concIds.size} distinct records, ${concCount} total`);
  // 5 concurrent keyless requests on the same stored data → dedup collapse
  const concNK = await Promise.all(
    Array.from({ length: 5 }, () =>
      api(engineerCookie, "POST", `/api/lab-tests/${fx.cbr.id}/calculate`, { json: {} }),
    ),
  );
  const nkOk = concNK.filter((r) => r.status === 200 && r.body?.success === true);
  const nkCount = await db.calculationRecord.count({ where: { labTestId: fx.cbr.id } });
  if (nkOk.length === 5 && nkCount === 1) {
    ok("5 concurrent keyless identical calculations → all 200, exactly 1 record (dedup)");
  } else no(`keyless concurrency: ${nkOk.length}/5 ok, ${nkCount} records`);
  // dedup replay flag
  const again = expectSuccess(await api(engineerCookie, "POST", `/api/lab-tests/${fx.cbr.id}/calculate`, { json: {} }), "sequential repeat calculate");
  const againMeta = (await api(engineerCookie, "POST", `/api/lab-tests/${fx.cbr.id}/calculate`, { json: {} })).body?.meta;
  if (again?.deduplicated === true || againMeta?.deduplicated === true) ok("repeat calculate reports deduplicated=true");
  else no("dedup flag missing");

  // ===== 8. Dry runs =====
  console.log("--- Suite 8: dry runs ---");
  const dryBefore = await db.calculationRecord.count({ where: { labTestId: fx.wcFull.id } });
  const dry = expectSuccess(await api(engineerCookie, "POST", `/api/lab-tests/${fx.wcFull.id}/calculate`, { json: { dryRun: true } }), "dry run");
  if (dry?.dryRun === true && dry?.record === null && dry?.outcome?.status === "ok") {
    ok("dry run: executes without persisting (record null)");
  } else no("dry run semantics wrong");
  const dryAfter = await db.calculationRecord.count({ where: { labTestId: fx.wcFull.id } });
  if (dryAfter === dryBefore) ok("dry run left the history unchanged");
  else no("dry run persisted a record");

  // ===== 9. Invalidation lifecycle (end-to-end through the API) =====
  console.log("--- Suite 9: invalidation lifecycle ---");
  const v1 = expectSuccess(await api(engineerCookie, "POST", `/api/lab-tests/${fx.proctor.id}/calculate`, { json: {} }), "recalculate Proctor (v1 valid)");
  const v1Id = v1?.record?.id ?? pr?.record?.id;
  // re-record a CHANGED registry-valid result (crest-window point 1.97 → 1.95:
  // peak moves, MDD/OMC become 1.951 @ 13.5 — verified against the engine)
  const proctorOriginal = await db.labTest.findUniqueOrThrow({ where: { id: fx.proctor.id } });
  const changed = JSON.parse(JSON.stringify(proctorOriginal.resultData));
  changed.points[3].dryDensity = 1.95;
  const put = await api(engineerCookie, "PUT", `/api/lab-tests/${fx.proctor.id}/result`, {
    json: { result: changed, summary: "re-measured point 1" },
  });
  expectStatus(put, 200, "re-record changed result");
  const v1After = await db.calculationRecord.findUniqueOrThrow({ where: { id: v1Id } });
  if (v1After.isValid === false && v1After.invalidatedReason === "LAB_TEST_RESULT_UPDATED") {
    ok("input change → previous result invalidated (atomic with the result update)");
  } else no(`invalidation failed: valid=${v1After.isValid}`);
  expectError(await api(engineerCookie, "GET", `/api/lab-tests/${fx.proctor.id}/calculations/latest`), 404, "NOT_FOUND", "latest valid → 404 after data change (no stale results)");
  const histInvalid = expectSuccess(await api(engineerCookie, "GET", `/api/lab-tests/${fx.proctor.id}/calculations?isValid=false`), "invalidated history");
  if (histInvalid.some((i: any) => i.id === v1Id)) ok("invalidated record preserved in history");
  else no("history lost the invalidated record");
  const v2 = expectSuccess(await api(engineerCookie, "POST", `/api/lab-tests/${fx.proctor.id}/calculate`, { json: {} }), "recalculate after invalidation");
  const latest2 = expectSuccess(await api(engineerCookie, "GET", `/api/lab-tests/${fx.proctor.id}/calculations/latest`), "latest after recalculation");
  if (latest2?.id === v2?.record?.id && latest2?.output?.results?.maxDryDensity === 1.951 && latest2?.output?.results?.optimumMoisture === 13.5) {
    ok("latest valid flipped to the recalculated record (changed-data golden 1.951 @ 13.5)");
  } else no(`latest after recalculation wrong: id ${latest2?.id === v2?.record?.id}, MDD ${latest2?.output?.results?.maxDryDensity} @ ${latest2?.output?.results?.optimumMoisture}`);
  // re-opening clears the result → invalidation + latest 404
  const reopen = await api(engineerCookie, "PATCH", `/api/lab-tests/${fx.proctor.id}`, {
    json: { status: "IN_PROGRESS" },
  });
  expectStatus(reopen, 200, "re-open the test (clears result)");
  const v2After = await db.calculationRecord.findUniqueOrThrow({ where: { id: v2.record.id } });
  if (v2After.isValid === false && v2After.invalidatedReason === "LAB_TEST_RESULT_CLEARED") {
    ok("re-opening → LAB_TEST_RESULT_CLEARED invalidation");
  } else no(`clear invalidation failed: ${v2After.invalidatedReason}`);
  expectError(await api(engineerCookie, "GET", `/api/lab-tests/${fx.proctor.id}/calculations/latest`), 404, "NOT_FOUND", "latest valid → 404 after clear");
  // restore the original result + recalculate (leaves the test in a healthy state)
  const restore = await api(engineerCookie, "PUT", `/api/lab-tests/${fx.proctor.id}/result`, {
    json: { result: proctorOriginal.resultData, summary: "restored fixture" },
  });
  expectStatus(restore, 200, "restore original result");
  const v3 = expectSuccess(await api(engineerCookie, "POST", `/api/lab-tests/${fx.proctor.id}/calculate`, { json: {} }), "final recalculation");
  if (v3?.record?.output?.results?.maxDryDensity === 1.971) ok("restored data → original golden again (full lifecycle)");
  else no("final recalculation golden wrong");

  // ===== 10. Activity logging =====
  console.log("--- Suite 10: activity logging ---");
  const acts = expectSuccess(await api(adminCookie, "GET", "/api/activity?limit=100"), "admin reads activity feed");
  const calcActs = (acts ?? []).filter((a: any) => String(a.action).startsWith("CALCULATION_"));
  const actionTypes = new Set(calcActs.map((a: any) => a.action));
  for (const expected of ["CALCULATION_CREATED", "CALCULATION_COMPLETED", "CALCULATION_FAILED", "CALCULATION_INVALIDATED", "CALCULATION_RECALCULATED"]) {
    if (actionTypes.has(expected)) ok(`${expected} present in the audit feed`);
    else no(`${expected} missing from the audit feed`);
  }
  const denialAct = (acts ?? []).find((a: any) => a.action === "CALCULATION_ACCESS_DENIED");
  if (denialAct && denialAct.user?.name) ok("CALCULATION_ACCESS_DENIED logged with user attribution");
  else no("denial event missing");
  const actsBlob = JSON.stringify(calcActs);
  if (!actsBlob.includes("wetMassG") && !actsBlob.includes("points") && !actsBlob.includes("inputSnapshot")) {
    ok("activity details carry no input/output payloads");
  } else no("activity leaked payload data");
  if (!actsBlob.includes("password") && !actsBlob.includes("token") && !actsBlob.includes("secret")) {
    ok("no sensitive values in activity records");
  } else no("sensitive data in activity records");
  const rockActs = expectSuccess(await api(rockEngineerCookie, "GET", "/api/activity?limit=100"), "RockWorks reads own feed");
  if ((rockActs ?? []).every((a: any) => a.organizationId !== undefined)) ok("activity feed per-organization (unchanged behavior)");
  else no("activity feed org scoping broken");

  // ===== final checks =====
  if (envelopeViolations.length === 0) ok("all responses used the uniform envelope");
  else { for (const v of envelopeViolations) no(`envelope: ${v}`); }
  if (leakScans.length === 0) ok("no stack traces / internals / secrets in any response");
  else { for (const v of leakScans) no(`leak: ${v}`); }

  await db.$disconnect();
}

main()
  .catch(async (e) => {
    console.error("SUITE ERROR:", e);
    fail++;
    await db.$disconnect();
    process.exit(1);
  })
  .then(async () => {
    await db.$disconnect();
    console.log(`\nM5.2-INTEGRATION API SUITE: ${pass} passed, ${fail} failed`);
    process.exit(fail > 0 ? 1 : 0);
  });
