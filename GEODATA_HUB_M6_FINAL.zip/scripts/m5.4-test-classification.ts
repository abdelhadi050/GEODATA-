/**
 * GEODATA HUB — M5.4 classification golden tests.
 *
 * Verifies that the USCS (ASTM D2487-17) and AASHTO (M 145-91) classification
 * modules produce the expected symbols, group names, and Group Index values
 * for known reference soils.
 *
 * Golden values were derived by running the engine against the seed fixtures
 * (GRAN_SANDY_SILT, GRAN_SILTY_CLAY, GRAN_DUNE_SAND, ATT_CLAY_31, ATT_CLAY_42,
 * ATT_CLAY_55) and recording the verbatim outputs. The authoritativeness of
 * these golden values rests on the standard-text invariants implemented in the
 * modules — every threshold and formula is cited inline in the module source.
 *
 * NOTABLE: the lab-entered "uscsClassification: 'SM'" on the GRAN_SANDY_SILT
 * fixture DISAGREES with the engine's computed symbol (SC). This is a feature,
 * not a bug: the lab-entered text is a free-text label, not an authoritative
 * classification. With LL=31 and PI=15, the soil plots ABOVE the A-line (A-line
 * PI at LL=31 = 0.73×(31−20) = 8.03; PI=15 > 8.03) and PI ≥ 7 — per ASTM D2487
 * Table 7 the fines modifier is C (clayey), not M (silty). The engine surfaces
 * this disagreement rather than echoing the lab's manual label.
 */
import { describe, it, expect } from "bun:test";
import { runClassification } from "@/lib/classification/engine";
import { uscsModule } from "@/lib/classification/modules/uscs";
import { aashtoModule } from "@/lib/classification/modules/aashto";
import { CLASSIFICATION_ENGINE_VERSION } from "@/lib/classification/engine";

// ---------------------------------------------------------------------------
// Seed fixtures (verbatim from prisma/seed.ts, sorted increasing diameter)
// ---------------------------------------------------------------------------

const GRAN_SANDY_SILT_POINTS = [
  { diameterMm: 0.002, percentFiner: 5 },
  { diameterMm: 0.006, percentFiner: 8 },
  { diameterMm: 0.02, percentFiner: 13 },
  { diameterMm: 0.063, percentFiner: 20 },
  { diameterMm: 0.125, percentFiner: 27 },
  { diameterMm: 0.25, percentFiner: 38 },
  { diameterMm: 0.5, percentFiner: 52 },
  { diameterMm: 1, percentFiner: 66 },
  { diameterMm: 2, percentFiner: 78 },
  { diameterMm: 4, percentFiner: 87 },
  { diameterMm: 8, percentFiner: 93 },
  { diameterMm: 16, percentFiner: 97 },
  { diameterMm: 31.5, percentFiner: 99 },
  { diameterMm: 63, percentFiner: 100 },
];

const GRAN_SILTY_CLAY_POINTS = [
  { diameterMm: 0.001, percentFiner: 21 },
  { diameterMm: 0.002, percentFiner: 27 },
  { diameterMm: 0.006, percentFiner: 41 },
  { diameterMm: 0.02, percentFiner: 62 },
  { diameterMm: 0.063, percentFiner: 88 },
  { diameterMm: 0.125, percentFiner: 93 },
  { diameterMm: 0.25, percentFiner: 96 },
  { diameterMm: 0.5, percentFiner: 98 },
  { diameterMm: 1, percentFiner: 99 },
  { diameterMm: 2, percentFiner: 100 },
];

const GRAN_DUNE_SAND_POINTS = [
  { diameterMm: 0.063, percentFiner: 2 },
  { diameterMm: 0.125, percentFiner: 6 },
  { diameterMm: 0.25, percentFiner: 24 },
  { diameterMm: 0.5, percentFiner: 62 },
  { diameterMm: 1, percentFiner: 91 },
  { diameterMm: 2, percentFiner: 99 },
  { diameterMm: 4, percentFiner: 100 },
];

const ATT_CLAY_42 = { liquidLimit: 42, plasticLimit: 19, plasticityIndex: 23 };
const ATT_CLAY_31 = { liquidLimit: 31, plasticLimit: 16, plasticityIndex: 15 };
const ATT_CLAY_55 = { liquidLimit: 55, plasticLimit: 24, plasticityIndex: 31, shrinkageLimit: 16 };

// ---------------------------------------------------------------------------
// USCS golden cases
// ---------------------------------------------------------------------------

describe("USCS classification (ASTM D2487-17) — golden cases", () => {
  it("GRAN_SANDY_SILT + ATT_CLAY_31 → SC (clayey sand; lab-entered SM is corrected)", () => {
    const outcome = runClassification(uscsModule, {
      points: GRAN_SANDY_SILT_POINTS,
      atterberg: ATT_CLAY_31,
    });
    expect(outcome.status).toBe("ok");
    if (outcome.status !== "ok") throw new Error("unreachable");
    expect(outcome.results.symbol).toBe("SC");
    expect(outcome.results.groupName).toBe("Clayey sand");
    expect(outcome.results.category).toBe("COARSE_GRAINED");
    expect(outcome.results.primaryType).toBe("S");
    // % fines ~ 21.78 (interpolated between 0.063→20% and 0.125→27%)
    expect(outcome.results.percentFines).toBeCloseTo(21.78, 1);
    // Sand-dominated coarse fraction
    expect(outcome.results.percentSand).toBeGreaterThan(50);
    expect(outcome.results.percentGravel).toBeLessThan(20);
    // A-line PI at LL=31: 0.73×(31−20) = 8.03
    expect(outcome.results.aLinePiAtLl).toBeCloseTo(8.03, 2);
    // U-line PI at LL=31: 0.9×(31−8) = 20.7
    expect(outcome.results.uLinePiAtLl).toBeCloseTo(20.7, 2);
    // Computed D10/D30/D60 from the PSD (interpolated, not the entered values)
    expect(outcome.results.d10).toBeCloseTo(0.0097, 3);
    expect(outcome.results.d60).toBeCloseTo(0.743, 2);
    expect(outcome.results.uniformityCoefficient).toBeGreaterThan(4); // Cu > 4 ⇒ would be GW if gravel
    // Standard provenance
    expect(outcome.standard).toBe("ASTM D2487");
    expect(outcome.standardVersion).toBe("D2487-17");
    expect(outcome.moduleId).toBe("uscs");
    expect(outcome.engineVersion).toBe(CLASSIFICATION_ENGINE_VERSION);
    // Reasoning must include the coarse/fine split and gravel/sand clauses
    const clauses = outcome.results.reasoning.map((r) => r.clause);
    expect(clauses.some((c) => c.includes("D2487 §6.2.1"))).toBe(true);
    expect(clauses.some((c) => c.includes("D2487 §6.3.1"))).toBe(true);
  });

  it("GRAN_SILTY_CLAY + ATT_CLAY_42 → CL (lean clay)", () => {
    const outcome = runClassification(uscsModule, {
      points: GRAN_SILTY_CLAY_POINTS,
      atterberg: ATT_CLAY_42,
    });
    expect(outcome.status).toBe("ok");
    if (outcome.status !== "ok") throw new Error("unreachable");
    expect(outcome.results.symbol).toBe("CL");
    expect(outcome.results.groupName).toBe("Lean clay");
    expect(outcome.results.category).toBe("FINE_GRAINED");
    // 88% fines at #200 — fine-grained
    expect(outcome.results.percentFines).toBeGreaterThan(50);
    expect(outcome.results.percentFines).toBeCloseTo(89.27, 1);
    // A-line PI at LL=42: 0.73×(42−20) = 16.06; PI=23 > 16.06 ⇒ above A-line
    expect(outcome.results.aLinePiAtLl).toBeCloseTo(16.06, 2);
    expect(outcome.results.enteredLiquidLimit).toBe(42);
    expect(outcome.results.enteredPlasticityIndex).toBe(23);
  });

  it("GRAN_SILTY_CLAY + ATT_CLAY_55 → CH (fat clay, LL ≥ 50)", () => {
    const outcome = runClassification(uscsModule, {
      points: GRAN_SILTY_CLAY_POINTS,
      atterberg: ATT_CLAY_55,
    });
    expect(outcome.status).toBe("ok");
    if (outcome.status !== "ok") throw new Error("unreachable");
    expect(outcome.results.symbol).toBe("CH");
    expect(outcome.results.groupName).toBe("Fat clay");
    expect(outcome.results.category).toBe("FINE_GRAINED");
    // A-line PI at LL=55: 0.73×(55−20) = 25.55; PI=31 > 25.55 ⇒ above A-line
    expect(outcome.results.aLinePiAtLl).toBeCloseTo(25.55, 2);
  });

  it("GRAN_DUNE_SAND (no Atterberg) → SP (clean poorly-graded sand, <5% fines)", () => {
    const outcome = runClassification(uscsModule, {
      points: GRAN_DUNE_SAND_POINTS,
    });
    expect(outcome.status).toBe("ok");
    if (outcome.status !== "ok") throw new Error("unreachable");
    expect(outcome.results.symbol).toBe("SP");
    expect(outcome.results.category).toBe("COARSE_GRAINED");
    expect(outcome.results.percentFines).toBeLessThan(5);
    expect(outcome.results.percentFines).toBeCloseTo(3.02, 1);
    // Clean sand: Cu < 6 ⇒ poorly-graded
    expect(outcome.results.uniformityCoefficient).toBeLessThan(6);
    expect(outcome.results.uniformityCoefficient).toBeCloseTo(3.306, 2);
    // No Atterberg needed for clean coarse-grained soil
    expect(outcome.results.enteredLiquidLimit).toBeNull();
    expect(outcome.results.aLinePiAtLl).toBeNull();
  });

  it("GRAN_DUNE_SAND + ATT_CLAY_31 → SP (clean sand ignores Atterberg)", () => {
    const outcome = runClassification(uscsModule, {
      points: GRAN_DUNE_SAND_POINTS,
      atterberg: ATT_CLAY_31,
    });
    expect(outcome.status).toBe("ok");
    if (outcome.status !== "ok") throw new Error("unreachable");
    // Clean sand (<5% fines) — Atterberg data is echoed but does not affect symbol
    expect(outcome.results.symbol).toBe("SP");
    expect(outcome.results.enteredLiquidLimit).toBe(31);
  });
});

// ---------------------------------------------------------------------------
// USCS edge cases — invalid / insufficient input
// ---------------------------------------------------------------------------

describe("USCS classification — edge cases", () => {
  it("rejects unordered points (coarse-to-fine storage order)", () => {
    const outcome = runClassification(uscsModule, {
      points: [
        { diameterMm: 4, percentFiner: 100 },
        { diameterMm: 2, percentFiner: 99 },
        { diameterMm: 1, percentFiner: 91 },
        { diameterMm: 0.5, percentFiner: 62 },
      ],
    });
    expect(outcome.status).toBe("error");
    if (outcome.status !== "error") throw new Error("unreachable");
    expect(outcome.error.code).toBe("INVALID_INPUT");
    expect(outcome.error.message).toContain("must be greater than");
  });

  it("rejects duplicate diameterMm", () => {
    const outcome = runClassification(uscsModule, {
      points: [
        { diameterMm: 0.1, percentFiner: 10 },
        { diameterMm: 0.1, percentFiner: 15 },
        { diameterMm: 1, percentFiner: 50 },
        { diameterMm: 5, percentFiner: 90 },
      ],
    });
    expect(outcome.status).toBe("error");
    if (outcome.status !== "error") throw new Error("unreachable");
    expect(outcome.error.code).toBe("INVALID_INPUT");
    expect(outcome.error.message).toContain("Duplicate diameterMm");
  });

  it("rejects non-monotonic percentFiner", () => {
    const outcome = runClassification(uscsModule, {
      points: [
        { diameterMm: 0.1, percentFiner: 50 },
        { diameterMm: 0.5, percentFiner: 40 }, // decreases
        { diameterMm: 1, percentFiner: 60 },
        { diameterMm: 5, percentFiner: 90 },
      ],
    });
    expect(outcome.status).toBe("error");
    if (outcome.status !== "error") throw new Error("unreachable");
    expect(outcome.error.code).toBe("INVALID_INPUT");
    expect(outcome.error.message).toContain("non-decreasing");
  });

  it("rejects fine-grained soil without Atterberg data (MISSING_INPUT)", () => {
    const outcome = runClassification(uscsModule, {
      points: GRAN_SILTY_CLAY_POINTS,
    });
    expect(outcome.status).toBe("error");
    if (outcome.status !== "error") throw new Error("unreachable");
    expect(outcome.error.code).toBe("MISSING_INPUT");
    expect(outcome.error.message).toContain("Atterberg");
  });

  it("rejects Atterberg with PL ≥ LL (INCONSISTENT_INPUT)", () => {
    const outcome = runClassification(uscsModule, {
      points: GRAN_SILTY_CLAY_POINTS,
      atterberg: { liquidLimit: 30, plasticLimit: 35, plasticityIndex: 0 },
    });
    expect(outcome.status).toBe("error");
    if (outcome.status !== "error") throw new Error("unreachable");
    expect(outcome.error.code).toBe("INCONSISTENT_INPUT");
    expect(outcome.error.message).toContain("plasticLimit");
  });

  it("rejects Atterberg with PI ≠ LL − PL (INCONSISTENT_INPUT)", () => {
    const outcome = runClassification(uscsModule, {
      points: GRAN_SILTY_CLAY_POINTS,
      atterberg: { liquidLimit: 50, plasticLimit: 20, plasticityIndex: 40 }, // expected 30
    });
    expect(outcome.status).toBe("error");
    if (outcome.status !== "error") throw new Error("unreachable");
    expect(outcome.error.code).toBe("INCONSISTENT_INPUT");
  });

  it("rejects PSD that does not span #200 (cannot determine fines)", () => {
    const outcome = runClassification(uscsModule, {
      points: [
        { diameterMm: 1, percentFiner: 10 },
        { diameterMm: 2, percentFiner: 20 },
        { diameterMm: 4, percentFiner: 40 },
        { diameterMm: 8, percentFiner: 80 },
      ],
      // No sieve at or below 0.075 mm — the boundary helper doesn't apply
      // because the smallest measured percentFiner is 10 (not 0).
    });
    expect(outcome.status).toBe("error");
    if (outcome.status !== "error") throw new Error("unreachable");
    expect(outcome.error.code).toBe("ARITHMETIC_DOMAIN_ERROR");
    expect(outcome.error.message).toContain("#200 sieve");
  });
});

// ---------------------------------------------------------------------------
// AASHTO golden cases
// ---------------------------------------------------------------------------

describe("AASHTO classification (M 145-91) — golden cases", () => {
  it("GRAN_SANDY_SILT + ATT_CLAY_31 → A-2-6 (0) (granular, LL≤40, PI≥11)", () => {
    const outcome = runClassification(aashtoModule, {
      points: GRAN_SANDY_SILT_POINTS,
      atterberg: ATT_CLAY_31,
    });
    expect(outcome.status).toBe("ok");
    if (outcome.status !== "ok") throw new Error("unreachable");
    expect(outcome.results.group).toBe("A-2-6");
    expect(outcome.results.designation).toBe("A-2-6 (0)");
    expect(outcome.results.category).toBe("GRANULAR");
    // F = 21.78 % ≤ 35 → granular
    expect(outcome.results.percentPassingNo200).toBeLessThan(35);
    expect(outcome.results.percentPassingNo200).toBeCloseTo(21.78, 1);
    // LL=31 ≤ 40, PI=15 ≥ 11 → A-2-6
    expect(outcome.results.liquidLimit).toBe(31);
    expect(outcome.results.plasticityIndex).toBe(15);
    // GI: A-2-6 uses only the PI-term per M 145 §3; LL-partial forced to 0.
    expect(outcome.results.giLlPartial).toBe(0);
    // PI-partial = 0.01 × (F−15) × (PI−10) = 0.01 × (21.78−15) × (15−10) = 0.339
    expect(outcome.results.giPiPartial).toBeCloseTo(0.3391, 3);
    // GI = round(0 + 0.3391) = 0 (rounds to nearest whole number; 0.34 → 0)
    expect(outcome.results.groupIndex).toBe(0);
    expect(outcome.standard).toBe("AASHTO M 145");
    expect(outcome.standardVersion).toBe("M 145-91 (2004)");
  });

  it("GRAN_SILTY_CLAY + ATT_CLAY_42 → A-7-6 (21) (silt-clay, LL≥41, PI>LL−30)", () => {
    const outcome = runClassification(aashtoModule, {
      points: GRAN_SILTY_CLAY_POINTS,
      atterberg: ATT_CLAY_42,
    });
    expect(outcome.status).toBe("ok");
    if (outcome.status !== "ok") throw new Error("unreachable");
    expect(outcome.results.group).toBe("A-7-6");
    expect(outcome.results.designation).toBe("A-7-6 (21)");
    expect(outcome.results.category).toBe("SILT_CLAY");
    // F = 89.27 % > 35 → silt-clay
    expect(outcome.results.percentPassingNo200).toBeGreaterThan(35);
    expect(outcome.results.percentPassingNo200).toBeCloseTo(89.27, 1);
    // LL=42 ≥ 41, PI=23 ≥ 11, PI=23 > LL−30=12 → A-7-6
    expect(outcome.results.liquidLimit).toBe(42);
    expect(outcome.results.plasticityIndex).toBe(23);
    // GI: LL-partial + PI-partial
    // LL-partial = (F−35) × [0.2 + 0.005×(LL−40)] = (89.27−35) × [0.2 + 0.01] = 54.27 × 0.21 = 11.397
    expect(outcome.results.giLlPartial).toBeCloseTo(11.397, 2);
    // PI-partial = 0.01 × (F−15) × (PI−10) = 0.01 × 74.27 × 13 = 9.655
    expect(outcome.results.giPiPartial).toBeCloseTo(9.655, 2);
    // GI = round(11.397 + 9.655) = round(21.05) = 21
    expect(outcome.results.groupIndex).toBe(21);
  });

  it("GRAN_SILTY_CLAY + ATT_CLAY_55 → A-7-6 (31) (high plasticity, PI>LL−30)", () => {
    const outcome = runClassification(aashtoModule, {
      points: GRAN_SILTY_CLAY_POINTS,
      atterberg: ATT_CLAY_55,
    });
    expect(outcome.status).toBe("ok");
    if (outcome.status !== "ok") throw new Error("unreachable");
    expect(outcome.results.group).toBe("A-7-6");
    expect(outcome.results.designation).toBe("A-7-6 (31)");
    // LL=55 ≥ 41, PI=31 ≥ 11, PI=31 > LL−30=25 → A-7-6
    expect(outcome.results.liquidLimit).toBe(55);
    expect(outcome.results.plasticityIndex).toBe(31);
    // GI = round(LL-partial + PI-partial) = round(14.925 + 15.597) = round(30.52) = 31
    expect(outcome.results.giLlPartial).toBeCloseTo(14.925, 2);
    expect(outcome.results.giPiPartial).toBeCloseTo(15.597, 2);
    expect(outcome.results.groupIndex).toBe(31);
  });

  it("GRAN_DUNE_SAND (no Atterberg) → A-3 (0) (NP fine sand)", () => {
    const outcome = runClassification(aashtoModule, {
      points: GRAN_DUNE_SAND_POINTS,
    });
    expect(outcome.status).toBe("ok");
    if (outcome.status !== "ok") throw new Error("unreachable");
    expect(outcome.results.group).toBe("A-3");
    expect(outcome.results.designation).toBe("A-3 (0)");
    expect(outcome.results.category).toBe("GRANULAR");
    // A-3: %pass#40 ≥ 51, %pass#200 ≤ 10, NP
    expect(outcome.results.percentPassingNo40).toBeGreaterThan(51);
    expect(outcome.results.percentPassingNo200).toBeLessThanOrEqual(10);
    expect(outcome.results.liquidLimit).toBeNull();
    expect(outcome.results.plasticityIndex).toBeNull();
    expect(outcome.results.groupIndex).toBe(0);
    // INSUFFICIENT_DATA warning about NP soil
    expect(outcome.warnings.length).toBe(1);
    expect(outcome.warnings[0].code).toBe("INSUFFICIENT_DATA");
  });
});

// ---------------------------------------------------------------------------
// AASHTO edge cases
// ---------------------------------------------------------------------------

describe("AASHTO classification — edge cases", () => {
  it("rejects unordered points", () => {
    const outcome = runClassification(aashtoModule, {
      points: [
        { diameterMm: 4, percentFiner: 100 },
        { diameterMm: 2, percentFiner: 99 },
        { diameterMm: 1, percentFiner: 91 },
        { diameterMm: 0.5, percentFiner: 62 },
      ],
    });
    expect(outcome.status).toBe("error");
    if (outcome.status !== "error") throw new Error("unreachable");
    expect(outcome.error.code).toBe("INVALID_INPUT");
  });

  it("rejects silt-clay soil without Atterberg data (MISSING_INPUT)", () => {
    const outcome = runClassification(aashtoModule, {
      points: GRAN_SILTY_CLAY_POINTS, // 89% fines → silt-clay
    });
    expect(outcome.status).toBe("error");
    if (outcome.status !== "error") throw new Error("unreachable");
    expect(outcome.error.code).toBe("MISSING_INPUT");
    expect(outcome.error.message).toContain("Atterberg");
  });

  it("rejects PSD that does not span #200 (cannot determine fines)", () => {
    const outcome = runClassification(aashtoModule, {
      points: [
        { diameterMm: 1, percentFiner: 10 },
        { diameterMm: 2, percentFiner: 20 },
        { diameterMm: 4, percentFiner: 40 },
        { diameterMm: 8, percentFiner: 80 },
      ],
    });
    expect(outcome.status).toBe("error");
    if (outcome.status !== "error") throw new Error("unreachable");
    expect(outcome.error.code).toBe("ARITHMETIC_DOMAIN_ERROR");
  });
});

// ---------------------------------------------------------------------------
// Engine determinism + provenance
// ---------------------------------------------------------------------------

describe("Classification engine — determinism and provenance", () => {
  it("identical inputs produce deeply identical outcomes (determinism)", () => {
    const a = runClassification(uscsModule, {
      points: GRAN_SANDY_SILT_POINTS,
      atterberg: ATT_CLAY_31,
    });
    const b = runClassification(uscsModule, {
      points: GRAN_SANDY_SILT_POINTS,
      atterberg: ATT_CLAY_31,
    });
    expect(JSON.stringify(a)).toBe(JSON.stringify(b));
  });

  it("every outcome carries the standard + engine provenance", () => {
    const ok = runClassification(uscsModule, {
      points: GRAN_SANDY_SILT_POINTS,
      atterberg: ATT_CLAY_31,
    });
    expect(ok.status).toBe("ok");
    if (ok.status !== "ok") throw new Error("unreachable");
    expect(ok.engineVersion).toBe(CLASSIFICATION_ENGINE_VERSION);
    expect(ok.moduleId).toBe("uscs");
    expect(ok.moduleVersion).toBe("1.0.0");
    expect(ok.standard).toBe("ASTM D2487");
    expect(ok.standardVersion).toBe("D2487-17");
    expect(ok.sourceType).toBe("SAMPLE");

    const err = runClassification(uscsModule, { points: [] });
    expect(err.status).toBe("error");
    if (err.status !== "error") throw new Error("unreachable");
    // Even failures carry the provenance — historical records always trace back
    // to the standard under which they were attempted.
    expect(err.engineVersion).toBe(CLASSIFICATION_ENGINE_VERSION);
    expect(err.standard).toBe("ASTM D2487");
    expect(err.standardVersion).toBe("D2487-17");
  });
});
