#!/usr/bin/env python3
"""M5.2-e golden-value independent verification (CBR 2.5 / 5.0 / max rule).

Run BEFORE writing the test expectations. Every expected value below is
computed independently of the TypeScript engine:

- high-precision Decimal (60 digits) for the true CBR ratios,
- IEEE-754 double probes mirroring the exact JS operation order designed for
  the module (exact-hit load reads, linear interpolation
  L = L0 + (L1 - L0) * (t - x0) / (x1 - x0), CBR = 100 * load / standard,
  steepest-segment origin correction x0 = x_i - L_i / slope),
- half-away-from-zero rounding predictions for the output boundary, with a
  tie-distance guard.

Designed module arithmetic (M5.2-e, ASTM D1883 / NF P94-078):

  CBR(2.5 mm) = 100 * load(2.5 mm) / 13.24 kN      (governed VERIFIED constant)
  CBR(5.0 mm) = 100 * load(5.0 mm) / 19.96 kN      (governed VERIFIED constant)
  reported    = max(CBR 2.5, CBR 5.0)              (registry identity rule)
  origin correction: steepest consecutive segment projected to zero load;
                     corrected penetration = penetration - x0.
  Entered-comparison tolerance: +/-0.01 pp (registry CBR identity magnitude).
"""
from decimal import Decimal as D, getcontext
import math

getcontext().prec = 60

STD_2_5 = 13.24
STD_5_0 = 19.96


def round_to_double(x, dp):
    scaled = x * 10 ** dp
    if abs(scaled) > 2 ** 53:
        raise ValueError("out of safe range")
    corrected_abs = abs(scaled) * (1 + 2.220446049250313e-16)
    rounded = math.floor(corrected_abs + 0.5)
    signed = -rounded if scaled < 0 else rounded
    result = signed / 10 ** dp
    return 0.0 if result == 0 else result


def tie_guard(x, dp, label):
    scaled = abs(x) * 10 ** dp
    dist = abs(scaled - math.floor(scaled) - 0.5)
    if dist < 1e-9:
        print(f"  !! TIE WARNING {label}: {x} at {dp} dp (scaled {scaled})")


def show(label, value, dp):
    tie_guard(value, dp, label)
    print(f"  {label:<56} = {value!r:<26} -> {dp} dp: {round_to_double(value, dp)}")
    return round_to_double(value, dp)


def load_at(points, target):
    """Mirror of loadAtPenetration (exact hit / linear interpolation)."""
    for i, (x, l) in enumerate(points):
        if x == target:
            return l
        if x > target:
            if i == 0:
                return None
            x0, l0 = points[i - 1]
            x1, l1 = points[i]
            return l0 + (l1 - l0) * ((target - x0) / (x1 - x0))
    return None


def origin_shift(points):
    """Mirror of applyOriginCorrection (steepest segment -> zero-load axis)."""
    best_i, best_slope = 0, float("-inf")
    for i in range(len(points) - 1):
        slope = (points[i + 1][1] - points[i][1]) / (points[i + 1][0] - points[i][0])
        if slope > best_slope:
            best_slope, best_i = slope, i
    xi, li = points[best_i]
    return xi - li / best_slope, best_i, best_slope


def cbr_report(label, points, entered=None, correction=False):
    print("=" * 100)
    print(f"FIXTURE {label}")
    print("=" * 100)
    curve = points
    shift = 0.0
    if correction:
        shift, seg, slope = origin_shift(points)
        print(f"  steepest segment index {seg}, slope = {slope!r}")
        show("origin shift x0 [mm]", shift, 3)
        if shift > 0:
            curve = [(x - shift, l) for (x, l) in points if x - shift >= 0]
            print(f"  corrected curve: {curve}")
        else:
            print("  shift <= 0 -> no correction applicable (INSUFFICIENT_DATA warning)")
    l25 = load_at(curve, 2.5)
    l50 = load_at(curve, 5.0)
    if l25 is not None:
        show("load at 2.5 mm [kN]", l25, 3)
        cbr25 = 100.0 * l25 / STD_2_5
        dec25 = (D(100) * D(str(l25)) / D("13.24"))
        print(f"  Decimal truth CBR2.5 = {dec25}")
        show("CBR at 2.5 mm [%]", cbr25, 2)
    else:
        print("  load at 2.5 mm: OUT OF RANGE -> null + INSUFFICIENT_DATA")
        cbr25 = None
    if l50 is not None:
        show("load at 5.0 mm [kN]", l50, 3)
        cbr50 = 100.0 * l50 / STD_5_0
        dec50 = (D(100) * D(str(l50)) / D("19.96"))
        print(f"  Decimal truth CBR5.0 = {dec50}")
        show("CBR at 5.0 mm [%]", cbr50, 2)
    else:
        print("  load at 5.0 mm: OUT OF RANGE -> null + INSUFFICIENT_DATA")
        cbr50 = None
    if cbr25 is not None and cbr50 is not None:
        reported = max(cbr25, cbr50)
        governs = "5.0MM" if cbr50 > cbr25 else "2.5MM"
        show("reported CBR (max rule) [%]", reported, 2)
        print(f"  reported from: {governs}  (5.0 governs -> REPORTING_RULE warning: {cbr50 > cbr25})")
    elif cbr25 is not None or cbr50 is not None:
        reported = cbr25 if cbr25 is not None else cbr50
        show("reported CBR (single available) [%]", reported, 2)
    if entered:
        for field, comp in [("cbrAt2_5", cbr25), ("cbrAt5_0", cbr50)]:
            if comp is not None and field in entered:
                d = comp - entered[field]
                print(f"  |computed {field} - entered {entered[field]}| = {abs(d)} -> warn? {abs(d) > 0.01}")
    print()
    return curve


print("=" * 100)
print("GOVERNED CONSTANTS CONSUMED (D8 registry, verified M5.2-e)")
print("=" * 100)
print(f"  cbr.standardLoadKnAt2_5mm = {STD_2_5} kN")
print(f"  cbr.standardLoadKnAt5_0mm = {STD_5_0} kN")
print()

# C1 - CBR_SOAKED_A1 seed: exact hits at 2.5 (8.9 kN) and 5.0 (17.2 kN)
C1 = [(0.5, 1.6), (1, 3.2), (2, 6.8), (2.5, 8.9), (4, 14.1), (5, 17.2), (7.5, 22.4), (10, 26.5), (12.5, 30.1)]
cbr_report("C1 - CBR_SOAKED_A1 (exact hits; entered {18, 21, 21} -> 3 discrepancies)",
           C1, entered={"cbrAt2_5": 18, "cbrAt5_0": 21, "cbrValue": 21})

# C2 - CBR_UNSOAKED_A1 seed: exact hits; computed CBR exceeds 100 (unclamped)
C2 = [(0.5, 3.5), (1, 7.1), (2, 14.9), (2.5, 19.1), (4, 29.6), (5, 36.2), (7.5, 47.5), (10, 55.3)]
cbr_report("C2 - CBR_UNSOAKED_A1 (computed > 100 %, unclamped; entered {45, 38, 45})",
           C2, entered={"cbrAt2_5": 45, "cbrAt5_0": 38, "cbrValue": 45})

# C3 - interpolation case (no exact 2.5 / 5.0 points)
C3 = [(1, 3.0), (2, 6.5), (3, 9.8), (4, 13.1), (6, 19.3)]
cbr_report("C3 - interpolation (loads interpolated between bracketing points)", C3)

# C4 - origin correction (concave-upward start, analyst-requested)
C4 = [(0.5, 0.2), (1.0, 0.9), (2.0, 3.4), (3.0, 6.6), (5.0, 13.3), (7.5, 21.2)]
cbr_report("C4 - origin correction requested (steepest-segment construction)", C4, correction=True)

# C5 - correction requested but not applicable (normal concave-down curve)
C5 = [(0.5, 3.0), (1.0, 5.6), (2.0, 10.2), (4.0, 17.8), (7.5, 27.4)]
cbr_report("C5 - correction requested, curve has no origin error (shift <= 0)", C5, correction=True)

# C6 - 2.5 mm above the measured range (max penetration 2.0)
C6 = [(0.5, 1.2), (1.0, 2.4), (2.0, 4.6)]
cbr_report("C6 - 2.5/5.0 mm beyond the measured range -> null + INSUFFICIENT_DATA x2", C6)

# C7 - 2.5 mm below the measured range (min penetration 3.0)
C7 = [(3.0, 9.0), (5.0, 14.0), (7.5, 20.0)]
cbr_report("C7 - 2.5 mm before the measured range -> CBR2.5 null; CBR5.0 computed", C7)

print("=" * 100)
print("VALIDATION-CASE NUMBERS")
print("=" * 100)
print("  entered cbrValue 30 vs max(18, 21) = 21: |30 - 21| = 9 > 0.01 -> INVALID_INPUT (registry mirror)")
print("  duplicate penetration (2.5 twice) -> INVALID_INPUT (registry uniqueness + ordering)")
print("  penetration 16 > 15 -> INVALID_INPUT (bounds)")
print("  loadKn 61 > 60 -> INVALID_INPUT (bounds)")
print("  unordered points -> INVALID_INPUT (ordering rule)")
print("  1 point -> INVALID_INPUT (min 2); 21 points -> INVALID_INPUT (max 20)")
print("  swellPercent 16 > 15 -> INVALID_INPUT (bounds); 1.2 echoed")
print()
print("ALL GOLDENS VERIFIED - values above are the independent expectations for")
print("scripts/m5.2-test-cbr.ts")
