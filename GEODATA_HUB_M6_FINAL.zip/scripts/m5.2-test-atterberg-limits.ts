/**
 * M5.2-c TEST — Atterberg limits calculation module (LL / PL / IP).
 *
 * Golden values independently verified BEFORE being asserted here (60-digit
 * Decimal regression + IEEE-double probes mirroring the module's exact op
 * order + half-away-from-zero rounding predictions with tie-distance guards
 * in scripts/m5.2-c-verify-goldens.py). Sources: M5.2-c authorization §2–§6,
 * registry atterbergResult contract (ASTM D4318 / NF P94-051), prisma/seed.ts
 * fixtures ATT_CLAY_42 {42,19,23} and ATT_CLAY_31 {31,16,15}.
 *
 * Coverage (authorization §6): normal valid cases (flow-curve regression,
 * PL trial statistics, IP identity); missing inputs; invalid measurements
 * (bounds, non-integer blows, NaN/Infinity, strings); boundary conditions
 * (±1.0 entered tolerance both sides, entered-identity ±1 boundary); non-
 * plastic soils; insufficient experimental points (2 points, identical
 * blows, no 25-blow bracket, non-falling curve); calculation consistency
 * (raw IP = raw LL − raw PL exactly; rounded identity; LL within the
 * measured water-content range); method gate (no silent Casagrande/cone
 * mixing); M5.1 registry parity with the documented divergences;
 * determinism across repeated runs; purity; envelope provenance.
 *
 * Intermediates (from the verifier, double probes; Decimal agrees to <1e-13):
 *   F1 [15→48.2, 20→45.6, 30→40.3, 40→36.8]:
 *     Sxy = −2.894663610449559, Sxx = 0.10622874619473467,
 *     slope = −27.24934364887605, intercept = 80.57639906512931,
 *     LL = intercept + slope·log10(25) = 42.48345136831219.
 *   F2 [18→44.6, 25→42.0, 33→39.8] (exact N=25 point — line read, not point):
 *     slope = −18.23390839208225, intercept = 67.48895933091306,
 *     LL = 41.99904927516046 (≠ 42.0 — the fitted line, not the measured point).
 *   F9 [20→32.7, 25→31.0, 32→29.1]:
 *     slope = −17.63819603046049, intercept = 55.6510307965538,
 *     LL = 30.993890884772757.
 *   P1 [18, 20]: mean = 19 (exact), s = √2 = 1.4142135623730951, range 2.
 *   P5 [15.5, 16.5]: mean = 16 (exact), s = √0.5 = 0.7071067811865476, range 1.
 *   P2 [21.5, 22.0, 22.9]: mean = 22.133333333333333, s = 0.709459888459758,
 *     range = 1.4000000000000021 → 1.4 (roundTo epsilon correction).
 *   Raw values asserted at 1e-9 against the double probes; rounded results
 *   asserted exactly (tie distances ≥ 9e-2 except P2 range, whose rounding
 *   the epsilon-corrected roundTo resolves deterministically — verified).
 * Exit code = number of failures.
 */
import { runCalculation } from "../src/lib/calc/engine";
import type { CalculationOutcome } from "../src/lib/calc/types";
import { ArithmeticDomainError } from "../src/lib/calc/errors";
import {
  ATTERBERG_ENTERED_TOLERANCE,
  LIQUID_LIMIT_BLOWS_TARGET,
  atterbergLimitsCalcInput,
  atterbergLimitsModule,
  fitFlowCurve,
  waterContentAtBlows,
  type AtterbergFlowPoint,
  type AtterbergLimitsInput,
  type AtterbergLimitsRaw,
  type AtterbergLimitsResults,
} from "../src/lib/calc/modules/atterberg-limits";
import { parseLabTestInput, parseLabTestResult } from "../src/lib/lab-tests/registry";

let pass = 0;
let fail = 0;
const ok = (m: string) => { console.log(`PASS: ${m}`); pass++; };
const no = (m: string) => { console.log(`FAIL: ${m}`); fail++; };

const approx = (actual: number, expected: number, tol: number): boolean =>
  Math.abs(actual - expected) <= tol;

type Outcome = CalculationOutcome<AtterbergLimitsInput, AtterbergLimitsRaw, AtterbergLimitsResults>;

interface ExpectedError {
  code: string;
  fieldPath?: string;
  messageHint?: string;
}

function expectError(outcome: Outcome, label: string, expected: ExpectedError): void {
  if (outcome.status !== "error") {
    no(`${label} — expected ${expected.code}, got success`);
    return;
  }
  const { code, message, details } = outcome.error;
  if (code !== expected.code) {
    no(`${label} — expected ${expected.code}, got ${code}`);
    return;
  }
  if (expected.fieldPath !== undefined && details?.fieldPath !== expected.fieldPath) {
    no(`${label} — expected fieldPath ${expected.fieldPath}, got ${String(details?.fieldPath)}`);
    return;
  }
  if (expected.messageHint !== undefined && !message.includes(expected.messageHint)) {
    no(`${label} — message '${message}' lacks hint '${expected.messageHint}'`);
    return;
  }
  ok(`${label} — ${code}${expected.fieldPath ? ` @ ${expected.fieldPath}` : ""}`);
}

// ---------------------------------------------------------------------------
// Fixtures (independently verified in scripts/m5.2-c-verify-goldens.py)
// ---------------------------------------------------------------------------
const FLOW_F1: AtterbergFlowPoint[] = [
  { blows: 15, waterContentPercent: 48.2 },
  { blows: 20, waterContentPercent: 45.6 },
  { blows: 30, waterContentPercent: 40.3 },
  { blows: 40, waterContentPercent: 36.8 },
];
// F2 contains a measured point at exactly 25 blows — the LL is read off the
// FITTED line (41.9990…), never off that single point (42.0).
const FLOW_F2: AtterbergFlowPoint[] = [
  { blows: 18, waterContentPercent: 44.6 },
  { blows: 25, waterContentPercent: 42.0 },
  { blows: 33, waterContentPercent: 39.8 },
];
const FLOW_F7: AtterbergFlowPoint[] = [
  { blows: 15, waterContentPercent: 37.0 },
  { blows: 25, waterContentPercent: 35.5 },
  { blows: 40, waterContentPercent: 33.5 },
];
const FLOW_F9: AtterbergFlowPoint[] = [
  { blows: 20, waterContentPercent: 32.7 },
  { blows: 25, waterContentPercent: 31.0 },
  { blows: 32, waterContentPercent: 29.1 },
];
const TRIALS_P1 = [18, 20]; // mean 19 exact, s = √2, range 2
const TRIALS_P2 = [21.5, 22.0, 22.9];
const TRIALS_P3 = [21.3]; // single trial: s null, range 0
const TRIALS_P4 = [38, 40]; // mean 39 — for the computed PL ≥ LL rejection
const TRIALS_P5 = [15.5, 16.5]; // mean 16 exact, s = √0.5, range 1

const flow = (pairs: ReadonlyArray<readonly [number, number]>): AtterbergFlowPoint[] =>
  pairs.map(([blows, waterContentPercent]) => ({ blows, waterContentPercent }));

/** Standard calculable payload: Casagrande method + F2 curve + P1 trials. */
const BASE = {
  method: "CASAGRANDE_CUP" as const,
  liquidLimitPoints: FLOW_F2,
  plasticLimitTrials: TRIALS_P1,
};

// ---------------------------------------------------------------------------
// 1. Golden envelopes
// ---------------------------------------------------------------------------
{
  // Golden E1 — F1 + P1: the primary four-point regression golden.
  const outcome = runCalculation(atterbergLimitsModule, {
    method: "CASAGRANDE_CUP", liquidLimitPoints: FLOW_F1, plasticLimitTrials: TRIALS_P1,
  });
  if (outcome.status !== "ok") no(`golden E1 — failed: ${outcome.error.message}`);
  else {
    const checks: Array<[boolean, string]> = [
      [approx(outcome.raw.flowCurveSlope, -27.24934364887605, 1e-9), "raw.flowCurveSlope ≈ −27.24934364887605"],
      [approx(outcome.raw.flowCurveIntercept, 80.57639906512931, 1e-9), "raw.flowCurveIntercept ≈ 80.57639906512931"],
      [approx(outcome.raw.liquidLimit, 42.48345136831219, 1e-9), "raw.liquidLimit ≈ 42.48345136831219"],
      [outcome.raw.plasticLimit === 19, "raw.plasticLimit = 19 (exact mean of [18, 20])"],
      [approx(outcome.raw.plasticityIndex, 23.48345136831219, 1e-9), "raw.plasticityIndex ≈ 23.48345136831219"],
      [approx(outcome.raw.plasticLimitTrialStdDev ?? 0, 1.4142135623730951, 1e-9), "raw stdDev ≈ √2 = 1.4142135623730951"],
      [outcome.raw.plasticLimitTrialRange === 2, "raw range = 2"],
      [outcome.results.liquidLimit === 42.48, "results.liquidLimit = 42.48 (2 dp)"],
      [outcome.results.flowCurveSlope === -27.2493, "results.flowCurveSlope = −27.2493 (4 dp)"],
      [outcome.results.flowCurveIntercept === 80.5764, "results.flowCurveIntercept = 80.5764 (4 dp)"],
      [outcome.results.plasticLimit === 19, "results.plasticLimit = 19"],
      [outcome.results.plasticityIndex === 23.48, "results.plasticityIndex = 23.48"],
      [outcome.results.plasticLimitTrialCount === 2, "trialCount = 2"],
      [outcome.results.plasticLimitTrialStdDev === 1.41, "results stdDev = 1.41 (2 dp)"],
      [outcome.results.plasticLimitTrialRange === 2, "results range = 2"],
      [outcome.results.nonPlastic === false, "nonPlastic = false"],
      [outcome.results.enteredLiquidLimit === null && outcome.results.enteredPlasticLimit === null && outcome.results.enteredPlasticityIndex === null, "entered* = null when absent"],
      [outcome.warnings.length === 0, "no warnings (no entered values)"],
      [outcome.raw.liquidLimit >= 36.8 && outcome.raw.liquidLimit <= 48.2, "LL within the measured water-content range"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`golden E1 — ${label}`);
      else no(`golden E1 — ${label}`);
    }
  }
}
{
  // Golden E2 — F2 + P1: exact 25-blow point present; LL read off the fitted
  // line (41.9990…), NOT off the measured point (42.0). Echoes seed
  // ATT_CLAY_42 {LL 42, PL 19, IP 23} after 2 dp rounding.
  const outcome = runCalculation(atterbergLimitsModule, {
    method: "CASAGRANDE_CUP", liquidLimitPoints: FLOW_F2, plasticLimitTrials: TRIALS_P1,
  });
  if (outcome.status !== "ok") no(`golden E2 — failed: ${outcome.error.message}`);
  else {
    const checks: Array<[boolean, string]> = [
      [approx(outcome.raw.flowCurveSlope, -18.23390839208225, 1e-9), "raw.flowCurveSlope ≈ −18.23390839208225"],
      [approx(outcome.raw.flowCurveIntercept, 67.48895933091306, 1e-9), "raw.flowCurveIntercept ≈ 67.48895933091306"],
      [approx(outcome.raw.liquidLimit, 41.99904927516046, 1e-9), "raw.liquidLimit ≈ 41.99904927516046"],
      [outcome.raw.liquidLimit !== 42, "LL ≠ 42.0 — the fitted LINE is read, not the exact N=25 measured point"],
      [outcome.raw.plasticLimit === 19, "raw.plasticLimit = 19 (exact)"],
      [approx(outcome.raw.plasticityIndex, 22.99904927516046, 1e-9), "raw.plasticityIndex ≈ 22.99904927516046"],
      [outcome.results.liquidLimit === 42, "results.liquidLimit = 42 (2 dp)"],
      [outcome.results.flowCurveSlope === -18.2339, "results.flowCurveSlope = −18.2339"],
      [outcome.results.flowCurveIntercept === 67.489, "results.flowCurveIntercept = 67.489"],
      [outcome.results.plasticLimit === 19, "results.plasticLimit = 19"],
      [outcome.results.plasticityIndex === 23, "results.plasticityIndex = 23"],
      [outcome.results.plasticLimitTrialStdDev === 1.41, "results stdDev = 1.41"],
      [outcome.raw.plasticityIndex === outcome.raw.liquidLimit - outcome.raw.plasticLimit!, "calculation consistency — raw IP = raw LL − raw PL (exact subtraction)"],
      [Math.abs(outcome.results.plasticityIndex! - (outcome.results.liquidLimit - outcome.results.plasticLimit!)) <= 1e-9, "calculation consistency — rounded identity within representation noise (probe: 30.99 − 16 = 14.989999999999998 vs 14.99)"],
      [outcome.raw.liquidLimit >= 39.8 && outcome.raw.liquidLimit <= 44.6, "LL within the measured water-content range"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`golden E2 — ${label}`);
      else no(`golden E2 — ${label}`);
    }
  }
}
{
  // Golden E3 — F9 + P5: seed ATT_CLAY_31 echo (LL ≈ 31, PL 16, IP ≈ 15).
  const outcome = runCalculation(atterbergLimitsModule, {
    method: "CASAGRANDE_CUP", liquidLimitPoints: FLOW_F9, plasticLimitTrials: TRIALS_P5,
  });
  if (outcome.status !== "ok") no(`golden E3 — failed: ${outcome.error.message}`);
  else {
    const checks: Array<[boolean, string]> = [
      [approx(outcome.raw.flowCurveSlope, -17.63819603046049, 1e-9), "raw.flowCurveSlope ≈ −17.63819603046049"],
      [approx(outcome.raw.flowCurveIntercept, 55.6510307965538, 1e-9), "raw.flowCurveIntercept ≈ 55.6510307965538"],
      [approx(outcome.raw.liquidLimit, 30.993890884772757, 1e-9), "raw.liquidLimit ≈ 30.993890884772757"],
      [outcome.raw.plasticLimit === 16, "raw.plasticLimit = 16 (exact mean of [15.5, 16.5])"],
      [approx(outcome.raw.plasticityIndex ?? 0, 14.993890884772757, 1e-9), "raw.plasticityIndex ≈ 14.993890884772757"],
      [approx(outcome.raw.plasticLimitTrialStdDev ?? 0, 0.7071067811865476, 1e-9), "raw stdDev ≈ √0.5 = 0.7071067811865476"],
      [outcome.raw.plasticLimitTrialRange === 1, "raw range = 1"],
      [outcome.results.liquidLimit === 30.99, "results.liquidLimit = 30.99"],
      [outcome.results.flowCurveSlope === -17.6382, "results.flowCurveSlope = −17.6382"],
      [outcome.results.flowCurveIntercept === 55.651, "results.flowCurveIntercept = 55.651"],
      [outcome.results.plasticLimit === 16, "results.plasticLimit = 16"],
      [outcome.results.plasticityIndex === 14.99, "results.plasticityIndex = 14.99"],
      [outcome.results.plasticLimitTrialStdDev === 0.71, "results stdDev = 0.71"],
      [Math.abs(outcome.results.plasticityIndex! - (outcome.results.liquidLimit - outcome.results.plasticLimit!)) <= 1e-9, "calculation consistency — rounded identity within representation noise (probe: 42.48 − 19 = 23.479999999999997 vs 23.48)"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`golden E3 — ${label}`);
      else no(`golden E3 — ${label}`);
    }
  }
}
{
  // Golden E5 — non-plastic soil: F2 flow curve + nonPlastic: true.
  // LL is still computed; PL and IP are null (reported NP, never invented).
  const outcome = runCalculation(atterbergLimitsModule, {
    method: "CASAGRANDE_CUP", liquidLimitPoints: FLOW_F2, nonPlastic: true,
  });
  if (outcome.status !== "ok") no(`golden E5 — failed: ${outcome.error.message}`);
  else {
    const checks: Array<[boolean, string]> = [
      [approx(outcome.raw.liquidLimit, 41.99904927516046, 1e-9), "raw.liquidLimit ≈ 41.99904927516046 (LL still computed)"],
      [outcome.raw.plasticLimit === null, "raw.plasticLimit = null (NP)"],
      [outcome.raw.plasticityIndex === null, "raw.plasticityIndex = null (NP)"],
      [outcome.raw.plasticLimitTrialStdDev === null, "raw stdDev = null (NP)"],
      [outcome.raw.plasticLimitTrialRange === null, "raw range = null (NP)"],
      [outcome.results.liquidLimit === 42, "results.liquidLimit = 42"],
      [outcome.results.flowCurveSlope === -18.2339, "results.flowCurveSlope = −18.2339"],
      [outcome.results.flowCurveIntercept === 67.489, "results.flowCurveIntercept = 67.489"],
      [outcome.results.plasticLimit === null, "results.plasticLimit = null (NP explicit)"],
      [outcome.results.plasticityIndex === null, "results.plasticityIndex = null (NP explicit)"],
      [outcome.results.nonPlastic === true, "results.nonPlastic = true"],
      [outcome.results.plasticLimitTrialCount === 0, "trialCount = 0"],
      [outcome.results.plasticLimitTrialStdDev === null && outcome.results.plasticLimitTrialRange === null, "trial stats null (NP)"],
      [outcome.warnings.length === 0, "no warnings"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`golden E5 (non-plastic) — ${label}`);
      else no(`golden E5 (non-plastic) — ${label}`);
    }
  }
}
{
  // Golden P3 — single PL trial: mean = the trial, stdDev null, range 0.
  const outcome = runCalculation(atterbergLimitsModule, {
    method: "CASAGRANDE_CUP", liquidLimitPoints: FLOW_F2, plasticLimitTrials: TRIALS_P3,
  });
  if (outcome.status !== "ok") no(`golden P3 — failed: ${outcome.error.message}`);
  else {
    const checks: Array<[boolean, string]> = [
      [outcome.raw.plasticLimit === 21.3, "raw.plasticLimit = 21.3 (single trial)"],
      [outcome.raw.plasticLimitTrialStdDev === null, "raw stdDev = null (n < 2)"],
      [outcome.raw.plasticLimitTrialRange === 0, "raw range = 0 (max − min of one value)"],
      [outcome.results.plasticLimit === 21.3, "results.plasticLimit = 21.3"],
      [outcome.results.plasticLimitTrialCount === 1, "trialCount = 1"],
      [outcome.results.plasticLimitTrialStdDev === null, "results stdDev = null"],
      [outcome.results.plasticLimitTrialRange === 0, "results range = 0"],
      [outcome.results.plasticityIndex === 20.7, "results.plasticityIndex = 20.7"],
      [outcome.raw.plasticityIndex === outcome.raw.liquidLimit - 21.3, "raw IP = raw LL − 21.3 (exact subtraction)"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`golden P3 (single trial) — ${label}`);
      else no(`golden P3 (single trial) — ${label}`);
    }
  }
}
{
  // Golden P2 — three PL trials: mean / sample std dev / range.
  const outcome = runCalculation(atterbergLimitsModule, {
    method: "CASAGRANDE_CUP", liquidLimitPoints: FLOW_F2, plasticLimitTrials: TRIALS_P2,
  });
  if (outcome.status !== "ok") no(`golden P2 — failed: ${outcome.error.message}`);
  else {
    const checks: Array<[boolean, string]> = [
      [approx(outcome.raw.plasticLimit ?? 0, 22.133333333333333, 1e-9), "raw.plasticLimit ≈ 22.133333333333333 (= 66.4/3)"],
      [approx(outcome.raw.plasticLimitTrialStdDev ?? 0, 0.709459888459758, 1e-9), "raw stdDev ≈ 0.709459888459758 (sample, n−1)"],
      [approx(outcome.raw.plasticLimitTrialRange ?? 0, 1.4000000000000021, 1e-9), "raw range ≈ 1.4000000000000021 (22.9 − 21.5)"],
      [outcome.results.plasticLimit === 22.13, "results.plasticLimit = 22.13"],
      [outcome.results.plasticLimitTrialStdDev === 0.71, "results stdDev = 0.71"],
      [outcome.results.plasticLimitTrialRange === 1.4, "results range = 1.4 (epsilon-corrected rounding)"],
      [outcome.results.plasticLimitTrialCount === 3, "trialCount = 3"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`golden P2 (three trials) — ${label}`);
      else no(`golden P2 (three trials) — ${label}`);
    }
  }
}

// ---------------------------------------------------------------------------
// 2. Flow-curve helpers (direct unit tests on the exported functions)
// ---------------------------------------------------------------------------
{
  const { slope, intercept } = fitFlowCurve(FLOW_F1);
  if (approx(slope, -27.24934364887605, 1e-9) && approx(intercept, 80.57639906512931, 1e-9)) {
    ok("fitFlowCurve(F1) — slope/intercept match the independent regression");
  } else no(`fitFlowCurve(F1) — slope=${slope}, intercept=${intercept}`);
}
{
  const { slope, intercept } = fitFlowCurve(FLOW_F2);
  const ll = waterContentAtBlows(slope, intercept, LIQUID_LIMIT_BLOWS_TARGET);
  if (ll === intercept + slope * Math.log10(25) && approx(ll, 41.99904927516046, 1e-9)) {
    ok("waterContentAtBlows(…, 25) — LL = intercept + slope·log10(25) ≈ 41.99904927516046");
  } else no(`waterContentAtBlows — LL = ${ll}`);
}
{
  if (LIQUID_LIMIT_BLOWS_TARGET === 25 && ATTERBERG_ENTERED_TOLERANCE === 1.0) {
    ok("definitional values — LL target 25 blows, entered tolerance ±1.0 exported");
  } else no("definitional constants — unexpected exported values");
}
{
  // Identical blows — regression undefined, rejected by the helper itself.
  let threw = false;
  let code = "";
  let message = "";
  try {
    fitFlowCurve(flow([[25, 40], [25, 41], [25, 42]]));
  } catch (error) {
    threw = true;
    if (error instanceof ArithmeticDomainError) {
      code = error.code;
      message = error.message;
    } else {
      code = `unexpected: ${String(error)}`;
    }
  }
  if (threw && code === "ARITHMETIC_DOMAIN_ERROR" && message.includes("distinct blow counts")) {
    ok("fitFlowCurve — identical blows → ARITHMETIC_DOMAIN_ERROR (undefined regression)");
  } else no(`fitFlowCurve identical blows — threw=${threw}, code=${code}`);
}

// ---------------------------------------------------------------------------
// 3. Entered-value warnings and boundary semantics
// ---------------------------------------------------------------------------
{
  // Warning trio — entered finals far from computed (all within the registry
  // identity, so validateInput accepts; the engine advises, never overwrites).
  const outcome = runCalculation(atterbergLimitsModule, {
    method: "CASAGRANDE_CUP", liquidLimitPoints: FLOW_F1, plasticLimitTrials: TRIALS_P1,
    liquidLimit: 55, plasticLimit: 17, plasticityIndex: 38,
  });
  if (outcome.status !== "ok") no(`warning trio — failed: ${outcome.error.message}`);
  else {
    if (outcome.warnings.length === 3) ok("warning trio — 3 warnings (LL, PL, IP)");
    else no(`warning trio — expected 3 warnings, got ${outcome.warnings.length}`);
    const fields = outcome.warnings.map((w) => w.details?.field);
    if (fields[0] === "liquidLimit" && fields[1] === "plasticLimit" && fields[2] === "plasticityIndex") {
      ok("warning trio — fixed warning order (liquidLimit, plasticLimit, plasticityIndex)");
    } else no(`warning trio — order wrong: ${JSON.stringify(fields)}`);
    const w0 = outcome.warnings[0];
    if (
      w0.code === "ENTERED_VALUE_DISCREPANCY" &&
      w0.details?.enteredValue === 55 &&
      w0.details?.computedValue === 42.4835 &&
      w0.details?.discrepancy === -12.5165 &&
      w0.details?.tolerance === 1.0
    ) {
      ok("warning trio — LL warning details (42.4835 vs 55, Δ −12.5165, tol ±1.0)");
    } else no(`warning trio — LL warning wrong: ${JSON.stringify(w0)}`);
    const w1 = outcome.warnings[1];
    if (
      w1.details?.enteredValue === 17 && w1.details?.computedValue === 19 &&
      w1.details?.discrepancy === 2 && w1.details?.tolerance === 1.0
    ) {
      ok("warning trio — PL warning details (19 vs 17, Δ +2)");
    } else no(`warning trio — PL warning wrong: ${JSON.stringify(w1)}`);
    const w2 = outcome.warnings[2];
    if (
      w2.details?.enteredValue === 38 && w2.details?.computedValue === 23.4835 &&
      w2.details?.discrepancy === -14.5165
    ) {
      ok("warning trio — IP warning details (23.4835 vs 38, Δ −14.5165)");
    } else no(`warning trio — IP warning wrong: ${JSON.stringify(w2)}`);
    // No overwrite: entered and computed coexist in the results.
    if (
      outcome.results.enteredLiquidLimit === 55 && outcome.results.liquidLimit === 42.48 &&
      outcome.results.enteredPlasticLimit === 17 && outcome.results.plasticLimit === 19 &&
      outcome.results.enteredPlasticityIndex === 38 && outcome.results.plasticityIndex === 23.48
    ) {
      ok("warning trio — entered values echoed and NOT overwritten");
    } else no("warning trio — overwrite or echo failure");
  }
}
{
  // B1 — boundary case: ΔPL exactly 1.0 (no warning, strict >), while the
  // derived IP crosses the tolerance on its own (Δ = −1.00095 → warning).
  const outcome = runCalculation(atterbergLimitsModule, {
    method: "CASAGRANDE_CUP", liquidLimitPoints: FLOW_F2, plasticLimitTrials: TRIALS_P1,
    liquidLimit: 42, plasticLimit: 18, plasticityIndex: 24,
  });
  if (outcome.status !== "ok") no(`B1 boundary — failed: ${outcome.error.message}`);
  else {
    if (outcome.warnings.length === 1) ok("B1 — exactly one warning (PL at exact |Δ|=1.0 stays silent)");
    else no(`B1 — expected 1 warning, got ${outcome.warnings.length}`);
    const w = outcome.warnings[0];
    if (
      w.details?.field === "plasticityIndex" &&
      w.details?.enteredValue === 24 &&
      w.details?.computedValue === 22.999 &&
      w.details?.discrepancy === -1.001
    ) {
      ok("B1 — the derived IP warning fires independently (22.999 vs 24, Δ −1.001)");
    } else no(`B1 — warning wrong: ${JSON.stringify(w)}`);
  }
}
{
  // B3 — clean seed echo: entered {42, 19, 23} vs computed {42.00, 19, 23.00}.
  const outcome = runCalculation(atterbergLimitsModule, {
    method: "CASAGRANDE_CUP", liquidLimitPoints: FLOW_F2, plasticLimitTrials: TRIALS_P1,
    liquidLimit: 42, plasticLimit: 19, plasticityIndex: 23,
  });
  if (outcome.status !== "ok") no(`B3 clean — failed: ${outcome.error.message}`);
  else {
    if (outcome.warnings.length === 0) ok("B3 — no warnings (all |Δ| ≤ 1; PL Δ = 0 exactly)");
    else no(`B3 — unexpected warnings: ${outcome.warnings.length}`);
    if (
      outcome.results.enteredLiquidLimit === 42 && outcome.results.enteredPlasticLimit === 19 &&
      outcome.results.enteredPlasticityIndex === 23
    ) {
      ok("B3 — entered seed values echoed (ATT_CLAY_42 {42, 19, 23})");
    } else no("B3 — echo wrong");
  }
}
{
  // Boundary matrix — ±1.0 tolerance, both sides, exact in IEEE doubles.
  const countPlWarnings = (entered: number): number => {
    const outcome = runCalculation(atterbergLimitsModule, {
      method: "CASAGRANDE_CUP", liquidLimitPoints: FLOW_F2, plasticLimitTrials: TRIALS_P1,
      plasticLimit: entered,
    });
    if (outcome.status !== "ok") return -1;
    return outcome.warnings.filter((w) => w.details?.field === "plasticLimit").length;
  };
  if (countPlWarnings(18.01) === 0) ok("boundary — entered PL 18.01 (Δ 0.99) → no warning");
  else no("boundary — 18.01 wrong");
  if (countPlWarnings(18) === 0) ok("boundary — entered PL 18 (Δ exactly 1.0) → no warning (strict >)");
  else no("boundary — 18 wrong");
  if (countPlWarnings(17.99) === 1) ok("boundary — entered PL 17.99 (Δ 1.01) → warning");
  else no("boundary — 17.99 wrong");
  if (countPlWarnings(19) === 0) ok("boundary — entered PL 19 (Δ 0) → no warning");
  else no("boundary — 19 wrong");
}
{
  // Entered-identity boundary (registry mirror, ±1) — both sides exact.
  const mk = (pi: number) =>
    runCalculation(atterbergLimitsModule, {
      method: "CASAGRANDE_CUP", liquidLimitPoints: FLOW_F2, plasticLimitTrials: TRIALS_P1,
      liquidLimit: 42, plasticLimit: 18, plasticityIndex: pi,
    });
  const atBoundary = mk(23);
  if (atBoundary.status === "ok") {
    ok("entered identity — |PI − (LL−PL)| = 1.0 exactly → accepted (boundary, registry parity)");
  } else {
    no(`entered identity — boundary 1.0 wrongly rejected: ${atBoundary.error.message}`);
  }
  expectError(mk(22.99), "entered identity |Δ| = 1.01 — rejected", {
    code: "INVALID_INPUT", fieldPath: "plasticityIndex", messageHint: "must equal liquidLimit - plasticLimit",
  });
}

// ---------------------------------------------------------------------------
// 4. Method gate — no silent mixing of Casagrande and cone penetrometer
// ---------------------------------------------------------------------------
{
  // Cone method with fully valid Casagrande-shaped data → rejected at method.
  expectError(
    runCalculation(atterbergLimitsModule, { ...BASE, method: "CONE_PENETROMETER" }),
    "cone penetrometer with Casagrande-shaped data",
    { code: "INVALID_INPUT", fieldPath: "method", messageHint: "not calculable" },
  );
}
{
  // Cone method with a foreign payload → the method gate STILL fires first
  // (before any schema interpretation) — the data is never reinterpreted.
  expectError(
    runCalculation(atterbergLimitsModule, { method: "CONE_PENETROMETER" }),
    "cone penetrometer with incomplete payload (gate precedence)",
    { code: "INVALID_INPUT", fieldPath: "method", messageHint: "never reinterpreted" },
  );
}
{
  expectError(
    runCalculation(atterbergLimitsModule, { ...BASE, method: "FALL_CONE" }),
    "unknown method string",
    { code: "INVALID_INPUT", fieldPath: "method" },
  );
}

// ---------------------------------------------------------------------------
// 5. Missing inputs and absent-vs-present distinctions
// ---------------------------------------------------------------------------
{
  expectError(
    runCalculation(atterbergLimitsModule, {}),
    "empty payload — missing method and liquidLimitPoints",
    { code: "MISSING_INPUT", messageHint: "method" },
  );
}
{
  expectError(
    runCalculation(atterbergLimitsModule, { method: "CASAGRANDE_CUP" }),
    "method only — missing liquidLimitPoints",
    { code: "MISSING_INPUT", messageHint: "liquidLimitPoints" },
  );
}
{
  // Schema-valid except the plastic-only requirement: trials required unless
  // nonPlastic — the module never invents a PL measurement.
  expectError(
    runCalculation(atterbergLimitsModule, { method: "CASAGRANDE_CUP", liquidLimitPoints: FLOW_F2 }),
    "plastic soil without PL trials",
    { code: "MISSING_INPUT", messageHint: "plasticLimitTrials" },
  );
}
{
  expectError(
    runCalculation(atterbergLimitsModule, { method: "CASAGRANDE_CUP", liquidLimitPoints: FLOW_F2, nonPlastic: false }),
    "nonPlastic: false explicitly — still requires trials",
    { code: "MISSING_INPUT", messageHint: "plasticLimitTrials" },
  );
}
{
  // Missing nested point field → MISSING (aggregated), not INVALID.
  expectError(
    runCalculation(atterbergLimitsModule, {
      method: "CASAGRANDE_CUP",
      liquidLimitPoints: [
        { waterContentPercent: 40 },
        { blows: 25, waterContentPercent: 42 },
        { blows: 33, waterContentPercent: 39.8 },
      ],
      plasticLimitTrials: TRIALS_P1,
    }),
    "point missing blows",
    { code: "MISSING_INPUT", messageHint: "liquidLimitPoints.0.blows" },
  );
}
{
  // present-but-null vs absent (same distinction as the water-content module).
  expectError(
    runCalculation(atterbergLimitsModule, { ...BASE, plasticLimitTrials: null }),
    "trials present but null",
    { code: "INVALID_INPUT", fieldPath: "plasticLimitTrials" },
  );
}
{
  expectError(
    runCalculation(atterbergLimitsModule, { ...BASE, plasticLimitTrials: [] }),
    "trials empty array",
    { code: "INVALID_INPUT", fieldPath: "plasticLimitTrials", messageHint: ">=1" },
  );
}

// ---------------------------------------------------------------------------
// 6. Invalid measurements — schema bounds and types
// ---------------------------------------------------------------------------
{
  const cases: Array<[string, unknown, ExpectedError]> = [
    ["blows 25.5 (non-integer)", { ...BASE, liquidLimitPoints: flow([[15, 48.2], [25.5, 42], [40, 36.8]]) }, { code: "INVALID_INPUT", fieldPath: "liquidLimitPoints.1.blows" }],
    ["blows 0", { ...BASE, liquidLimitPoints: flow([[0, 48.2], [25, 42], [40, 36.8]]) }, { code: "INVALID_INPUT", fieldPath: "liquidLimitPoints.0.blows" }],
    ["blows −3", { ...BASE, liquidLimitPoints: flow([[15, 48.2], [25, 42], [-3, 36.8]]) }, { code: "INVALID_INPUT", fieldPath: "liquidLimitPoints.2.blows" }],
    ["blows 201 (max 200)", { ...BASE, liquidLimitPoints: flow([[15, 48.2], [25, 42], [201, 36.8]]) }, { code: "INVALID_INPUT", fieldPath: "liquidLimitPoints.2.blows" }],
    ["water content −0.1", { ...BASE, liquidLimitPoints: flow([[15, -0.1], [25, 42], [40, 36.8]]) }, { code: "INVALID_INPUT", fieldPath: "liquidLimitPoints.0.waterContentPercent" }],
    ["water content 300.5 (max 300)", { ...BASE, liquidLimitPoints: flow([[15, 48.2], [25, 42], [40, 300.5]]) }, { code: "INVALID_INPUT", fieldPath: "liquidLimitPoints.2.waterContentPercent" }],
    ["NaN blows", { ...BASE, liquidLimitPoints: flow([[15, 48.2], [Number.NaN, 42], [40, 36.8]]) }, { code: "INVALID_INPUT", fieldPath: "liquidLimitPoints.1.blows" }],
    ["Infinity water content", { ...BASE, liquidLimitPoints: flow([[15, 48.2], [25, Number.POSITIVE_INFINITY], [40, 36.8]]) }, { code: "INVALID_INPUT", fieldPath: "liquidLimitPoints.1.waterContentPercent" }],
    ["string blows", { ...BASE, liquidLimitPoints: flow([[15, 48.2], ["25", 42], [40, 36.8]]) }, { code: "INVALID_INPUT", fieldPath: "liquidLimitPoints.1.blows", messageHint: "expected number" }],
    ["trial 320 (max 300)", { ...BASE, plasticLimitTrials: [19, 320] }, { code: "INVALID_INPUT", fieldPath: "plasticLimitTrials.1" }],
    ["trial −1", { ...BASE, plasticLimitTrials: [-1, 19] }, { code: "INVALID_INPUT", fieldPath: "plasticLimitTrials.0" }],
    ["string trial", { ...BASE, plasticLimitTrials: [19, "18"] }, { code: "INVALID_INPUT", fieldPath: "plasticLimitTrials.1", messageHint: "expected number" }],
    ["7 trials (max 6)", { ...BASE, plasticLimitTrials: [19, 19, 19, 19, 19, 19, 19] }, { code: "INVALID_INPUT", fieldPath: "plasticLimitTrials", messageHint: "<=6" }],
    ["entered liquidLimit 9.5 (min 10)", { ...BASE, liquidLimit: 9.5 }, { code: "INVALID_INPUT", fieldPath: "liquidLimit" }],
    ["entered liquidLimit 150.5 (max 150)", { ...BASE, liquidLimit: 150.5 }, { code: "INVALID_INPUT", fieldPath: "liquidLimit" }],
    ["entered plasticLimit 4.5 (min 5)", { ...BASE, plasticLimit: 4.5 }, { code: "INVALID_INPUT", fieldPath: "plasticLimit" }],
    ["entered plasticLimit 100.5 (max 100)", { ...BASE, plasticLimit: 100.5 }, { code: "INVALID_INPUT", fieldPath: "plasticLimit" }],
    ["entered plasticityIndex −0.5 (min 0)", { ...BASE, plasticityIndex: -0.5 }, { code: "INVALID_INPUT", fieldPath: "plasticityIndex" }],
    ["entered plasticityIndex 100.5 (max 100)", { ...BASE, plasticityIndex: 100.5 }, { code: "INVALID_INPUT", fieldPath: "plasticityIndex" }],
  ];
  for (const [label, payload, expected] of cases) {
    expectError(runCalculation(atterbergLimitsModule, payload), label, expected);
  }
}
{
  // Insufficient points — below the multipoint minimum of 3.
  expectError(
    runCalculation(atterbergLimitsModule, {
      method: "CASAGRANDE_CUP",
      liquidLimitPoints: flow([[15, 48.2], [40, 36.8]]),
      plasticLimitTrials: TRIALS_P1,
    }),
    "insufficient points (2 < 3)",
    { code: "INVALID_INPUT", fieldPath: "liquidLimitPoints", messageHint: ">=3" },
  );
}
{
  // Excessive points — above the contract maximum of 10.
  const many = Array.from({ length: 11 }, (_, i) => ({ blows: 10 + i * 3, waterContentPercent: 50 - i * 2 }));
  expectError(
    runCalculation(atterbergLimitsModule, { method: "CASAGRANDE_CUP", liquidLimitPoints: many, plasticLimitTrials: TRIALS_P1 }),
    "excessive points (11 > 10)",
    { code: "INVALID_INPUT", fieldPath: "liquidLimitPoints", messageHint: "<=10" },
  );
}

// ---------------------------------------------------------------------------
// 7. Invalid experimental data — physical rules and domain errors
// ---------------------------------------------------------------------------
{
  // All blows identical — the regression is undefined.
  expectError(
    runCalculation(atterbergLimitsModule, {
      method: "CASAGRANDE_CUP",
      liquidLimitPoints: flow([[25, 40], [25, 41], [25, 42]]),
      plasticLimitTrials: TRIALS_P1,
    }),
    "identical blows (zero blow-count spread)",
    { code: "ARITHMETIC_DOMAIN_ERROR", messageHint: "distinct blow counts" },
  );
}
{
  // 25 blows outside the measured range, above — extrapolation rejected.
  expectError(
    runCalculation(atterbergLimitsModule, {
      method: "CASAGRANDE_CUP",
      liquidLimitPoints: flow([[30, 45], [35, 42], [40, 39]]),
      plasticLimitTrials: TRIALS_P1,
    }),
    "all blows above 25 — extrapolation rejected",
    { code: "ARITHMETIC_DOMAIN_ERROR", messageHint: "outside the measured range" },
  );
}
{
  // 25 blows outside the measured range, below — extrapolation rejected.
  expectError(
    runCalculation(atterbergLimitsModule, {
      method: "CASAGRANDE_CUP",
      liquidLimitPoints: flow([[12, 50], [18, 46], [20, 44]]),
      plasticLimitTrials: TRIALS_P1,
    }),
    "all blows below 25 — extrapolation rejected",
    { code: "ARITHMETIC_DOMAIN_ERROR", messageHint: "outside the measured range" },
  );
}
{
  // Rising flow curve — water content INCREASES with blows: impossible.
  expectError(
    runCalculation(atterbergLimitsModule, {
      method: "CASAGRANDE_CUP",
      liquidLimitPoints: flow([[15, 30], [25, 40], [40, 50]]),
      plasticLimitTrials: TRIALS_P1,
    }),
    "rising flow curve (slope > 0)",
    { code: "INVALID_INPUT", fieldPath: "liquidLimitPoints", messageHint: "not falling" },
  );
}
{
  // Flat flow curve (slope = 0) — also physically impossible.
  expectError(
    runCalculation(atterbergLimitsModule, {
      method: "CASAGRANDE_CUP",
      liquidLimitPoints: flow([[15, 40], [25, 40], [40, 40]]),
      plasticLimitTrials: TRIALS_P1,
    }),
    "flat flow curve (slope = 0)",
    { code: "INVALID_INPUT", fieldPath: "liquidLimitPoints", messageHint: "not falling" },
  );
}
{
  // Computed PL ≥ computed LL — the trials contradict the flow curve.
  expectError(
    runCalculation(atterbergLimitsModule, {
      method: "CASAGRANDE_CUP", liquidLimitPoints: FLOW_F7, plasticLimitTrials: TRIALS_P4,
    }),
    "computed PL (39) ≥ computed LL (35.28)",
    { code: "INVALID_INPUT", fieldPath: "plasticLimitTrials", messageHint: "not lower than computed liquid limit" },
  );
}
{
  // Entered PL ≥ entered LL — registry mirror on the entered values.
  expectError(
    runCalculation(atterbergLimitsModule, { ...BASE, liquidLimit: 42, plasticLimit: 42 }),
    "entered plasticLimit ≥ entered liquidLimit",
    { code: "INVALID_INPUT", fieldPath: "plasticLimit", messageHint: "must be lower than" },
  );
}
{
  // Entered PI identity violation (registry mirror, ±1).
  expectError(
    runCalculation(atterbergLimitsModule, { ...BASE, liquidLimit: 42, plasticLimit: 19, plasticityIndex: 20 }),
    "entered plasticityIndex ≠ LL − PL (±1)",
    { code: "INVALID_INPUT", fieldPath: "plasticityIndex", messageHint: "must equal liquidLimit - plasticLimit" },
  );
}

// ---------------------------------------------------------------------------
// 8. Non-plastic semantics — contradictions rejected, never reconciled
// ---------------------------------------------------------------------------
{
  expectError(
    runCalculation(atterbergLimitsModule, {
      method: "CASAGRANDE_CUP", liquidLimitPoints: FLOW_F2, nonPlastic: true, plasticLimitTrials: TRIALS_P1,
    }),
    "nonPlastic combined with PL trials",
    { code: "INVALID_INPUT", fieldPath: "plasticLimitTrials", messageHint: "cannot be combined" },
  );
}
{
  expectError(
    runCalculation(atterbergLimitsModule, {
      method: "CASAGRANDE_CUP", liquidLimitPoints: FLOW_F2, nonPlastic: true, plasticLimit: 19,
    }),
    "nonPlastic combined with entered plasticLimit",
    { code: "INVALID_INPUT", fieldPath: "plasticLimit", messageHint: "cannot be combined" },
  );
}
{
  expectError(
    runCalculation(atterbergLimitsModule, {
      method: "CASAGRANDE_CUP", liquidLimitPoints: FLOW_F2, nonPlastic: true, plasticityIndex: 23,
    }),
    "nonPlastic combined with entered plasticityIndex",
    { code: "INVALID_INPUT", fieldPath: "plasticityIndex", messageHint: "cannot be combined" },
  );
}
{
  // nonPlastic + entered liquidLimit is legitimate (an NP soil can have an LL)
  // — and the entered comparison still applies.
  const outcome = runCalculation(atterbergLimitsModule, {
    method: "CASAGRANDE_CUP", liquidLimitPoints: FLOW_F2, nonPlastic: true, liquidLimit: 55,
  });
  if (outcome.status !== "ok") no(`NP + entered LL — failed: ${outcome.error.message}`);
  else {
    if (outcome.results.plasticLimit === null && outcome.results.plasticityIndex === null) {
      ok("NP + entered LL — accepted; PL/IP remain null");
    } else no("NP + entered LL — PL/IP should be null");
    if (outcome.warnings.length === 1 && outcome.warnings[0].details?.field === "liquidLimit") {
      ok("NP + entered LL — LL comparison still warns (computed 41.999 vs entered 55)");
    } else no(`NP + entered LL — warnings: ${outcome.warnings.length}`);
  }
}

// ---------------------------------------------------------------------------
// 9. Legitimate replicate data — duplicate blow counts are kept (global fit)
// ---------------------------------------------------------------------------
{
  const outcome = runCalculation(atterbergLimitsModule, {
    method: "CASAGRANDE_CUP",
    liquidLimitPoints: flow([[15, 48.2], [20, 45.6], [20, 45.0], [30, 40.3], [40, 36.8]]),
    plasticLimitTrials: TRIALS_P1,
  });
  if (outcome.status === "ok" && outcome.warnings.length === 0 && outcome.results.flowCurveSlope < 0) {
    ok("duplicate blow counts (replicate at N=20) — accepted, fitted globally");
  } else if (outcome.status === "ok") {
    no("duplicate blows — unexpected warnings");
  } else {
    no(`duplicate blows — rejected: ${outcome.error.message}`);
  }
}

// ---------------------------------------------------------------------------
// 10. M5.1 registry compatibility (behavioral parity + documented divergences)
// ---------------------------------------------------------------------------
{
  // Results revalidation — the computed (rounded) indicator triples pass the
  // registry result schema, identities included.
  const revalidate = (ll: number, pl: number, pi: number): boolean =>
    parseLabTestResult("ATTERBERG_LIMITS", {
      liquidLimit: ll, plasticLimit: pl, plasticityIndex: pi,
    }).ok;

  if (revalidate(42.48, 19, 23.48)) ok("revalidation — E1 results pass the registry result schema");
  else no("revalidation — E1 results rejected");
  if (revalidate(42, 19, 23)) ok("revalidation — E2 results pass (deep-equal to seed ATT_CLAY_42)");
  else no("revalidation — E2 results rejected");
  if (revalidate(30.99, 16, 14.99)) ok("revalidation — E3 results pass");
  else no("revalidation — E3 results rejected");
}
{
  // Shared valid: full result shape with the registry's optional fields —
  // the module strips them (not calculable), the registry stores them.
  const modulePayload = {
    method: "CASAGRANDE_CUP", liquidLimitPoints: FLOW_F2, plasticLimitTrials: TRIALS_P1,
    liquidLimit: 42, plasticLimit: 19, plasticityIndex: 23,
    shrinkageLimit: 16, uscsSymbol: "CL", liquidityIndex: 0.05, notes: "cup method",
  };
  const parsed = atterbergLimitsCalcInput.safeParse(modulePayload);
  const registryOk = parseLabTestResult("ATTERBERG_LIMITS", {
    liquidLimit: 42, plasticLimit: 19, plasticityIndex: 23,
    shrinkageLimit: 16, uscsSymbol: "CL", liquidityIndex: 0.05,
  }).ok;
  const outcome = runCalculation(atterbergLimitsModule, modulePayload);
  const stripped =
    parsed.success &&
    !("shrinkageLimit" in (parsed.data as Record<string, unknown>)) &&
    !("uscsSymbol" in (parsed.data as Record<string, unknown>)) &&
    !("liquidityIndex" in (parsed.data as Record<string, unknown>)) &&
    !("notes" in (parsed.data as Record<string, unknown>));
  if (
    stripped && registryOk &&
    outcome.status === "ok" && outcome.warnings.length === 0
  ) {
    ok("parity — registry optional fields stripped by the module, stored by the registry; both accept");
  } else {
    no(`parity — stripping=${stripped}, registry=${registryOk}, module=${outcome.status === "ok"}`);
  }
}
{
  // Shared invalid — entered-identity violations: module AND registry reject.
  const cases: Array<[string, Record<string, number>]> = [
    ["PI ≠ LL − PL by 3", { liquidLimit: 42, plasticLimit: 19, plasticityIndex: 20 }],
    ["PI ≠ LL − PL by 1.01", { liquidLimit: 42, plasticLimit: 18, plasticityIndex: 22.99 }],
    ["PL ≥ LL (entered)", { liquidLimit: 19, plasticLimit: 42, plasticityIndex: 0 }],
    ["liquidLimit out of bounds (151)", { liquidLimit: 151, plasticLimit: 19, plasticityIndex: 23 }],
    ["plasticLimit out of bounds (4.5)", { liquidLimit: 42, plasticLimit: 4.5, plasticityIndex: 23 }],
  ];
  for (const [label, entered] of cases) {
    const moduleRejects = runCalculation(atterbergLimitsModule, { ...BASE, ...entered }).status === "error";
    const registryRejects = !parseLabTestResult("ATTERBERG_LIMITS", entered).ok;
    if (moduleRejects && registryRejects) ok(`parity — ${label}: module AND registry both reject`);
    else no(`parity — ${label}: module=${moduleRejects}, registry=${registryRejects}`);
  }
}
{
  // Shared valid boundary — |PI − (LL−PL)| = 1.0 exactly: both accept.
  const entered = { liquidLimit: 42, plasticLimit: 18, plasticityIndex: 23 };
  const moduleOutcome = runCalculation(atterbergLimitsModule, { ...BASE, ...entered });
  const registryOk = parseLabTestResult("ATTERBERG_LIMITS", entered).ok;
  if (registryOk && moduleOutcome.status === "ok") {
    ok("parity — identity boundary |Δ| = 1.0: module AND registry both accept");
  } else {
    no(`parity — boundary: module=${moduleOutcome.status === "ok"}, registry=${registryOk}`);
  }
}
{
  // Advisory parity — seed ATT_CLAY_55 entered finals are registry-valid
  // storage; the module accepts them too but warns (they disagree with the
  // raw measurements) — engine advises, registry gates.
  const entered = { liquidLimit: 55, plasticLimit: 24, plasticityIndex: 31 };
  const registryOk = parseLabTestResult("ATTERBERG_LIMITS", { ...entered, shrinkageLimit: 16, uscsSymbol: "CH" }).ok;
  const outcome = runCalculation(atterbergLimitsModule, { ...BASE, ...entered });
  if (
    registryOk && outcome.status === "ok" && outcome.warnings.length === 3 &&
    outcome.results.enteredLiquidLimit === 55
  ) {
    ok("parity — seed ATT_CLAY_55 finals: registry stores, module accepts + advises (3 warnings)");
  } else {
    no(`parity — ATT_CLAY_55: registry=${registryOk}, warnings=${outcome.status === "ok" ? outcome.warnings.length : "err"}`);
  }
}
{
  // Divergence 1 — finals-only payload: valid REGISTRY STORAGE, NOT
  // calculable by the module (no flow points — the module never invents them).
  const finalsOnly = { liquidLimit: 42, plasticLimit: 19, plasticityIndex: 23 };
  const registryOk = parseLabTestResult("ATTERBERG_LIMITS", finalsOnly).ok;
  const outcome = runCalculation(atterbergLimitsModule, finalsOnly);
  if (registryOk && outcome.status === "error" && outcome.error.code === "MISSING_INPUT") {
    ok("divergence 1 — registry stores finals-only record; module rejects MISSING_INPUT (not calculable)");
  } else {
    no("divergence 1 — behavior does not match the documented contract");
  }
}
{
  // Divergence 2 — non-plastic: the module reports NP (null PL/IP); the
  // registry result schema has NO NP representation (plasticLimit and
  // plasticityIndex are required) — NP results cannot be stored today.
  const npModule = runCalculation(atterbergLimitsModule, {
    method: "CASAGRANDE_CUP", liquidLimitPoints: FLOW_F2, nonPlastic: true,
  });
  const registryAcceptsNp =
    parseLabTestResult("ATTERBERG_LIMITS", { liquidLimit: 42 }).ok ||
    parseLabTestResult("ATTERBERG_LIMITS", { liquidLimit: 42, plasticLimit: null, plasticityIndex: null }).ok;
  if (npModule.status === "ok" && npModule.results.plasticLimit === null && !registryAcceptsNp) {
    ok("divergence 2 — module reports NP (null PL/IP); registry cannot store NP (documented)");
  } else {
    no("divergence 2 — behavior does not match the documented contract");
  }
}
{
  // Divergence 3 — cone penetrometer: legal registry INPUT storage; the
  // module refuses to calculate it (adopted standards are Casagrande-based).
  const registryInputOk = parseLabTestInput("ATTERBERG_LIMITS", {
    method: "CONE_PENETROMETER", notes: "cone method",
  }).ok;
  const outcome = runCalculation(atterbergLimitsModule, { ...BASE, method: "CONE_PENETROMETER" });
  if (registryInputOk && outcome.status === "error" && outcome.error.code === "INVALID_INPUT") {
    ok("divergence 3 — registry stores CONE_PENETROMETER input; module rejects (unsupported for calculation)");
  } else {
    no("divergence 3 — behavior does not match the documented contract");
  }
}
{
  // Divergence 4 — computed PL below the registry storage minimum: the module
  // reports as-is (never clamped); the registry gates at write time.
  const outcome = runCalculation(atterbergLimitsModule, {
    method: "CASAGRANDE_CUP", liquidLimitPoints: FLOW_F2, plasticLimitTrials: [3.6, 4.0],
  });
  const registryOk = parseLabTestResult("ATTERBERG_LIMITS", {
    liquidLimit: 42, plasticLimit: 3.8, plasticityIndex: 38.2,
  }).ok;
  if (
    outcome.status === "ok" && outcome.results.plasticLimit === 3.8 && !registryOk
  ) {
    ok("divergence 4 — computed PL 3.8 (< registry min 5) reported as-is; registry rejects storage");
  } else {
    no(`divergence 4 — module=${outcome.status === "ok" ? outcome.results.plasticLimit : "err"}, registry=${registryOk}`);
  }
}
{
  if (
    atterbergLimitsModule.testType === "ATTERBERG_LIMITS" &&
    atterbergLimitsModule.id === "atterberg-limits" &&
    atterbergLimitsModule.version === "1.0.0"
  ) {
    ok("module metadata — testType 'ATTERBERG_LIMITS' matches the registry code");
  } else {
    no("module metadata — mismatch");
  }
}

// ---------------------------------------------------------------------------
// 11. Determinism, purity, envelope, echo, rounding boundary
// ---------------------------------------------------------------------------
{
  const payload = {
    method: "CASAGRANDE_CUP", liquidLimitPoints: FLOW_F2, plasticLimitTrials: TRIALS_P1,
  };
  const before = JSON.stringify(payload);
  const signatures = new Set<string>();
  for (let i = 0; i < 25; i++) signatures.add(JSON.stringify(runCalculation(atterbergLimitsModule, payload)));
  if (signatures.size === 1) ok("determinism — 25 success runs deeply identical");
  else no("determinism — success runs diverged");
  if (JSON.stringify(payload) === before) ok("purity — input payload not mutated");
  else no("purity — input payload mutated");
  const outcome = runCalculation(atterbergLimitsModule, payload);
  if (outcome.status === "ok" && JSON.stringify(outcome.input) === JSON.stringify(payload)) {
    ok("input echo — parsed input echoed verbatim");
  } else no("input echo — altered");
}
{
  const payload = {
    method: "CASAGRANDE_CUP", liquidLimitPoints: FLOW_F1, plasticLimitTrials: TRIALS_P1,
    liquidLimit: 55, plasticLimit: 17, plasticityIndex: 38,
  };
  const signatures = new Set<string>();
  for (let i = 0; i < 25; i++) signatures.add(JSON.stringify(runCalculation(atterbergLimitsModule, payload)));
  if (signatures.size === 1) ok("determinism — 25 warning-case runs deeply identical");
  else no("determinism — warning-case runs diverged");
}
{
  const payload = { method: "CASAGRANDE_CUP", liquidLimitPoints: FLOW_F2, nonPlastic: true };
  const signatures = new Set<string>();
  for (let i = 0; i < 25; i++) signatures.add(JSON.stringify(runCalculation(atterbergLimitsModule, payload)));
  if (signatures.size === 1) ok("determinism — 25 non-plastic runs deeply identical");
  else no("determinism — non-plastic runs diverged");
}
{
  const outcome = runCalculation(atterbergLimitsModule, BASE);
  if (outcome.status === "ok") {
    if (
      outcome.moduleId === "atterberg-limits" &&
      outcome.moduleVersion === "1.0.0" &&
      outcome.testType === "ATTERBERG_LIMITS" &&
      typeof outcome.engineVersion === "string" && outcome.engineVersion.length > 0
    ) {
      ok("envelope — moduleId/moduleVersion/testType/engineVersion present");
    } else no("envelope — provenance incomplete");
    // Rounding boundary: raw keeps full precision, results are rounded.
    const rawDecimals = String(outcome.raw.liquidLimit).split(".")[1]?.length ?? 0;
    const slopeDecimals = String(outcome.raw.flowCurveSlope).split(".")[1]?.length ?? 0;
    if (
      rawDecimals > 2 && String(outcome.results.liquidLimit) === "42" &&
      slopeDecimals > 4 && String(outcome.results.flowCurveSlope) === "-18.2339"
    ) {
      ok(`rounding boundary — raw keeps ${rawDecimals}/${slopeDecimals} decimals; results 2 dp / 4 dp`);
    } else no("rounding boundary — precision policy violated");
  } else {
    no("envelope — run failed");
  }
}

console.log(`\n================ M5.2-c ATTERBERG LIMITS TEST SUMMARY: ${pass} passed, ${fail} failed ================`);
process.exit(fail);
