/**
 * PHASE 1 ENVIRONMENT PROBE — NOT application code.
 * Verifies Prisma Json field round-trip (write + read + query) on SQLite,
 * which the GEODATA HUB schema relies on for GeoJSON boundaries and
 * structured lab-test results.
 */
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

async function main() {
  const geojson = {
    type: "Polygon",
    coordinates: [
      [
        [4.4, 51.9],
        [4.5, 51.9],
        [4.5, 51.95],
        [4.4, 51.95],
        [4.4, 51.9],
      ],
    ],
  };

  const created = await db.jsonProbe.create({
    data: { payload: geojson },
  });

  const read = await db.jsonProbe.findUnique({ where: { id: created.id } });
  const roundTripOk =
    JSON.stringify(read?.payload) === JSON.stringify(geojson);

  console.log("Json write/read round-trip:", roundTripOk ? "OK" : "FAILED");
  console.log("Read payload type:", read?.payload?.type);

  await db.jsonProbe.delete({ where: { id: created.id } });
  console.log("Cleanup: OK");
}

main()
  .catch((e) => {
    console.error("PROBE FAILED:", e.message);
    process.exitCode = 1;
  })
  .finally(() => db.$disconnect());
