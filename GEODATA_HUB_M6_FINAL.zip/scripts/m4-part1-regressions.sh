#!/usr/bin/env bash
# M4 phase 1: static checks + backup + seed + M2/M3/M1 regressions.
# Single bash invocation (sandbox process-group rule).
set -u
cd /home/z/my-project

BASE=http://127.0.0.1:3000
PASS=0; FAIL=0
step(){ echo ""; echo "###############################################"; echo "### $1"; echo "###############################################"; }

stop_dev(){ pkill -f "next dev" 2>/dev/null || true; sleep 1; }
start_dev(){
  nohup bun run dev < /dev/null > /tmp/m4-dev.out 2>&1 &
  DEV_PID=$!
  for i in $(seq 1 90); do
    curl -sf "$BASE/api/health" >/dev/null 2>&1 && break
    sleep 1
  done
  if curl -sf "$BASE/api/health" >/dev/null 2>&1; then echo "dev server up (pid $DEV_PID)"; else echo "DEV SERVER FAILED"; tail -40 /tmp/m4-dev.out; exit 1; fi
}

step "0. Static checks"
bunx tsc --noEmit && { echo "tsc: PASS"; PASS=$((PASS+1)); } || { echo "tsc: FAIL"; FAIL=$((FAIL+1)); }
bun run lint && { echo "lint: PASS"; PASS=$((PASS+1)); } || { echo "lint: FAIL"; FAIL=$((FAIL+1)); }

step "1. Safety backup of current database"
cp db/custom.db db/custom.db.bak-pre-m4 && echo "backup: db/custom.db.bak-pre-m4" && PASS=$((PASS+1))

stop_dev

step "2. Pristine seed (deterministic state)"
bun run db:seed && { echo "seed: PASS"; PASS=$((PASS+1)); } || { echo "seed: FAIL"; FAIL=$((FAIL+1)); }

step "3. M2 regression — lab-test registry (12 types)"
bun scripts/m2-test-registry.ts && PASS=$((PASS+1)) || FAIL=$((FAIL+1))

step "4. M2 regression — service layer (tenant isolation etc.)"
bun scripts/m2-test-services.ts && PASS=$((PASS+1)) || FAIL=$((FAIL+1))

step "5. M2 suite re-seed (it mutates share states)"
stop_dev
bun run db:seed >/dev/null 2>&1 && echo "re-seed: done" && PASS=$((PASS+1)) || FAIL=$((FAIL+1))

step "6. M3 regression — API integration suite (live dev server)"
start_dev
bun scripts/m3-test-api.ts
M3_RC=$?
if [ $M3_RC -eq 0 ]; then PASS=$((PASS+1)); else FAIL=$((FAIL+1)); fi

step "7. M1 regression — browser auth tests (manages own dev server)"
stop_dev
bash scripts/m1-auth-test.sh
M1_RC=$?
if [ $M1_RC -eq 0 ]; then PASS=$((PASS+1)); else FAIL=$((FAIL+1)); fi

echo ""
echo "=============================================="
echo "M4 PHASE 1 SUMMARY: $PASS steps passed, $FAIL failed"
echo "  (m3 api rc=$M3_RC, m1 browser rc=$M1_RC)"
echo "=============================================="
exit $((FAIL > 0 ? 1 : 0))
