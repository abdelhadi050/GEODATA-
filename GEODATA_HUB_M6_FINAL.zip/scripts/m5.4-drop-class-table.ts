/**
 * M5.4 — drop the manually-created ClassificationRecord table so Prisma can
 * recreate it with the correct DateTime column types. The table was created
 * via direct SQL in m5.4-apply-schema.ts but Prisma's SQLite DateTime
 * handling is incompatible with the TEXT DEFAULT (datetime('now')) column
 * type — Prisma expects to manage the DateTime serialization itself.
 */
import { Database } from "bun:sqlite";
import path from "node:path";

const dbPath = path.resolve(process.cwd(), "db/custom.db");
const db = new Database(dbPath, { readwrite: true, create: false });

// Drop the indexes and table created by m5.4-apply-schema.ts.
const statements = [
  "DROP INDEX IF EXISTS ClassificationRecord_sampleId_idempotencyKey_key",
  "DROP INDEX IF EXISTS ClassificationRecord_sampleId_isValid_createdAt_idx",
  "DROP INDEX IF EXISTS ClassificationRecord_sampleId_createdAt_idx",
  "DROP INDEX IF EXISTS ClassificationRecord_organizationId_projectId_createdAt_idx",
  "DROP INDEX IF EXISTS ClassificationRecord_projectId_createdAt_idx",
  "DROP INDEX IF EXISTS ClassificationRecord_moduleId_createdAt_idx",
  "DROP TABLE IF EXISTS ClassificationRecord",
];
for (const s of statements) {
  try {
    db.run(s);
    console.log("✓", s);
  } catch (e) {
    console.error("✗", s, (e as Error).message);
  }
}

// Verify.
const tables = db.query("SELECT name FROM sqlite_master WHERE type='table' AND name LIKE 'Classification%'").all();
console.log("\nClassification tables remaining:", tables);

db.close();
