#!/usr/bin/env bash
# M5.3 Frontend Integration full run protocol.
#
#   Part 1 — static checks + all 13 calculation-engine suites (M5.2-a..g,
#            unchanged) — the engines must remain bit-identical.
#   Part 2 — fresh seed → M5.3 browser UI suite (new) → runtime error scan
#   Part 3 — M5.2 integration regressions (service + API suites, unchanged)
#   Part 4 — the established M5.1 project regression protocol, phases 1 and 2
#            (unchanged — M2/M3/M5.1/M1 suites, M4 browser UI regression,
#            ends with a pristine re-seed + integrity check)
#   Part 5 — production build + extended integrity check + final pristine
#            re-seed and record count
#
# Each part is one bash invocation (sandbox process-group rule: background
# servers do not survive between invocations, so server + suite always run in
# the SAME invocation).
set -u
cd /home/z/my-project

BASE=http://127.0.0.1:3000
PART="${1:-all}"
PASS=0; FAIL=0
step(){ echo ""; echo "###############################################"; echo "### $1"; echo "###############################################"; }

stop_dev(){ pkill -f "next dev" 2>/dev/null || true; sleep 1; }
start_dev(){
  nohup bun run dev < /dev/null > /tmp/m53-dev.out 2>&1 &
  DEV_PID=$!
  for i in $(seq 1 90); do
    curl -sf "$BASE/api/health" >/dev/null 2>&1 && break
    sleep 1
  done
  if curl -sf "$BASE/api/health" >/dev/null 2>&1; then echo "dev server up (pid $DEV_PID)"; else echo "DEV SERVER FAILED"; tail -40 /tmp/m53-dev.out; exit 1; fi
}

if [ "$PART" = "1" ] || [ "$PART" = "all" ]; then

step "1. Static checks"
bunx tsc --noEmit && { echo "tsc: PASS"; PASS=$((PASS+1)); } || { echo "tsc: FAIL"; FAIL=$((FAIL+1)); }
bun run lint && { echo "lint: PASS"; PASS=$((PASS+1)); } || { echo "lint: FAIL"; FAIL=$((FAIL+1)); }

step "2. Engine suites (M5.2-a..g, unchanged — engines must stay bit-identical)"
ENGINE_RC=0
for suite in engine units formulas constants water-content granulometry atterberg-limits proctor cbr oedometer direct-shear pressuremeter; do
  bun "scripts/m5.2-test-${suite}.ts" > "/tmp/m53-engine-${suite}.txt" 2>&1
  RC=$?
  TAIL=$(tail -1 "/tmp/m53-engine-${suite}.txt")
  echo "  ${suite}: ${TAIL} (rc=${RC})"
  [ $RC -eq 0 ] && PASS=$((PASS+1)) || { FAIL=$((FAIL+1)); ENGINE_RC=1; }
done
[ $ENGINE_RC -eq 0 ] && echo "all engine suites green" || echo "ENGINE SUITE FAILURE"

echo ""
echo "============================================="
echo "M5.3 PART 1 SUMMARY: $PASS steps passed, $FAIL failed"
echo "============================================="
exit $((FAIL > 0 ? 1 : 0))
fi

if [ "$PART" = "2" ] || [ "$PART" = "all" ]; then

stop_dev

step "3. Fresh seed → M5.3 browser UI suite (new suite, live dev server)"
bun run db:seed >/dev/null 2>&1 && echo "seed: done" && PASS=$((PASS+1)) || FAIL=$((FAIL+1))
start_dev
curl -s -o /dev/null "$BASE/login" || true
bash scripts/m5.3-test-ui.sh > /tmp/m53-ui.txt 2>&1
UI_RC=$?
tail -2 /tmp/m53-ui.txt
grep -c "^PASS" /tmp/m53-ui.txt | sed 's/^/  PASS lines: /'
grep -c "^FAIL" /tmp/m53-ui.txt | sed 's/^/  FAIL lines: /' || true
[ $UI_RC -eq 0 ] && PASS=$((PASS+1)) || FAIL=$((FAIL+1))

step "4. Runtime error scan (dev log)"
if grep -aqiE "hydration|Module not found|unhandled promise" /tmp/m53-dev.out; then
  echo "  potential errors:"
  grep -aiE "hydration|Module not found|unhandled promise" /tmp/m53-dev.out | head -5
  FAIL=$((FAIL+1))
else
  echo "no hydration/module/unhandled errors in dev log"; PASS=$((PASS+1))
fi
stop_dev

step "5. Re-seed after the UI suite (it deliberately mutates calculation data)"
bun run db:seed >/dev/null 2>&1 && echo "re-seed: done" && PASS=$((PASS+1)) || FAIL=$((FAIL+1))

echo ""
echo "============================================="
echo "M5.3 PART 2 SUMMARY: $PASS steps passed, $FAIL failed"
echo "============================================="
exit $((FAIL > 0 ? 1 : 0))
fi

if [ "$PART" = "3" ] || [ "$PART" = "all" ]; then

stop_dev

step "6. M5.2 integration regression — service suite (fresh seed)"
bun run db:seed >/dev/null 2>&1 && echo "seed: done" && PASS=$((PASS+1)) || FAIL=$((FAIL+1))
bun scripts/m5.2-int-test-service.ts > /tmp/m53-int-service.txt 2>&1
SV_RC=$?
tail -1 /tmp/m53-int-service.txt
[ $SV_RC -eq 0 ] && PASS=$((PASS+1)) || FAIL=$((FAIL+1))

step "7. M5.2 integration regression — API suite (live dev server, fresh seed)"
bun run db:seed >/dev/null 2>&1 && echo "seed: done" && PASS=$((PASS+1)) || FAIL=$((FAIL+1))
start_dev
bun scripts/m5.2-int-test-api.ts > /tmp/m53-int-api.txt 2>&1
API_RC=$?
tail -1 /tmp/m53-int-api.txt
grep -c "^FAIL" /tmp/m53-int-api.txt | sed 's/^/  FAIL lines: /' || true
[ $API_RC -eq 0 ] && PASS=$((PASS+1)) || FAIL=$((FAIL+1))
stop_dev

step "8. Re-seed after integration suites"
bun run db:seed >/dev/null 2>&1 && echo "re-seed: done" && PASS=$((PASS+1)) || FAIL=$((FAIL+1))

echo ""
echo "============================================="
echo "M5.3 PART 3 SUMMARY: $PASS steps passed, $FAIL failed"
echo "============================================="
exit $((FAIL > 0 ? 1 : 0))
fi

if [ "$PART" = "4" ] || [ "$PART" = "all" ]; then

step "9. Established project regression — phase 1 (unchanged M5.1 protocol)"
bash scripts/m5-run-all.sh 1
P1=$?
[ $P1 -eq 0 ] && PASS=$((PASS+1)) || FAIL=$((FAIL+1))

step "10. Established project regression — phase 2 (unchanged; includes the M4 browser UI regression and ends with a pristine re-seed + integrity check)"
bash scripts/m5-run-all.sh 2
P2=$?
[ $P2 -eq 0 ] && PASS=$((PASS+1)) || FAIL=$((FAIL+1))

echo ""
echo "============================================="
echo "M5.3 PART 4 SUMMARY: $PASS steps passed, $FAIL failed"
echo "============================================="
exit $((FAIL > 0 ? 1 : 0))
fi

if [ "$PART" = "5" ] || [ "$PART" = "all" ]; then

stop_dev

step "11. Production build"
bun run build > /tmp/m53-build.txt 2>&1
BUILD_RC=$?
tail -5 /tmp/m53-build.txt
[ $BUILD_RC -eq 0 ] && { echo "build: PASS"; PASS=$((PASS+1)); } || { echo "build: FAIL"; FAIL=$((FAIL+1)); }

step "12. Final pristine re-seed + extended integrity check"
bun run db:seed >/dev/null 2>&1 && echo "final seed: done" && PASS=$((PASS+1)) || FAIL=$((FAIL+1))
bun scripts/m5.2-int-check-db.ts && PASS=$((PASS+1)) || FAIL=$((FAIL+1))
bun scripts/m5-count-records.ts && PASS=$((PASS+1)) || FAIL=$((FAIL+1))

echo ""
echo "============================================="
echo "M5.3 FULL PROTOCOL SUMMARY: $PASS steps passed, $FAIL failed"
echo "============================================="
exit $((FAIL > 0 ? 1 : 0))
fi

echo "usage: bash scripts/m5.3-run-all.sh [1|2|3|4|5|all]"
exit 1
