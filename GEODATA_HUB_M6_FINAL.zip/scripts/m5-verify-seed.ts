/** M5.1 — verify seeded inputData + new fixtures landed correctly. */
import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();

async function main() {
  // 1. Input fixtures by type
  const allTests = await db.labTest.findMany({
    select: { testType: true, inputData: true },
  });
  const withInputs = allTests.filter((t) => t.inputData !== null);
  const byType: Record<string, number> = {};
  for (const t of withInputs) byType[t.testType] = (byType[t.testType] ?? 0) + 1;
  console.log("inputData by type:", JSON.stringify(byType));
  console.log("total with inputData:", withInputs.length);

  // 2. GeoStruct PROCTOR count (m2-services asserts 4, tenant-scoped)
  const geo = await db.organization.findUniqueOrThrow({ where: { slug: "geostruct" } });
  const proctor = await db.labTest.count({
    where: { testType: "PROCTOR", sample: { borehole: { project: { organizationId: geo.id } } } },
  });
  console.log("GeoStruct PROCTOR count:", proctor, "(m2-services expects 4)");

  // 3. PRESSUREMETER tests
  const pmt = await db.labTest.findMany({
    where: { testType: "PRESSUREMETER" },
    select: { status: true, resultData: true, inputData: true, sample: { select: { code: true, borehole: { select: { code: true, project: { select: { code: true } } } } } } },
  });
  for (const t of pmt) {
    const r = t.resultData as { limitPressureKpa?: number; menardModulusMPa?: number; points?: unknown[] } | null;
    console.log(
      `PMT ${t.sample.borehole.project.code}/${t.sample.borehole.code}/${t.sample.code}: status=${t.status} points=${r?.points?.length} PL=${r?.limitPressureKpa} EM=${r?.menardModulusMPa} hasInput=${t.inputData !== null}`,
    );
  }

  // 4. DS stages fixture
  const dsStages = await db.labTest.findMany({
    where: { testType: "DIRECT_SHEAR", sample: { code: "S-04" } },
    select: { resultData: true, inputData: true, sample: { select: { code: true, borehole: { select: { project: { select: { code: true } } } } } } },
  });
  for (const t of dsStages) {
    const r = t.resultData as { stages?: unknown[] } | null;
    console.log(`DS stages fixture (${t.sample.borehole.project.code}/S-04): stages=${r?.stages?.length} hasInput=${t.inputData !== null}`);
  }

  // 5. Water content corrected masses
  const wc = await db.labTest.findMany({
    where: { testType: "WATER_CONTENT" },
    select: { resultData: true, sample: { select: { code: true, borehole: { select: { code: true } } } } },
  });
  for (const t of wc) {
    const r = t.resultData as { waterContentPercent: number; wetMassG?: number; dryMassG?: number; containerMassG?: number } | null;
    if (r?.wetMassG && r?.dryMassG && r?.containerMassG) {
      const computed = (100 * (r.wetMassG - r.dryMassG)) / (r.dryMassG - r.containerMassG);
      console.log(
        `WC ${t.sample.borehole.code}/${t.sample.code}: entered=${r.waterContentPercent} computed=${computed.toFixed(3)} delta=${Math.abs(computed - r.waterContentPercent).toFixed(3)} (rule fires >0.5)`,
      );
    }
  }

  await db.$disconnect();
}

main().catch((e) => {
  console.error("VERIFY CRASHED:", e);
  process.exit(1);
});
