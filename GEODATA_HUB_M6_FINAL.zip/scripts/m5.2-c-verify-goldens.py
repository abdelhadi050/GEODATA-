#!/usr/bin/env python3
"""M5.2-c golden-value independent verification (Atterberg limits: LL / PL / IP).

Run BEFORE writing the module and the test expectations. Every expected value
below is computed independently of the TypeScript engine:

- high-precision Decimal (60 digits) for the true flow-curve regression values,
- IEEE-754 double probes mirroring the exact JS operation order designed for
  the module (sequential sums, two-pass variance, one-subtraction IP), so
  raw-value expectations and warning-boundary arithmetic are predicted exactly,
- half-away-from-zero rounding predictions for the output boundary, with a
  tie-distance guard (no golden value may sit on a .5 tie).

Designed module arithmetic (M5.2-c, Casagrande cup method):

  Flow curve  : least-squares straight line of water content w on
                x = log10(N) over the measured (blows, w) points — the
                deterministic realization of the standard's "best straight
                line through the plotted points" (ASTM D4318 / NF P94-051).
                    slope     = Sxy / Sxx       (Sxx > 0: >= 2 distinct blows)
                    intercept = mean(w) - slope * mean(x)
  Liquid limit: LL = intercept + slope * log10(25)   (25 blows: definitional)
  Plastic lim.: PL = arithmetic mean of the trial water contents
  Plasticity  : IP = LL - PL
  Trial stats : sample std dev (n >= 2, two-pass, divisor n-1); range max-min.
  Entered-comparison tolerance: +/-1.0 (registry ATTERBERG identity magnitude,
                project engineering tolerance — same class as WC +/-0.5,
                GRANULOMETRY +/-0.05).
"""
from decimal import Decimal as D, getcontext
import math

getcontext().prec = 60


# --- exact-double mirror helpers (JS op order designed for the module) ------

def js_mean(xs):
    """Mirror of formulas/statistics.ts mean(): sequential sum, then / n."""
    s = 0.0
    for v in xs:
        s += v
    return s / len(xs)


def js_fit_flow(points):
    """Mirror of the designed fitFlowCurve() double op order."""
    xs = [math.log10(p[0]) for p in points]
    ys = [p[1] for p in points]
    x_mean = js_mean(xs)
    y_mean = js_mean(ys)
    sxy = 0.0
    sxx = 0.0
    for x, y in zip(xs, ys):
        dx = x - x_mean
        dy = y - y_mean
        sxy += dx * dy
        sxx += dx * dx
    slope = sxy / sxx
    intercept = y_mean - slope * x_mean
    return slope, intercept, sxy, sxx


def js_wc_at(slope, intercept, blows):
    """Mirror of waterContentAtBlows(): intercept + slope * log10(N)."""
    return intercept + slope * math.log10(blows)


def js_sample_stddev(xs):
    """Mirror of formulas/statistics.ts sampleStandardDeviation (two-pass)."""
    m = js_mean(xs)
    sum_sq = 0.0
    for v in xs:
        sum_sq += (v - m) * (v - m)
    return math.sqrt(sum_sq / (len(xs) - 1))


def round_to_double(x, dp):
    """Mirror of units.ts roundTo: half away from zero, epsilon-corrected."""
    scaled = x * 10 ** dp
    corrected = abs(scaled) * (1 + 2.220446049250313e-16)
    r = math.floor(corrected + 0.5)  # Math.round semantics (half up on abs)
    signed = -r if scaled < 0 else r
    v = signed / 10 ** dp
    return 0.0 if v == 0 else v


def tie_distance(x, dp):
    """Distance from x*10^dp to the nearest .5 tie (must be >> 0 for goldens)."""
    scaled = x * 10 ** dp
    frac = abs(scaled - math.floor(scaled))
    return min(frac, 1 - frac) if frac != 0 else 0.0


# --- high-precision (Decimal) reference implementations ---------------------

def dec_fit_flow(points):
    xs = [D(str(p[0])).ln() / D(10).ln() for p in points]
    ys = [D(str(p[1])) for p in points]
    n = len(points)
    x_mean = sum(xs) / n
    y_mean = sum(ys) / n
    sxy = sum((x - x_mean) * (y - y_mean) for x, y in zip(xs, ys))
    sxx = sum((x - x_mean) * (x - x_mean) for x in xs)
    slope = sxy / sxx
    intercept = y_mean - slope * x_mean
    return slope, intercept


def dec_wc_at(slope, intercept, blows):
    return intercept + slope * (D(str(blows)).ln() / D(10).ln())


def show(name, val, dp=None):
    hi = float(val) if isinstance(val, D) else val
    extra = ""
    if dp is not None:
        extra = f"  -> {dp} dp: {round_to_double(hi, dp)!r}  (tie dist {tie_distance(hi, dp):.3e})"
    print(f"  {name:44s} = {hi:.15g}{extra}")


def report_flow(tag, points):
    print(f"  {tag}: " + "  ".join(f"N={n}->w={w}" for n, w in points))
    d_slope, d_intercept = dec_fit_flow(points)
    show("DEC slope  (dw per log10 cycle)", d_slope, 4)
    show("DEC intercept (w at log10N=0)", d_intercept, 4)
    show("DEC LL at N=25", dec_wc_at(d_slope, d_intercept, 25), 2)
    slope, intercept, sxy, sxx = js_fit_flow(points)
    show("DBL slope", slope)
    show("DBL intercept", intercept)
    ll = js_wc_at(slope, intercept, 25)
    show("DBL LL = intercept + slope*log10(25)", ll, 2)
    print(f"    (Sxy={sxy!r}, Sxx={sxx!r}, log10(25)={math.log10(25.0)!r})")
    return ll, slope, intercept


def report_pl(tag, trials):
    m = js_mean(trials)
    print(f"  {tag}: trials={trials}")
    show("PL mean", m, 2)
    if len(trials) >= 2:
        show("sample std dev", js_sample_stddev(trials), 2)
    else:
        print("    sample std dev: null (n < 2)")
    show("range (max-min)", max(trials) - min(trials), 2)
    return m


print("=" * 78)
print("F1 — four-point flow curve with scatter (primary regression golden)")
print("=" * 78)
F1 = [(15, 48.2), (20, 45.6), (30, 40.3), (40, 36.8)]
ll_f1, slope_f1, int_f1 = report_flow("F1", F1)

print()
print("=" * 78)
print("F2 — three-point curve, contains an exact N=25 point (line read, not")
print("     point read); computed LL ~= 42 (seed ATT_CLAY_42 echo)")
print("=" * 78)
F2 = [(18, 44.6), (25, 42.0), (33, 39.8)]
ll_f2, slope_f2, int_f2 = report_flow("F2", F2)

print()
print("=" * 78)
print("F7 — curve with LL ~= 35.3 (for the computed PL >= LL rejection)")
print("=" * 78)
F7 = [(15, 37.0), (25, 35.5), (40, 33.5)]
ll_f7, _, _ = report_flow("F7", F7)

print()
print("=" * 78)
print("F9 — seed ATT_CLAY_31 echo curve (LL ~= 31) + PL trials [15.5, 16.5]")
print("=" * 78)
F9 = [(20, 32.7), (25, 31.0), (32, 29.1)]
ll_f9, slope_f9, int_f9 = report_flow("F9", F9)

print()
print("=" * 78)
print("PL trial statistics (exact doubles where possible)")
print("=" * 78)
pl_p1 = report_pl("P1 [18, 20]  (exact: mean 19, s = sqrt(2))", [18, 20])
pl_p2 = report_pl("P2 [21.5, 22.0, 22.9]", [21.5, 22.0, 22.9])
pl_p3 = report_pl("P3 [21.3]  (single trial: s null, range 0)", [21.3])
pl_p4 = report_pl("P4 [38, 40]  (for PL >= LL rejection: mean 39)", [38, 40])
pl_p5 = report_pl("P5 [15.5, 16.5]  (exact mean 16, s = sqrt(0.5))", [15.5, 16.5])

print()
print("=" * 78)
print("Golden envelopes: IP = LL - PL (one subtraction), entered deltas")
print("=" * 78)

for tag, ll, pl in [
    ("E1 = F1 + P1", ll_f1, pl_p1),
    ("E2 = F2 + P1", ll_f2, pl_p1),
    ("E3 = F9 + P5", ll_f9, pl_p5),
]:
    ip = ll - pl
    print(f"  {tag}:")
    show("LL (raw)", ll, 2)
    show("PL (raw)", pl, 2)
    show("IP = LL - PL (raw)", ip, 2)

print()
print("  Entered-comparison boundaries (tolerance +/-1.0, strict >):")
d = pl_p1 - 18.0
print(f"    P1 vs entered PL 18:  D = 19 - 18 = {d!r}  |D|>1? {abs(d) > 1.0}  -> no warning (exact boundary)")
d = pl_p1 - 17.99
print(f"    P1 vs entered PL 17.99: D = {d!r}  |D|>1? {abs(d) > 1.0}  -> WARNING")
d = pl_p1 - 18.01
print(f"    P1 vs entered PL 18.01: D = {d!r}  |D|>1? {abs(d) > 1.0}  -> no warning")
d = ll_f2 - 42.0
print(f"    F2 LL vs entered LL 42: D = {d!r}  |D|>1? {abs(d) > 1.0}  -> no warning")
d = (ll_f2 - pl_p1) - 24.0
print(f"    E2 IP vs entered PI 24: D = {d!r}  |D|>1? {abs(d) > 1.0}  -> no warning")
d = (ll_f2 - pl_p1) - 25.0
print(f"    E2 IP vs entered PI 25: D = {d!r}  |D|>1? {abs(d) > 1.0}  -> WARNING")
d = ll_f1 - 55.0
print(f"    F1 LL vs entered LL 55: D = {d!r}  |D|>1? {abs(d) > 1.0}  -> WARNING")
d = pl_p1 - 17.0
print(f"    P1 vs entered PL 17:  D = {d!r}  |D|>1? {abs(d) > 1.0}  -> WARNING")
d = (ll_f1 - pl_p1) - 38.0
print(f"    E1 IP vs entered PI 38: D = {d!r}  |D|>1? {abs(d) > 1.0}  -> WARNING")

print()
print("  Entered-identity registry mirror (PI = LL - PL +/-1.0, registry expr):")
for ll_e, pl_e, pi_e in [(42.0, 18.0, 23.0), (42.0, 18.0, 22.99), (42.0, 18.0, 24.0), (42.0, 19.0, 23.0), (55.0, 24.0, 31.0)]:
    expected = ll_e - pl_e
    delta = abs(pi_e - expected)
    print(f"    entered LL={ll_e} PL={pl_e} PI={pi_e}: |PI-(LL-PL)| = {delta!r} > 1.0? {delta > 1.0}"
          f"  -> {'REJECT' if delta > 1.0 else 'accept'}")

print()
print("  Computed PL >= computed LL rejection (E7 = F7 + P4):")
print(f"    F7 LL = {ll_f7!r} (2dp {round_to_double(ll_f7, 2)!r}); P4 PL = {pl_p4!r}"
      f"  -> PL >= LL? {pl_p4 >= ll_f7}  -> INVALID_INPUT")

print()
print("=" * 78)
print("Rejection-curve arithmetic (predicted outcomes only, no goldens needed)")
print("=" * 78)
F3 = [(15, 30.0), (25, 40.0), (40, 50.0)]  # w increases with blows
s3, i3, _, _ = js_fit_flow(F3)
print(f"  F3 positive slope: slope = {s3!r} >= 0 -> INVALID_INPUT (physical rule)")
F4 = [(15, 40.0), (25, 40.0), (40, 40.0)]  # flat w
s4, i4, _, _ = js_fit_flow(F4)
print(f"  F4 flat w:        slope = {s4!r} >= 0 -> INVALID_INPUT (physical rule)")
print("  F5 all blows > 25 (30/35/40): 25 outside [30,40] -> ARITHMETIC_DOMAIN_ERROR (no extrapolation)")
print("  F6 all blows < 25 (12/18/20): 25 outside [12,20] -> ARITHMETIC_DOMAIN_ERROR (no extrapolation)")
print("  F8 identical blows [25,25,25]: < 2 distinct blows -> ARITHMETIC_DOMAIN_ERROR (zero Sxx)")

print()
print("=" * 78)
print("Registry revalidation predictions (computed results -> atterbergResult)")
print("=" * 78)
for tag, ll, pl in [("E2 (F2+P1)", ll_f2, pl_p1), ("E3 (F9+P5)", ll_f9, pl_p5), ("E1 (F1+P1)", ll_f1, pl_p1)]:
    ll_r = round_to_double(ll, 2)
    pl_r = round_to_double(pl, 2)
    ip_r = round_to_double(ll - pl, 2)
    in_bounds = 10 <= ll_r <= 150 and 5 <= pl_r <= 100 and 0 <= ip_r <= 100
    identity_ok = abs(ip_r - (ll_r - pl_r)) <= 1.0
    order_ok = pl_r < ll_r
    print(f"  {tag}: rounded LL={ll_r!r} PL={pl_r!r} IP={ip_r!r}"
          f"  bounds={in_bounds} identity={identity_ok} PL<LL={order_ok}"
          f"  -> registry {'ACCEPTS' if (in_bounds and identity_ok and order_ok) else 'REJECTS'}")
print("  (low-PL divergence probe) trials [3.6, 4.0] -> PL = 4.0 exact? ",
      f"{js_mean([3.6, 4.0])!r} -> 2dp {round_to_double(js_mean([3.6, 4.0]), 2)!r}"
      "  (< registry min 5: module reports as-is, registry cannot store — documented divergence)")
print("  (non-plastic) module results PL=null IP=null: registry atterbergResult requires")
print("   plasticLimit + plasticityIndex -> cannot store NP (documented divergence)")

print()
print("=" * 78)
print("Full expected envelopes (double probes, transcribe into the test suite)")
print("=" * 78)
for tag, ll, slope, intercept, pl_trials in [
    ("E1 = F1 + P1", ll_f1, slope_f1, int_f1, [18, 20]),
    ("E2 = F2 + P1", ll_f2, slope_f2, int_f2, [18, 20]),
    ("E3 = F9 + P5", ll_f9, slope_f9, int_f9, [15.5, 16.5]),
]:
    pl = js_mean(pl_trials)
    ip = ll - pl
    s = js_sample_stddev(pl_trials) if len(pl_trials) >= 2 else None
    rng = max(pl_trials) - min(pl_trials)
    print(f"  {tag}:")
    print(f"    raw      slope={slope!r} intercept={intercept!r} LL={ll!r} PL={pl!r} IP={ip!r}")
    print(f"              stdDev={s!r} range={rng!r}")
    print(f"    results  slope={round_to_double(slope, 4)!r} intercept={round_to_double(intercept, 4)!r} "
          f"LL={round_to_double(ll, 2)!r} PL={round_to_double(pl, 2)!r} IP={round_to_double(ip, 2)!r} "
          f"stdDev={round_to_double(s, 2) if s is not None else None!r} range={round_to_double(rng, 2)!r}")
print("  E5 = F2 + nonPlastic (PL/IP null, trials absent):")
print(f"    results  LL={round_to_double(ll_f2, 2)!r} slope={round_to_double(slope_f2, 4)!r} "
      f"intercept={round_to_double(int_f2, 4)!r} PL=null IP=null count=0 stdDev=null range=null")

print()
print("=" * 78)
print("Warning-detail predictions (details carry 4 dp values, granulometry shape)")
print("=" * 78)

cases = [
    ("W-LL  E1 LL vs entered 55", ll_f1, 55.0),
    ("W-PL  P1 PL vs entered 17", pl_p1, 17.0),
    ("W-PI  E1 IP vs entered 38", ll_f1 - pl_p1, 38.0),
    ("W-IP2 E2 IP vs entered 24 (only warning in B1)", ll_f2 - pl_p1, 24.0),
    ("W-NP  E5(NP) LL vs entered 55", ll_f2, 55.0),
]
for tag, computed, entered in cases:
    d = computed - entered
    print(f"  {tag}:")
    print(f"    raw computed={computed!r} entered={entered!r} D={d!r} |D|>1? {abs(d) > 1.0}")
    print(f"    details: computedValue={round_to_double(computed, 4)!r} "
          f"discrepancy={round_to_double(d, 4)!r} tolerance=1.0")

print()
print("  No-warning boundary re-check (hardcoded labels above corrected by flags):")
print(f"    P1 PL vs entered 18:  D = {pl_p1 - 18.0!r} -> |D|>1? {abs(pl_p1 - 18.0) > 1.0} (exact boundary, NO warning)")
print(f"    E2 IP vs entered 24:  D = {(ll_f2 - pl_p1) - 24.0!r} -> |D|>1? "
      f"{abs((ll_f2 - pl_p1) - 24.0) > 1.0} (WARNING — label in the section above was a verifier typo;"
      " the computed flag is authoritative)")

print()
print("verifier complete — values above are the independent golden expectations")
