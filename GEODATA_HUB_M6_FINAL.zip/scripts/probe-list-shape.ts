/**
 * Probe: does GET /api/lab-tests list items include resultData today?
 * (Determines the correct D3 implementation.)
 */
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();
const BASE = process.env.BASE ?? "http://127.0.0.1:3000";
const PASSWORD = "Demo1234!";

function cookieFrom(setCookies: string[], name: string): string | null {
  for (const c of setCookies) {
    const [pair] = c.split(";");
    const eq = pair.indexOf("=");
    if (pair.slice(0, eq) === name) return pair.slice(eq + 1);
  }
  return null;
}

async function login(email: string): Promise<string | null> {
  const r1 = await fetch(`${BASE}/api/auth/csrf`);
  const { csrfToken } = (await r1.json()) as { csrfToken: string };
  const csrfCookie = cookieFrom(r1.headers.getSetCookie(), "next-auth.csrf-token");
  if (!csrfCookie) return null;
  const r2 = await fetch(`${BASE}/api/auth/callback/credentials`, {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
      Cookie: `next-auth.csrf-token=${csrfCookie}`,
    },
    body: new URLSearchParams({
      csrfToken,
      email,
      password: PASSWORD,
      callbackUrl: `${BASE}/`,
      json: "true",
    }),
    redirect: "manual",
  });
  const session = cookieFrom(r2.headers.getSetCookie(), "next-auth.session-token");
  return session ? `next-auth.session-token=${session}` : null;
}

async function main() {
  const cookie = await login("manager@geodata.demo");
  if (!cookie) {
    console.log("LOGIN FAILED");
    process.exit(1);
  }
  const res = await fetch(`${BASE}/api/lab-tests?testType=WATER_CONTENT&pageSize=3`, {
    headers: { Cookie: cookie },
  });
  const body = (await res.json()) as any;
  const items = body?.data ?? [];
  console.log("items:", items.length);
  for (const it of items) {
    console.log(
      JSON.stringify({
        id: it.id?.slice(0, 8),
        testType: it.testType,
        keys: Object.keys(it).sort().join(","),
        hasResultData: "resultData" in it,
        resultDataNull: it.resultData === null,
        hasInputData: "inputData" in it,
      }),
    );
  }
  // Also check the service layer directly (what Prisma returns with include + no select)
  const raw = await db.labTest.findMany({
    where: { testType: "WATER_CONTENT" },
    take: 1,
    include: { sample: { select: { code: true } } },
  });
  console.log("direct prisma keys:", Object.keys(raw[0]).sort().join(","));
  await db.$disconnect();
}

main().catch((e) => {
  console.error("PROBE CRASHED:", e);
  process.exit(1);
});
