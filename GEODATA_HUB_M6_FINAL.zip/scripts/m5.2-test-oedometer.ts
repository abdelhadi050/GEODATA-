/**
 * M5.2-f TEST — Oedometer consolidation calculation module (Cc / Cs / mv /
 * σ′p Casagrande / Cv log-time fit).
 *
 * Golden values independently verified BEFORE being asserted here (60-digit
 * Decimal regression + IEEE-double probes mirroring the module's exact op
 * order — terminal-window VCL fit, circumscribed-curvature Casagrande
 * construction, bisector/VCL intersection, fixed-window log-time fit — in
 * scripts/m5.2-f-verify-goldens-oedometer.py). Sources: M5.2-f authorization
 * §6.A, registry oedometerResult contract (ASTM D2435 / NF P94-090 /
 * ISO 17892-5), prisma/seed.ts fixture OEDO_CLAY (Cc 0.155, Cs 0.022, σ′p
 * 180, cv 1.8 m²/year — echoed without comparison: no registry tolerance).
 *
 * Coverage (authorization §9): normal valid cases (VCL/Cc goldens, unloading
 * Cs, mv per increment, height-datum stage resolution, Casagrande σ′p
 * construction, Cv log-time fit); missing inputs (empty payload, stage
 * without a measurement, height stages without the datum); invalid inputs
 * (ordering violations, contradictory stage fields, non-compressing
 * terminal window, out-of-bounds void ratios, bad reading series, stage
 * count bounds); boundary conditions (2-stage secant, Cs sign); unit
 * consistency (mm²/min ↔ cm²/s exact SI conversion); insufficient
 * experimental data (no unloading branch → Cs null, < 3 stages → σ′p null,
 * construction not closable → σ′p null, m²/year D8-blocked); calculation
 * accuracy (Decimal-agreed regressions); physical and engineering
 * consistency (e decreasing with log σ′, σ′p inside the tested range);
 * error and warning handling (INSUFFICIENT_DATA / PHYSICAL_CONSISTENCY
 * codes); M5.1 registry parity with documented divergences; determinism
 * (25 runs × paths); purity; envelope provenance.
 *
 * Key verifier goldens (double probes; Decimal agrees to <1e-13):
 *   O1 OEDO_CLAY: vclSlope = −0.15446965641226226 (Cc 0.1545), σ′p =
 *     129.39004317454868 kPa (B at 100 kPa, curvature 0.14148605799165467),
 *     mv = [2.92887…e-4, 2.31823…e-4, 1.86567…e-4, 1.22216…e-4, 6.68151…e-5].
 *   O2 (+ unloading 400→50): Cs = 0.048500150185355376, eF = 0.826.
 *   O4 (Cv): d0 = 0.5, d100 = 0.91, t50 = 1.723945642493957 min,
 *     Cv = 11.427274453677596 mm²/min = 0.0019045457422795992 cm²/s.
 * Exit code = number of failures.
 */
import { runCalculation } from "../src/lib/calc/engine";
import type { CalculationOutcome } from "../src/lib/calc/types";
import {
  casagrandeLogTimeFit,
  fitLine,
  oedometerCalcInput,
  oedometerModule,
  tripleCurvature,
  voidRatioFromHeight,
  type OedometerInput,
  type OedometerRaw,
  type OedometerResults,
} from "../src/lib/calc/modules/oedometer";
import { parseLabTestResult } from "../src/lib/lab-tests/registry";

let pass = 0;
let fail = 0;
const ok = (m: string) => { console.log(`PASS: ${m}`); pass++; };
const no = (m: string) => { console.log(`FAIL: ${m}`); fail++; };

const approx = (actual: number, expected: number, tol: number): boolean =>
  Math.abs(actual - expected) <= tol;

type Outcome = CalculationOutcome<OedometerInput, OedometerRaw, OedometerResults>;

interface ExpectedError {
  code: string;
  fieldPath?: string;
  messageHint?: string;
}

function expectError(outcome: Outcome, label: string, expected: ExpectedError): void {
  if (outcome.status !== "error") {
    no(`${label} — expected ${expected.code}, got success`);
    return;
  }
  const { code, message, details } = outcome.error;
  if (code !== expected.code) {
    no(`${label} — expected ${expected.code}, got ${code}`);
    return;
  }
  if (expected.fieldPath !== undefined && details?.fieldPath !== expected.fieldPath) {
    no(`${label} — expected fieldPath ${expected.fieldPath}, got ${String(details?.fieldPath)}`);
    return;
  }
  if (expected.messageHint !== undefined && !message.includes(expected.messageHint)) {
    no(`${label} — message '${message}' lacks hint '${expected.messageHint}'`);
    return;
  }
  ok(`${label} — ${code}${expected.fieldPath ? ` @ ${expected.fieldPath}` : ""}`);
}

// ---------------------------------------------------------------------------
// Fixtures (independently verified in scripts/m5.2-f-verify-goldens-oedometer.py)
// ---------------------------------------------------------------------------

/** OEDO_CLAY seed shape — registry loading stages. */
const OEDO_LOADING = [
  { verticalPressureKpa: 25, voidRatio: 0.912 },
  { verticalPressureKpa: 50, voidRatio: 0.898 },
  { verticalPressureKpa: 100, voidRatio: 0.876 },
  { verticalPressureKpa: 200, voidRatio: 0.841 },
  { verticalPressureKpa: 400, voidRatio: 0.796 },
  { verticalPressureKpa: 800, voidRatio: 0.748 },
];
const OEDO_ENTERED = {
  compressionIndexCc: 0.155,
  swellingIndexCs: 0.022,
  preConsolidationPressureKpa: 180,
  coefficientOfConsolidationCvM2PerYear: 1.8,
};

/** Rebound branch (pressures strictly decreasing). */
const OEDO_UNLOADING = [
  { verticalPressureKpa: 400, voidRatio: 0.782 },
  { verticalPressureKpa: 200, voidRatio: 0.801 },
  { verticalPressureKpa: 100, voidRatio: 0.815 },
  { verticalPressureKpa: 50, voidRatio: 0.826 },
];

/** Height-based stages (datum: H = 20 mm at e = 0.912). */
const OEDO_HEIGHTS = [
  { verticalPressureKpa: 25, specimenHeightMm: 19.999999999999996 },
  { verticalPressureKpa: 50, specimenHeightMm: 19.85355648535565 },
  { verticalPressureKpa: 100, specimenHeightMm: 19.623430962343097 },
  { verticalPressureKpa: 200, specimenHeightMm: 19.25732217573222 },
  { verticalPressureKpa: 400, specimenHeightMm: 18.78661087866109 },
  { verticalPressureKpa: 800, specimenHeightMm: 18.284518828451883 },
];

/** Casagrande log-time reading series (d0 = 0.5, d100 = 0.91 by design). */
const CV_READINGS = [
  { timeMin: 0.1, dialMm: 0.5474341649025257 },
  { timeMin: 0.25, dialMm: 0.575 },
  { timeMin: 0.5, dialMm: 0.6060660171779821 },
  { timeMin: 1, dialMm: 0.65 },
  { timeMin: 2, dialMm: 0.72 },
  { timeMin: 4, dialMm: 0.7819218350604349 },
  { timeMin: 8, dialMm: 0.8438436701208697 },
  { timeMin: 15, dialMm: 0.9 },
  { timeMin: 30, dialMm: 0.91 },
  { timeMin: 60, dialMm: 0.91 },
  { timeMin: 120, dialMm: 0.91 },
  { timeMin: 240, dialMm: 0.91 },
];

// ---------------------------------------------------------------------------
// 1. Golden envelopes
// ---------------------------------------------------------------------------
{
  // O1 — the registry seed shape: terminal-3 VCL, Casagrande σ′p, mv, Cs null.
  const outcome = runCalculation(oedometerModule, {
    loadingStages: OEDO_LOADING, ...OEDO_ENTERED,
  });
  if (outcome.status !== "ok") no(`golden O1 — failed: ${outcome.error.message}`);
  else {
    const insuff = outcome.warnings.filter((w) => w.code === "INSUFFICIENT_DATA");
    const checks: Array<[boolean, string]> = [
      [approx(outcome.raw.vclSlope, -0.15446965641226226, 1e-9), "raw.vclSlope ≈ −0.15446965641226226 (terminal-3 window 200/400/800)"],
      [approx(outcome.raw.vclIntercept, 1.1969393128245245, 1e-9), "raw.vclIntercept ≈ 1.1969393128245245"],
      [outcome.raw.vclWindowCount === 3, "VCL window = 3 stages"],
      [approx(outcome.raw.compressionIndexCc, 0.15446965641226226, 1e-12), "raw Cc = −slope ≈ 0.15446965641226226"],
      [outcome.results.compressionIndexCc === 0.1545, "results Cc = 0.1545 (4 dp)"],
      [approx(outcome.raw.preConsolidationPressureKpa ?? 0, 129.39004317454868, 1e-9), "raw σ′p ≈ 129.39004317454868 kPa (Casagrande)"],
      [outcome.results.preConsolidationPressureKpa === 129.4, "results σ′p = 129.4 (1 dp)"],
      [outcome.results.preConsolidationMethod === "CASAGRANDE", "method = CASAGRANDE (documented)"],
      [approx(outcome.raw.casagrandeBCurvature ?? 0, 0.14148605799165467, 1e-12), "B curvature ≈ 0.14148605799165467 (B at 100 kPa)"],
      [approx(10 ** (outcome.raw.casagrandeBLog10Pressure ?? 0), 100, 1e-9), "B at σ′ = 100 kPa"],
      [outcome.raw.preConsolidationPressureKpa !== null && outcome.raw.preConsolidationPressureKpa > 100 && outcome.raw.preConsolidationPressureKpa < 800, "σ′p strictly inside the tested range (100 < 129.4 < 800)"],
      [approx(outcome.raw.mvPerIncrementKpaInverse[0], 0.0002928870292887032, 1e-15), "mv(25→50) ≈ 2.92887…e-4 1/kPa"],
      [approx(outcome.raw.mvPerIncrementKpaInverse[4], 6.681514476614706e-5, 1e-18), "mv(400→800) ≈ 6.68151…e-5 1/kPa"],
      [outcome.results.mvPerIncrementKpaInverse.length === 5, "5 loading increments"],
      [outcome.results.mvPerIncrementKpaInverse[0] === 0.000293, "results mv[0] = 0.000293 (6 dp)"],
      [outcome.results.initialVoidRatio === 0.912, "e0 = 0.912 (first loading stage)"],
      [outcome.results.finalVoidRatio === 0.748, "eF = 0.748 (last loading stage, no unloading)"],
      [outcome.raw.swellingIndexCs === null && outcome.results.swellingIndexCs === null, "Cs null (no unloading branch)"],
      [insuff.length === 1 && insuff[0].message.includes("unloading"), "one INSUFFICIENT_DATA warning (Cs not computable)"],
      [outcome.warnings.length === 1, "exactly 1 warning"],
      [outcome.results.enteredCompressionIndexCc === 0.155, "entered Cc echoed (0.155) WITHOUT comparison — no registry tolerance, none invented"],
      [outcome.results.enteredSwellingIndexCs === 0.022, "entered Cs echoed"],
      [outcome.results.enteredPreConsolidationPressureKpa === 180, "entered σ′p echoed (180 ≠ computed 129.4 — no warning by design)"],
      [outcome.results.enteredCvM2PerYear === 1.8, "entered cv echoed"],
      [outcome.results.curve.length === 6 && outcome.results.curve.every((p) => p.branch === "LOADING"), "curve = 6 loading points"],
      [outcome.results.curve[2].voidRatio === 0.876, "curve[2] e = 0.876 (4 dp)"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`golden O1 — ${label}`);
      else no(`golden O1 — ${label}`);
    }
  }
}
{
  // O2 — with the unloading branch: Cs from the rebound fit, eF = 0.826.
  const outcome = runCalculation(oedometerModule, {
    loadingStages: OEDO_LOADING, unloadingStages: OEDO_UNLOADING,
  });
  if (outcome.status !== "ok") no(`golden O2 — failed: ${outcome.error.message}`);
  else {
    const checks: Array<[boolean, string]> = [
      [approx(outcome.raw.swellingIndexCs ?? 0, 0.048500150185355376, 1e-12), "raw Cs ≈ 0.048500150185355376"],
      [outcome.results.swellingIndexCs === 0.0485, "results Cs = 0.0485 (4 dp)"],
      [outcome.results.finalVoidRatio === 0.826, "eF = 0.826 (last unloading stage)"],
      [outcome.results.curve.length === 10, "curve = 10 points (6 loading + 4 unloading)"],
      [outcome.results.curve[6].branch === "UNLOADING" && outcome.results.curve[6].voidRatio === 0.782, "curve[6] = unloading point (400 kPa, e 0.782)"],
      [approx(outcome.raw.compressionIndexCc, 0.15446965641226226, 1e-12), "Cc unchanged by the unloading branch"],
      [approx(outcome.raw.preConsolidationPressureKpa ?? 0, 129.39004317454868, 1e-9), "σ′p unchanged (loading branch only)"],
      [outcome.warnings.length === 0, "no warnings (Cs computable)"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`golden O2 — ${label}`);
      else no(`golden O2 — ${label}`);
    }
  }
}
{
  // O3 — height-based stages: e derived through the 1-D phase datum.
  const outcome = runCalculation(oedometerModule, {
    loadingStages: OEDO_HEIGHTS,
    referenceHeightMm: 20,
    referenceVoidRatio: 0.912,
  });
  if (outcome.status !== "ok") no(`golden O3 — failed: ${outcome.error.message}`);
  else {
    const roundTrip = [0.9119999999999995, 0.8980000000000001, 0.8759999999999999, 0.8410000000000002, 0.796, 0.748];
    const checks: Array<[boolean, string]> = [
      [outcome.raw.loadingStages.every((s, i) => approx(s.voidRatio, roundTrip[i], 1e-15)), "derived void ratios = the height-datum round-trip doubles"],
      [approx(outcome.raw.compressionIndexCc, 0.15446965641226226, 1e-9), "Cc ≈ the O1 golden (height path consistent with the void-ratio path)"],
      [approx(outcome.raw.preConsolidationPressureKpa ?? 0, 129.39004317454868, 1e-7), "σ′p ≈ the O1 golden (path independence within fp noise)"],
      [outcome.results.initialVoidRatio === 0.912, "e0 = 0.912 (4 dp)"],
      [outcome.warnings.length === 1, "one warning (Cs null — no unloading branch)"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`golden O3 — ${label}`);
      else no(`golden O3 — ${label}`);
    }
  }
}
{
  // O4 — Casagrande log-time fit with the reading series (Hd = 10 mm).
  const outcome = runCalculation(oedometerModule, {
    loadingStages: OEDO_LOADING,
    consolidationReading: { incrementFromIndex: 4, readings: CV_READINGS, drainagePathMm: 10 },
  });
  if (outcome.status !== "ok") no(`golden O4 — failed: ${outcome.error.message}`);
  else {
    const insuff = outcome.warnings.filter((w) => w.code === "INSUFFICIENT_DATA");
    const checks: Array<[boolean, string]> = [
      [outcome.raw.cvFit !== null, "cvFit computed"],
      [approx(outcome.raw.cvFit?.d0Mm ?? 0, 0.5, 1e-12), "d0 ≈ 0.5 (early √t-line intercept)"],
      [approx(outcome.raw.cvFit?.d100Mm ?? 0, 0.91, 1e-12), "d100 ≈ 0.91 (primary/secondary line intersection)"],
      [approx(outcome.raw.cvFit?.t50Min ?? 0, 1.723945642493957, 1e-12), "t50 ≈ 1.723945642493957 min (log10-t interpolation)"],
      [approx(outcome.raw.cvFit?.cvMm2PerMin ?? 0, 11.427274453677596, 1e-9), "Cv ≈ 11.427274453677596 mm²/min = 0.197 × 100 / t50"],
      [approx(outcome.raw.cvFit?.cvCm2PerS ?? 0, 0.0019045457422795992, 1e-15), "Cv ≈ 0.0019045457422795992 cm²/s (exact /6000)"],
      [outcome.results.cvMm2PerMin === 11.4273, "results Cv = 11.4273 mm²/min (4 dp)"],
      [outcome.results.cvCm2PerS === 0.001905, "results Cv = 0.001905 cm²/s (6 dp)"],
      [outcome.results.cvM2PerYear === null, "cvM2PerYear null (year-length convention unverified — D8)"],
      [insuff.some((w) => w.message.includes("m²/year")), "INSUFFICIENT_DATA warning explains the blocked m²/year conversion"],
      [insuff.some((w) => w.message.includes("unloading")), "INSUFFICIENT_DATA warning for Cs (no unloading branch) still present"],
      [outcome.warnings.length === 2, "exactly 2 warnings"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`golden O4 — ${label}`);
      else no(`golden O4 — ${label}`);
    }
  }
}
{
  // O5 — gently overconsolidated curve: the mechanical construction closes
  // at 86.7 kPa (documented behavior: the module computes the construction;
  // a curvature-free curve yields a modest σ′p — the raw internals are
  // reported for the caller's judgment).
  const outcome = runCalculation(oedometerModule, {
    loadingStages: [
      { verticalPressureKpa: 25, voidRatio: 0.9 },
      { verticalPressureKpa: 50, voidRatio: 0.896 },
      { verticalPressureKpa: 100, voidRatio: 0.891 },
      { verticalPressureKpa: 200, voidRatio: 0.885 },
      { verticalPressureKpa: 400, voidRatio: 0.878 },
      { verticalPressureKpa: 800, voidRatio: 0.87 },
    ],
  });
  if (outcome.status !== "ok") no(`golden O5 — failed: ${outcome.error.message}`);
  else {
    const checks: Array<[boolean, string]> = [
      [outcome.results.compressionIndexCc === 0.0249, "Cc = 0.0249 (terminal recompression-scale slope — OC data)"],
      [outcome.results.preConsolidationPressureKpa === 86.7, "σ′p = 86.7 kPa (mechanical construction result, documented)"],
      [outcome.raw.casagrandeBCurvature !== null, "B curvature reported in raw (transparency)"],
      [outcome.warnings.length === 1, "one warning (Cs null)"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`golden O5 — ${label}`);
      else no(`golden O5 — ${label}`);
    }
  }
}
{
  // O9 — kink inside the terminal window: the construction does NOT close
  // (the bisector meets the VCL backwards) → σ′p null + INSUFFICIENT_DATA.
  const outcome = runCalculation(oedometerModule, {
    loadingStages: [
      { verticalPressureKpa: 25, voidRatio: 0.95 },
      { verticalPressureKpa: 50, voidRatio: 0.948 },
      { verticalPressureKpa: 100, voidRatio: 0.945 },
      { verticalPressureKpa: 200, voidRatio: 0.94 },
      { verticalPressureKpa: 400, voidRatio: 0.85 },
      { verticalPressureKpa: 800, voidRatio: 0.82 },
    ],
  });
  if (outcome.status !== "ok") no(`golden O9 — failed: ${outcome.error.message}`);
  else {
    const insuff = outcome.warnings.filter((w) => w.code === "INSUFFICIENT_DATA");
    const checks: Array<[boolean, string]> = [
      [outcome.results.preConsolidationPressureKpa === null, "σ′p null (construction does not close)"],
      [outcome.results.preConsolidationMethod === null, "method null"],
      [insuff.some((w) => w.message.includes("does not close") || w.message.includes("Casagrande")), "INSUFFICIENT_DATA warning names the Casagrande failure"],
      [outcome.results.compressionIndexCc === 0.1993, "Cc still computed (0.1993) from the terminal window"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`golden O9 — ${label}`);
      else no(`golden O9 — ${label}`);
    }
  }
}
{
  // O6 — two loading stages: Cc = 2-point secant; σ′p undefined.
  const outcome = runCalculation(oedometerModule, {
    loadingStages: [
      { verticalPressureKpa: 100, voidRatio: 0.9 },
      { verticalPressureKpa: 200, voidRatio: 0.86 },
    ],
  });
  if (outcome.status !== "ok") no(`golden O6 — failed: ${outcome.error.message}`);
  else {
    const checks: Array<[boolean, string]> = [
      [outcome.raw.vclWindowCount === 2, "VCL window = 2 stages"],
      [approx(outcome.raw.compressionIndexCc, 0.13287712379549457, 1e-12), "raw Cc ≈ 0.13287712379549457 (secant)"],
      [outcome.results.compressionIndexCc === 0.1329, "results Cc = 0.1329"],
      [outcome.results.preConsolidationPressureKpa === null, "σ′p null (fewer than 3 stages)"],
      [outcome.results.mvPerIncrementKpaInverse.length === 1, "1 mv increment"],
      [outcome.warnings.filter((w) => w.code === "INSUFFICIENT_DATA").length === 2, "2 INSUFFICIENT_DATA warnings (σ′p, Cs)"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`golden O6 — ${label}`);
      else no(`golden O6 — ${label}`);
    }
  }
}

// ---------------------------------------------------------------------------
// 2. Validation — ordering, contradictory and missing measurements
// ---------------------------------------------------------------------------
{
  const outcome = runCalculation(oedometerModule, {
    loadingStages: [
      { verticalPressureKpa: 100, voidRatio: 0.9 },
      { verticalPressureKpa: 100, voidRatio: 0.86 },
      { verticalPressureKpa: 200, voidRatio: 0.84 },
    ],
  });
  expectError(outcome, "loading pressures not strictly increasing", {
    code: "INVALID_INPUT",
    fieldPath: "loadingStages.1.verticalPressureKpa",
    messageHint: "strictly increasing",
  });
}
{
  const outcome = runCalculation(oedometerModule, {
    loadingStages: OEDO_LOADING,
    unloadingStages: [
      { verticalPressureKpa: 400, voidRatio: 0.782 },
      { verticalPressureKpa: 500, voidRatio: 0.77 },
    ],
  });
  expectError(outcome, "unloading pressures not strictly decreasing", {
    code: "INVALID_INPUT",
    fieldPath: "unloadingStages.1.verticalPressureKpa",
    messageHint: "strictly decreasing",
  });
}
{
  const outcome = runCalculation(oedometerModule, {
    loadingStages: [
      { verticalPressureKpa: 100, voidRatio: 0.9, specimenHeightMm: 19 },
      { verticalPressureKpa: 200, voidRatio: 0.86 },
    ],
  });
  expectError(outcome, "stage with both voidRatio and height", {
    code: "INVALID_INPUT",
    fieldPath: "loadingStages.0.voidRatio",
    messageHint: "contradictory",
  });
}
{
  const outcome = runCalculation(oedometerModule, {
    loadingStages: [
      { verticalPressureKpa: 100 },
      { verticalPressureKpa: 200, voidRatio: 0.86 },
    ],
  });
  expectError(outcome, "stage with no measurement", {
    code: "INVALID_INPUT",
    fieldPath: "loadingStages.0.voidRatio",
    messageHint: "neither",
  });
}
{
  const outcome = runCalculation(oedometerModule, {
    loadingStages: [
      { verticalPressureKpa: 100, specimenHeightMm: 19.5 },
      { verticalPressureKpa: 200, specimenHeightMm: 19.2 },
    ],
  });
  expectError(outcome, "height-based stages without the datum", {
    code: "MISSING_INPUT",
    messageHint: "referenceHeightMm, referenceVoidRatio",
  });
}
{
  const outcome = runCalculation(oedometerModule, {
    loadingStages: [
      { verticalPressureKpa: 100, specimenHeightMm: 5 },
      { verticalPressureKpa: 200, specimenHeightMm: 4.9 },
    ],
    referenceHeightMm: 20,
    referenceVoidRatio: 0.912,
  });
  expectError(outcome, "derived void ratio below the registry bound", {
    code: "INVALID_INPUT",
    fieldPath: "loadingStages.0.voidRatio",
    messageHint: "outside the registry bound",
  });
}
{
  // Non-compressing terminal window (e rising with log σ′).
  const outcome = runCalculation(oedometerModule, {
    loadingStages: [
      { verticalPressureKpa: 25, voidRatio: 0.9 },
      { verticalPressureKpa: 50, voidRatio: 0.88 },
      { verticalPressureKpa: 100, voidRatio: 0.89 },
      { verticalPressureKpa: 200, voidRatio: 0.9 },
    ],
  });
  expectError(outcome, "non-compressing terminal window", {
    code: "INVALID_INPUT",
    fieldPath: "loadingStages",
    messageHint: "physically inconsistent",
  });
}
{
  const outcome = runCalculation(oedometerModule, {
    loadingStages: Array.from({ length: 13 }, (_, i) => ({ verticalPressureKpa: 25 * 2 ** i, voidRatio: 0.9 - i * 0.01 })),
  });
  expectError(outcome, "13 loading stages (max 12)", { code: "INVALID_INPUT" });
}
{
  const outcome = runCalculation(oedometerModule, { loadingStages: [{ verticalPressureKpa: 100, voidRatio: 0.9 }] });
  expectError(outcome, "1 loading stage (min 2)", { code: "INVALID_INPUT" });
}
{
  const outcome = runCalculation(oedometerModule, {});
  expectError(outcome, "empty payload", { code: "MISSING_INPUT", messageHint: "loadingStages" });
}
{
  // Reading-series validation: non-increasing time.
  const outcome = runCalculation(oedometerModule, {
    loadingStages: OEDO_LOADING,
    consolidationReading: {
      incrementFromIndex: 4,
      readings: [
        { timeMin: 1, dialMm: 0.6 }, { timeMin: 1, dialMm: 0.62 },
        { timeMin: 2, dialMm: 0.7 }, { timeMin: 4, dialMm: 0.75 },
        { timeMin: 8, dialMm: 0.8 }, { timeMin: 15, dialMm: 0.83 },
      ],
      drainagePathMm: 10,
    },
  });
  expectError(outcome, "readings with non-increasing time", {
    code: "INVALID_INPUT",
    fieldPath: "consolidationReading.readings.1.timeMin",
    messageHint: "strictly increasing",
  });
}
{
  const outcome = runCalculation(oedometerModule, {
    loadingStages: OEDO_LOADING,
    consolidationReading: { incrementFromIndex: 5, readings: CV_READINGS, drainagePathMm: 10 },
  });
  expectError(outcome, "incrementFromIndex beyond the last increment", {
    code: "INVALID_INPUT",
    fieldPath: "consolidationReading.incrementFromIndex",
    messageHint: "loading increment",
  });
}
{
  const outcome = runCalculation(oedometerModule, {
    loadingStages: OEDO_LOADING,
    consolidationReading: {
      incrementFromIndex: 4,
      readings: [
        { timeMin: 1, dialMm: 0.6 }, { timeMin: 2, dialMm: 0.62 },
        { timeMin: 4, dialMm: 0.7 }, { timeMin: 8, dialMm: 0.75 },
        { timeMin: 15, dialMm: 0.8 }, { timeMin: 30, dialMm: 0.83 },
      ],
      drainagePathMm: 10,
    },
  });
  if (outcome.status === "ok") ok("valid 6-reading series accepted (minimum)");
  else no(`valid 6-reading series rejected: ${outcome.error.message}`);
}

// ---------------------------------------------------------------------------
// 3. Direct helper tests
// ---------------------------------------------------------------------------
{
  const e = voidRatioFromHeight(19.85355648535565, 20, 0.912);
  if (approx(e, 0.8980000000000001, 1e-15)) ok("helper — voidRatioFromHeight round trip (H 19.8536 → e ≈ 0.898)");
  else no(`helper — voidRatioFromHeight = ${e}`);
  try {
    voidRatioFromHeight(0, 20, 0.9);
    no("helper — voidRatioFromHeight(0, …) no throw");
  } catch {
    ok("helper — voidRatioFromHeight(0, …) throws (domain)");
  }
}
{
  const line = fitLine([{ x: 1, y: 2 }, { x: 2, y: 4 }, { x: 3, y: 6 }]);
  if (approx(line.slope, 2, 1e-12) && approx(line.intercept, 0, 1e-12)) ok("helper — fitLine exact line (slope 2, intercept 0)");
  else no(`helper — fitLine wrong: ${JSON.stringify(line)}`);
  try {
    fitLine([{ x: 1, y: 1 }, { x: 1, y: 2 }]);
    no("helper — fitLine single distinct x no throw");
  } catch {
    ok("helper — fitLine single distinct x throws");
  }
}
{
  const k = tripleCurvature({ x: 0, y: 0 }, { x: 1, y: 0 }, { x: 2, y: 0.001 });
  if (k > 0) ok(`helper — tripleCurvature > 0 for a bent triple (${k.toExponential(3)})`);
  else no("helper — tripleCurvature should be positive");
  if (tripleCurvature({ x: 0, y: 0 }, { x: 1, y: 1 }, { x: 2, y: 2 }) === 0) ok("helper — collinear triple curvature = 0");
  else no("helper — collinear triple should be 0");
}
{
  const fit = casagrandeLogTimeFit(CV_READINGS);
  const checks: Array<[boolean, string]> = [
    [approx(fit.d0Mm, 0.5, 1e-12), "helper — log-time fit d0 ≈ 0.5"],
    [approx(fit.d100Mm, 0.91, 1e-12), "helper — log-time fit d100 ≈ 0.91"],
    [fit.t50Min !== null && approx(fit.t50Min, 1.723945642493957, 1e-12), "helper — log-time fit t50 ≈ 1.723945642493957"],
  ];
  for (const [condition, label] of checks) {
    if (condition) ok(label);
    else no(label);
  }
}

// ---------------------------------------------------------------------------
// 4. Schema stripping
// ---------------------------------------------------------------------------
{
  const parsed = oedometerCalcInput.safeParse({
    loadingStages: OEDO_LOADING, notes: "extra", unknownKey: 1,
  });
  if (parsed.success && !("notes" in parsed.data) && !("unknownKey" in parsed.data)) {
    ok("schema — unknown keys (notes) stripped");
  } else {
    no("schema — stripping failed");
  }
}

// ---------------------------------------------------------------------------
// 5. M5.1 registry compatibility — parity and documented divergences
// ---------------------------------------------------------------------------
{
  // Shared valid: the registry-shaped payload (stages + entered indicators)
  // passes both; note the registry field name is `stages` — the module
  // contract names it `loadingStages` (engine-side extension keeping the
  // unloading branch separate).
  const registryPayload = {
    stages: OEDO_LOADING.map((s) => ({ verticalPressureKpa: s.verticalPressureKpa, voidRatio: s.voidRatio })),
    compressionIndexCc: 0.155,
    swellingIndexCs: 0.022,
    preConsolidationPressureKpa: 180,
    coefficientOfConsolidationCvM2PerYear: 1.8,
  };
  const registryOutcome = parseLabTestResult("OEDOMETER", registryPayload);
  const moduleOutcome = runCalculation(oedometerModule, {
    loadingStages: registryPayload.stages, ...OEDO_ENTERED,
  });
  const checks: Array<[boolean, string]> = [
    [registryOutcome.ok, "shared valid — registry result schema accepts the seed payload"],
    [moduleOutcome.status === "ok", "shared valid — module accepts the same stages (loadingStages field)"],
  ];
  if (moduleOutcome.status === "ok") {
    // Computed results revalidate through the registry (in-bounds values).
    const computedPayload = {
      stages: moduleOutcome.results.curve
        .filter((p) => p.branch === "LOADING")
        .map((p) => ({ verticalPressureKpa: p.verticalPressureKpa, voidRatio: p.voidRatio })),
      compressionIndexCc: moduleOutcome.results.compressionIndexCc,
      swellingIndexCs: moduleOutcome.results.swellingIndexCs ?? undefined,
      preConsolidationPressureKpa: moduleOutcome.results.preConsolidationPressureKpa ?? undefined,
    };
    const revalidated = parseLabTestResult("OEDOMETER", computedPayload);
    checks.push([revalidated.ok, `computed curve + Cc/σ′p revalidate through the registry${revalidated.ok ? "" : `: ${revalidated.error}`}`]);
  }
  for (const [condition, label] of checks) {
    if (condition) ok(`parity — ${label}`);
    else no(`parity — ${label}`);
  }
}
{
  // Shared invalid (both reject): non-increasing loading pressures.
  const badStages = [
    { verticalPressureKpa: 100, voidRatio: 0.9 },
    { verticalPressureKpa: 100, voidRatio: 0.86 },
    { verticalPressureKpa: 200, voidRatio: 0.84 },
  ];
  const m = runCalculation(oedometerModule, { loadingStages: badStages });
  const r = parseLabTestResult("OEDOMETER", { stages: badStages });
  if (m.status === "error" && !r.ok) ok("shared invalid — non-increasing pressures: both reject");
  else no(`shared invalid — pressures: module ${m.status}, registry ok=${r.ok}`);
}
{
  // Shared invalid (both reject): void ratio out of the registry bound.
  const badStages = [
    { verticalPressureKpa: 100, voidRatio: 0.1 },
    { verticalPressureKpa: 200, voidRatio: 0.09 },
  ];
  const m = runCalculation(oedometerModule, { loadingStages: badStages });
  const r = parseLabTestResult("OEDOMETER", { stages: badStages });
  if (m.status === "error" && !r.ok) ok("shared invalid — void ratio 0.1 below bound: both reject");
  else no(`shared invalid — void ratio: module ${m.status}, registry ok=${r.ok}`);
}
{
  // Documented divergence 1 — unloading stages: the registry schema has no
  // unloading representation (loading-only, strictly increasing); the module
  // accepts a separate unloading branch.
  const payload = { stages: [...OEDO_LOADING, ...OEDO_UNLOADING] };
  const r = parseLabTestResult("OEDOMETER", payload);
  const m = runCalculation(oedometerModule, { loadingStages: OEDO_LOADING, unloadingStages: OEDO_UNLOADING });
  if (m.status === "ok" && !r.ok) ok("divergence — unloading branch: module computes Cs; the registry schema cannot store it (loading-only)");
  else no(`divergence — unloading: module ${m.status}, registry ok=${r.ok}`);
}
{
  // Documented divergence 2 — height-based stages and the Cv reading series
  // are engine-side extensions with no registry storage.
  const m = runCalculation(oedometerModule, {
    loadingStages: OEDO_HEIGHTS, referenceHeightMm: 20, referenceVoidRatio: 0.912,
    consolidationReading: { incrementFromIndex: 4, readings: CV_READINGS, drainagePathMm: 10 },
  });
  if (m.status === "ok" && m.results.cvMm2PerMin === 11.4273) {
    ok("divergence — height stages + Cv reading series: engine-side extensions (no registry storage)");
  } else {
    no(`divergence — extensions failed: ${m.status === "error" ? m.error.message : "no cv"}`);
  }
}
{
  // Documented divergence 3 — computed Cc 0.1545 vs entered 0.155 and σ′p
  // 129.4 vs entered 180: echoed WITHOUT warnings (no registry tolerance
  // identity exists for oedometer indicators — none invented).
  const m = runCalculation(oedometerModule, { loadingStages: OEDO_LOADING, ...OEDO_ENTERED });
  if (m.status === "ok" && m.warnings.length === 1 && m.warnings[0].code === "INSUFFICIENT_DATA") {
    ok("divergence — entered-vs-computed discrepancies (Cc, σ′p) produce NO comparison warnings (no tolerance exists; values echoed)");
  } else {
    no(`divergence — unexpected warnings: ${JSON.stringify(m.status === "ok" ? m.warnings : m.error)}`);
  }
}

// ---------------------------------------------------------------------------
// 6. Determinism, purity, envelope
// ---------------------------------------------------------------------------
{
  const payload = { loadingStages: OEDO_LOADING, ...OEDO_ENTERED };
  const first = runCalculation(oedometerModule, payload);
  let allEqual = true;
  for (let i = 0; i < 25; i++) {
    if (JSON.stringify(runCalculation(oedometerModule, payload)) !== JSON.stringify(first)) allEqual = false;
  }
  if (allEqual) ok("determinism — 25 runs deeply identical (warning path)");
  else no("determinism — warning path outputs differ");
}
{
  const payload = {
    loadingStages: OEDO_LOADING,
    unloadingStages: OEDO_UNLOADING,
    consolidationReading: { incrementFromIndex: 4, readings: CV_READINGS, drainagePathMm: 10 },
  };
  const first = runCalculation(oedometerModule, payload);
  let allEqual = true;
  for (let i = 0; i < 25; i++) {
    if (JSON.stringify(runCalculation(oedometerModule, payload)) !== JSON.stringify(first)) allEqual = false;
  }
  if (allEqual) ok("determinism — 25 runs deeply identical (Cv path)");
  else no("determinism — Cv path outputs differ");
}
{
  const payload = {
    loadingStages: [
      { verticalPressureKpa: 25, voidRatio: 0.912 },
      { verticalPressureKpa: 50, voidRatio: 0.898 },
      { verticalPressureKpa: 100, voidRatio: 0.876 },
      { verticalPressureKpa: 200, voidRatio: 0.841 },
    ],
  };
  const snapshot = JSON.stringify(payload);
  runCalculation(oedometerModule, payload);
  if (JSON.stringify(payload) === snapshot) ok("purity — input payload never mutated");
  else no("purity — input payload mutated");
}
{
  const outcome = runCalculation(oedometerModule, { loadingStages: OEDO_LOADING });
  if (outcome.status !== "ok") no(`envelope — failed: ${outcome.error.message}`);
  else {
    const checks: Array<[boolean, string]> = [
      [outcome.engineVersion === "1.0.0", "engineVersion = 1.0.0"],
      [outcome.moduleId === "oedometer", "moduleId = oedometer"],
      [outcome.moduleVersion === "1.0.0", "moduleVersion = 1.0.0"],
      [outcome.testType === "OEDOMETER", "testType = OEDOMETER"],
    ];
    for (const [condition, label] of checks) {
      if (condition) ok(`envelope — ${label}`);
      else no(`envelope — ${label}`);
    }
  }
}

console.log(`\n================ M5.2-f OEDOMETER TEST SUMMARY: ${pass} passed, ${fail} failed ================`);
process.exit(fail);
