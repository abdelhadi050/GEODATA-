/**
 * M5.4 — apply additive schema migrations directly to the SQLite database.
 *
 * Adds the new Report columns (with defaults for existing rows) and creates
 * the ClassificationRecord table. Equivalent to running prisma migrate but
 * without the strict-mode block on adding NOT NULL columns to populated
 * tables.
 */
import { Database } from "bun:sqlite";
import path from "node:path";

const dbPath = path.resolve(process.cwd(), "db/custom.db");
console.log("Opening database at:", dbPath);
const db = new Database(dbPath, { readwrite: true, create: false });

function exec(sql: string) {
  try {
    db.run(sql);
    console.log("✓", sql.slice(0, 80).replace(/\s+/g, " "));
  } catch (e) {
    // ALTER TABLE ADD COLUMN fails if the column already exists; CREATE TABLE
    // fails if the table exists; CREATE INDEX fails if the index exists. We
    // treat these as no-ops so the script is idempotent.
    const msg = (e as Error).message;
    if (msg.includes("duplicate column name") || msg.includes("already exists")) {
      console.log("· (exists)", sql.slice(0, 80).replace(/\s+/g, " "));
    } else {
      console.error("✗", sql.slice(0, 80).replace(/\s+/g, " "), "→", msg);
      throw e;
    }
  }
}

// --- Additive columns on Report ---
exec("ALTER TABLE Report ADD COLUMN status TEXT NOT NULL DEFAULT 'DRAFT'");
exec("ALTER TABLE Report ADD COLUMN version INTEGER NOT NULL DEFAULT 1");
exec("ALTER TABLE Report ADD COLUMN sampleId TEXT");
exec("ALTER TABLE Report ADD COLUMN boreholeId TEXT");
exec("ALTER TABLE Report ADD COLUMN contentSnapshot TEXT");
exec("ALTER TABLE Report ADD COLUMN pdfStoragePath TEXT");
exec("ALTER TABLE Report ADD COLUMN pdfGeneratedAt TEXT");
exec("ALTER TABLE Report ADD COLUMN pdfFileSize INTEGER");
exec("ALTER TABLE Report ADD COLUMN pdfPageCount INTEGER");
// SQLite ALTER TABLE ADD COLUMN doesn't accept non-constant defaults
// (datetime('now') is non-constant). Use a constant sentinel default, then
// UPDATE the existing rows to the current time so Prisma's @updatedAt
// invariant holds for existing data.
exec("ALTER TABLE Report ADD COLUMN updatedAt TEXT NOT NULL DEFAULT '2026-01-01 00:00:00'");
exec("UPDATE Report SET updatedAt = datetime('now') WHERE updatedAt = '2026-01-01 00:00:00'");

// --- New ClassificationRecord table ---
exec(`
CREATE TABLE ClassificationRecord (
  id TEXT PRIMARY KEY NOT NULL,
  organizationId TEXT NOT NULL,
  projectId TEXT NOT NULL,
  sampleId TEXT NOT NULL,
  moduleId TEXT NOT NULL,
  moduleVersion TEXT NOT NULL,
  engineVersion TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'PENDING',
  inputSource TEXT NOT NULL,
  inputSnapshot TEXT NOT NULL,
  inputFingerprint TEXT NOT NULL,
  output TEXT,
  warnings TEXT,
  errorCode TEXT,
  errorMessage TEXT,
  errorDetails TEXT,
  standard TEXT,
  standardVersion TEXT,
  idempotencyKey TEXT,
  isValid BOOLEAN NOT NULL DEFAULT 1,
  invalidatedAt TEXT,
  invalidatedReason TEXT,
  createdById TEXT NOT NULL,
  createdAt TEXT NOT NULL DEFAULT (datetime('now')),
  updatedAt TEXT NOT NULL DEFAULT (datetime('now'))
)
`);

// --- Indexes ---
exec("CREATE UNIQUE INDEX ClassificationRecord_sampleId_idempotencyKey_key ON ClassificationRecord(sampleId, idempotencyKey)");
exec("CREATE INDEX ClassificationRecord_sampleId_isValid_createdAt_idx ON ClassificationRecord(sampleId, isValid, createdAt)");
exec("CREATE INDEX ClassificationRecord_sampleId_createdAt_idx ON ClassificationRecord(sampleId, createdAt)");
exec("CREATE INDEX ClassificationRecord_organizationId_projectId_createdAt_idx ON ClassificationRecord(organizationId, projectId, createdAt)");
exec("CREATE INDEX ClassificationRecord_projectId_createdAt_idx ON ClassificationRecord(projectId, createdAt)");
exec("CREATE INDEX ClassificationRecord_moduleId_createdAt_idx ON ClassificationRecord(moduleId, createdAt)");
exec("CREATE INDEX Report_sampleId_idx ON Report(sampleId)");
exec("CREATE INDEX Report_boreholeId_idx ON Report(boreholeId)");

// --- Verify ---
const reportCount = db.query("SELECT COUNT(*) as n FROM Report").get() as { n: number };
const classCount = db.query("SELECT COUNT(*) as n FROM ClassificationRecord").get() as { n: number };
console.log(`\nReport rows: ${reportCount.n}`);
console.log(`ClassificationRecord rows: ${classCount.n}`);

const reportCols = db.query("PRAGMA table_info(Report)").all() as Array<{ name: string }>;
console.log("\nReport columns:", reportCols.map((c) => c.name).join(", "));

db.close();
