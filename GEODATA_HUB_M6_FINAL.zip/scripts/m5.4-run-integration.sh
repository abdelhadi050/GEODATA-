#!/usr/bin/env bash
# M5.4 integration test — runs the dev server and the test suite in the
# same bash invocation (the sandbox kills background servers between
# invocations). Mirrors scripts/m5-run-all.sh.
set -u
cd /home/z/my-project

stop_dev(){ pkill -f "next dev" 2>/dev/null || true; sleep 1; }
trap stop_dev EXIT

stop_dev
echo "→ Starting dev server..."
nohup bun run dev < /dev/null > /tmp/m54-dev.out 2>&1 &
DEV_PID=$!

# Wait for the server to come up
for i in $(seq 1 30); do
  if curl -sf http://localhost:3000/api/health > /dev/null 2>&1; then
    echo "✓ Dev server ready (pid $DEV_PID)"
    break
  fi
  sleep 1
done

if ! curl -sf http://localhost:3000/api/health > /dev/null 2>&1; then
  echo "✗ Dev server failed to start. Log:"
  tail -30 /tmp/m54-dev.out
  exit 1
fi

echo "→ Running M5.4 integration tests..."
bun test ./scripts/m5.4-test-integration.ts
TEST_RC=$?

echo "→ Stopping dev server..."
stop_dev
exit $TEST_RC
