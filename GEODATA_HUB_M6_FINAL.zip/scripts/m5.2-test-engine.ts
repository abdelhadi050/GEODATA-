/**
 * M5.2-a TEST — Calculation engine pipeline and error handling.
 *
 * Covers: outcome envelope shape, every error-code mapping (CalculationError
 * subclasses, plain Error, non-Error throws), the finiteness guard (NaN /
 * ±Infinity in input / raw / results, nesting depth limit), warning
 * pass-through and normalization, determinism (25 repeated runs), input
 * immutability, and the exported type guards.
 * Exit code = number of failures.
 */
import {
  CALCULATION_ENGINE_VERSION,
  isCalculationFailure,
  isCalculationSuccess,
  runCalculation,
} from "../src/lib/calc/engine";
import type { CalculationModule, CalculationOutcome, CalculationWarning } from "../src/lib/calc/types";
import {
  CalculationError,
  InvalidInputError,
  MissingInputError,
} from "../src/lib/calc/errors";
import { waterContentModule } from "../src/lib/calc/modules/water-content";

let pass = 0;
let fail = 0;
const ok = (m: string) => { console.log(`PASS: ${m}`); pass++; };
const no = (m: string) => { console.log(`FAIL: ${m}`); fail++; };

// ---------------------------------------------------------------------------
// Mock modules (test-local, minimal)
// ---------------------------------------------------------------------------
interface MockInput { x: number }
interface MockRaw { doubled: number }
interface MockResults { doubled: number }

/** A minimal well-behaved module: doubles a validated number. */
const mockDoubleModule: CalculationModule<MockInput, MockRaw, MockResults> = {
  id: "mock.double",
  testType: "MOCK",
  version: "0.1.0",
  label: "Mock doubler",
  description: "Test-local module.",
  validateInput(raw: unknown): MockInput {
    if (raw === null || typeof raw !== "object" || !("x" in raw)) {
      throw new MissingInputError("Missing required input field(s): x", [
        { path: "x", code: "invalid_type", message: "expected number, received undefined" },
      ]);
    }
    const x = (raw as Record<string, unknown>).x;
    if (typeof x !== "number" || !Number.isFinite(x)) {
      throw new InvalidInputError("x", `x must be a finite number (received ${String(x)})`);
    }
    return { x };
  },
  compute(input: MockInput) {
    return { raw: { doubled: input.x * 2 }, results: { doubled: input.x * 2 }, warnings: [] };
  },
};

function expectFailure(
  outcome: CalculationOutcome<unknown, unknown, unknown>,
  label: string,
  code: string,
  messageHint?: string,
): void {
  if (outcome.status !== "error") {
    no(`${label} — expected failure, got success`);
    return;
  }
  if (outcome.error.code !== code) {
    no(`${label} — expected ${code}, got ${outcome.error.code}`);
    return;
  }
  if (messageHint !== undefined && !outcome.error.message.includes(messageHint)) {
    no(`${label} — message '${outcome.error.message}' lacks hint '${messageHint}'`);
    return;
  }
  ok(`${label} — ${code} failure envelope`);
}

// ---------------------------------------------------------------------------
// 1. Happy path: envelope shape and provenance
// ---------------------------------------------------------------------------
{
  const outcome = runCalculation(mockDoubleModule, { x: 21 });
  if (isCalculationSuccess(outcome)) {
    const checks = [
      outcome.status === "ok",
      outcome.engineVersion === CALCULATION_ENGINE_VERSION,
      outcome.moduleId === "mock.double",
      outcome.moduleVersion === "0.1.0",
      outcome.testType === "MOCK",
      outcome.input.x === 21,
      outcome.raw.doubled === 42,
      outcome.results.doubled === 42,
      Array.isArray(outcome.warnings) && outcome.warnings.length === 0,
    ];
    if (checks.every(Boolean)) ok("happy path — full success envelope (provenance, input echo, raw, results, warnings)");
    else no(`happy path — envelope wrong: ${JSON.stringify(outcome)}`);
  } else {
    no(`happy path — unexpected failure: ${outcome.error.message}`);
  }
  if (isCalculationFailure(outcome)) no("type guards — isCalculationFailure true on success");
  else ok("type guards — isCalculationFailure false on success");
}

// ---------------------------------------------------------------------------
// 2. Error-code mapping
// ---------------------------------------------------------------------------
expectFailure(runCalculation(mockDoubleModule, {}), "validateInput throws MissingInputError", "MISSING_INPUT", "x");
{
  const outcome = runCalculation(mockDoubleModule, { x: "abc" });
  expectFailure(outcome, "validateInput throws InvalidInputError", "INVALID_INPUT", "finite number");
  const details = outcome.status === "error" ? outcome.error.details : undefined;
  if (details && details.fieldPath === "x") ok("InvalidInputError — details.fieldPath = x");
  else no("InvalidInputError — details.fieldPath missing");
}
{
  const throwing: CalculationModule<MockInput, MockRaw, MockResults> = {
    ...mockDoubleModule,
    id: "mock.throws-in-compute",
    compute(): never {
      throw new InvalidInputError("x", "physically impossible value");
    },
  };
  expectFailure(runCalculation(throwing, { x: 1 }), "compute throws InvalidInputError", "INVALID_INPUT", "physically impossible");
}
{
  const throwing: CalculationModule<MockInput, MockRaw, MockResults> = {
    ...mockDoubleModule,
    id: "mock.plain-error",
    compute(): never {
      throw new Error("boom");
    },
  };
  const outcome = runCalculation(throwing, { x: 1 });
  expectFailure(outcome, "compute throws plain Error → INTERNAL_ERROR", "INTERNAL_ERROR", "boom");
  const details = outcome.status === "error" ? outcome.error.details : undefined;
  if (details && details.originalErrorName === "Error") ok("INTERNAL_ERROR — details.originalErrorName = Error");
  else no("INTERNAL_ERROR — details.originalErrorName missing");
}
{
  const throwing: CalculationModule<MockInput, MockRaw, MockResults> = {
    ...mockDoubleModule,
    id: "mock.non-error-throw",
    compute(): never {
      throw "oops (a string)";
    },
  };
  const outcome = runCalculation(throwing, { x: 1 });
  expectFailure(outcome, "compute throws non-Error value → INTERNAL_ERROR", "INTERNAL_ERROR", "oops");
}
{
  const customCode: CalculationModule<MockInput, MockRaw, MockResults> = {
    ...mockDoubleModule,
    id: "mock.custom-code",
    validateInput(): never {
      // A module may raise any CalculationError itself; the engine must map
      // its code/message/details faithfully instead of rewrapping them.
      throw new CalculationError("INTERNAL_ERROR", "simulated module-level internal error");
    },
  };
  const outcome = runCalculation(customCode, { x: 1 });
  expectFailure(outcome, "module-raised CalculationError mapped faithfully", "INTERNAL_ERROR", "simulated module-level");
}

// ---------------------------------------------------------------------------
// 3. Finiteness guard
// ---------------------------------------------------------------------------
{
  const nanModule: CalculationModule<MockInput, MockRaw, MockResults> = {
    ...mockDoubleModule,
    id: "mock.nan-results",
    compute() {
      return { raw: { doubled: 42 }, results: { doubled: Number.NaN }, warnings: [] };
    },
  };
  const outcome = runCalculation(nanModule, { x: 21 });
  expectFailure(outcome, "finiteness guard — NaN in results", "ARITHMETIC_DOMAIN_ERROR", "results.doubled");
}
{
  const infModule: CalculationModule<MockInput, MockRaw, MockResults> = {
    ...mockDoubleModule,
    id: "mock.inf-raw",
    compute() {
      return { raw: { doubled: Number.POSITIVE_INFINITY }, results: { doubled: 42 }, warnings: [] };
    },
  };
  expectFailure(runCalculation(infModule, { x: 21 }), "finiteness guard — +Infinity in raw", "ARITHMETIC_DOMAIN_ERROR", "raw.doubled");
}
{
  const nanInputModule: CalculationModule<{ x: number }, MockRaw, MockResults> = {
    ...mockDoubleModule,
    validateInput(): { x: number } {
      return { x: Number.NaN }; // module bug: non-finite input passes validation
    },
  };
  const outcome = runCalculation(nanInputModule, { x: 1 });
  expectFailure(outcome, "finiteness guard — NaN in echoed input", "ARITHMETIC_DOMAIN_ERROR", "input.x");
}
{
  // Non-finite nested inside arrays must be found with a path-addressed report.
  const nestedModule: CalculationModule<MockInput, { points: number[] }, MockResults> = {
    ...mockDoubleModule,
    id: "mock.nested-nan",
    compute() {
      return { raw: { points: [1, 2, Number.NaN] }, results: { doubled: 42 }, warnings: [] };
    },
  };
  const outcome = runCalculation(nestedModule, { x: 1 });
  expectFailure(outcome, "finiteness guard — NaN nested in raw array", "ARITHMETIC_DOMAIN_ERROR", "raw.points[2]");
}
{
  // Nesting beyond MAX_SCAN_DEPTH → deterministic INTERNAL_ERROR, no infinite recursion.
  let deep: Record<string, unknown> = { leaf: 1 };
  for (let i = 0; i < 60; i++) deep = { deeper: deep };
  const deepModule: CalculationModule<MockInput, unknown, MockResults> = {
    ...mockDoubleModule,
    id: "mock.too-deep",
    compute() {
      return { raw: deep, results: { doubled: 42 }, warnings: [] };
    },
  };
  const outcome = runCalculation(deepModule, { x: 1 });
  expectFailure(outcome, "finiteness guard — payload deeper than 32 levels", "INTERNAL_ERROR", "nesting exceeds");
}

// ---------------------------------------------------------------------------
// 4. Warnings pass-through and normalization
// ---------------------------------------------------------------------------
{
  const warning: CalculationWarning = {
    code: "ENTERED_VALUE_DISCREPANCY",
    message: "test warning",
    details: { tolerancePercent: 0.5 },
  };
  const warningModule: CalculationModule<MockInput, MockRaw, MockResults> = {
    ...mockDoubleModule,
    id: "mock.warning",
    compute(input: MockInput) {
      return { raw: { doubled: input.x * 2 }, results: { doubled: input.x * 2 }, warnings: [warning] };
    },
  };
  const outcome = runCalculation(warningModule, { x: 3 });
  if (isCalculationSuccess(outcome)) {
    if (outcome.warnings.length === 1 && JSON.stringify(outcome.warnings[0]) === JSON.stringify(warning)) {
      ok("warnings — passed through unchanged with success status");
    } else no("warnings — pass-through altered the warning");
  } else no("warnings — warning module failed unexpectedly");
}
{
  // A module (buggy or JS-side) that omits warnings gets an empty array, not undefined.
  const noWarningsModule = {
    ...mockDoubleModule,
    id: "mock.no-warnings",
    compute(input: MockInput) {
      return { raw: { doubled: input.x * 2 }, results: { doubled: input.x * 2 } };
    },
  } as unknown as CalculationModule<MockInput, MockRaw, MockResults>;
  const outcome = runCalculation(noWarningsModule, { x: 3 });
  if (isCalculationSuccess(outcome) && Array.isArray(outcome.warnings) && outcome.warnings.length === 0) {
    ok("warnings — missing warnings array normalized to []");
  } else no("warnings — normalization to [] failed");
}
{
  // compute returning a non-object is a module bug → INTERNAL_ERROR.
  const nullComputeModule = {
    ...mockDoubleModule,
    id: "mock.null-compute",
    compute(): null {
      return null;
    },
  } as unknown as CalculationModule<MockInput, MockRaw, MockResults>;
  expectFailure(runCalculation(nullComputeModule, { x: 1 }), "compute returns null → INTERNAL_ERROR", "INTERNAL_ERROR");
}

// ---------------------------------------------------------------------------
// 5. Determinism — 25 repeated runs (mock + real water-content module)
// ---------------------------------------------------------------------------
{
  const signatures: string[] = [];
  for (let i = 0; i < 25; i++) signatures.push(JSON.stringify(runCalculation(mockDoubleModule, { x: 18.4397163120567 })));
  if (new Set(signatures).size === 1) ok("determinism — 25 identical mock runs (deep-equal JSON)");
  else no("determinism — mock runs diverged");
}
{
  const payload = { waterContentPercent: 18.5, wetMassG: 112.0, dryMassG: 101.6, containerMassG: 45.2 };
  const signatures: string[] = [];
  for (let i = 0; i < 25; i++) signatures.push(JSON.stringify(runCalculation(waterContentModule, payload)));
  if (new Set(signatures).size === 1) ok("determinism — 25 identical water-content runs");
  else no("determinism — water-content runs diverged");
}

// ---------------------------------------------------------------------------
// 6. Input immutability — the engine never mutates the raw payload
// ---------------------------------------------------------------------------
{
  const payload = { waterContentPercent: 18.5, wetMassG: 112.0, dryMassG: 101.6, containerMassG: 45.2 };
  const before = JSON.stringify(payload);
  runCalculation(waterContentModule, payload);
  runCalculation(waterContentModule, payload);
  if (JSON.stringify(payload) === before) ok("input purity — raw payload unchanged after runs");
  else no("input purity — payload was mutated");
}

// ---------------------------------------------------------------------------
// 7. Failure envelopes carry the same provenance as successes
// ---------------------------------------------------------------------------
{
  const outcome = runCalculation(waterContentModule, {});
  if (outcome.status === "error") {
    const provenanceOk =
      outcome.moduleId === "water-content" &&
      outcome.moduleVersion === "1.0.0" &&
      outcome.testType === "WATER_CONTENT" &&
      outcome.engineVersion === CALCULATION_ENGINE_VERSION;
    if (provenanceOk) ok("failure envelope — module/engine provenance present");
    else no("failure envelope — provenance wrong");
  } else {
    no("failure envelope — expected failure");
  }
  if (isCalculationFailure(outcome) && !isCalculationSuccess(outcome)) {
    ok("type guards — isCalculationFailure true / isCalculationSuccess false on failure");
  } else {
    no("type guards — failed on failure outcome");
  }
}

console.log(`\n================ M5.2-a ENGINE TEST SUMMARY: ${pass} passed, ${fail} failed ================`);
process.exit(fail);
