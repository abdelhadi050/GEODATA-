#!/usr/bin/env python3
"""M5.2-g golden-value independent verification (Ménard pressuremeter:
pf / EM / PL / emPlRatio).

Run BEFORE writing the test expectations. Every expected value below is
computed independently of the TypeScript engine:

- high-precision Decimal (60 digits) for the construction truth,
- IEEE-754 double probes mirroring the exact JS operation order designed for
  the module (injected volumes, two-half least-squares creep lines and their
  intersection, interpolated v(p1)/v(p2), EM = 2(1+nu)(Vc+vm)dp/dv with
  nu = 0.33 from the governed registry, vL = Vc + 2 v1, interpolated p(vL)),
- half-away-from-zero rounding predictions with tie-distance guards.

Designed module arithmetic (M5.2-g, NF P94-110-1/2 / ASTM D4719 / EN ISO
22476-4 — verified definitions):

  Injected volume : v(p) = volumeCm3 - referenceVolumeCm3 (or the reading)
  Creep pressure : intersection of the LSQ line over the FIRST HALF and the
                   line over the SECOND HALF of the (p, V60-V30) creep points
  Ménard modulus : EM = 2(1+nu) * (Vc + (v1+v2)/2) * (p2-p1)/(v2-v1)  [kPa]
                   nu = 0.33 (governed VERIFIED constant -> factor 2.66)
  Limit pressure : vL = Vc + 2*v1; PL = p interpolated at vL on the curve
  Ratio          : emPlRatio = EM / PL  (kPa/kPa; registry identity
                   EM[MPa]*1000/PL[kPa])
"""
from decimal import Decimal as D, getcontext
import math

getcontext().prec = 60

NU = 0.33


def round_to_double(x, dp):
    scaled = x * 10 ** dp
    if abs(scaled) > 2 ** 53:
        raise ValueError("out of safe range")
    corrected_abs = abs(scaled) * (1 + 2.220446049250313e-16)
    rounded = math.floor(corrected_abs + 0.5)
    signed = -rounded if scaled < 0 else rounded
    result = signed / 10 ** dp
    return 0.0 if result == 0 else result


def tie_guard(x, dp, label):
    scaled = abs(x) * 10 ** dp
    dist = abs(scaled - math.floor(scaled) - 0.5)
    if dist < 1e-9:
        print(f"  !! TIE WARNING {label}: {x} at {dp} dp (scaled {scaled})")


def show(label, value, dp):
    tie_guard(value, dp, label)
    print(f"  {label:<56} = {value!r:<24} -> {dp} dp: {round_to_double(value, dp)}")
    return round_to_double(value, dp)


def js_fit_line(pts):
    """Mirror of the module's two-pass LSQ line (creep construction)."""
    n = len(pts)
    sx = sum(x for x, _ in pts)
    sy = sum(y for _, y in pts)
    xm, ym = sx / n, sy / n
    sxy = sum((x - xm) * (y - ym) for x, y in pts)
    sxx = sum((x - xm) ** 2 for x, _ in pts)
    slope = sxy / sxx
    return slope, ym - slope * xm


def js_creep_pressure(creep):
    """Mirror of creepPressureFromCreepCurve (first/second half lines)."""
    n = len(creep)
    half = n // 2
    first = creep[:max(2, half)]
    second = creep[max(2, half):]
    s1, i1 = js_fit_line(first)
    s2, i2 = js_fit_line(second)
    denom = s1 - s2
    if denom == 0:
        return None, s1, s2
    x = (i2 - i1) / denom
    if not (creep[0][0] <= x <= creep[-1][0]):
        return None, s1, s2
    return x, s1, s2


def js_v_at(curve, target_p):
    """Mirror of injectedVolumeAtPressure (exact hit / linear interpolation)."""
    for i, (p, v) in enumerate(curve):
        if p == target_p:
            return v
        if p > target_p:
            if i == 0:
                raise ValueError("below range")
            p0, v0 = curve[i - 1]
            return v0 + (v - v0) * ((target_p - p0) / (p - p0))
    raise ValueError("above range")


def js_p_at_volume(curve, target_v):
    """Mirror of pressureAtInjectedVolume (linear interpolation in v)."""
    if target_v < curve[0][1]:
        return None
    for i in range(1, len(curve)):
        v1, v2 = curve[i - 1][1], curve[i][1]
        if target_v <= v2:
            if v2 == v1:
                return curve[i - 1][0]
            frac = (target_v - v1) / (v2 - v1)
            return curve[i - 1][0] + (curve[i][0] - curve[i - 1][0]) * frac
    return None


# ---------------------------------------------------------------------------
# M1 — the full computable fixture
# ---------------------------------------------------------------------------
print("=" * 100)
print("FIXTURE M1 - full Ménard analysis (Vc = 535, reference = 40 cm3)")
print("=" * 100)
pressures = [0, 100, 200, 300, 400, 500, 600, 700, 800, 900, 1000, 1100, 1200, 1300, 1400]
injected = [0, 20, 45, 70, 95, 122, 150, 180, 215, 260, 330, 430, 570, 750, 960]
readings = [v + 40 for v in injected]
# creep pairs on steps 200..900 kPa: creep = [2, 2, 2, 2.5, 3, 4, 6, 9]
creep_steps = [200, 300, 400, 500, 600, 700, 800, 900]
creep_values = [2, 2, 2, 2.5, 3, 4, 6, 9]
v30 = {}
for p, c in zip(creep_steps, creep_values):
    idx = pressures.index(p)
    v30[p] = readings[idx] - c
print(f"  points (p, reading): {list(zip(pressures, readings))}")
print(f"  V30 readings: {v30}")
print(f"  creep curve: {list(zip(creep_steps, creep_values))}")

curve = list(zip(pressures, injected))
creep = list(zip(creep_steps, creep_values))
pf, s1, s2 = js_creep_pressure(creep)
print(f"  first-half slope = {s1!r}, second-half slope = {s2!r}")
show("pf (creep intersection) [kPa]", pf, 1)

# EM over the designated section p1 = 600 (= pf), p2 = 800
P1, P2 = 600.0, 800.0
v1 = js_v_at(curve, P1)
v2 = js_v_at(curve, P2)
show("v1 at p1=600 [cm3]", v1, 2)
show("v2 at p2=800 [cm3]", v2, 2)
VC = 535.0
factor = 2 * (1 + NU)
vm = (v1 + v2) / 2
total = VC + vm
em_kpa = (factor * total * (P2 - P1)) / (v2 - v1)
print(f"  factor = 2(1+0.33) = {factor!r}, vm = {vm!r}, Vc+vm = {total!r}")
show("EM [kPa]", em_kpa, 2)
show("EM [MPa]", em_kpa / 1000, 2)

# PL at vL = Vc + 2 v1
vL = VC + 2 * v1
show("vL = Vc + 2*v1 [cm3]", vL, 2)
pl = js_p_at_volume(curve, vL)
show("PL [kPa]", pl, 1)
ratio = em_kpa / pl
show("emPlRatio = EM/PL", ratio, 2)
print(f"  Decimal check: EM = {D(2) * (D(1) + D('0.33')) * (D('535') + D('182.5')) * D(200) / D(65)} kPa")
print(f"  PL exact fraction: 1300 + 100*(835-750)/(960-750) = {1300 + 100 * 85 / 210}")
print()

# ---------------------------------------------------------------------------
# M5 — PL beyond the measured range (curve truncated at 1200 kPa)
# ---------------------------------------------------------------------------
print("=" * 100)
print("FIXTURE M5 - limit state not reached (curve truncated)")
print("=" * 100)
curve5 = curve[:13]  # up to 1200 kPa, max injected 570
pl5 = js_p_at_volume(curve5, vL)
print(f"  max injected = {curve5[-1][1]} cm3 < vL = {vL} cm3 -> PL = {pl5} (null + INSUFFICIENT_DATA)")
print()

# ---------------------------------------------------------------------------
# M2/M3 — seed payloads (registry shape, no Vc / no creep pairs / no emRange)
# ---------------------------------------------------------------------------
print("=" * 100)
print("FIXTURE M2/M3 - PMT seeds (echo-only; entered identities verified)")
print("=" * 100)
m2_em, m2_pl = 12.4, 950
ratio_entered = 13.05
expected_ratio = m2_em * 1000 / m2_pl
print(f"  M2 entered identity: EM*1000/PL = {expected_ratio!r} vs entered {ratio_entered}: |d| = {abs(expected_ratio - ratio_entered)} <= 0.5 ? {abs(expected_ratio - ratio_entered) <= 0.5}")
m3_em, m3_pl = 24.8, 1750
ratio3_entered = 14.17
expected3 = m3_em * 1000 / m3_pl
print(f"  M3 entered identity: EM*1000/PL = {expected3!r} vs entered {ratio3_entered}: |d| = {abs(expected3 - ratio3_entered)} <= 0.5 ? {abs(expected3 - ratio3_entered) <= 0.5}")
print()

print("=" * 100)
print("VALIDATION-CASE NUMBERS")
print("=" * 100)
print("  unordered / duplicate pressures -> INVALID_INPUT (registry mirror)")
print("  decreasing volumes -> INVALID_INPUT (registry mirror, -0.01 slack)")
print("  V30 > V60 per point -> INVALID_INPUT (module rule)")
print("  referenceVolumeCm3 > a reading -> INVALID_INPUT (negative injected)")
print("  emRange p2 <= p1 -> INVALID_INPUT")
print("  emRange outside the measured range -> INVALID_INPUT")
print("  designated section with v2 <= v1 -> INVALID_INPUT")
print("  entered pf >= PL -> INVALID_INPUT (registry mirror)")
print("  entered emPlRatio identity violation > 0.5 -> INVALID_INPUT (registry mirror)")
print("  4 points -> INVALID_INPUT (min 5); 31 points -> INVALID_INPUT (max 30)")
print("  pressure 5001 / volume 2001 -> INVALID_INPUT (bounds)")
print()
print("ALL GOLDENS VERIFIED - values above are the independent expectations for")
print("scripts/m5.2-test-pressuremeter.ts")
