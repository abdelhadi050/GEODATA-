/**
 * M6 END-TO-END VALIDATION — full workflow + role coverage.
 *
 * Verifies the complete pipeline:
 *   Organization → Project → Borehole → Soil Layers → Samples →
 *   Laboratory Tests → Calculations → Classification → Reports → PDF Export.
 *
 * Role matrix tested:
 *   - ENGINEER  (can manage everything in own org; cannot manage sharing,
 *                  cannot manage team roles)
 *   - VIEWER    (read-only across the board; cannot mutate anything)
 *   - Cross-org isolation (a viewer from org B cannot read org A's data
 *                            unless an approved share exists)
 *
 * Each test runs against the live dev server. Mirrors the M5.4 integration
 * test pattern (login via NextAuth credentials → cookie-authenticated API
 * calls).
 */
import { describe, it, expect, beforeAll } from "bun:test";

const API = "http://localhost:3000/api";
const PASSWORD = "Demo1234!";

function cookieFrom(setCookies: string[], name: string): string | null {
  for (const c of setCookies) {
    const [pair] = c.split(";");
    const eq = pair.indexOf("=");
    if (pair.slice(0, eq) === name) return pair.slice(eq + 1);
  }
  return null;
}

async function login(email: string): Promise<string> {
  const r1 = await fetch(`${API}/auth/csrf`, { signal: AbortSignal.timeout(30_000) });
  const { csrfToken } = (await r1.json()) as { csrfToken: string };
  const csrfCookie = cookieFrom(r1.headers.getSetCookie(), "next-auth.csrf-token");
  if (!csrfCookie) throw new Error("No csrf cookie");
  const r2 = await fetch(`${API}/auth/callback/credentials`, {
    method: "POST",
    signal: AbortSignal.timeout(30_000),
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
      Cookie: `next-auth.csrf-token=${csrfCookie}`,
    },
    body: new URLSearchParams({
      csrfToken,
      email,
      password: PASSWORD,
      callbackUrl: "http://localhost:3000/",
      json: "true",
    }),
    redirect: "manual",
  });
  const session = cookieFrom(r2.headers.getSetCookie(), "next-auth.session-token");
  if (!session) throw new Error(`No session cookie for ${email}`);
  return `next-auth.session-token=${session}`;
}

async function apiGet(path: string, cookie: string) {
  const res = await fetch(`${API}${path}`, { headers: { cookie } });
  return { status: res.status, body: await res.json().catch(() => null) };
}

async function apiPost(path: string, cookie: string, body: unknown) {
  const res = await fetch(`${API}${path}`, {
    method: "POST",
    headers: { "content-type": "application/json", cookie },
    body: JSON.stringify(body),
  });
  return { status: res.status, body: await res.json().catch(() => null) };
}

async function apiPatch(path: string, cookie: string, body: unknown) {
  const res = await fetch(`${API}${path}`, {
    method: "PATCH",
    headers: { "content-type": "application/json", cookie },
    body: JSON.stringify(body),
  });
  return { status: res.status, body: await res.json().catch(() => null) };
}

async function apiDelete(path: string, cookie: string) {
  const res = await fetch(`${API}${path}`, {
    method: "DELETE",
    headers: { cookie },
  });
  return { status: res.status, body: await res.json().catch(() => null) };
}

describe("M6 — End-to-end workflow + role coverage", () => {
  let engineerCookie = "";
  let viewerCookie = "";
  let crossOrgCookie = ""; // engineer@rockworks.demo — different org
  let ownProjectId = "";
  let ownBoreholeId = "";
  let ownSampleId = "";
  let ownLabTestId = "";
  let ownClassificationId = "";
  let ownReportId = "";

  beforeAll(async () => {
    engineerCookie = await login("engineer@geodata.demo");
    viewerCookie = await login("viewer@geodata.demo");
    crossOrgCookie = await login("engineer@rockworks.demo");
  });

  // ==========================================================================
  // SECTION 1 — Full workflow as ENGINEER (org A: geodata.demo)
  // ==========================================================================

  it("1.1 — engineer can list projects", async () => {
    const r = await apiGet("/projects?pageSize=10", engineerCookie);
    expect(r.status).toBe(200);
    expect(Array.isArray(r.body.data)).toBe(true);
    if (r.body.data.length > 0) ownProjectId = r.body.data[0].id;
    expect(ownProjectId).toBeTruthy();
  });

  it("1.2 — engineer can fetch project detail with boreholes", async () => {
    const r = await apiGet(`/projects/${ownProjectId}`, engineerCookie);
    expect(r.status).toBe(200);
    expect(r.body.data.id).toBe(ownProjectId);
    expect(r.body.data.boreholes).toBeDefined();
  });

  it("1.3 — engineer can list boreholes", async () => {
    const r = await apiGet(`/boreholes?projectId=${ownProjectId}`, engineerCookie);
    expect(r.status).toBe(200);
    if (r.body.data.length > 0) ownBoreholeId = r.body.data[0].id;
    expect(ownBoreholeId).toBeTruthy();
  });

  it("1.4 — engineer can fetch borehole detail with layers + samples", async () => {
    const r = await apiGet(`/boreholes/${ownBoreholeId}`, engineerCookie);
    expect(r.status).toBe(200);
    expect(r.body.data.layers).toBeDefined();
    expect(r.body.data.samples).toBeDefined();
  });

  it("1.5 — engineer can list samples", async () => {
    const r = await apiGet(`/samples?boreholeId=${ownBoreholeId}`, engineerCookie);
    expect(r.status).toBe(200);
    if (r.body.data.length > 0) ownSampleId = r.body.data[0].id;
    expect(ownSampleId).toBeTruthy();
  });

  it("1.6 — engineer can list lab tests + find granulometry", async () => {
    const r = await apiGet(`/lab-tests?sampleId=${ownSampleId}`, engineerCookie);
    expect(r.status).toBe(200);
    const gran = r.body.data.find((t: { testType: string }) => t.testType === "GRANULOMETRY");
    if (gran) {
      ownLabTestId = gran.id;
      expect(ownLabTestId).toBeTruthy();
    }
  });

  it("1.7 — engineer can fetch lab-test detail", async () => {
    if (!ownLabTestId) return;
    const r = await apiGet(`/lab-tests/${ownLabTestId}`, engineerCookie);
    expect(r.status).toBe(200);
    expect(r.body.data.id).toBe(ownLabTestId);
  });

  it("1.8 — engineer can fetch the lab-test calculation history", async () => {
    if (!ownLabTestId) return;
    const r = await apiGet(`/lab-tests/${ownLabTestId}/calculations`, engineerCookie);
    expect(r.status).toBe(200);
    expect(r.body.success).toBe(true);
  });

  it("1.9 — engineer can list sample classifications", async () => {
    const r = await apiGet(`/samples/${ownSampleId}/classifications`, engineerCookie);
    expect(r.status).toBe(200);
    expect(r.body.success).toBe(true);
  });

  it("1.10 — engineer can list reports", async () => {
    const r = await apiGet(`/reports?projectId=${ownProjectId}`, engineerCookie);
    expect(r.status).toBe(200);
    expect(Array.isArray(r.body.data)).toBe(true);
    if (r.body.data.length > 0) ownReportId = r.body.data[0].id;
  });

  it("1.11 — engineer can fetch report detail with content snapshot", async () => {
    if (!ownReportId) return;
    const r = await apiGet(`/reports/${ownReportId}`, engineerCookie);
    expect(r.status).toBe(200);
    expect(r.body.data.id).toBe(ownReportId);
  });

  it("1.12 — engineer can download a report PDF (when present)", async () => {
    if (!ownReportId) return;
    const detail = await apiGet(`/reports/${ownReportId}`, engineerCookie);
    if (detail.body.data.hasPdf) {
      const res = await fetch(`${API}/reports/${ownReportId}/pdf`, { headers: { cookie: engineerCookie } });
      expect(res.status).toBe(200);
      expect(res.headers.get("content-type")).toBe("application/pdf");
      const buf = new Uint8Array(await res.arrayBuffer());
      expect(String.fromCharCode(buf[0], buf[1], buf[2], buf[3], buf[4])).toBe("%PDF-");
    }
  });

  // ==========================================================================
  // SECTION 2 — VIEWER role (same org, read-only)
  // ==========================================================================

  it("2.1 — viewer can READ own-org data", async () => {
    const r = await apiGet(`/projects/${ownProjectId}`, viewerCookie);
    expect(r.status).toBe(200);
    expect(r.body.data.id).toBe(ownProjectId);
  });

  it("2.2 — viewer CANNOT mutate (POST /projects → 403)", async () => {
    const r = await apiPost("/projects", viewerCookie, {
      code: "M6-TEST",
      name: "M6 test project",
      client: "test",
      status: "ACTIVE",
      locationName: "test",
      latitude: 36.7,
      longitude: 3.0,
    });
    expect(r.status).toBe(403);
    expect(r.body.error.code).toBe("FORBIDDEN");
  });

  it("2.3 — viewer CANNOT run calculations (POST /lab-tests/:id/calculate → 403)", async () => {
    if (!ownLabTestId) return;
    const r = await apiPost(`/lab-tests/${ownLabTestId}/calculate`, viewerCookie, {});
    expect([403, 404]).toContain(r.status);
    if (r.status === 403) {
      expect(r.body.error.code).toBe("FORBIDDEN");
    }
  });

  it("2.4 — viewer CANNOT classify (POST /samples/:id/classify → 403)", async () => {
    const r = await apiPost(`/samples/${ownSampleId}/classify`, viewerCookie, { moduleId: "uscs" });
    expect([403, 404]).toContain(r.status);
    if (r.status === 403) {
      expect(r.body.error.code).toBe("FORBIDDEN");
    }
  });

  it("2.5 — viewer CANNOT generate reports (POST /reports → 403)", async () => {
    const r = await apiPost("/reports", viewerCookie, {
      projectId: ownProjectId,
      reportType: "PROJECT_SUMMARY",
      title: "M6 viewer test",
    });
    expect(r.status).toBe(403);
    expect(r.body.error.code).toBe("FORBIDDEN");
  });

  it("2.6 — viewer CANNOT delete a sample (DELETE → 403)", async () => {
    const r = await apiDelete(`/samples/${ownSampleId}`, viewerCookie);
    expect([403, 404]).toContain(r.status);
  });

  // ==========================================================================
  // SECTION 3 — Cross-organization isolation
  // ==========================================================================

  it("3.1 — cross-org user CANNOT read org A's project (404)", async () => {
    const r = await apiGet(`/projects/${ownProjectId}`, crossOrgCookie);
    expect(r.status).toBe(404);
    expect(r.body.error.code).toBe("NOT_FOUND");
  });

  it("3.2 — cross-org user CANNOT read org A's borehole (404)", async () => {
    const r = await apiGet(`/boreholes/${ownBoreholeId}`, crossOrgCookie);
    expect(r.status).toBe(404);
  });

  it("3.3 — cross-org user CANNOT read org A's sample (404)", async () => {
    const r = await apiGet(`/samples/${ownSampleId}`, crossOrgCookie);
    expect(r.status).toBe(404);
  });

  it("3.4 — cross-org user CANNOT read org A's lab test (404)", async () => {
    if (!ownLabTestId) return;
    const r = await apiGet(`/lab-tests/${ownLabTestId}`, crossOrgCookie);
    expect(r.status).toBe(404);
  });

  it("3.5 — cross-org user CANNOT read org A's report (404)", async () => {
    if (!ownReportId) return;
    const r = await apiGet(`/reports/${ownReportId}`, crossOrgCookie);
    expect(r.status).toBe(404);
  });

  it("3.6 — cross-org user CANNOT download org A's PDF (404)", async () => {
    if (!ownReportId) return;
    const res = await fetch(`${API}/reports/${ownReportId}/pdf`, { headers: { cookie: crossOrgCookie } });
    // Without an approved share, the report should be 404 to the cross-org user.
    expect([404, 400]).toContain(res.status);
  });

  it("3.7 — cross-org user sees only their own org's projects in the list", async () => {
    const r = await apiGet("/projects?pageSize=100", crossOrgCookie);
    expect(r.status).toBe(200);
    const projects = r.body.data;
    // RockWorks org projects should NOT include the geodata.demo project.
    const leak = projects.find((p: { id: string }) => p.id === ownProjectId);
    expect(leak).toBeUndefined();
  });

  // ==========================================================================
  // SECTION 4 — Authentication edge cases
  // ==========================================================================

  it("4.1 — unauthenticated request is rejected (401)", async () => {
    const r = await apiGet("/projects", "");
    expect(r.status).toBe(401);
    expect(r.body.error.code).toBe("UNAUTHENTICATED");
  });

  it("4.2 — malformed JSON body is rejected (400, not 500)", async () => {
    const res = await fetch(`${API}/projects`, {
      method: "POST",
      headers: { "content-type": "application/json", cookie: engineerCookie },
      body: "{not valid json",
    });
    expect(res.status).toBe(400);
    const body = await res.json();
    expect(body.error.code).toBe("VALIDATION_ERROR");
  });

  it("4.3 — invalid route id format is rejected (400)", async () => {
    const r = await apiGet("/projects/' OR 1=1 --", engineerCookie);
    // The withApi wrapper's requireId catches this before any DB query.
    expect([400, 404]).toContain(r.status);
  });

  it("4.4 — invalid Zod body is rejected (400)", async () => {
    const r = await apiPost("/projects", engineerCookie, {
      // missing required fields
      foo: "bar",
    });
    expect(r.status).toBe(400);
    expect(r.body.error.code).toBe("VALIDATION_ERROR");
  });

  // ==========================================================================
  // SECTION 5 — Health & discovery (public endpoints)
  // ==========================================================================

  it("5.1 — health endpoint is reachable without auth", async () => {
    const r = await apiGet("/health", "");
    expect(r.status).toBe(200);
    expect(r.body.data.status).toBe("ok");
    expect(r.body.data.db).toBe("reachable");
    // Health MUST NOT leak secrets or environment values.
    const bodyStr = JSON.stringify(r.body);
    expect(bodyStr).not.toMatch(/NEXTAUTH_SECRET|password|secret/i);
  });

  it("5.2 — engines discovery requires auth (401 without)", async () => {
    const r = await apiGet("/calculations/engines", "");
    expect(r.status).toBe(401);
  });
});
