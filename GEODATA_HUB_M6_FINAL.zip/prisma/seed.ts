/**
 * GEODATA HUB — M2 demo seed (fictional demonstration data).
 *
 * Realistic Algerian project names, plausible coordinates and stratigraphy.
 * ALL laboratory results are validated through the lab-test registry (Zod)
 * before insertion — the seed fails fast if any result is schema-invalid.
 *
 * NOTE: this is a DEMO seed — it resets the demonstration dataset. The reset
 * only ever touches this seeded demo data (the database contains no other
 * records in the sandbox).
 */
import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";
import fs from "node:fs/promises";
import path from "node:path";
import { parseLabTestResult, parseLabTestInput, type LabTestType } from "../src/lib/lab-tests/registry";

const db = new PrismaClient();

const DEMO_PASSWORD = "Demo1234!";
const daysAgo = (n: number) => new Date(Date.now() - n * 24 * 3600 * 1000);
const daysAhead = (n: number) => new Date(Date.now() + n * 24 * 3600 * 1000);

// ---------------------------------------------------------------------------
// data shapes
// ---------------------------------------------------------------------------
interface LayerSpec {
  code: string;
  from: number;
  to: number;
  material: "FILL" | "SOIL" | "ROCK";
  description: string;
  uscs?: string;
  consistency?: string;
}

interface TestSpec {
  type: LabTestType;
  result?: unknown;
  // M5.1: test-definition inputs (planned parameters). Validated through the
  // registry inputSchema at insert time — the seed fails fast on invalid
  // inputs exactly as it does for results.
  input?: unknown;
  status?: "PENDING" | "IN_PROGRESS" | "REJECTED";
  summary?: string;
  notes?: string;
  performed?: boolean;
}

interface SampleSpec {
  code: string;
  type: "DISTURBED" | "UNDISTURBED" | "ROCK_CORE" | "WATER";
  from: number;
  to: number;
  recovery?: number;
  labStatus: "NOT_SENT" | "SENT" | "IN_TEST" | "COMPLETED" | "REJECTED";
  notes?: string;
  tests: TestSpec[];
}

interface BoreholeSpec {
  code: string;
  type: "ROTARY_CORE" | "SPT" | "CPT" | "TRIAL_PIT" | "AUGER";
  lat: number;
  lng: number;
  elevation: number;
  depth: number;
  status: "PLANNED" | "DRILLED" | "SAMPLED" | "COMPLETED" | "ABANDONED";
  drilledBy?: string;
  drilledDaysAgo?: number;
  notes?: string;
  layers?: LayerSpec[];
  samples?: SampleSpec[];
}

interface ProjectSpec {
  code: string;
  name: string;
  client: string;
  status: "ACTIVE" | "ON_HOLD" | "COMPLETED" | "ARCHIVED";
  locationName: string;
  lat: number;
  lng: number;
  withBoundary: boolean;
  description: string;
  createdDaysAgo: number;
  boreholes: BoreholeSpec[];
}

// ---------------------------------------------------------------------------
// realistic laboratory results (all registry-validated at insert time)
// ---------------------------------------------------------------------------
const GRAN_SANDY_SILT = {
  points: [
    { diameterMm: 63, percentFiner: 100 },
    { diameterMm: 31.5, percentFiner: 99 },
    { diameterMm: 16, percentFiner: 97 },
    { diameterMm: 8, percentFiner: 93 },
    { diameterMm: 4, percentFiner: 87 },
    { diameterMm: 2, percentFiner: 78 },
    { diameterMm: 1, percentFiner: 66 },
    { diameterMm: 0.5, percentFiner: 52 },
    { diameterMm: 0.25, percentFiner: 38 },
    { diameterMm: 0.125, percentFiner: 27 },
    { diameterMm: 0.063, percentFiner: 20 },
    { diameterMm: 0.02, percentFiner: 13 },
    { diameterMm: 0.006, percentFiner: 8 },
    { diameterMm: 0.002, percentFiner: 5 },
  ],
  d10: 0.05,
  d30: 0.25,
  d60: 1.5,
  uniformityCoefficient: 30,
  coefficientOfCurvature: 0.83,
  uscsClassification: "SM",
};

const GRAN_SILTY_CLAY = {
  points: [
    { diameterMm: 2, percentFiner: 100 },
    { diameterMm: 1, percentFiner: 99 },
    { diameterMm: 0.5, percentFiner: 98 },
    { diameterMm: 0.25, percentFiner: 96 },
    { diameterMm: 0.125, percentFiner: 93 },
    { diameterMm: 0.063, percentFiner: 88 },
    { diameterMm: 0.02, percentFiner: 62 },
    { diameterMm: 0.006, percentFiner: 41 },
    { diameterMm: 0.002, percentFiner: 27 },
    { diameterMm: 0.001, percentFiner: 21 },
  ],
  d10: 0.0012,
  d30: 0.004,
  d60: 0.018,
  uniformityCoefficient: 15,
  coefficientOfCurvature: 0.74,
  uscsClassification: "CL",
};

const GRAN_DUNE_SAND = {
  points: [
    { diameterMm: 4, percentFiner: 100 },
    { diameterMm: 2, percentFiner: 99 },
    { diameterMm: 1, percentFiner: 91 },
    { diameterMm: 0.5, percentFiner: 62 },
    { diameterMm: 0.25, percentFiner: 24 },
    { diameterMm: 0.125, percentFiner: 6 },
    { diameterMm: 0.063, percentFiner: 2 },
  ],
  d10: 0.14,
  d30: 0.21,
  d60: 0.32,
  uniformityCoefficient: 2.29,
  coefficientOfCurvature: 0.98,
  uscsClassification: "SP",
};

const ATT_CLAY_42 = { liquidLimit: 42, plasticLimit: 19, plasticityIndex: 23, uscsSymbol: "CL" };
const ATT_CLAY_31 = { liquidLimit: 31, plasticLimit: 16, plasticityIndex: 15, uscsSymbol: "CL" };
const ATT_CLAY_55 = { liquidLimit: 55, plasticLimit: 24, plasticityIndex: 31, shrinkageLimit: 16, uscsSymbol: "CH" };

const PROCTOR_STD = {
  method: "STANDARD",
  points: [
    { moistureContent: 8, dryDensity: 1.72 },
    { moistureContent: 10, dryDensity: 1.86 },
    { moistureContent: 12, dryDensity: 1.94 },
    { moistureContent: 14, dryDensity: 1.97 },
    { moistureContent: 16, dryDensity: 1.92 },
    { moistureContent: 18, dryDensity: 1.84 },
  ],
  maxDryDensity: 1.97,
  optimumMoisture: 13.5,
};

const PROCTOR_MOD = {
  method: "MODIFIED",
  points: [
    // M5.1: wetDensityMgM3 = dryDensity × (1 + w/100) on every point — ready
    // for the M5.2 ρd = ρ/(1+w) derivation helper.
    { moistureContent: 6, dryDensity: 1.9, wetDensityMgM3: 2.014 },
    { moistureContent: 8, dryDensity: 2.02, wetDensityMgM3: 2.182 },
    { moistureContent: 10, dryDensity: 2.09, wetDensityMgM3: 2.299 },
    { moistureContent: 12, dryDensity: 2.1, wetDensityMgM3: 2.352 },
    { moistureContent: 14, dryDensity: 2.05, wetDensityMgM3: 2.337 },
    { moistureContent: 16, dryDensity: 1.96, wetDensityMgM3: 2.274 },
  ],
  maxDryDensity: 2.1,
  optimumMoisture: 11.5,
};

const CBR_SOAKED_A1 = {
  condition: "SOAKED",
  points: [
    { penetrationMm: 0.5, loadKn: 1.6 },
    { penetrationMm: 1, loadKn: 3.2 },
    { penetrationMm: 2, loadKn: 6.8 },
    { penetrationMm: 2.5, loadKn: 8.9 },
    { penetrationMm: 4, loadKn: 14.1 },
    { penetrationMm: 5, loadKn: 17.2 },
    { penetrationMm: 7.5, loadKn: 22.4 },
    { penetrationMm: 10, loadKn: 26.5 },
    { penetrationMm: 12.5, loadKn: 30.1 },
  ],
  cbrAt2_5: 18,
  cbrAt5_0: 21,
  cbrValue: 21,
  swellPercent: 1.2,
};

const CBR_UNSOAKED_A1 = {
  condition: "UNSOAKED",
  points: [
    { penetrationMm: 0.5, loadKn: 3.5 },
    { penetrationMm: 1, loadKn: 7.1 },
    { penetrationMm: 2, loadKn: 14.9 },
    { penetrationMm: 2.5, loadKn: 19.1 },
    { penetrationMm: 4, loadKn: 29.6 },
    { penetrationMm: 5, loadKn: 36.2 },
    { penetrationMm: 7.5, loadKn: 47.5 },
    { penetrationMm: 10, loadKn: 55.3 },
  ],
  cbrAt2_5: 45,
  cbrAt5_0: 38,
  cbrValue: 45,
};

const SPT_A1_2M = {
  depthFrom: 2,
  depthTo: 2.45,
  hammerType: "SAFETY",
  blows1st150: 6,
  blows2nd150: 8,
  blows3rd150: 9,
  nValue: 17,
  energyRatio: 60,
  n60: 17,
  soilDescription: "Firm sandy silty clay",
};

const SPT_A1_4_5M = {
  depthFrom: 4.5,
  depthTo: 4.95,
  hammerType: "SAFETY",
  blows1st150: 5,
  blows2nd150: 7,
  blows3rd150: 7,
  nValue: 14,
  energyRatio: 60,
  n60: 14,
  soilDescription: "Firm silty clay with sand",
};

const SPT_A1_7M = {
  depthFrom: 7,
  depthTo: 7.45,
  hammerType: "SAFETY",
  blows1st150: 9,
  blows2nd150: 12,
  blows3rd150: 14,
  nValue: 26,
  energyRatio: 60,
  n60: 26,
  soilDescription: "Very stiff clayey marl",
};

const SPT_CNS_3M = {
  depthFrom: 3,
  depthTo: 3.45,
  hammerType: "AUTOMATIC",
  blows1st150: 7,
  blows2nd150: 10,
  blows3rd150: 11,
  nValue: 21,
  energyRatio: 72,
  n60: 25.2,
  soilDescription: "Stiff residual clay over limestone",
};

const SPT_CNS_6M = {
  depthFrom: 6,
  depthTo: 6.45,
  hammerType: "AUTOMATIC",
  blows1st150: 14,
  blows2nd150: 19,
  blows3rd150: 22,
  nValue: 41,
  energyRatio: 72,
  n60: 49.2,
  soilDescription: "Weathered limestone, fragmented",
};

function cptSeries(
  from: number,
  to: number,
  step: number,
  base: number,
  amp: number,
): { finalDepth: number; points: { depth: number; coneResistanceMpa: number; sleeveFrictionKpa: number }[]; frictionRatioAvg: number } {
  const points: { depth: number; coneResistanceMpa: number; sleeveFrictionKpa: number }[] = [];
  for (let d = from; d <= to + 1e-9; d = +(d + step).toFixed(3)) {
    const qc = Math.min(60, Math.max(0.8, +(base + amp * Math.sin(d * 1.1) + d * 0.9).toFixed(2)));
    const fs = Math.min(500, Math.max(12, +(24 + 16 * Math.cos(d * 0.8) + d * 5).toFixed(1)));
    points.push({ depth: +d.toFixed(2), coneResistanceMpa: qc, sleeveFrictionKpa: fs });
  }
  const avgFs = points.reduce((s, p) => s + p.sleeveFrictionKpa, 0) / points.length;
  const avgQc = points.reduce((s, p) => s + p.coneResistanceMpa, 0) / points.length;
  return {
    finalDepth: points[points.length - 1].depth,
    points,
    frictionRatioAvg: +((avgFs / (avgQc * 1000)) * 100).toFixed(2),
  };
}

const UCS_SANDSTONE = {
  specimenDiameterMm: 54,
  peakStressKpa: 4200,
  strainAtFailurePercent: 0.9,
  failurePattern: "SHEAR",
  rockClass: "Sandstone — moderately weak",
};

const UCS_CALCARENITE = {
  specimenDiameterMm: 54,
  peakStressKpa: 8600,
  strainAtFailurePercent: 1.2,
  failurePattern: "AXIAL",
  rockClass: "Calcarenite — moderately strong",
};

const UCS_MARL = {
  specimenDiameterMm: 54,
  peakStressKpa: 1500,
  strainAtFailurePercent: 1.6,
  failurePattern: "CONICAL",
  rockClass: "Marl — weak, slightly weathered",
};

const TRIAX_UU_CLAY = {
  type: "UU",
  stages: [
    { confiningPressureKpa: 100, peakDeviatorStressKpa: 95, strainAtFailurePercent: 3.4 },
    { confiningPressureKpa: 200, peakDeviatorStressKpa: 130, strainAtFailurePercent: 3.8 },
    { confiningPressureKpa: 400, peakDeviatorStressKpa: 178, strainAtFailurePercent: 4.6 },
  ],
  cohesionKpa: 38,
  frictionAngleDeg: 14,
};

const TRIAX_CU_MARL = {
  type: "CU",
  stages: [
    // M5.1: per-stage stress–strain curves (strictly increasing strain) and
    // pore pressure at failure — the raw reading sequences for the M5.2/M5.3
    // stress–strain and Mohr-circle visualizations.
    {
      confiningPressureKpa: 150, peakDeviatorStressKpa: 184, strainAtFailurePercent: 2.9,
      porePressureAtFailureKpa: -32,
      stressStrain: [
        { strainPercent: 0, deviatorStressKpa: 0 },
        { strainPercent: 0.5, deviatorStressKpa: 38 },
        { strainPercent: 1.0, deviatorStressKpa: 72 },
        { strainPercent: 1.5, deviatorStressKpa: 105 },
        { strainPercent: 2.0, deviatorStressKpa: 134 },
        { strainPercent: 2.5, deviatorStressKpa: 161 },
        { strainPercent: 2.9, deviatorStressKpa: 184 },
      ],
    },
    {
      confiningPressureKpa: 300, peakDeviatorStressKpa: 281, strainAtFailurePercent: 3.2,
      porePressureAtFailureKpa: -48,
      stressStrain: [
        { strainPercent: 0, deviatorStressKpa: 0 },
        { strainPercent: 0.5, deviatorStressKpa: 55 },
        { strainPercent: 1.0, deviatorStressKpa: 104 },
        { strainPercent: 1.5, deviatorStressKpa: 150 },
        { strainPercent: 2.0, deviatorStressKpa: 192 },
        { strainPercent: 2.5, deviatorStressKpa: 232 },
        { strainPercent: 3.2, deviatorStressKpa: 281 },
      ],
    },
    {
      confiningPressureKpa: 600, peakDeviatorStressKpa: 448, strainAtFailurePercent: 3.9,
      porePressureAtFailureKpa: -74,
      stressStrain: [
        { strainPercent: 0, deviatorStressKpa: 0 },
        { strainPercent: 0.5, deviatorStressKpa: 72 },
        { strainPercent: 1.0, deviatorStressKpa: 138 },
        { strainPercent: 1.5, deviatorStressKpa: 200 },
        { strainPercent: 2.0, deviatorStressKpa: 258 },
        { strainPercent: 2.5, deviatorStressKpa: 312 },
        { strainPercent: 3.9, deviatorStressKpa: 448 },
      ],
    },
  ],
  cohesionKpa: 26,
  frictionAngleDeg: 19,
  excessPorePressureKpa: -74,
};

const OEDO_CLAY = {
  stages: [
    { verticalPressureKpa: 25, voidRatio: 0.912 },
    { verticalPressureKpa: 50, voidRatio: 0.898 },
    { verticalPressureKpa: 100, voidRatio: 0.876 },
    { verticalPressureKpa: 200, voidRatio: 0.841 },
    { verticalPressureKpa: 400, voidRatio: 0.796 },
    { verticalPressureKpa: 800, voidRatio: 0.748 },
  ],
  compressionIndexCc: 0.155,
  swellingIndexCs: 0.022,
  preConsolidationPressureKpa: 180,
  coefficientOfConsolidationCvM2PerYear: 1.8,
};

const DS_100 = { normalStressKpa: 100, peakShearStressKpa: 68, cohesionKpa: 20, frictionAngleDeg: 25 };
const DS_200 = { normalStressKpa: 200, peakShearStressKpa: 118 };
const DS_300 = { normalStressKpa: 300, peakShearStressKpa: 165, residualShearStressKpa: 121 };

// M5.1: multi-stage direct-shear program (new stages[] format). Peak values
// follow τ ≈ 20 kPa + σn × tan 25°, consistent with the c′/φ′ entered.
const DS_STAGES_PROGRAM = {
  stages: [
    { normalStressKpa: 50, peakShearStressKpa: 43 },
    { normalStressKpa: 100, peakShearStressKpa: 67 },
    { normalStressKpa: 150, peakShearStressKpa: 90, residualShearStressKpa: 66 },
  ],
  cohesionKpa: 20,
  frictionAngleDeg: 25,
};

// M5.1: Ménard pressuremeter records (synthetic in-situ readings, same
// interval-sample pattern as SPT/CPT). pf, PL and EM are entered from the
// corrected curve — the NF P94-110-2 derivation procedure is NOT applied
// here (M5.2 will implement it after standard verification). Values are
// arithmetically self-consistent (emPlRatio = EM×1000/PL).
const PMT_CLAY_2M5 = {
  points: [
    { pressureKpa: 0, volumeCm3: 45 },
    { pressureKpa: 50, volumeCm3: 55 },
    { pressureKpa: 100, volumeCm3: 68 },
    { pressureKpa: 150, volumeCm3: 82 },
    { pressureKpa: 200, volumeCm3: 97 },
    { pressureKpa: 250, volumeCm3: 113 },
    { pressureKpa: 300, volumeCm3: 130 },
    { pressureKpa: 350, volumeCm3: 148 },
    { pressureKpa: 400, volumeCm3: 168 },
    { pressureKpa: 450, volumeCm3: 190 },
    { pressureKpa: 500, volumeCm3: 215 },
    { pressureKpa: 600, volumeCm3: 268 },
    { pressureKpa: 700, volumeCm3: 330 },
    { pressureKpa: 800, volumeCm3: 410 },
  ],
  creepPressureKpa: 450,
  limitPressureKpa: 950,
  menardModulusMPa: 12.4,
  emPlRatio: 13.05,
};

const PMT_MARL_8M5 = {
  points: [
    { pressureKpa: 0, volumeCm3: 40 },
    { pressureKpa: 100, volumeCm3: 50 },
    { pressureKpa: 200, volumeCm3: 62 },
    { pressureKpa: 300, volumeCm3: 76 },
    { pressureKpa: 400, volumeCm3: 92 },
    { pressureKpa: 500, volumeCm3: 110 },
    { pressureKpa: 600, volumeCm3: 130 },
    { pressureKpa: 700, volumeCm3: 153 },
    { pressureKpa: 800, volumeCm3: 180 },
    { pressureKpa: 1000, volumeCm3: 240 },
    { pressureKpa: 1200, volumeCm3: 315 },
    { pressureKpa: 1400, volumeCm3: 405 },
    { pressureKpa: 1600, volumeCm3: 515 },
  ],
  creepPressureKpa: 800,
  limitPressureKpa: 1750,
  menardModulusMPa: 24.8,
  emPlRatio: 14.17,
};

// M5.1 mass semantics (approved): containerMassG = tare, wetMassG =
// tare + wet soil, dryMassG = tare + dry soil. The masses below satisfy
// w = 100 × (wet − dry) / (dry − tare) within ±0.5:
//   WC_18_5 : 100 × (235.5 − 205.3) / (205.3 − 42.1)  = 18.5 %
//   WC_11_9 : 100 × (203.5 − 186.1) / (186.1 − 39.8)  = 11.9 %
const WC_18_5 = { waterContentPercent: 18.5, wetMassG: 235.5, dryMassG: 205.3, containerMassG: 42.1 };
const WC_22_4 = { waterContentPercent: 22.4 };
const WC_16_1 = { waterContentPercent: 16.1 };
const WC_28_7 = { waterContentPercent: 28.7 };
const WC_11_9 = { waterContentPercent: 11.9, wetMassG: 203.5, dryMassG: 186.1, containerMassG: 39.8 };

const GS_267 = { specificGravity: 2.67, method: "PYCNOMETER", temperatureC: 20 };
const GS_271 = { specificGravity: 2.71, method: "PYCNOMETER", temperatureC: 20 };
const GS_264 = { specificGravity: 2.64, method: "PYCNOMETER", temperatureC: 21 };

// ---------------------------------------------------------------------------
// projects & boreholes (Algerian sites)
// ---------------------------------------------------------------------------
const PROJECTS: ProjectSpec[] = [
  {
    code: "A1-TEN-2025",
    name: "East–West Highway A1 — Ténès–Chlef Section",
    client: "Agence Nationale des Autoroutes (ANA)",
    status: "ACTIVE",
    locationName: "Ténès–Chlef, Algeria",
    lat: 36.1708,
    lng: 1.3012,
    withBoundary: true,
    description:
      "Geotechnical investigation for 12.4 km of highway upgrade between Ténès and Chlef across the coastal Tell: cut slopes in marl and sandstone, embankment compaction verification and wadi-crossing foundations.",
    createdDaysAgo: 42,
    boreholes: [
      {
        code: "BH-01",
        type: "ROTARY_CORE",
        lat: 36.1708,
        lng: 1.3012,
        elevation: 38,
        depth: 20,
        status: "COMPLETED",
        drilledBy: "Forage Géotechnique Algérie SPA",
        drilledDaysAgo: 35,
        layers: [
          { code: "1", from: 0, to: 0.5, material: "FILL", description: "Crushed stone fill with brick debris, brown, loose", uscs: "GM", consistency: "loose" },
          { code: "2a", from: 0.5, to: 3.2, material: "SOIL", description: "Sandy silty clay, brown, firm, low plasticity", uscs: "CL", consistency: "firm" },
          { code: "2b", from: 3.2, to: 8.4, material: "SOIL", description: "Clayey marl, gray, stiff, locally fissured", uscs: "CL", consistency: "stiff" },
          { code: "3", from: 8.4, to: 20, material: "ROCK", description: "Sandstone, gray, moderately weathered, bedding 45°", consistency: "RQD 55%, moderately weak" },
        ],
        samples: [
          { code: "S-01", type: "DISTURBED", from: 1.0, to: 1.45, labStatus: "COMPLETED", tests: [
            {
              type: "GRANULOMETRY", result: GRAN_SANDY_SILT, performed: true, summary: "Sandy silt (SM), 20% fines",
              input: { method: "SIEVE_AND_HYDROMETER", sampleMassKg: 2.5, notes: "Washed sieving; hydrometer on the fines fraction." },
            },
            {
              type: "ATTERBERG_LIMITS", result: ATT_CLAY_31, performed: true, summary: "CL — low plasticity",
              input: { method: "CASAGRANDE_CUP", notes: "Cup method with multipoint flow confirmation." },
            },
            {
              type: "PROCTOR", result: PROCTOR_STD, performed: true, summary: "γd,max 1.97 Mg/m³ @ w_opt 13.5%",
              input: { method: "STANDARD", mold: "101.6MM", notes: "Compaction effort per ASTM D698." },
            },
            {
              type: "CBR", result: CBR_SOAKED_A1, performed: true, summary: "CBR (soaked) 21%",
              input: { condition: "SOAKED", surchargeKg: 4.5, soakingDays: 4, notes: "Immersion with surcharge before penetration." },
            },
          ] },
          { code: "S-02", type: "UNDISTURBED", from: 4.0, to: 4.45, labStatus: "COMPLETED", tests: [
            { type: "WATER_CONTENT", result: WC_22_4, performed: true },
            { type: "TRIAXIAL", result: TRIAX_UU_CLAY, performed: true, summary: "UU: c=38 kPa, φ=14°" },
          ] },
          { code: "S-03", type: "ROCK_CORE", from: 12.0, to: 12.5, recovery: 88, labStatus: "COMPLETED", tests: [
            {
              type: "UCS", result: UCS_SANDSTONE, performed: true, summary: "4.2 MPa, moderately weak",
              input: { specimenDiameterMm: 54, specimenHeightMm: 108, loadingRateMmMin: 0.1, notes: "NX core specimen, LVDT strain measurement." },
            },
          ] },
        ],
      },
      {
        code: "BH-02",
        type: "ROTARY_CORE",
        lat: 36.1725,
        lng: 1.3128,
        elevation: 35,
        depth: 18,
        status: "COMPLETED",
        drilledBy: "Forage Géotechnique Algérie SPA",
        drilledDaysAgo: 32,
        layers: [
          { code: "1", from: 0, to: 0.6, material: "FILL", description: "Crushed stone fill, brown, loose", uscs: "GM", consistency: "loose" },
          { code: "2a", from: 0.6, to: 3.0, material: "SOIL", description: "Sandy silty clay, brown, firm", uscs: "CL", consistency: "firm" },
          { code: "2b", from: 3.0, to: 9.1, material: "SOIL", description: "Clayey marl, gray, stiff, with gypsum traces", uscs: "CL", consistency: "stiff" },
          { code: "3", from: 9.1, to: 18, material: "ROCK", description: "Sandstone, gray, slightly weathered, thick bedded", consistency: "RQD 68%, moderately weak" },
        ],
        samples: [
          { code: "S-01", type: "UNDISTURBED", from: 5.0, to: 5.45, labStatus: "COMPLETED", tests: [
            { type: "OEDOMETER", result: OEDO_CLAY, performed: true, summary: "Cc 0.155, σ'p ≈ 180 kPa" },
            { type: "ATTERBERG_LIMITS", result: ATT_CLAY_42, performed: true, summary: "CL — medium plasticity" },
          ] },
          { code: "S-02", type: "ROCK_CORE", from: 11.0, to: 11.5, recovery: 92, labStatus: "COMPLETED", tests: [
            { type: "UCS", result: UCS_SANDSTONE, performed: true, summary: "4.2 MPa" },
          ] },
          { code: "S-03", type: "DISTURBED", from: 2.0, to: 2.45, labStatus: "COMPLETED", tests: [
            { type: "SPECIFIC_GRAVITY", result: GS_267, performed: true },
            { type: "GRANULOMETRY", result: GRAN_SILTY_CLAY, performed: true, summary: "CL, 88% fines" },
          ] },
        ],
      },
      {
        code: "BH-03",
        type: "SPT",
        lat: 36.1741,
        lng: 1.3247,
        elevation: 30,
        depth: 12,
        status: "COMPLETED",
        drilledBy: "Sondages Chlef EURL",
        drilledDaysAgo: 28,
        layers: [
          { code: "1", from: 0, to: 0.4, material: "FILL", description: "Topsoil with gravel, brown", consistency: "loose" },
          { code: "2a", from: 0.4, to: 4.2, material: "SOIL", description: "Firm sandy silty clay, brown", uscs: "CL", consistency: "firm" },
          { code: "2b", from: 4.2, to: 8.0, material: "SOIL", description: "Stiff clayey marl, gray", uscs: "CL", consistency: "stiff" },
          { code: "3", from: 8.0, to: 12, material: "ROCK", description: "Weathered sandstone, fragmented to blocky", consistency: "RQD 20%, weak" },
        ],
        samples: [
          { code: "SPT-01", type: "DISTURBED", from: 2.0, to: 2.45, labStatus: "COMPLETED", tests: [
            { type: "SPT", result: SPT_A1_2M, performed: true, summary: "N=17 (N60=17)" },
          ] },
          { code: "SPT-02", type: "DISTURBED", from: 4.5, to: 4.95, labStatus: "COMPLETED", tests: [
            { type: "SPT", result: SPT_A1_4_5M, performed: true, summary: "N=14 (N60=14)" },
            { type: "WATER_CONTENT", result: WC_18_5, performed: true },
          ] },
          { code: "SPT-03", type: "DISTURBED", from: 7.0, to: 7.45, labStatus: "COMPLETED", tests: [
            { type: "SPT", result: SPT_A1_7M, performed: true, summary: "N=26 (N60=26)" },
          ] },
        ],
      },
      {
        code: "BH-04",
        type: "SPT",
        lat: 36.1755,
        lng: 1.3372,
        elevation: 27,
        depth: 10,
        status: "SAMPLED",
        drilledBy: "Sondages Chlef EURL",
        drilledDaysAgo: 18,
        layers: [
          { code: "1", from: 0, to: 0.5, material: "FILL", description: "Fill with cobbles, brown", consistency: "loose" },
          { code: "2", from: 0.5, to: 5.5, material: "SOIL", description: "Sandy silty clay, brown, firm to stiff", uscs: "CL", consistency: "firm" },
          { code: "3", from: 5.5, to: 10, material: "SOIL", description: "Very stiff clayey marl, gray, dry", uscs: "CH", consistency: "very stiff" },
        ],
        samples: [
          { code: "SPT-01", type: "DISTURBED", from: 2.0, to: 2.45, labStatus: "SENT", tests: [
            { type: "SPT", result: SPT_A1_2M, performed: true, summary: "N=17" },
          ] },
          { code: "S-01", type: "DISTURBED", from: 3.0, to: 3.45, labStatus: "IN_TEST", tests: [
            { type: "PROCTOR", status: "IN_PROGRESS" },
          ] },
        ],
      },
      {
        code: "BH-05",
        type: "CPT",
        lat: 36.178,
        lng: 1.3489,
        elevation: 24,
        depth: 15,
        status: "COMPLETED",
        drilledBy: "CPT Algérie — self-propelled rig",
        drilledDaysAgo: 15,
        layers: [
          { code: "1", from: 0, to: 0.4, material: "FILL", description: "Gravel fill", consistency: "loose" },
          { code: "2", from: 0.4, to: 6.2, material: "SOIL", description: "Silty clay with sand, brown, firm", uscs: "CL", consistency: "firm" },
          { code: "3", from: 6.2, to: 15, material: "SOIL", description: "Clayey marl, gray, very stiff, interbedded sandstone bands", uscs: "CL", consistency: "very stiff" },
        ],
        samples: [
          { code: "CPT-R1", type: "DISTURBED", from: 0.5, to: 12, labStatus: "COMPLETED", notes: "Continuous CPT sounding run (representative record)", tests: [
            { type: "CPT", result: cptSeries(0.5, 12, 0.25, 4.5, 3), performed: true, summary: "Refusal not reached; qc up to 14 MPa in marl bands" },
          ] },
        ],
      },
      {
        code: "TP-06",
        type: "TRIAL_PIT",
        lat: 36.1812,
        lng: 1.3615,
        elevation: 20,
        depth: 4,
        status: "COMPLETED",
        drilledBy: "GeoStruct field crew",
        drilledDaysAgo: 12,
        notes: "Wadi Chélif floodplain — trial pit for embankment borrow assessment",
        layers: [
          { code: "1", from: 0, to: 0.3, material: "FILL", description: "Silty topsoil with roots", uscs: "OL", consistency: "soft" },
          { code: "2", from: 0.3, to: 1.8, material: "SOIL", description: "Wadi alluvium: poorly graded gravel with cobbles and sand", uscs: "GP", consistency: "medium dense" },
          { code: "3", from: 1.8, to: 4, material: "SOIL", description: "Dense gravelly sand, gray, water-bearing at 2.6 m", uscs: "SW", consistency: "dense" },
        ],
        samples: [
          { code: "TP-01", type: "DISTURBED", from: 1.0, to: 1.4, labStatus: "COMPLETED", tests: [
            { type: "GRANULOMETRY", result: GRAN_DUNE_SAND, performed: true, summary: "SP-gravelly, Cu 2.3" },
            {
              type: "PROCTOR", result: PROCTOR_MOD, performed: true, summary: "Modified: 2.10 Mg/m³ @ 11.5%",
              input: { method: "MODIFIED", mold: "152.4MM", notes: "Compaction effort per ASTM D1557; wet densities recorded per point." },
            },
            { type: "CBR", result: CBR_UNSOAKED_A1, performed: true, summary: "CBR (unsoaked) 45%" },
          ] },
        ],
      },
    ],
  },
  {
    code: "METRO-ALG-EXT",
    name: "Algiers Metro Line 1 Extension — Chevalley Segment",
    client: "Entreprise du Métro d'Alger (EMA)",
    status: "ACTIVE",
    locationName: "Chevalley, Alger, Algeria",
    lat: 36.7589,
    lng: 3.0231,
    withBoundary: true,
    description:
      "Deep investigation for cut-and-cover stations and a TBM launch shaft in the Chevalley sector: Astian calcarenite and marl units, groundwater control assessment.",
    createdDaysAgo: 30,
    boreholes: [
      {
        code: "LB-01",
        type: "ROTARY_CORE",
        lat: 36.7589,
        lng: 3.0231,
        elevation: 84,
        depth: 35,
        status: "COMPLETED",
        drilledBy: "Sondages Profonds Algérie",
        drilledDaysAgo: 24,
        layers: [
          { code: "1", from: 0, to: 1.2, material: "FILL", description: "Made ground: sandy gravel with construction debris", uscs: "GM", consistency: "loose" },
          { code: "2", from: 1.2, to: 6.5, material: "SOIL", description: "Lean clay, reddish brown, stiff (residual soils)", uscs: "CL", consistency: "stiff" },
          { code: "3a", from: 6.5, to: 14.0, material: "SOIL", description: "Marl, gray, hard, fissured, with gypsum veins", uscs: "CH", consistency: "hard" },
          { code: "3b", from: 14.0, to: 21.0, material: "ROCK", description: "Marl, gray, weak to moderately weak, thinly bedded", consistency: "RQD 45%, weak" },
          { code: "4", from: 21.0, to: 35, material: "ROCK", description: "Calcarenite (Astian), creamy gray, moderately strong, cross-bedded", consistency: "RQD 72%, moderately strong" },
        ],
        samples: [
          { code: "S-01", type: "UNDISTURBED", from: 8.0, to: 8.45, labStatus: "COMPLETED", tests: [
            {
              type: "TRIAXIAL", result: TRIAX_CU_MARL, performed: true, summary: "CU: c=26 kPa, φ=19°",
              input: { type: "CU", specimenCount: 3, backPressureKpa: 300, notes: "Saturation confirmed before consolidation; per-stage stress–strain recorded." },
            },
            {
              type: "OEDOMETER", result: OEDO_CLAY, performed: true, summary: "Cc 0.155",
              input: { specimenDiameterMm: 75, specimenHeightMm: 20, initialVoidRatio: 0.91, notes: "Load increments doubled at 24 h intervals." },
            },
            { type: "WATER_CONTENT", result: WC_28_7, performed: true },
          ] },
          { code: "S-02", type: "ROCK_CORE", from: 24.0, to: 24.6, recovery: 95, labStatus: "COMPLETED", tests: [
            { type: "UCS", result: UCS_CALCARENITE, performed: true, summary: "8.6 MPa, moderately strong" },
          ] },
        ],
      },
      {
        code: "LB-02",
        type: "ROTARY_CORE",
        lat: 36.7604,
        lng: 3.0288,
        elevation: 82,
        depth: 30,
        status: "COMPLETED",
        drilledBy: "Sondages Profonds Algérie",
        drilledDaysAgo: 20,
        layers: [
          { code: "1", from: 0, to: 0.9, material: "FILL", description: "Made ground, gravelly", uscs: "GM", consistency: "loose" },
          { code: "2", from: 0.9, to: 5.8, material: "SOIL", description: "Lean clay, reddish brown, stiff", uscs: "CL", consistency: "stiff" },
          { code: "3", from: 5.8, to: 16.2, material: "ROCK", description: "Marl, gray, weak, with sandstone interbeds", consistency: "RQD 40%, weak" },
          { code: "4", from: 16.2, to: 30, material: "ROCK", description: "Calcarenite, creamy gray, moderately strong", consistency: "RQD 70%" },
        ],
        samples: [
          { code: "S-01", type: "ROCK_CORE", from: 18.0, to: 18.6, recovery: 90, labStatus: "COMPLETED", tests: [
            { type: "UCS", result: UCS_MARL, performed: true, summary: "1.5 MPa marl interbed" },
          ] },
          { code: "S-02", type: "UNDISTURBED", from: 3.5, to: 3.95, labStatus: "COMPLETED", tests: [
            { type: "ATTERBERG_LIMITS", result: ATT_CLAY_42, performed: true, summary: "CL" },
            { type: "SPECIFIC_GRAVITY", result: GS_271, performed: true },
          ] },
        ],
      },
      {
        code: "LB-03",
        type: "ROTARY_CORE",
        lat: 36.7618,
        lng: 3.0346,
        elevation: 79,
        depth: 28,
        status: "DRILLED",
        drilledBy: "Sondages Profonds Algérie",
        drilledDaysAgo: 8,
        layers: [
          { code: "1", from: 0, to: 1.0, material: "FILL", description: "Made ground", consistency: "loose" },
          { code: "2", from: 1.0, to: 6.0, material: "SOIL", description: "Lean clay, reddish brown, stiff", uscs: "CL", consistency: "stiff" },
          { code: "3", from: 6.0, to: 15.0, material: "ROCK", description: "Marl, gray, weak", consistency: "RQD 35%, weak" },
          { code: "4", from: 15.0, to: 28, material: "ROCK", description: "Calcarenite, moderately strong", consistency: "RQD 65%" },
        ],
        samples: [
          { code: "S-01", type: "ROCK_CORE", from: 17.0, to: 17.6, recovery: 85, labStatus: "SENT", tests: [
            { type: "UCS", status: "PENDING" },
          ] },
        ],
      },
      {
        code: "LB-04",
        type: "SPT",
        lat: 36.7631,
        lng: 3.0402,
        elevation: 77,
        depth: 15,
        status: "COMPLETED",
        drilledBy: "Sondages Profonds Algérie",
        drilledDaysAgo: 5,
        layers: [
          { code: "1", from: 0, to: 0.8, material: "FILL", description: "Made ground, gravelly", consistency: "loose" },
          { code: "2", from: 0.8, to: 6.4, material: "SOIL", description: "Lean clay, reddish brown, stiff", uscs: "CL", consistency: "stiff" },
          { code: "3", from: 6.4, to: 15, material: "SOIL", description: "Very stiff marly clay, gray", uscs: "CH", consistency: "very stiff" },
        ],
        samples: [
          { code: "SPT-01", type: "DISTURBED", from: 3.0, to: 3.45, labStatus: "COMPLETED", tests: [
            { type: "SPT", result: SPT_A1_4_5M, performed: true, summary: "N=14" },
          ] },
          { code: "SPT-02", type: "DISTURBED", from: 6.5, to: 6.95, labStatus: "COMPLETED", tests: [
            { type: "WATER_CONTENT", result: WC_16_1, performed: true },
          ] },
          // M5.1: Ménard pressuremeter intervals — synthetic in-situ records
          // following the SPT/CPT interval-sample pattern (no schema relation
          // changes; one PRESSUREMETER test per interval).
          {
            code: "PMT-01", type: "DISTURBED", from: 2.5, to: 2.95, labStatus: "COMPLETED",
            notes: "Ménard pressuremeter interval — prebored hole, stiff lean clay",
            tests: [
              {
                type: "PRESSUREMETER", result: PMT_CLAY_2M5, performed: true,
                summary: "EM 12.4 MPa, PL 950 kPa (pf 450 kPa)",
                input: {
                  probeType: "Ménard NB (74 mm)", testDepthM: 2.5, boreholeDiameterMm: 76,
                  groundwaterPresent: true,
                  membraneCalibration: [
                    { pressureKpa: 0, volumeCm3: 0 },
                    { pressureKpa: 100, volumeCm3: 18 },
                    { pressureKpa: 200, volumeCm3: 36 },
                    { pressureKpa: 400, volumeCm3: 71 },
                  ],
                  notes: "Membrane calibrated in free air before testing.",
                },
              },
            ],
          },
          {
            code: "PMT-02", type: "DISTURBED", from: 8.5, to: 8.95, labStatus: "COMPLETED",
            notes: "Ménard pressuremeter interval — very stiff marly clay",
            tests: [
              {
                type: "PRESSUREMETER", result: PMT_MARL_8M5, performed: true,
                summary: "EM 24.8 MPa, PL 1750 kPa (pf 800 kPa)",
                input: {
                  probeType: "Ménard NB (74 mm)", testDepthM: 8.5, boreholeDiameterMm: 76,
                  groundwaterPresent: true,
                  notes: "Slow creep response in marly clay; extended final holds recorded.",
                },
              },
            ],
          },
        ],
      },
      {
        code: "LB-05",
        type: "CPT",
        lat: 36.7572,
        lng: 3.0175,
        elevation: 86,
        depth: 18,
        status: "COMPLETED",
        drilledBy: "CPT Algérie",
        drilledDaysAgo: 3,
        layers: [
          { code: "1", from: 0, to: 0.7, material: "FILL", description: "Made ground", consistency: "loose" },
          { code: "2", from: 0.7, to: 7.0, material: "SOIL", description: "Lean clay, reddish brown, stiff", uscs: "CL", consistency: "stiff" },
          { code: "3", from: 7.0, to: 18, material: "ROCK", description: "Marl to calcarenite, weak to moderately weak", consistency: "RQD n/a (CPT)" },
        ],
        samples: [
          { code: "CPT-R1", type: "DISTURBED", from: 0.5, to: 15, labStatus: "COMPLETED", notes: "CPT sounding record", tests: [
            {
              type: "CPT", result: cptSeries(0.5, 15, 0.25, 7, 5), performed: true, summary: "Marl at 7 m, qc > 15 MPa",
              input: { coneType: "STANDARD_10CM2", porePressure: false, notes: "Continuous push at the standard rate; readings every 0.25 m." },
            },
          ] },
        ],
      },
    ],
  },
  {
    code: "TRAM-CNS-2025",
    name: "Constantine Tramway Extension — Zouaghi Segment",
    client: "SETRAM Constantine",
    status: "ACTIVE",
    locationName: "Zouaghi, Constantine, Algeria",
    lat: 36.2414,
    lng: 6.5702,
    withBoundary: false,
    description:
      "Trackbed investigation along the Zouaghi alignment on the Constantine limestone plateau: residual clays over karstic limestone, subgrade modulus verification.",
    createdDaysAgo: 21,
    boreholes: [
      {
        code: "CS-01",
        type: "ROTARY_CORE",
        lat: 36.2414,
        lng: 6.5702,
        elevation: 640,
        depth: 15,
        status: "COMPLETED",
        drilledBy: "Sondages Est Algérie",
        drilledDaysAgo: 16,
        layers: [
          { code: "1", from: 0, to: 0.4, material: "FILL", description: "Subgrade fill, gravelly, brown", uscs: "GM", consistency: "medium dense" },
          { code: "2", from: 0.4, to: 4.5, material: "SOIL", description: "Residual clay, reddish brown, stiff, with limestone gravel", uscs: "CL", consistency: "stiff" },
          { code: "3", from: 4.5, to: 15, material: "ROCK", description: "Limestone, beige-gray, karstic voids noted at 7.2–7.6 m", consistency: "RQD 60%, moderately weak" },
        ],
        samples: [
          { code: "S-01", type: "DISTURBED", from: 1.5, to: 1.95, labStatus: "COMPLETED", tests: [
            { type: "GRANULOMETRY", result: GRAN_SILTY_CLAY, performed: true, summary: "CL" },
            { type: "ATTERBERG_LIMITS", result: ATT_CLAY_55, performed: true, summary: "CH — high plasticity" },
            { type: "PROCTOR", result: PROCTOR_STD, performed: true, summary: "1.97 Mg/m³ @ 13.5%" },
          ] },
          { code: "S-02", type: "ROCK_CORE", from: 9.0, to: 9.5, recovery: 82, labStatus: "COMPLETED", tests: [
            { type: "UCS", result: UCS_MARL, performed: true, summary: "1.5 MPa, karstic-affected" },
          ] },
        ],
      },
      {
        code: "CS-02",
        type: "SPT",
        lat: 36.2439,
        lng: 6.5751,
        elevation: 638,
        depth: 10,
        status: "COMPLETED",
        drilledBy: "Sondages Est Algérie",
        drilledDaysAgo: 10,
        layers: [
          { code: "1", from: 0, to: 0.4, material: "FILL", description: "Subgrade fill", consistency: "medium dense" },
          { code: "2", from: 0.4, to: 4.8, material: "SOIL", description: "Residual clay, reddish brown, stiff", uscs: "CL", consistency: "stiff" },
          { code: "3", from: 4.8, to: 10, material: "ROCK", description: "Limestone, fragmented to blocky, karstic", consistency: "RQD 35%, weak" },
        ],
        samples: [
          { code: "SPT-01", type: "DISTURBED", from: 3.0, to: 3.45, labStatus: "COMPLETED", tests: [
            {
              type: "SPT", result: SPT_CNS_3M, performed: true, summary: "N=21 (N60=25)",
              // M5.1: demonstrates the optional effectiveOverburdenKpa input
              // (σ′v0 estimated from site unit weights — the (N1)60 correction
              // itself arrives with the M5.2 calculation engine).
              input: { hammerType: "AUTOMATIC", energyRatio: 72, effectiveOverburdenKpa: 46.9, notes: "σ′v0 from site unit weights: 2.2 m above water at 18.1 kN/m³ + 0.8 m buoyant at 8.8 kN/m³." },
            },
          ] },
          { code: "SPT-02", type: "DISTURBED", from: 6.0, to: 6.45, labStatus: "COMPLETED", tests: [
            { type: "SPT", result: SPT_CNS_6M, performed: true, summary: "N=41 (N60=49)" },
          ] },
        ],
      },
      {
        code: "TP-03",
        type: "TRIAL_PIT",
        lat: 36.2462,
        lng: 6.5803,
        elevation: 635,
        depth: 3,
        status: "COMPLETED",
        drilledBy: "GeoStruct field crew",
        drilledDaysAgo: 6,
        layers: [
          { code: "1", from: 0, to: 0.3, material: "FILL", description: "Topsoil with rubble", consistency: "loose" },
          { code: "2", from: 0.3, to: 2.2, material: "SOIL", description: "Residual clay, stiff, with limestone blocks", uscs: "CL", consistency: "stiff" },
          { code: "3", from: 2.2, to: 3, material: "ROCK", description: "Limestone, weathered, blocky", consistency: "weak" },
        ],
        samples: [
          { code: "TP-01", type: "DISTURBED", from: 1.0, to: 1.4, labStatus: "COMPLETED", tests: [
            { type: "CBR", result: CBR_SOAKED_A1, performed: true, summary: "Subgrade CBR (soaked) 21%" },
            { type: "SPECIFIC_GRAVITY", result: GS_264, performed: true },
          ] },
        ],
      },
      {
        code: "CS-04",
        type: "AUGER",
        lat: 36.2487,
        lng: 6.5852,
        elevation: 633,
        depth: 8,
        status: "PLANNED",
      },
    ],
  },
  {
    code: "PORT-ORN-TERM",
    name: "Oran Port — Container Terminal Expansion",
    client: "Entreprise Portuaire d'Oran (EPO)",
    status: "ON_HOLD",
    locationName: "Port d'Oran, Oran, Algeria",
    lat: 35.7123,
    lng: -0.6456,
    withBoundary: true,
    description:
      "Maritime geotechnics for the container terminal quay extension: hydraulic fills over soft clays, dredge-line verification and piled deck foundations (on hold pending funding).",
    createdDaysAgo: 55,
    boreholes: [
      {
        code: "PM-01",
        type: "ROTARY_CORE",
        lat: 35.7123,
        lng: -0.6456,
        elevation: 3,
        depth: 25,
        status: "COMPLETED",
        drilledBy: "Marine Sondages Oran",
        drilledDaysAgo: 48,
        layers: [
          { code: "1", from: 0, to: 3.5, material: "FILL", description: "Hydraulic fill: loose fine sand with shell fragments", uscs: "SP", consistency: "loose" },
          { code: "2", from: 3.5, to: 8.0, material: "SOIL", description: "Soft organic silty clay, dark gray, w > LL", uscs: "OH", consistency: "soft" },
          { code: "3", from: 8.0, to: 15.0, material: "SOIL", description: "Dense sand with gravel, gray, water-bearing", uscs: "SW", consistency: "dense" },
          { code: "4", from: 15.0, to: 25, material: "ROCK", description: "Marl, gray-blue, moderately weak", consistency: "RQD 55%" },
        ],
        samples: [
          { code: "S-01", type: "UNDISTURBED", from: 5.0, to: 5.45, labStatus: "COMPLETED", tests: [
            { type: "OEDOMETER", result: OEDO_CLAY, performed: true, summary: "Cc 0.155, normally consolidated" },
            { type: "WATER_CONTENT", result: WC_28_7, performed: true },
          ] },
          { code: "S-02", type: "DISTURBED", from: 1.5, to: 1.95, labStatus: "COMPLETED", tests: [
            { type: "GRANULOMETRY", result: GRAN_DUNE_SAND, performed: true, summary: "SP, uniform fine sand" },
            { type: "WATER_CONTENT", result: WC_11_9, performed: true },
          ] },
        ],
      },
      {
        code: "PM-02",
        type: "CPT",
        lat: 35.7141,
        lng: -0.6428,
        elevation: 2,
        depth: 20,
        status: "COMPLETED",
        drilledBy: "Marine CPT platform",
        drilledDaysAgo: 44,
        layers: [
          { code: "1", from: 0, to: 3.8, material: "FILL", description: "Hydraulic fill sand, loose", uscs: "SP", consistency: "loose" },
          { code: "2", from: 3.8, to: 8.4, material: "SOIL", description: "Soft organic clay", uscs: "OH", consistency: "soft" },
          { code: "3", from: 8.4, to: 20, material: "SOIL", description: "Dense sand over marl", uscs: "SW", consistency: "dense" },
        ],
        samples: [
          { code: "CPT-R1", type: "DISTURBED", from: 0.5, to: 18, labStatus: "COMPLETED", notes: "CPT sounding record", tests: [
            { type: "CPT", result: cptSeries(0.5, 18, 0.25, 6, 6), performed: true, summary: "Soft clay cap over dense sand" },
          ] },
        ],
      },
      {
        code: "PM-03",
        type: "ROTARY_CORE",
        lat: 35.7158,
        lng: -0.6399,
        elevation: 3,
        depth: 22,
        status: "DRILLED",
        drilledBy: "Marine Sondages Oran",
        drilledDaysAgo: 12,
        layers: [
          { code: "1", from: 0, to: 3.2, material: "FILL", description: "Hydraulic fill sand, loose", uscs: "SP", consistency: "loose" },
          { code: "2", from: 3.2, to: 7.6, material: "SOIL", description: "Soft organic silty clay", uscs: "OH", consistency: "soft" },
          { code: "3", from: 7.6, to: 22, material: "SOIL", description: "Dense gravelly sand over marl", uscs: "SW", consistency: "dense" },
        ],
        samples: [
          { code: "S-01", type: "UNDISTURBED", from: 4.5, to: 4.95, labStatus: "IN_TEST", tests: [
            { type: "TRIAXIAL", status: "IN_PROGRESS" },
          ] },
        ],
      },
      {
        code: "PM-04",
        type: "SPT",
        lat: 35.7174,
        lng: -0.6371,
        elevation: 4,
        depth: 12,
        status: "PLANNED",
      },
    ],
  },
  {
    code: "BDL-HOSP-2024",
    name: "Boumerdès Regional Hospital — Foundation Investigation",
    client: "Direction des Équipements Publics — Wilaya de Boumerdès",
    status: "COMPLETED",
    locationName: "Boumerdès, Algeria",
    lat: 36.7651,
    lng: 3.4711,
    withBoundary: false,
    description:
      "Completed investigation for a 240-bed hospital in a seismic zone (RPA 99/2003): spread foundations in stiff clays over marl, liquefaction screening of sandy units.",
    createdDaysAgo: 130,
    boreholes: [
      {
        code: "BH-01",
        type: "ROTARY_CORE",
        lat: 36.7651,
        lng: 3.4711,
        elevation: 62,
        depth: 20,
        status: "COMPLETED",
        drilledBy: "Sondages Boumerdès",
        drilledDaysAgo: 120,
        layers: [
          { code: "1", from: 0, to: 0.5, material: "FILL", description: "Topsoil with rubble", consistency: "loose" },
          { code: "2a", from: 0.5, to: 4.0, material: "SOIL", description: "Silty clay, brown, stiff", uscs: "CL", consistency: "stiff" },
          { code: "2b", from: 4.0, to: 7.5, material: "SOIL", description: "Silty sand, brown, medium dense", uscs: "SM", consistency: "medium dense" },
          { code: "3", from: 7.5, to: 20, material: "ROCK", description: "Marl, gray, moderately weak to moderately strong", consistency: "RQD 62%" },
        ],
        samples: [
          { code: "S-01", type: "UNDISTURBED", from: 2.5, to: 2.95, labStatus: "COMPLETED", tests: [
            { type: "DIRECT_SHEAR", result: DS_100, performed: true, summary: "c=20 kPa, φ=25°" },
            {
              type: "WATER_CONTENT", result: WC_18_5, performed: true,
              input: { containerId: "TIN-214", ovenTemperatureC: 110, notes: "Aluminum tin, oven-dried to constant mass." },
            },
          ] },
          { code: "S-02", type: "UNDISTURBED", from: 5.5, to: 5.95, labStatus: "COMPLETED", tests: [
            { type: "DIRECT_SHEAR", result: DS_200, performed: true, summary: "τ_peak 118 kPa @ 200 kPa" },
          ] },
          { code: "S-03", type: "ROCK_CORE", from: 12.0, to: 12.5, recovery: 90, labStatus: "COMPLETED", tests: [
            { type: "UCS", result: UCS_MARL, performed: true, summary: "1.5 MPa marl" },
          ] },
          // M5.1: multi-stage direct-shear program on companion specimens
          // (new stages[] result format, alongside the scalar records above).
          {
            code: "S-04", type: "UNDISTURBED", from: 3.5, to: 3.95, labStatus: "COMPLETED",
            notes: "Companion specimens for the multi-stage shear program",
            tests: [
              {
                type: "DIRECT_SHEAR", result: DS_STAGES_PROGRAM, performed: true,
                summary: "Multi-stage envelope: c′=20 kPa, φ′=25°",
                input: { specimenDiameterMm: 63.5, rateMmMin: 0.05, notes: "Three-stage program on companion specimens from the same undisturbed sample." },
              },
            ],
          },
        ],
      },
      {
        code: "BH-02",
        type: "SPT",
        lat: 36.7668,
        lng: 3.4745,
        elevation: 60,
        depth: 15,
        status: "COMPLETED",
        drilledBy: "Sondages Boumerdès",
        drilledDaysAgo: 118,
        layers: [
          { code: "1", from: 0, to: 0.5, material: "FILL", description: "Topsoil", consistency: "loose" },
          { code: "2", from: 0.5, to: 4.2, material: "SOIL", description: "Silty clay, brown, stiff", uscs: "CL", consistency: "stiff" },
          { code: "3", from: 4.2, to: 15, material: "SOIL", description: "Silty sand to marly clay, dense to very stiff", uscs: "SM", consistency: "dense" },
        ],
        samples: [
          { code: "SPT-01", type: "DISTURBED", from: 5.0, to: 5.45, labStatus: "COMPLETED", tests: [
            { type: "SPT", result: SPT_A1_7M, performed: true, summary: "N=26" },
            { type: "GRANULOMETRY", result: GRAN_SANDY_SILT, performed: true, summary: "SM — liquefaction screening: not susceptible" },
          ] },
          { code: "SPT-02", type: "DISTURBED", from: 8.0, to: 8.45, labStatus: "COMPLETED", tests: [
            { type: "SPT", result: SPT_CNS_6M, performed: true, summary: "N=41" },
          ] },
        ],
      },
      {
        code: "BH-03",
        type: "TRIAL_PIT",
        lat: 36.7682,
        lng: 3.4708,
        elevation: 58,
        depth: 3.5,
        status: "COMPLETED",
        drilledBy: "GeoStruct field crew",
        drilledDaysAgo: 116,
        layers: [
          { code: "1", from: 0, to: 0.4, material: "FILL", description: "Topsoil", consistency: "loose" },
          { code: "2", from: 0.4, to: 2.0, material: "SOIL", description: "Silty clay, brown, stiff", uscs: "CL", consistency: "stiff" },
          { code: "3", from: 2.0, to: 3.5, material: "SOIL", description: "Clayey sand, dense", uscs: "SC", consistency: "dense" },
        ],
        samples: [
          { code: "TP-01", type: "DISTURBED", from: 1.2, to: 1.6, labStatus: "COMPLETED", tests: [
            { type: "DIRECT_SHEAR", result: DS_300, performed: true, summary: "τ_peak 165, τ_res 121 kPa" },
            {
              type: "SPECIFIC_GRAVITY", result: GS_267, performed: true,
              input: { method: "PYCNOMETER", notes: "Degassed distilled water; temperature-corrected." },
            },
          ] },
        ],
      },
      {
        code: "BH-04",
        type: "ROTARY_CORE",
        lat: 36.7635,
        lng: 3.4679,
        elevation: 64,
        depth: 18,
        status: "COMPLETED",
        drilledBy: "Sondages Boumerdès",
        drilledDaysAgo: 112,
        layers: [
          { code: "1", from: 0, to: 0.6, material: "FILL", description: "Made ground", consistency: "loose" },
          { code: "2", from: 0.6, to: 3.8, material: "SOIL", description: "Silty clay, brown, stiff", uscs: "CL", consistency: "stiff" },
          { code: "3", from: 3.8, to: 18, material: "ROCK", description: "Marl with sandstone bands, gray", consistency: "RQD 58%" },
        ],
        samples: [
          { code: "S-01", type: "UNDISTURBED", from: 2.0, to: 2.45, labStatus: "REJECTED", notes: "Sample damaged during transport — re-sampling requested", tests: [
            { type: "ATTERBERG_LIMITS", status: "REJECTED", notes: "Specimen disturbed; test inconclusive" },
          ] },
        ],
      },
    ],
  },
];

const ROCKWORKS_PROJECT: ProjectSpec = {
  code: "ANNABA-IND-2026",
  name: "Annaba Industrial Zone — Geotechnical Verification Program",
  client: "Société de Gestion des Zones Industrielles (SGZI)",
  status: "ACTIVE",
  locationName: "Zone Industrielle El Bouni, Annaba, Algeria",
  lat: 36.8976,
  lng: 7.7673,
  withBoundary: false,
  description:
    "RockWorks Laboratory's own verification program for warehouse foundations in the El Bouni industrial zone: dune sands over Numidian clays and flysch.",
  createdDaysAgo: 25,
  boreholes: [
    {
      code: "AB-01",
      type: "SPT",
      lat: 36.8976,
      lng: 7.7673,
      elevation: 12,
      depth: 12,
      status: "COMPLETED",
      drilledBy: "RockWorks field unit",
      drilledDaysAgo: 18,
      layers: [
        { code: "1", from: 0, to: 0.3, material: "FILL", description: "Sandy topsoil with vegetation", consistency: "loose" },
        { code: "2", from: 0.3, to: 3.8, material: "SOIL", description: "Dune sand, fine, uniform, loose to medium dense", uscs: "SP", consistency: "medium dense" },
        { code: "3", from: 3.8, to: 7.2, material: "SOIL", description: "Firm sandy clay, brown (Numidian clay weathering crust)", uscs: "CL", consistency: "firm" },
        { code: "4", from: 7.2, to: 12, material: "ROCK", description: "Numidian sandstone / flysch alternation, gray", consistency: "RQD 50%, moderately weak" },
      ],
      samples: [
        { code: "SPT-01", type: "DISTURBED", from: 1.5, to: 1.95, labStatus: "COMPLETED", tests: [
          { type: "SPT", result: SPT_A1_2M, performed: true, summary: "N=17" },
          { type: "GRANULOMETRY", result: GRAN_DUNE_SAND, performed: true, summary: "SP, uniform" },
        ] },
        { code: "S-01", type: "DISTURBED", from: 5.0, to: 5.45, labStatus: "COMPLETED", tests: [
          { type: "ATTERBERG_LIMITS", result: ATT_CLAY_31, performed: true, summary: "CL" },
          { type: "PROCTOR", result: PROCTOR_STD, performed: true, summary: "1.97 Mg/m³ @ 13.5%" },
          { type: "CBR", result: CBR_SOAKED_A1, performed: true, summary: "CBR 21% (soaked)" },
        ] },
      ],
    },
    {
      code: "AB-02",
      type: "ROTARY_CORE",
      lat: 36.8995,
      lng: 7.7701,
      elevation: 11,
      depth: 15,
      status: "SAMPLED",
      drilledBy: "RockWorks field unit",
      drilledDaysAgo: 9,
      layers: [
        { code: "1", from: 0, to: 0.4, material: "FILL", description: "Sandy fill", consistency: "loose" },
        { code: "2", from: 0.4, to: 4.2, material: "SOIL", description: "Dune sand, fine, medium dense", uscs: "SP", consistency: "medium dense" },
        { code: "3", from: 4.2, to: 8.0, material: "SOIL", description: "Sandy clay, firm to stiff", uscs: "CL", consistency: "stiff" },
        { code: "4", from: 8.0, to: 15, material: "ROCK", description: "Numidian sandstone, gray, cross-bedded", consistency: "RQD 65%" },
      ],
      samples: [
        { code: "S-01", type: "ROCK_CORE", from: 10.0, to: 10.5, recovery: 88, labStatus: "SENT", tests: [
          { type: "UCS", status: "PENDING" },
        ] },
        { code: "S-02", type: "DISTURBED", from: 2.0, to: 2.45, labStatus: "IN_TEST", tests: [
          { type: "SPECIFIC_GRAVITY", status: "IN_PROGRESS" },
        ] },
      ],
    },
    {
      code: "AB-03",
      type: "TRIAL_PIT",
      lat: 36.9013,
      lng: 7.7728,
      elevation: 10,
      depth: 3,
      status: "COMPLETED",
      drilledBy: "RockWorks field unit",
      drilledDaysAgo: 4,
      layers: [
        { code: "1", from: 0, to: 0.3, material: "FILL", description: "Sandy topsoil", consistency: "loose" },
        { code: "2", from: 0.3, to: 2.4, material: "SOIL", description: "Dune sand, fine, loose", uscs: "SP", consistency: "loose" },
        { code: "3", from: 2.4, to: 3, material: "SOIL", description: "Organic silty clay, dark, soft (wetland edge)", uscs: "OL", consistency: "soft" },
      ],
      samples: [
        { code: "TP-01", type: "DISTURBED", from: 1.0, to: 1.4, labStatus: "COMPLETED", tests: [
          { type: "GRANULOMETRY", result: GRAN_DUNE_SAND, performed: true, summary: "SP" },
          { type: "WATER_CONTENT", result: WC_16_1, performed: true },
        ] },
      ],
    },
  ],
};

// ===========================================================================
// seed execution
// ===========================================================================
async function reset() {
  console.log("Resetting demo dataset (demo seed)…");
  await db.activityLog.deleteMany();
  await db.report.deleteMany();
  await db.sharingRequest.deleteMany();
  await db.document.deleteMany();
  await db.labTest.deleteMany();
  await db.sample.deleteMany();
  await db.geologicalLayer.deleteMany();
  await db.borehole.deleteMany();
  await db.project.deleteMany();
  await db.user.deleteMany();
  await db.organization.deleteMany();
  const uploads = path.join(process.cwd(), "storage", "uploads");
  await fs.mkdir(uploads, { recursive: true });
  for (const f of await fs.readdir(uploads)) {
    await fs.unlink(path.join(uploads, f));
  }
}

async function main() {
  await reset();

  // --- organizations & users ---
  const passwordHash = await bcrypt.hash(DEMO_PASSWORD, 10);
  const geostruct = await db.organization.create({
    data: { slug: "geostruct", name: "GeoStruct Consulting" },
  });
  const rockworks = await db.organization.create({
    data: { slug: "rockworks", name: "RockWorks Laboratory" },
  });

  const mkUser = (orgId: string, email: string, name: string, role: string) =>
    db.user.create({ data: { organizationId: orgId, email, name, role, passwordHash } });

  const geoAdmin = await mkUser(geostruct.id, "admin@geodata.demo", "Ana Rivera", "ORG_ADMIN");
  const geoManager = await mkUser(geostruct.id, "manager@geodata.demo", "Yacine Benali", "PROJECT_MANAGER");
  const geoEngineer = await mkUser(geostruct.id, "engineer@geodata.demo", "Karim Bouzidi", "ENGINEER");
  await mkUser(geostruct.id, "viewer@geodata.demo", "Nadia Cherif", "VIEWER");
  const rockAdmin = await mkUser(rockworks.id, "admin@rockworks.demo", "Sofiane Mansouri", "ORG_ADMIN");
  const rockEngineer = await mkUser(rockworks.id, "engineer@rockworks.demo", "Lina Toumi", "ENGINEER");

  console.log("organizations: 2 | users: 6");

  // --- projects, boreholes, layers, samples, lab tests ---
  const counters = { boreholes: 0, layers: 0, samples: 0, labTests: 0, completed: 0, pending: 0 };
  const createdProjects: Record<string, { id: string; boreholes: Record<string, string>; samples: Record<string, string> }> = {};

  async function seedProject(spec: ProjectSpec, orgId: string, creatorId: string) {
    // boundary: simple polygon around the site centroid (0.02° ≈ 2 km box)
    const boundary = spec.withBoundary
      ? {
          type: "Polygon",
          coordinates: [
            [
              [spec.lng - 0.02, spec.lat - 0.012],
              [spec.lng + 0.022, spec.lat - 0.011],
              [spec.lng + 0.024, spec.lat + 0.013],
              [spec.lng - 0.018, spec.lat + 0.012],
              [spec.lng - 0.02, spec.lat - 0.012],
            ],
          ],
        }
      : null;

    const project = await db.project.create({
      data: {
        organizationId: orgId,
        code: spec.code,
        name: spec.name,
        description: spec.description,
        client: spec.client,
        status: spec.status,
        locationName: spec.locationName,
        latitude: spec.lat,
        longitude: spec.lng,
        boundary: (boundary ?? undefined) as never,
        createdById: creatorId,
        createdAt: daysAgo(spec.createdDaysAgo),
      },
    });
    createdProjects[spec.code] = { id: project.id, boreholes: {}, samples: {} };

    for (const bh of spec.boreholes) {
      const borehole = await db.borehole.create({
        data: {
          projectId: project.id,
          code: bh.code,
          type: bh.type,
          latitude: bh.lat,
          longitude: bh.lng,
          elevation: bh.elevation,
          depth: bh.depth,
          status: bh.status,
          drilledBy: bh.drilledBy,
          drillingDate: bh.drilledDaysAgo ? daysAgo(bh.drilledDaysAgo) : null,
          notes: bh.notes,
        },
      });
      createdProjects[spec.code].boreholes[bh.code] = borehole.id;
      counters.boreholes++;

      const layerRecords: { id: string; from: number; to: number }[] = [];
      for (const l of bh.layers ?? []) {
        const layer = await db.geologicalLayer.create({
          data: {
            boreholeId: borehole.id,
            depthFrom: l.from,
            depthTo: l.to,
            layerCode: l.code,
            materialType: l.material,
            description: l.description,
            uscs: l.uscs,
            consistency: l.consistency,
          },
        });
        layerRecords.push({ id: layer.id, from: l.from, to: l.to });
        counters.layers++;
      }

      for (const s of bh.samples ?? []) {
        const host = layerRecords.find((l) => s.from >= l.from && s.from < l.to);
        const sample = await db.sample.create({
          data: {
            boreholeId: borehole.id,
            layerId: host?.id,
            code: s.code,
            type: s.type,
            depthFrom: s.from,
            depthTo: s.to,
            recovery: s.recovery,
            labStatus: s.labStatus,
            collectedAt: bh.drilledDaysAgo ? daysAgo(bh.drilledDaysAgo) : null,
            notes: s.notes,
          },
        });
        createdProjects[spec.code].samples[`${bh.code}:${s.code}`] = sample.id;
        counters.samples++;

        for (const t of s.tests) {
          let resultData: unknown = undefined;
          if (t.result !== undefined) {
            const parsed = parseLabTestResult(t.type, t.result);
            if (!parsed.ok) {
              throw new Error(
                `Seed result failed registry validation (${spec.code}/${bh.code}/${s.code}/${t.type}): ${parsed.error}`,
              );
            }
            resultData = parsed.data;
          }
          let inputData: unknown = undefined;
          if (t.input !== undefined) {
            const parsedInput = parseLabTestInput(t.type, t.input);
            if (!parsedInput.ok) {
              throw new Error(
                `Seed input failed registry validation (${spec.code}/${bh.code}/${s.code}/${t.type}): ${parsedInput.error}`,
              );
            }
            inputData = parsedInput.data;
          }
          await db.labTest.create({
            data: {
              sampleId: sample.id,
              testType: t.type,
              status: t.result !== undefined ? "COMPLETED" : t.status ?? "PENDING",
              performedBy: t.result !== undefined ? rockEngineer.name : null,
              performedAt: t.result !== undefined ? daysAgo(Math.max(1, (bh.drilledDaysAgo ?? 5) - 2)) : null,
              resultData: (resultData as never) ?? undefined,
              inputData: (inputData as never) ?? undefined,
              summary: t.summary,
              notes: t.notes,
            },
          });
          counters.labTests++;
          if (t.result !== undefined) counters.completed++;
          else counters.pending++;
        }
      }
    }
    console.log(
      `project ${spec.code}: ${spec.boreholes.length} boreholes | cumulative boreholes=${counters.boreholes} layers=${counters.layers} samples=${counters.samples} tests=${counters.labTests}`,
    );
  }

  for (const spec of PROJECTS) {
    await seedProject(spec, geostruct.id, geoManager.id);
  }
  await seedProject(ROCKWORKS_PROJECT, rockworks.id, rockAdmin.id);

  // --- documents (files generated into private storage) ---
  const uploads = path.join(process.cwd(), "storage", "uploads");
  async function addDocument(
    orgId: string,
    projectId: string,
    boreholeId: string | null,
    uploaderId: string,
    title: string,
    docType: string,
    fileName: string,
    content: string,
    days: number,
  ) {
    const stored = `${crypto.randomUUID()}.txt`;
    await fs.writeFile(path.join(uploads, stored), content, "utf-8");
    const stat = await fs.stat(path.join(uploads, stored));
    return db.document.create({
      data: {
        organizationId: orgId,
        projectId,
        boreholeId,
        title,
        docType,
        fileName,
        filePath: `storage/uploads/${stored}`,
        fileSize: stat.size,
        mimeType: "text/plain",
        uploadedById: uploaderId,
        createdAt: daysAgo(days),
      },
    });
  }

  const A1 = createdProjects["A1-TEN-2025"];
  const METRO = createdProjects["METRO-ALG-EXT"];
  const PORT = createdProjects["PORT-ORN-TERM"];
  const BDL = createdProjects["BDL-HOSP-2024"];
  const ANNABA = createdProjects["ANNABA-IND-2026"];

  await addDocument(geostruct.id, A1.id, null, geoManager.id,
    "A1 Ténès–Chlef — Geotechnical Investigation Report (Draft)", "REPORT",
    "A1-TEN-2025_Investigation_Report_Draft.txt",
    "GEODATA HUB — seed document (demo)\n\nProject A1-TEN-2025 East–West Highway A1 — Ténès–Chlef Section\nClient: Agence Nationale des Autoroutes (ANA)\n\nDRAFT report: 6 investigation points, embankment compaction verification,\nmarl/sandstone cut-slope stability, wadi-crossing foundations.\n(This is fictional demonstration content.)", 34);
  await addDocument(geostruct.id, A1.id, A1.boreholes["BH-01"], geoEngineer.id,
    "A1 — BH-01 Borehole Log", "LAB_DATA",
    "A1_BH-01_Borehole_Log.txt",
    "BOREHOLE LOG (seed demo)\nBH-01 | Rotary core | 20.0 m | elev 38 m\nFill 0.0–0.5 m; sandy silty clay 0.5–3.2 m; clayey marl 3.2–8.4 m;\nsandstone 8.4–20.0 m (RQD 55%).\nSamples S-01..S-03.", 30);
  await addDocument(geostruct.id, METRO.id, null, geoEngineer.id,
    "Chevalley — Site Location Plan (excerpt)", "DRAWING",
    "METRO_Chevalley_SitePlan_excerpt.txt",
    "SITE PLAN EXCERPT (seed demo) — LB-01..LB-05 locations, cut-and-cover\nalignment, TBM launch shaft footprint. Coordinate system WGS84.", 22);
  await addDocument(geostruct.id, PORT.id, null, geoManager.id,
    "Oran Port — Environmental Screening Note", "CORRESPONDENCE",
    "PORT-ORN_Environmental_Screening.txt",
    "CORRESPONDENCE (seed demo) — screening note for quay extension:\nhydraulic fill handling, soft organic clay management, dredge spoil disposal.", 40);
  await addDocument(geostruct.id, BDL.id, null, geoManager.id,
    "Boumerdès Hospital — Final Investigation Report", "REPORT",
    "BDL-HOSP-2024_Final_Report.txt",
    "FINAL REPORT (seed demo) — 240-bed hospital, seismic zone RPA 99/2003.\nSpread foundations in stiff clay; liquefaction screening of SM units: not\nsusceptible. (Fictional demonstration content.)", 100);
  await addDocument(rockworks.id, ANNABA.id, null, rockAdmin.id,
    "Annaba — Laboratory Program Quotation", "CORRESPONDENCE",
    "ANNABA-IND-2026_Lab_Quotation.txt",
    "QUOTATION (seed demo) — RockWorks Laboratory proposal for index,\ncompaction and strength testing of the El Bouni verification program.", 20);
  console.log("documents: 6 (files written to storage/uploads)");

  // --- sharing requests ---
  const share1 = await db.sharingRequest.create({
    data: {
      projectId: A1.id,
      requesterId: geoManager.id,
      targetOrganizationId: rockworks.id,
      permission: "VIEW",
      status: "APPROVED",
      message: "Lab verification program for embankment materials — read access to field data requested.",
      expiresAt: daysAhead(90),
      decidedById: rockAdmin.id,
      decidedAt: daysAgo(5),
      createdAt: daysAgo(8),
    },
  });
  const share2 = await db.sharingRequest.create({
    data: {
      projectId: PORT.id,
      requesterId: geoManager.id,
      targetOrganizationId: rockworks.id,
      permission: "VIEW",
      status: "PENDING",
      message: "Would like RockWorks to review the soft-clay consolidation data before restart.",
      createdAt: daysAgo(2),
    },
  });
  await db.sharingRequest.create({
    data: {
      projectId: ANNABA.id,
      requesterId: rockAdmin.id,
      targetOrganizationId: geostruct.id,
      permission: "VIEW",
      status: "PENDING",
      message: "Requesting GeoStruct review of our El Bouni verification program data.",
      createdAt: daysAgo(1),
    },
  });
  await db.sharingRequest.create({
    data: {
      projectId: METRO.id,
      requesterId: geoManager.id,
      targetOrganizationId: rockworks.id,
      permission: "VIEW",
      status: "REJECTED",
      message: "Sharing Chevalley field data for cross-check.",
      decidedById: rockAdmin.id,
      decidedAt: daysAgo(10),
      createdAt: daysAgo(12),
    },
  });
  console.log("sharing requests: 4 (1 approved, 2 pending, 1 rejected)");

  // --- reports ---
  await db.report.create({
    data: { projectId: A1.id, reportType: "BOREHOLE_LOG", title: "Borehole log — BH-01, A1 Ténès–Chlef", generatedById: geoEngineer.id, createdAt: daysAgo(14) },
  });
  await db.report.create({
    data: { projectId: A1.id, reportType: "TEST_SUMMARY", title: "Embankment compaction summary — A1 Ténès–Chlef", generatedById: geoManager.id, createdAt: daysAgo(7) },
  });
  await db.report.create({
    data: { projectId: METRO.id, reportType: "BOREHOLE_LOG", title: "Borehole log — LB-02, Chevalley", generatedById: geoEngineer.id, createdAt: daysAgo(5) },
  });
  console.log("reports: 3");

  // --- activity feed ---
  const activity: { orgId: string; userId: string; action: string; entityType: string; entityId: string | null; details: Record<string, unknown>; days: number }[] = [
    { orgId: geostruct.id, userId: geoManager.id, action: "PROJECT_CREATED", entityType: "Project", entityId: A1.id, details: { code: "A1-TEN-2025" }, days: 42 },
    { orgId: geostruct.id, userId: geoManager.id, action: "PROJECT_CREATED", entityType: "Project", entityId: METRO.id, details: { code: "METRO-ALG-EXT" }, days: 30 },
    { orgId: geostruct.id, userId: geoManager.id, action: "PROJECT_CREATED", entityType: "Project", entityId: PORT.id, details: { code: "PORT-ORN-TERM" }, days: 55 },
    { orgId: geostruct.id, userId: geoEngineer.id, action: "BOREHOLE_CREATED", entityType: "Borehole", entityId: A1.boreholes["BH-01"] ?? null, details: { code: "BH-01" }, days: 36 },
    { orgId: geostruct.id, userId: geoEngineer.id, action: "BOREHOLE_CREATED", entityType: "Borehole", entityId: METRO.boreholes["LB-01"] ?? null, details: { code: "LB-01" }, days: 25 },
    { orgId: geostruct.id, userId: geoEngineer.id, action: "LAB_TEST_RESULT_RECORDED", entityType: "LabTest", entityId: null, details: { testType: "PROCTOR", sampleCode: "BH-01/S-01" }, days: 20 },
    { orgId: geostruct.id, userId: geoEngineer.id, action: "LAB_TEST_RESULT_RECORDED", entityType: "LabTest", entityId: null, details: { testType: "CBR", sampleCode: "BH-01/S-01" }, days: 19 },
    { orgId: geostruct.id, userId: geoManager.id, action: "SHARE_REQUESTED", entityType: "SharingRequest", entityId: share1.id, details: { projectCode: "A1-TEN-2025", targetOrganization: "RockWorks Laboratory" }, days: 8 },
    { orgId: rockworks.id, userId: rockAdmin.id, action: "SHARE_APPROVED", entityType: "SharingRequest", entityId: share1.id, details: { projectCode: "A1-TEN-2025" }, days: 5 },
    { orgId: geostruct.id, userId: geoEngineer.id, action: "DOCUMENT_UPLOADED", entityType: "Document", entityId: null, details: { title: "A1 Ténès–Chlef — Geotechnical Investigation Report (Draft)" }, days: 34 },
    { orgId: geostruct.id, userId: geoManager.id, action: "REPORT_GENERATED", entityType: "Report", entityId: null, details: { title: "Embankment compaction summary — A1 Ténès–Chlef" }, days: 7 },
    { orgId: rockworks.id, userId: rockAdmin.id, action: "PROJECT_CREATED", entityType: "Project", entityId: ANNABA.id, details: { code: "ANNABA-IND-2026" }, days: 25 },
    { orgId: geostruct.id, userId: geoManager.id, action: "SHARE_REQUESTED", entityType: "SharingRequest", entityId: share2.id, details: { projectCode: "PORT-ORN-TERM", targetOrganization: "RockWorks Laboratory" }, days: 2 },
    { orgId: geostruct.id, userId: geoEngineer.id, action: "BOREHOLE_CREATED", entityType: "Borehole", entityId: METRO.boreholes["LB-05"] ?? null, details: { code: "LB-05" }, days: 3 },
    { orgId: geostruct.id, userId: geoEngineer.id, action: "LAB_TEST_RESULT_RECORDED", entityType: "LabTest", entityId: null, details: { testType: "CPT", sampleCode: "LB-05/CPT-R1" }, days: 2 },
  ];
  for (const a of activity) {
    await db.activityLog.create({
      data: {
        organizationId: a.orgId,
        userId: a.userId,
        action: a.action,
        entityType: a.entityType,
        entityId: a.entityId,
        details: a.details as never,
        createdAt: daysAgo(a.days),
      },
    });
  }
  console.log("activity entries: " + activity.length);

  // --- summary ---
  const [orgs, users, projects, boreholes, layers, samples, tests, docs, shares, reports, acts] =
    await Promise.all([
      db.organization.count(),
      db.user.count(),
      db.project.count(),
      db.borehole.count(),
      db.geologicalLayer.count(),
      db.sample.count(),
      db.labTest.count(),
      db.document.count(),
      db.sharingRequest.count(),
      db.report.count(),
      db.activityLog.count(),
    ]);
  const byType = await db.labTest.groupBy({ by: ["testType"], _count: { _all: true } });
  console.log("\n================ SEED COMPLETE ================");
  console.log(`organizations=${orgs} users=${users} projects=${projects} boreholes=${boreholes}`);
  console.log(`layers=${layers} samples=${samples} labTests=${tests} (completed=${counters.completed}, pending/in-progress=${counters.pending})`);
  console.log(`documents=${docs} sharingRequests=${shares} reports=${reports} activity=${acts}`);
  console.log("tests by type: " + byType.map((t) => `${t.testType}=${t._count._all}`).join(", "));
  console.log("demo password for all users: " + DEMO_PASSWORD);
}

main()
  .catch((e) => {
    console.error("SEED FAILED:", e);
    process.exitCode = 1;
  })
  .finally(() => db.$disconnect());

