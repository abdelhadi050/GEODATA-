/**
 * GET /api/documents — list documents of accessible projects (own +
 * actively shared), newest first. `filePath` (internal storage path) is
 * stripped from every item — clients download through the API only.
 */
import { withApi, omit } from "@/lib/api/api-utils";
import { apiSuccess, listMeta } from "@/lib/api/api-response";
import { requireUser } from "@/lib/api/api-auth";
import { parseQuery } from "@/lib/api/api-validation";
import { documentsQuery } from "@/lib/api/schemas";
import { listDocuments } from "@/lib/services/documents";

export const GET = withApi(async (req) => {
  const user = await requireUser();
  const q = parseQuery(req, documentsQuery);
  const result = await listDocuments(user, q);
  return apiSuccess(result.items.map((d) => omit(d, ["filePath"])), {
    meta: listMeta(result),
  });
});
