/**
 * POST /api/documents/upload — secure multipart upload (M3).
 *
 * Security pipeline (in order):
 *   1. Authentication + DOCUMENT_MANAGE authorization BEFORE the file is
 *      accepted or written.
 *   2. Early size gate on Content-Length (413) — oversized bodies are
 *      rejected without being buffered; the uploaded File.size is
 *      re-checked after parsing.
 *   3. Field validation with Zod (projectId / title / docType / fileName;
 *      fileName is path-traversal hardened).
 *   4. Type validation: the DECLARED MIME type must be in the allowlist
 *      (415 otherwise) AND consistent with the file's actual magic bytes
 *      (415 on mismatch). Plain-text types additionally require a
 *      matching extension. The stored extension derives from the
 *      validated MIME type, never from the client filename.
 *   5. Storage under a generated UUID name inside storage/uploads (path
 *      traversal impossible); metadata is registered through the M2
 *      document service, which re-validates project/borehole ownership
 *      for the actor's organization and logs DOCUMENT_UPLOADED.
 *   6. If metadata registration fails (e.g. foreign project → 404), the
 *      already-written file is removed again — no orphans.
 *
 * The response never contains the physical storage path.
 */
import crypto from "node:crypto";
import fs from "node:fs/promises";
import path from "node:path";
import { withApi } from "@/lib/api/api-utils";
import { apiSuccess } from "@/lib/api/api-response";
import { requireUser, requireCapability } from "@/lib/api/api-auth";
import { Errors, AppError } from "@/lib/errors";
import { CAPABILITIES } from "@/lib/rbac";
import { uploadMeta } from "@/lib/api/schemas";
import { parseOrThrow } from "@/lib/validation/parse";
import { createDocument, STORAGE_ROOT } from "@/lib/services/documents";
import { MAX_DOCUMENT_BYTES, ALLOWED_MIME_TYPES } from "@/lib/validation/document";
import { omit } from "@/lib/api/api-utils";

const EXTENSION_BY_MIME: Record<string, string> = {
  "application/pdf": ".pdf",
  "text/plain": ".txt",
  "text/csv": ".csv",
  "image/png": ".png",
  "image/jpeg": ".jpg",
  "image/webp": ".webp",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document": ".docx",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": ".xlsx",
  "application/zip": ".zip",
};

/** Hard ceiling for the early Content-Length gate (pathological sizes only;
 *  legitimate oversize is rejected cleanly after parsing). */
const HARD_UPLOAD_CEILING = 50 * 1024 * 1024;
const TEXT_MIMES = new Set(["text/plain", "text/csv"]);
const TEXT_EXTENSIONS = new Set([".txt", ".csv"]);
const ZIP_FAMILY_MIMES = new Set([
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  "application/zip",
]);

/** Normalize a declared MIME type (strip parameters like ";charset=utf-8"). */
function normalizeMime(value: string): string {
  return value.split(";")[0].trim().toLowerCase();
}

const tooLarge = () =>
  new AppError(
    "PAYLOAD_TOO_LARGE",
    413,
    `File exceeds the maximum allowed size (${Math.round(MAX_DOCUMENT_BYTES / (1024 * 1024))} MB)`,
  );

const unsupported = (message: string) =>
  new AppError("UNSUPPORTED_MEDIA_TYPE", 415, message);

/** Content sniffing — returns a content family (never trusts the client). */
function sniffFamily(bytes: Uint8Array): string {
  const startsWith = (...prefix: number[]) =>
    prefix.every((b, i) => bytes[i] === b);
  if (startsWith(0x25, 0x50, 0x44, 0x46)) return "pdf"; // %PDF
  if (startsWith(0x89, 0x50, 0x4e, 0x47)) return "png";
  if (startsWith(0xff, 0xd8, 0xff)) return "jpeg";
  if (
    startsWith(0x52, 0x49, 0x46, 0x46) &&
    bytes[8] === 0x57 && bytes[9] === 0x45 && bytes[10] === 0x42 && bytes[11] === 0x50
  ) {
    return "webp"; // RIFF....WEBP
  }
  if (startsWith(0x50, 0x4b, 0x03, 0x04) || startsWith(0x50, 0x4b, 0x05, 0x06)) {
    return "zip"; // docx / xlsx / zip containers
  }
  return "unknown"; // plain text and everything else
}

function mimeFamily(mime: string): string {
  switch (mime) {
    case "application/pdf": return "pdf";
    case "image/png": return "png";
    case "image/jpeg": return "jpeg";
    case "image/webp": return "webp";
    default: return ZIP_FAMILY_MIMES.has(mime) ? "zip" : "unknown";
  }
}

export const POST = withApi(async (req) => {
  // 1. Authenticate + authorize before accepting the file.
  const user = await requireUser();
  requireCapability(user, CAPABILITIES.DOCUMENT_MANAGE);

  // 2. Early size gate for pathological bodies only (50 MB+); the precise
  //    per-file limit is enforced after parsing so clients receive a clean,
  //    readable 413 envelope.
  const declaredLength = Number(req.headers.get("content-length") ?? "0");
  if (declaredLength > HARD_UPLOAD_CEILING) throw tooLarge();

  // 3. Parse the multipart form.
  let form: FormData;
  try {
    form = await req.formData();
  } catch {
    throw Errors.validation("Malformed multipart form data");
  }

  const file = form.get("file");
  if (!(file instanceof File)) {
    throw Errors.validation("A file field is required");
  }

  const rawFields: Record<string, string> = {};
  for (const key of ["projectId", "boreholeId", "title", "docType", "fileName", "mimeType"]) {
    const value = form.get(key);
    if (typeof value === "string" && value.length > 0) rawFields[key] = value;
  }
  // Metadata filename: explicit field wins, otherwise the uploaded file's name.
  rawFields.fileName = rawFields.fileName ?? file.name;

  const meta = parseOrThrow(uploadMeta, {
    projectId: rawFields.projectId,
    boreholeId: rawFields.boreholeId,
    title: rawFields.title,
    docType: rawFields.docType,
    fileName: rawFields.fileName,
  });

  // 4. Exact size checks (post-parse).
  if (file.size < 1) throw Errors.validation("File is empty");
  if (file.size > MAX_DOCUMENT_BYTES) throw tooLarge();

  // 5. Type checks: declared MIME allowlist + magic-byte consistency.
  //    Normalize first — clients may append parameters (";charset=utf-8").
  const declaredMime = normalizeMime(rawFields.mimeType ?? file.type ?? "");
  if (!(ALLOWED_MIME_TYPES as readonly string[]).includes(declaredMime)) {
    throw unsupported("Unsupported file type");
  }
  // Membership proven above — narrow to the allowlist union type.
  const mimeType = declaredMime as (typeof ALLOWED_MIME_TYPES)[number];
  const header = new Uint8Array(await file.slice(0, 16).arrayBuffer());
  const sniffed = sniffFamily(header);
  const expected = mimeFamily(mimeType);
  if (sniffed !== "unknown") {
    if (sniffed !== expected) {
      throw unsupported("File content does not match its declared type");
    }
  } else {
    // Text families cannot be sniffed by magic bytes: require a text
    // declaration and a matching extension.
    if (!TEXT_MIMES.has(mimeType)) {
      throw unsupported("File content does not match its declared type");
    }
    const ext = path.extname(rawFields.fileName).toLowerCase();
    if (!TEXT_EXTENSIONS.has(ext)) {
      throw unsupported("Plain-text uploads require a .txt or .csv filename");
    }
  }

  // 6. Store under a generated name; extension derived from the VALIDATED
  //    MIME type (never from the client-controlled filename).
  const storedName = `${crypto.randomUUID()}${EXTENSION_BY_MIME[mimeType]}`;
  await fs.mkdir(STORAGE_ROOT, { recursive: true });
  const bytes = new Uint8Array(await file.arrayBuffer());
  await fs.writeFile(path.join(STORAGE_ROOT, storedName), bytes);

  // 7. Register metadata through the service (re-validates ownership,
  //    RBAC, filename safety, stored-name format, and logs the upload).
  try {
    const document = await createDocument(
      user,
      {
        projectId: meta.projectId,
        boreholeId: meta.boreholeId,
        title: meta.title,
        docType: meta.docType,
        fileName: meta.fileName,
        mimeType,
        fileSize: file.size,
      },
      storedName,
    );
    return apiSuccess(omit(document, ["filePath"]), { status: 201 });
  } catch (err) {
    // Roll back the stored file so failed uploads leave no orphans.
    try {
      await fs.unlink(path.join(STORAGE_ROOT, storedName));
    } catch {
      // best effort
    }
    throw err;
  }
});
