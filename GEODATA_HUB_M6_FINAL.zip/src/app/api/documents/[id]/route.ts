/**
 * /api/documents/[id] — metadata detail / update / delete.
 * Detail is readable through approved project shares (service-enforced);
 * mutations require ownership. The internal `filePath` is stripped from
 * every response — files are only reachable via the download endpoint.
 */
import { withApi, omit } from "@/lib/api/api-utils";
import { apiSuccess } from "@/lib/api/api-response";
import { requireUser } from "@/lib/api/api-auth";
import { parseJsonBody, requireId } from "@/lib/api/api-validation";
import { updateDocumentBody } from "@/lib/api/schemas";
import {
  getDocument,
  updateDocument,
  deleteDocument,
} from "@/lib/services/documents";

export const GET = withApi(async (_req, ctx) => {
  const user = await requireUser();
  const { id } = await ctx.params;
  const document = await getDocument(user, requireId(id));
  return apiSuccess(omit(document, ["filePath"]));
});

export const PATCH = withApi(async (req, ctx) => {
  const user = await requireUser();
  const { id } = await ctx.params;
  const body = await parseJsonBody(req, updateDocumentBody);
  const document = await updateDocument(user, requireId(id), body);
  return apiSuccess(omit(document, ["filePath"]));
});

export const DELETE = withApi(async (_req, ctx) => {
  const user = await requireUser();
  const { id } = await ctx.params;
  const result = await deleteDocument(user, requireId(id));
  return apiSuccess(result);
});
