/**
 * GET /api/documents/[id]/download — stream a stored document (M3).
 *
 * Security:
 *   - Authentication + DOCUMENT_DOWNLOAD capability on every request.
 *   - Access = own-organization document OR an approved, non-expired
 *     share of the parent project (service-enforced; everything else is
 *     404 so foreign documents are indistinguishable from missing ones).
 *   - The file resolves through the hardened storage-path resolver
 *     (traversal outside storage/uploads is impossible), and streams
 *     with safe Content-Type / Content-Disposition headers. No direct
 *     storage URL is ever exposed.
 *   - A missing backing file returns 404 without revealing any path.
 */
import fs from "node:fs/promises";
import { withApi } from "@/lib/api/api-utils";
import { requireUser, requireCapability } from "@/lib/api/api-auth";
import { requireId } from "@/lib/api/api-validation";
import { Errors } from "@/lib/errors";
import { CAPABILITIES } from "@/lib/rbac";
import { getDocument, resolveStoragePath } from "@/lib/services/documents";

export const GET = withApi(async (_req, ctx) => {
  const user = await requireUser();
  requireCapability(user, CAPABILITIES.DOCUMENT_DOWNLOAD);
  const { id } = await ctx.params;
  const document = await getDocument(user, requireId(id));

  let bytes: Buffer;
  try {
    const abs = resolveStoragePath(
      document.filePath.replace(/^storage\/uploads\//, ""),
    );
    bytes = await fs.readFile(abs);
  } catch {
    throw Errors.notFound("Document file");
  }

  // Copy into a standalone ArrayBuffer (BodyInit-compatible).
  const body = new ArrayBuffer(bytes.byteLength);
  new Uint8Array(body).set(bytes);

  // ASCII-safe fallback name (validated charset at upload time anyway).
  const safeName = document.fileName.replace(/[^\w\-. ()[\]]+/g, "_");

  return new Response(body, {
    status: 200,
    headers: {
      "Content-Type": document.mimeType,
      "Content-Length": String(bytes.length),
      "Content-Disposition": `attachment; filename="${safeName}"`,
      "Cache-Control": "private, no-store",
      "X-Content-Type-Options": "nosniff",
    },
  });
});
