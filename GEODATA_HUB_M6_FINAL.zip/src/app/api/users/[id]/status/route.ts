/**
 * PATCH /api/users/[id]/status — activate / deactivate a team member.
 * RBAC: TEAM_MANAGE (service-enforced, incl. self-deactivation and
 * last-active-admin guards). Deactivation takes effect on the target's
 * next request (DB-fresh sessions).
 */
import { withApi } from "@/lib/api/api-utils";
import { apiSuccess } from "@/lib/api/api-response";
import { requireUser } from "@/lib/api/api-auth";
import { parseJsonBody, requireId } from "@/lib/api/api-validation";
import { userStatusBody } from "@/lib/api/schemas";
import { setUserActive } from "@/lib/services/organizations";

export const PATCH = withApi(async (req, ctx) => {
  const user = await requireUser();
  const { id } = await ctx.params;
  const body = await parseJsonBody(req, userStatusBody);
  const updated = await setUserActive(user, requireId(id, "user id"), body.isActive);
  return apiSuccess(updated);
});
