/**
 * PATCH /api/users/[id]/role — change a team member's role.
 * RBAC: TEAM_MANAGE (service-enforced). Target must belong to the
 * actor's organization (foreign users surface as 404). Role values are
 * validated by the service against ALL_ROLES.
 */
import { withApi } from "@/lib/api/api-utils";
import { apiSuccess } from "@/lib/api/api-response";
import { requireUser } from "@/lib/api/api-auth";
import { parseJsonBody, requireId } from "@/lib/api/api-validation";
import { userRoleBody } from "@/lib/api/schemas";
import { changeUserRole } from "@/lib/services/organizations";
import type { Role } from "@/lib/constants";

export const PATCH = withApi(async (req, ctx) => {
  const user = await requireUser();
  const { id } = await ctx.params;
  const body = await parseJsonBody(req, userRoleBody);
  const updated = await changeUserRole(user, requireId(id, "user id"), body.role as Role);
  return apiSuccess(updated);
});
