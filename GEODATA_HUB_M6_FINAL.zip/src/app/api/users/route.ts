/**
 * GET /api/users — team directory of the actor's own organization.
 * RBAC: TEAM_VIEW (service-enforced). Never exposes password hashes —
 * the service selects safe fields only.
 */
import { withApi } from "@/lib/api/api-utils";
import { apiSuccess } from "@/lib/api/api-response";
import { requireUser } from "@/lib/api/api-auth";
import { parseQuery } from "@/lib/api/api-validation";
import { usersQuery } from "@/lib/api/schemas";
import { listOrganizationUsers } from "@/lib/services/organizations";

export const GET = withApi(async (req) => {
  const user = await requireUser();
  const q = parseQuery(req, usersQuery);
  const users = await listOrganizationUsers(user, q);
  return apiSuccess(users, { meta: { total: users.length } });
});
