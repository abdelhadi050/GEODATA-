/**
 * GET /api/calculations/[id] — calculation record detail (full snapshot:
 * input, output, warnings, engine provenance, registry standard/units and
 * lab-test context). Tenancy is resolved through the lab-test access chain
 * (own organization or approved project share); foreign records surface as
 * NOT_FOUND — no existence leak.
 */
import { withApi } from "@/lib/api/api-utils";
import { apiSuccess } from "@/lib/api/api-response";
import { requireUser } from "@/lib/api/api-auth";
import { requireId } from "@/lib/api/api-validation";
import { getCalculation } from "@/lib/services/calculations";

export const GET = withApi(async (_req, ctx) => {
  const user = await requireUser();
  const { id } = await ctx.params;
  const { calculation, accessSource } = await getCalculation(user, requireId(id));
  return apiSuccess({ ...calculation, accessSource });
});
