/**
 * GET /api/calculations/engines — the calculation engine registry
 * (discovery): every registered module with its id, test type, label,
 * description and engine/module versions. Static route segment takes
 * precedence over [id]. Authenticated users only (mirrors
 * /api/lab-tests/registry); no tenant data involved.
 */
import { withApi } from "@/lib/api/api-utils";
import { apiSuccess } from "@/lib/api/api-response";
import { requireUser } from "@/lib/api/api-auth";
import { listCalcModules } from "@/lib/calc/registry";

export const GET = withApi(async () => {
  await requireUser();
  const engines = listCalcModules();
  return apiSuccess(engines, { meta: { total: engines.length } });
});
