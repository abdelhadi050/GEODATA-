/**
 * POST /api/layers — add a geological layer to an own-org borehole.
 * RBAC: LAYER_MANAGE (service-enforced, incl. overlap and depth checks).
 */
import { withApi } from "@/lib/api/api-utils";
import { apiSuccess } from "@/lib/api/api-response";
import { requireUser } from "@/lib/api/api-auth";
import { parseJsonBody } from "@/lib/api/api-validation";
import { createLayerBody } from "@/lib/api/schemas";
import { createLayer } from "@/lib/services/layers";

export const POST = withApi(async (req) => {
  const user = await requireUser();
  const body = await parseJsonBody(req, createLayerBody);
  const layer = await createLayer(user, body);
  return apiSuccess(layer, { status: 201 });
});
