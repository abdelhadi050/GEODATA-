/**
 * /api/layers/[id] — update / delete a geological layer (own org only).
 * Overlap and depth validations run in the service.
 */
import { withApi } from "@/lib/api/api-utils";
import { apiSuccess } from "@/lib/api/api-response";
import { requireUser } from "@/lib/api/api-auth";
import { parseJsonBody, requireId } from "@/lib/api/api-validation";
import { updateLayerBody } from "@/lib/api/schemas";
import { updateLayer, deleteLayer } from "@/lib/services/layers";

export const PATCH = withApi(async (req, ctx) => {
  const user = await requireUser();
  const { id } = await ctx.params;
  const body = await parseJsonBody(req, updateLayerBody);
  const layer = await updateLayer(user, requireId(id), body);
  return apiSuccess(layer);
});

export const DELETE = withApi(async (_req, ctx) => {
  const user = await requireUser();
  const { id } = await ctx.params;
  const result = await deleteLayer(user, requireId(id));
  return apiSuccess(result);
});
