/**
 * GEODATA HUB — health / diagnostics (public, unauthenticated).
 * Normalized into the M3 API envelope. The DB probe doubles as the
 * readiness check used by the test scripts.
 */
import { db } from "@/lib/db";
import { apiSuccess, apiError } from "@/lib/api/api-response";

export async function GET() {
  try {
    await db.user.count();
    return apiSuccess({
      status: "ok",
      service: "geodata-hub",
      db: "reachable",
      auth: "nextauth-v4",
      api: "v1",
    });
  } catch {
    return apiError("SERVICE_UNAVAILABLE", "Service is degraded", 503);
  }
}
