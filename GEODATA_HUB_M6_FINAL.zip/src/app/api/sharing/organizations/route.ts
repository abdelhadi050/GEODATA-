/**
 * GET /api/sharing/organizations — organizations available as share
 * targets for cross-organization collaboration (excludes the actor's
 * own). RBAC: SHARING_MANAGE (service-enforced).
 */
import { withApi } from "@/lib/api/api-utils";
import { apiSuccess } from "@/lib/api/api-response";
import { requireUser } from "@/lib/api/api-auth";
import { listShareableOrganizations } from "@/lib/services/sharing";

export const GET = withApi(async () => {
  const user = await requireUser();
  const organizations = await listShareableOrganizations(user);
  return apiSuccess(organizations, { meta: { total: organizations.length } });
});
