/**
 * /api/sharing/requests — list + create.
 *
 * RBAC (route-level, per the RBAC matrix): SHARING_MANAGE
 * (PROJECT_MANAGER and ORG_ADMIN). Engineers and viewers can still SEE
 * shared content through the project endpoints — sharing administration
 * itself is a management capability.
 *
 * Flow: the OWNING organization creates a request; the TARGET
 * organization decides (approve/reject); the owner can revoke.
 */
import { withApi } from "@/lib/api/api-utils";
import { apiSuccess } from "@/lib/api/api-response";
import { requireUser, requireCapability } from "@/lib/api/api-auth";
import { parseJsonBody } from "@/lib/api/api-validation";
import { createSharingRequestBody } from "@/lib/api/schemas";
import { CAPABILITIES } from "@/lib/rbac";
import {
  listSharingRequests,
  createSharingRequest,
} from "@/lib/services/sharing";

export const GET = withApi(async () => {
  const user = await requireUser();
  requireCapability(user, CAPABILITIES.SHARING_MANAGE);
  const { sent, inbox } = await listSharingRequests(user);
  return apiSuccess({ sent, inbox }, { meta: { total: sent.length + inbox.length } });
});

export const POST = withApi(async (req) => {
  const user = await requireUser();
  const body = await parseJsonBody(req, createSharingRequestBody);
  const request = await createSharingRequest(user, body);
  return apiSuccess(request, { status: 201 });
});
