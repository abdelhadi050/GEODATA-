/**
 * POST /api/sharing/requests/[id]/decision — approve or reject a
 * pending incoming request. RBAC: SHARING_DECIDE, and only the TARGET
 * organization may decide (service-enforced boundary).
 */
import { withApi } from "@/lib/api/api-utils";
import { apiSuccess } from "@/lib/api/api-response";
import { requireUser } from "@/lib/api/api-auth";
import { parseJsonBody, requireId } from "@/lib/api/api-validation";
import { sharingDecisionBody } from "@/lib/api/schemas";
import { decideSharingRequest } from "@/lib/services/sharing";

export const POST = withApi(async (req, ctx) => {
  const user = await requireUser();
  const { id } = await ctx.params;
  const body = await parseJsonBody(req, sharingDecisionBody);
  const request = await decideSharingRequest(user, requireId(id), body.decision);
  return apiSuccess(request);
});
