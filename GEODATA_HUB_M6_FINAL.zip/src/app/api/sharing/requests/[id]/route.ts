/**
 * DELETE /api/sharing/requests/[id] — revoke a pending or approved
 * share. RBAC: SHARING_MANAGE, and only the OWNING organization may
 * revoke (service-enforced boundary). Revocation cuts read access for
 * the target organization immediately.
 */
import { withApi } from "@/lib/api/api-utils";
import { apiSuccess } from "@/lib/api/api-response";
import { requireUser } from "@/lib/api/api-auth";
import { requireId } from "@/lib/api/api-validation";
import { revokeSharingRequest } from "@/lib/services/sharing";

export const DELETE = withApi(async (_req, ctx) => {
  const user = await requireUser();
  const { id } = await ctx.params;
  const request = await revokeSharingRequest(user, requireId(id));
  return apiSuccess(request);
});
