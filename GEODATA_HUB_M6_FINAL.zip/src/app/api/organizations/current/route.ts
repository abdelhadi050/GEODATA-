/**
 * GET /api/organizations/current — the authenticated user's organization.
 * Organization identity derives from the session (never client input);
 * there is deliberately no "list all organizations" endpoint, and no
 * organization deletion endpoint (audit preservation — see docs/10 §7).
 */
import { withApi } from "@/lib/api/api-utils";
import { apiSuccess } from "@/lib/api/api-response";
import { requireUser } from "@/lib/api/api-auth";
import { getOrganization } from "@/lib/services/organizations";

export const GET = withApi(async () => {
  const user = await requireUser();
  const organization = await getOrganization(user);
  return apiSuccess(organization);
});
