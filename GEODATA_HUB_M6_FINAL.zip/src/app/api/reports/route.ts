/**
 * /api/reports — list + create.
 * List: reports of accessible projects (own + actively shared).
 * RBAC: REPORT_VIEW to list/read (route guard, all roles per matrix);
 * REPORT_GENERATE to create (service-enforced).
 *
 * M5.4 extension: POST accepts an extended body with optional sampleId /
 * boreholeId / generatePdf. The M2-M5.3 body shape (projectId, reportType,
 * title) remains accepted for backward compatibility — the new fields are
 * strictly optional. When `generatePdf` is true (default), the PDF is
 * generated in the same request and the row is returned with status
 * GENERATED.
 */
import { withApi } from "@/lib/api/api-utils";
import { apiSuccess } from "@/lib/api/api-response";
import { requireUser, requireCapability } from "@/lib/api/api-auth";
import { parseQuery, parseJsonBody } from "@/lib/api/api-validation";
import { reportsQuery, createReportBodyM5_4 } from "@/lib/api/schemas";
import { CAPABILITIES } from "@/lib/rbac";
import { listReports, createReport } from "@/lib/services/reports";

export const GET = withApi(async (req) => {
  const user = await requireUser();
  requireCapability(user, CAPABILITIES.REPORT_VIEW);
  const q = parseQuery(req, reportsQuery);
  const reports = await listReports(user, q);
  return apiSuccess(reports, { meta: { total: reports.length } });
});

export const POST = withApi(async (req) => {
  const user = await requireUser();
  const body = await parseJsonBody(req, createReportBodyM5_4);
  const result = await createReport(user, body);
  return apiSuccess(result, { status: 201 });
});
