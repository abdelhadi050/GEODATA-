/**
 * GET /api/reports/:id/pdf — download the generated PDF.
 *
 * Streams the PDF file (under storage/reports/<reportId>.pdf) to the client
 * with the correct Content-Type and Content-Disposition headers.
 *
 * RBAC: REPORT_VIEW on a report whose project is own or actively shared
 * (service-enforced via getReport, which throws NOT_FOUND when the project
 * is inaccessible — no existence leak).
 *
 * Returns 404 when the report exists but has no PDF yet (status = DRAFT).
 */
import { withApi } from "@/lib/api/api-utils";
import { apiError } from "@/lib/api/api-response";
import { requireUser, requireCapability } from "@/lib/api/api-auth";
import { requireId } from "@/lib/api/api-validation";
import { CAPABILITIES } from "@/lib/rbac";
import { getReport } from "@/lib/services/reports";
import { Errors } from "@/lib/errors";
import fs from "node:fs/promises";
import path from "node:path";

export const GET = withApi(async (_req, ctx) => {
  const user = await requireUser();
  requireCapability(user, CAPABILITIES.REPORT_VIEW);
  const { id } = await ctx.params;
  const report = await getReport(user, requireId(id));

  if (!report.pdfStoragePath || !report.pdfGeneratedAt) {
    throw Errors.notFound("Report PDF — the report has not been generated yet");
  }

  const absolutePath = path.resolve(process.cwd(), "storage", report.pdfStoragePath);
  // Prevent path traversal — the storagePath is server-controlled but
  // defensive validation is still in order.
  const storageRoot = path.resolve(process.cwd(), "storage");
  const resolved = path.resolve(absolutePath);
  if (!resolved.startsWith(storageRoot + path.sep) && resolved !== storageRoot) {
    throw Errors.validation("Invalid PDF storage path");
  }

  let data: Buffer;
  try {
    data = await fs.readFile(absolutePath);
  } catch {
    throw Errors.notFound("Report PDF file");
  }

  const filename = `${report.title.replace(/[^A-Za-z0-9-_]+/g, "_").slice(0, 60)}_v${report.version}.pdf`;
  return new Response(new Uint8Array(data), {
    status: 200,
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `attachment; filename="${filename}"`,
      "Content-Length": String(data.byteLength),
      "Cache-Control": "private, no-store",
      "X-Content-Type-Options": "nosniff",
    },
  });
});

// Suppress the unused-import warning for apiError (kept for consistency with
// the project's API envelope conventions; this route streams binary PDF data
// and bypasses the JSON envelope).
void apiError;
