/**
 * GET /api/reports/:id — report detail, readable when the parent
 * project is own or actively shared (service-enforced boundary).
 *
 * M5.4: the detail payload now carries status, version, sampleId/boreholeId,
 * contentSnapshot, pdfStoragePath, pdfGeneratedAt, pdfFileSize, pdfPageCount.
 */
import { withApi } from "@/lib/api/api-utils";
import { apiSuccess } from "@/lib/api/api-response";
import { requireUser, requireCapability } from "@/lib/api/api-auth";
import { requireId } from "@/lib/api/api-validation";
import { CAPABILITIES } from "@/lib/rbac";
import { getReport } from "@/lib/services/reports";

export const GET = withApi(async (_req, ctx) => {
  const user = await requireUser();
  requireCapability(user, CAPABILITIES.REPORT_VIEW);
  const { id } = await ctx.params;
  const report = await getReport(user, requireId(id));
  return apiSuccess(report);
});
