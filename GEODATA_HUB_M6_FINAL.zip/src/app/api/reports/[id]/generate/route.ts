/**
 * POST /api/reports/:id/generate — render (or re-render) the PDF for a report.
 *
 * When the report is currently DRAFT, this renders the PDF in place and
 * promotes the row to GENERATED.
 *
 * When the report is already GENERATED, this creates a NEW version row
 * (version+1) with the freshly-rendered PDF — historical reports are
 * preserved (a regeneration never overwrites a previous generation).
 *
 * RBAC: REPORT_GENERATE on an own-organization report (service-enforced).
 *
 * Response: 200 with the new/updated report detail + pdfGenerated=true.
 */
import { withApi } from "@/lib/api/api-utils";
import { apiSuccess } from "@/lib/api/api-response";
import { requireUser, requireCapability } from "@/lib/api/api-auth";
import { requireId } from "@/lib/api/api-validation";
import { CAPABILITIES } from "@/lib/rbac";
import { generateReportPdfNow } from "@/lib/services/reports";

export const POST = withApi(async (_req, ctx) => {
  const user = await requireUser();
  requireCapability(user, CAPABILITIES.REPORT_GENERATE);
  const { id } = await ctx.params;
  const result = await generateReportPdfNow(user, requireId(id));
  return apiSuccess(result, { status: 201 });
});
