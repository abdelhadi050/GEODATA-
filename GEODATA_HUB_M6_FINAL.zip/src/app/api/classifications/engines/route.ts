/**
 * GET /api/classifications/engines — discovery endpoint.
 *
 * Lists every registered classification module (USCS, AASHTO) with its
 * module id, version, standard citation, and engine version. Mirrors
 * /api/calculations/engines (M5.2 Integration) exactly.
 *
 * RBAC: any authenticated user can discover engines (no project context).
 */
import { withApi } from "@/lib/api/api-utils";
import { apiSuccess } from "@/lib/api/api-response";
import { requireUser } from "@/lib/api/api-auth";
import { listClassModules } from "@/lib/classification/registry";

export const GET = withApi(async () => {
  await requireUser();
  const engines = listClassModules();
  return apiSuccess(engines, { meta: { total: engines.length } });
});
