/**
 * GET /api/classifications/:id — classification detail by record id.
 *
 * Tenancy is enforced via the sample access chain: the record's sampleId
 * is resolved against the actor's accessible samples (own org or actively
 * shared project). Foreign records surface as 404 (no existence leak).
 *
 * Mirrors /api/calculations/:id (M5.2 Integration).
 */
import { withApi } from "@/lib/api/api-utils";
import { apiSuccess } from "@/lib/api/api-response";
import { requireUser, requireCapability } from "@/lib/api/api-auth";
import { requireId } from "@/lib/api/api-validation";
import { CAPABILITIES } from "@/lib/rbac";
import { getClassification } from "@/lib/services/classifications";

export const GET = withApi(async (_req, ctx) => {
  const user = await requireUser();
  requireCapability(user, CAPABILITIES.LAB_TEST_VIEW);
  const { id } = await ctx.params;
  const result = await getClassification(user, requireId(id));
  return apiSuccess(result.classification, {
    meta: { accessSource: result.accessSource },
  });
});
