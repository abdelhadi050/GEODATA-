/**
 * GET /api/activity — the actor's own-organization activity feed
 * (append-only audit trail). Any authenticated, active user may read
 * their organization's feed; entries never contain secrets or paths.
 */
import { withApi } from "@/lib/api/api-utils";
import { apiSuccess } from "@/lib/api/api-response";
import { requireUser } from "@/lib/api/api-auth";
import { parseQuery } from "@/lib/api/api-validation";
import { activityQuery } from "@/lib/api/schemas";
import { listActivity } from "@/lib/services/activity";

export const GET = withApi(async (req) => {
  const user = await requireUser();
  const q = parseQuery(req, activityQuery);
  const entries = await listActivity(user, q.limit ?? 20);
  return apiSuccess(entries, { meta: { total: entries.length } });
});
