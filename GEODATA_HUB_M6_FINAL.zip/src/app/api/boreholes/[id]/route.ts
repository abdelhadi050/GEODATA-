/**
 * /api/boreholes/[id] — detail / update / delete.
 * Detail includes layers, samples (with lab tests) and documents, and is
 * readable through approved shares. Mutations require ownership.
 */
import { withApi, omit } from "@/lib/api/api-utils";
import { apiSuccess } from "@/lib/api/api-response";
import { requireUser } from "@/lib/api/api-auth";
import { parseJsonBody, requireId } from "@/lib/api/api-validation";
import { updateBoreholeBody } from "@/lib/api/schemas";
import {
  getBorehole,
  updateBorehole,
  deleteBorehole,
} from "@/lib/services/boreholes";

export const GET = withApi(async (_req, ctx) => {
  const user = await requireUser();
  const { id } = await ctx.params;
  const borehole = await getBorehole(user, requireId(id));
  // Embedded documents must not leak the internal storage path.
  return apiSuccess({
    ...borehole,
    documents: borehole.documents.map((d) => omit(d, ["filePath"])),
  });
});

export const PATCH = withApi(async (req, ctx) => {
  const user = await requireUser();
  const { id } = await ctx.params;
  const body = await parseJsonBody(req, updateBoreholeBody);
  const borehole = await updateBorehole(user, requireId(id), body);
  return apiSuccess(borehole);
});

export const DELETE = withApi(async (_req, ctx) => {
  const user = await requireUser();
  const { id } = await ctx.params;
  const result = await deleteBorehole(user, requireId(id));
  return apiSuccess(result);
});
