/**
 * GET /api/boreholes/[id]/layers — stratigraphy of one borehole.
 * Readable when the parent borehole's project is own or actively shared.
 */
import { withApi } from "@/lib/api/api-utils";
import { apiSuccess } from "@/lib/api/api-response";
import { requireUser } from "@/lib/api/api-auth";
import { requireId } from "@/lib/api/api-validation";
import { listLayersForBorehole } from "@/lib/services/layers";

export const GET = withApi(async (_req, ctx) => {
  const user = await requireUser();
  const { id } = await ctx.params;
  const layers = await listLayersForBorehole(user, requireId(id, "borehole id"));
  return apiSuccess(layers, { meta: { total: layers.length } });
});
