/**
 * /api/boreholes — list + create.
 * List is scoped to accessible projects (own + actively shared); the
 * `sharedWithYou` flag marks cross-tenant rows. Create requires the
 * parent project to belong to the actor's organization (foreign parents
 * return 404).
 */
import { withApi } from "@/lib/api/api-utils";
import { apiSuccess, listMeta } from "@/lib/api/api-response";
import { requireUser } from "@/lib/api/api-auth";
import { parseQuery, parseJsonBody } from "@/lib/api/api-validation";
import { boreholesQuery, createBoreholeBody } from "@/lib/api/schemas";
import { listBoreholes, createBorehole } from "@/lib/services/boreholes";

export const GET = withApi(async (req) => {
  const user = await requireUser();
  const q = parseQuery(req, boreholesQuery);
  const result = await listBoreholes(user, q);
  return apiSuccess(result.items, { meta: listMeta(result) });
});

export const POST = withApi(async (req) => {
  const user = await requireUser();
  const body = await parseJsonBody(req, createBoreholeBody);
  const borehole = await createBorehole(user, body);
  return apiSuccess(borehole, { status: 201 });
});
