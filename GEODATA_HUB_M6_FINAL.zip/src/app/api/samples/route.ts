/**
 * /api/samples — list + create (tenant-scoped through the accessible
 * project set). Create requires an own-org borehole parent; depth checks
 * run in the service.
 */
import { withApi } from "@/lib/api/api-utils";
import { apiSuccess, listMeta } from "@/lib/api/api-response";
import { requireUser } from "@/lib/api/api-auth";
import { parseQuery, parseJsonBody } from "@/lib/api/api-validation";
import { samplesQuery, createSampleBody } from "@/lib/api/schemas";
import { listSamples, createSample } from "@/lib/services/samples";

export const GET = withApi(async (req) => {
  const user = await requireUser();
  const q = parseQuery(req, samplesQuery);
  const result = await listSamples(user, q);
  return apiSuccess(result.items, { meta: listMeta(result) });
});

export const POST = withApi(async (req) => {
  const user = await requireUser();
  const body = await parseJsonBody(req, createSampleBody);
  const sample = await createSample(user, body);
  return apiSuccess(sample, { status: 201 });
});
