/**
 * GET /api/samples/:id/classifications/latest?moduleId=uscs|aashto — the
 * latest VALID classification of a sample for the requested module.
 *
 * Returns the newest record computed from CURRENT data (isValid = true,
 * status = COMPLETED, inputSource = SAMPLE_DATA). 404 when none exists.
 *
 * Mirrors /api/lab-tests/:id/calculations/latest (M5.2 Integration).
 */
import { withApi } from "@/lib/api/api-utils";
import { apiSuccess } from "@/lib/api/api-response";
import { requireUser, requireCapability } from "@/lib/api/api-auth";
import { requireId, parseQuery } from "@/lib/api/api-validation";
import { latestClassificationQuery } from "@/lib/api/schemas";
import { CAPABILITIES } from "@/lib/rbac";
import { getLatestValidClassification } from "@/lib/services/classifications";

export const GET = withApi(async (req, ctx) => {
  const user = await requireUser();
  requireCapability(user, CAPABILITIES.LAB_TEST_VIEW);
  const { id } = await ctx.params;
  const q = parseQuery(req, latestClassificationQuery);
  const result = await getLatestValidClassification(user, requireId(id), q.moduleId);
  return apiSuccess(result.classification, {
    meta: { accessSource: result.accessSource },
  });
});
