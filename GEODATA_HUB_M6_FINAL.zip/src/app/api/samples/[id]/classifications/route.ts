/**
 * GET /api/samples/:id/classifications — per-sample classification history.
 *
 * Returns the paginated list of classification records for the sample
 * (own organization or actively shared project — service-enforced).
 * Includes VALID, STALE (isValid=false) and FAILED records — the same
 * three-state history view as /api/lab-tests/:id/calculations.
 *
 * Query: status?, isValid?, moduleId?, page?, pageSize?
 *
 * RBAC: LAB_TEST_VIEW (universal in the matrix); service enforces the
 * tenancy chain via getAccessibleSampleOrThrow.
 */
import { withApi } from "@/lib/api/api-utils";
import { apiSuccess, listMeta } from "@/lib/api/api-response";
import { requireUser, requireCapability } from "@/lib/api/api-auth";
import { requireId } from "@/lib/api/api-validation";
import { parseQuery } from "@/lib/api/api-validation";
import { sampleClassificationsQuery } from "@/lib/api/schemas";
import { CAPABILITIES } from "@/lib/rbac";
import { listSampleClassifications } from "@/lib/services/classifications";

export const GET = withApi(async (req, ctx) => {
  const user = await requireUser();
  requireCapability(user, CAPABILITIES.LAB_TEST_VIEW);
  const { id } = await ctx.params;
  const q = parseQuery(req, sampleClassificationsQuery);
  const result = await listSampleClassifications(user, requireId(id), q);
  return apiSuccess(result.items, { meta: listMeta(result) });
});
