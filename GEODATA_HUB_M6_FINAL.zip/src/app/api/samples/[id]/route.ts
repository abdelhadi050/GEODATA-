/**
 * /api/samples/[id] — detail / update / delete.
 * Detail readable through approved shares; mutations require ownership.
 */
import { withApi } from "@/lib/api/api-utils";
import { apiSuccess } from "@/lib/api/api-response";
import { requireUser } from "@/lib/api/api-auth";
import { parseJsonBody, requireId } from "@/lib/api/api-validation";
import { updateSampleBody } from "@/lib/api/schemas";
import { getSample, updateSample, deleteSample } from "@/lib/services/samples";

export const GET = withApi(async (_req, ctx) => {
  const user = await requireUser();
  const { id } = await ctx.params;
  const sample = await getSample(user, requireId(id));
  return apiSuccess(sample);
});

export const PATCH = withApi(async (req, ctx) => {
  const user = await requireUser();
  const { id } = await ctx.params;
  const body = await parseJsonBody(req, updateSampleBody);
  const sample = await updateSample(user, requireId(id), body);
  return apiSuccess(sample);
});

export const DELETE = withApi(async (_req, ctx) => {
  const user = await requireUser();
  const { id } = await ctx.params;
  const result = await deleteSample(user, requireId(id));
  return apiSuccess(result);
});
