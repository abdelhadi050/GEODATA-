/**
 * POST /api/samples/:id/classify — submit a classification for a sample.
 *
 * Runs the registered classification engine for the requested module
 * (USCS or AASHTO) over the sample's lab-test data and persists an
 * immutable snapshot (input + output + engine + standard provenance).
 *
 * Body:
 *   { moduleId: "uscs" | "aashto", input?: object,
 *     idempotencyKey?: string, dryRun?: boolean }
 *
 * RBAC: LAB_TEST_RESULT on an own-organization sample (service-enforced —
 * shared-project samples are read-only, same policy as recording lab results
 * and running calculations).
 *
 * Response: 200 with the persisted record detail + engine outcome envelope.
 * Classification failures (invalid/insufficient data) are PERSISTED as FAILED
 * records and returned with HTTP 200 + status "FAILED" — they are engine
 * outcomes, distinct from infrastructure errors which use the error envelope
 * (success: false) with 4xx/5xx.
 *
 * Mirrors /api/lab-tests/:id/calculate (M5.2 Integration).
 */
import { withApi } from "@/lib/api/api-utils";
import { apiSuccess } from "@/lib/api/api-response";
import { requireUser } from "@/lib/api/api-auth";
import { requireId } from "@/lib/api/api-validation";
import { classifySampleBody } from "@/lib/api/schemas";
import { parseOrThrow } from "@/lib/validation/parse";
import { Errors } from "@/lib/errors";
import { classifySample } from "@/lib/services/classifications";

export const POST = withApi(async (req, ctx) => {
  const user = await requireUser();
  const { id } = await ctx.params;
  // Empty body is invalid here — moduleId is required. Reuse the standard
  // JSON + strict-schema pipeline.
  let rawBody: unknown;
  try {
    const text = await req.text();
    rawBody = text.trim() === "" ? {} : JSON.parse(text);
  } catch {
    throw Errors.validation("Request body must be valid JSON");
  }
  const body = parseOrThrow(classifySampleBody, rawBody);

  const result = await classifySample(user, requireId(id), body.moduleId, {
    ...(body.input !== undefined ? { input: body.input } : {}),
    ...(body.idempotencyKey !== undefined ? { idempotencyKey: body.idempotencyKey } : {}),
    ...(body.dryRun !== undefined ? { dryRun: body.dryRun } : {}),
  });

  return apiSuccess(result, {
    meta: {
      replayed: result.replayed,
      deduplicated: result.deduplicated,
      dryRun: result.dryRun,
    },
  });
});
