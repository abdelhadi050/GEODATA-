/**
 * /api/projects — list + create.
 * List: own projects + actively shared ones, with pagination / filters.
 * Create: RBAC PROJECT_CREATE (service-enforced); organizationId derives
 * from the session — an organizationId in the body is rejected (strict
 * schema) and never read.
 */
import { withApi } from "@/lib/api/api-utils";
import { apiSuccess, listMeta } from "@/lib/api/api-response";
import { requireUser } from "@/lib/api/api-auth";
import { parseQuery, parseJsonBody } from "@/lib/api/api-validation";
import { projectsQuery, createProjectBody } from "@/lib/api/schemas";
import { listProjects, createProject } from "@/lib/services/projects";

export const GET = withApi(async (req) => {
  const user = await requireUser();
  const q = parseQuery(req, projectsQuery);
  const result = await listProjects(user, q);
  return apiSuccess(result.items, { meta: listMeta(result) });
});

export const POST = withApi(async (req) => {
  const user = await requireUser();
  const body = await parseJsonBody(req, createProjectBody);
  const project = await createProject(user, body);
  return apiSuccess(project, { status: 201 });
});
