/**
 * /api/projects/[id] — detail / update / delete.
 * Detail: readable when own OR actively shared (shared reads are marked
 * `accessSource: "shared"`). Update/delete require ownership — shared
 * projects are read-only, and foreign/inaccessible ids return 404 so
 * their existence is never leaked.
 */
import { withApi, omit } from "@/lib/api/api-utils";
import { apiSuccess } from "@/lib/api/api-response";
import { requireUser } from "@/lib/api/api-auth";
import { parseJsonBody, requireId } from "@/lib/api/api-validation";
import { updateProjectBody } from "@/lib/api/schemas";
import {
  getProject,
  updateProject,
  deleteProject,
} from "@/lib/services/projects";

export const GET = withApi(async (_req, ctx) => {
  const user = await requireUser();
  const { id } = await ctx.params;
  const project = await getProject(user, requireId(id));
  // Embedded documents must not leak the internal storage path.
  return apiSuccess({
    ...project,
    documents: project.documents.map((d) => omit(d, ["filePath"])),
  });
});

export const PATCH = withApi(async (req, ctx) => {
  const user = await requireUser();
  const { id } = await ctx.params;
  const body = await parseJsonBody(req, updateProjectBody);
  const project = await updateProject(user, requireId(id), body);
  return apiSuccess(project);
});

export const DELETE = withApi(async (_req, ctx) => {
  const user = await requireUser();
  const { id } = await ctx.params;
  const result = await deleteProject(user, requireId(id));
  return apiSuccess(result);
});
