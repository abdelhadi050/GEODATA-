/**
 * GET /api/projects/[id]/calculations — project-scoped calculation listing.
 * Paginated (page/pageSize ≤ 100), newest first, with optional status /
 * isValid / moduleId / testType filters. Access: own organization or an
 * approved, non-expired project share (records on shared projects belong to
 * the owning organization and are read-only for share recipients).
 */
import { withApi } from "@/lib/api/api-utils";
import { apiSuccess, listMeta } from "@/lib/api/api-response";
import { requireUser } from "@/lib/api/api-auth";
import { parseQuery, requireId } from "@/lib/api/api-validation";
import { projectCalculationsQuery } from "@/lib/api/schemas";
import { listProjectCalculations } from "@/lib/services/calculations";

export const GET = withApi(async (req, ctx) => {
  const user = await requireUser();
  const { id } = await ctx.params;
  const q = parseQuery(req, projectCalculationsQuery);
  const result = await listProjectCalculations(user, requireId(id), {
    ...(q.status !== undefined ? { status: q.status } : {}),
    ...(q.isValid !== undefined && q.isValid !== null ? { isValid: q.isValid } : {}),
    ...(q.moduleId !== undefined ? { moduleId: q.moduleId } : {}),
    ...(q.testType !== undefined ? { testType: q.testType } : {}),
    ...(q.page !== undefined ? { page: q.page } : {}),
    ...(q.pageSize !== undefined ? { pageSize: q.pageSize } : {}),
  });
  return apiSuccess(result.items, { meta: listMeta(result) });
});
