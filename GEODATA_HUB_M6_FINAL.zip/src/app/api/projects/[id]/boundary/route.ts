/**
 * PUT /api/projects/[id]/boundary — set the project GeoJSON boundary.
 * RBAC: PROJECT_EDIT on an OWN project (service-enforced). The polygon
 * itself is validated by the shared GeoJSON schema (closed rings,
 * [lon, lat] positions, bounded counts).
 */
import { withApi } from "@/lib/api/api-utils";
import { apiSuccess } from "@/lib/api/api-response";
import { requireUser } from "@/lib/api/api-auth";
import { parseJsonBody, requireId } from "@/lib/api/api-validation";
import { projectBoundaryBody } from "@/lib/api/schemas";
import { setProjectBoundary } from "@/lib/services/projects";

export const PUT = withApi(async (req, ctx) => {
  const user = await requireUser();
  const { id } = await ctx.params;
  const boundary = await parseJsonBody(req, projectBoundaryBody);
  const project = await setProjectBoundary(user, requireId(id), boundary);
  return apiSuccess(project);
});
