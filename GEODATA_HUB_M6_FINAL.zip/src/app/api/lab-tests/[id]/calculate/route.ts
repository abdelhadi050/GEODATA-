/**
 * POST /api/lab-tests/[id]/calculate — submit a calculation.
 *
 * Runs the registered calculation engine for the lab test's type through the
 * calculation service and persists an immutable snapshot (input + output +
 * engine provenance + registry standard/units).
 *
 * Body (all optional — an empty body is valid and means "use the stored
 * result payload"):
 *   { input?: object, idempotencyKey?: string, dryRun?: boolean }
 *
 * RBAC: LAB_TEST_RESULT on an own-organization test (service-enforced —
 * shared-project tests are read-only, same policy as recording results).
 *
 * Response: 200 with the persisted record detail + engine outcome envelope.
 * Calculation failures (invalid/insufficient data) are PERSISTED as FAILED
 * records and returned with HTTP 200 + status "FAILED" — they are engine
 * outcomes, distinct from infrastructure errors which use the error envelope
 * (success: false) with 4xx/5xx.
 */
import { withApi } from "@/lib/api/api-utils";
import { apiSuccess } from "@/lib/api/api-response";
import { requireUser } from "@/lib/api/api-auth";
import { requireId } from "@/lib/api/api-validation";
import { calculateLabTestBody } from "@/lib/api/schemas";
import { parseOrThrow } from "@/lib/validation/parse";
import { Errors } from "@/lib/errors";
import { calculateLabTest } from "@/lib/services/calculations";

export const POST = withApi(async (req, ctx) => {
  const user = await requireUser();
  const { id } = await ctx.params;
  // An empty body is the primary use case (calculate from stored resultData):
  // read the raw text first, default to {} — otherwise reuse the standard
  // JSON + strict-schema pipeline.
  let rawBody: unknown = {};
  try {
    const text = await req.text();
    if (text.trim() !== "") rawBody = JSON.parse(text);
  } catch {
    throw Errors.validation("Request body must be valid JSON");
  }
  const body = parseOrThrow(calculateLabTestBody, rawBody);

  const result = await calculateLabTest(user, requireId(id), {
    ...(body.input !== undefined ? { input: body.input } : {}),
    ...(body.idempotencyKey !== undefined ? { idempotencyKey: body.idempotencyKey } : {}),
    ...(body.dryRun !== undefined ? { dryRun: body.dryRun } : {}),
  });

  return apiSuccess(result, {
    meta: {
      replayed: result.replayed,
      deduplicated: result.deduplicated,
      dryRun: result.dryRun,
    },
  });
});
