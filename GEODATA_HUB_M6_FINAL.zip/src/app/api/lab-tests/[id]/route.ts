/**
 * /api/lab-tests/[id] — detail / update status+notes / delete.
 * Detail embeds the registry metadata (units, chart config) for the
 * test's type so clients can render results correctly.
 */
import { withApi } from "@/lib/api/api-utils";
import { apiSuccess } from "@/lib/api/api-response";
import { requireUser } from "@/lib/api/api-auth";
import { parseJsonBody, requireId } from "@/lib/api/api-validation";
import { updateLabTestBody } from "@/lib/api/schemas";
import {
  getLabTest,
  updateLabTest,
  deleteLabTest,
} from "@/lib/services/lab-tests";

export const GET = withApi(async (_req, ctx) => {
  const user = await requireUser();
  const { id } = await ctx.params;
  const labTest = await getLabTest(user, requireId(id));
  return apiSuccess(labTest);
});

export const PATCH = withApi(async (req, ctx) => {
  const user = await requireUser();
  const { id } = await ctx.params;
  const body = await parseJsonBody(req, updateLabTestBody);
  const labTest = await updateLabTest(user, requireId(id), body);
  return apiSuccess(labTest);
});

export const DELETE = withApi(async (_req, ctx) => {
  const user = await requireUser();
  const { id } = await ctx.params;
  const result = await deleteLabTest(user, requireId(id));
  return apiSuccess(result);
});
