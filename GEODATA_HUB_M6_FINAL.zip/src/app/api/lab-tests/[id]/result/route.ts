/**
 * PUT /api/lab-tests/[id]/result — record a structured laboratory result.
 * RBAC: LAB_TEST_RESULT on an own-org test (service-enforced). The
 * result payload is validated against the per-type registry schema
 * (Zod) inside the service — never stored as arbitrary JSON. A valid
 * result marks the test COMPLETED and stamps performer and timestamp.
 */
import { withApi } from "@/lib/api/api-utils";
import { apiSuccess } from "@/lib/api/api-response";
import { requireUser } from "@/lib/api/api-auth";
import { parseJsonBody, requireId } from "@/lib/api/api-validation";
import { labTestResultBody } from "@/lib/api/schemas";
import { recordLabTestResult } from "@/lib/services/lab-tests";
import { Errors } from "@/lib/errors";

export const PUT = withApi(async (req, ctx) => {
  const user = await requireUser();
  const { id } = await ctx.params;
  const body = await parseJsonBody(req, labTestResultBody);
  if (body.result === undefined || body.result === null) {
    throw Errors.validation("result is required");
  }
  const labTest = await recordLabTestResult(user, requireId(id), body.result, {
    summary: body.summary,
  });
  return apiSuccess(labTest);
});
