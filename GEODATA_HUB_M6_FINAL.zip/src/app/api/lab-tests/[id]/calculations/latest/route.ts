/**
 * GET /api/lab-tests/[id]/calculations/latest — the latest VALID calculation
 * result for the test: the newest record computed from CURRENT data
 * (isValid = true) that completed successfully. 404 when none exists yet.
 * Stale (invalidated) and failed records are never returned here — consumers
 * cannot be served outdated results through this endpoint.
 */
import { withApi } from "@/lib/api/api-utils";
import { apiSuccess } from "@/lib/api/api-response";
import { requireUser } from "@/lib/api/api-auth";
import { requireId } from "@/lib/api/api-validation";
import { getLatestValidCalculation } from "@/lib/services/calculations";

export const GET = withApi(async (_req, ctx) => {
  const user = await requireUser();
  const { id } = await ctx.params;
  const { calculation, accessSource } = await getLatestValidCalculation(
    user,
    requireId(id),
  );
  return apiSuccess({ ...calculation, accessSource });
});
