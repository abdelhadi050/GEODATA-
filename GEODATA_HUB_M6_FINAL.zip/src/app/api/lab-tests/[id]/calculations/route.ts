/**
 * GET /api/lab-tests/[id]/calculations — calculation history for a lab test.
 * Paginated (page/pageSize ≤ 100), newest first, with optional status /
 * isValid / moduleId filters. List items are lean (no input/output
 * snapshots); the detail endpoint returns the full record.
 *
 * RBAC: read via the tenancy access chain (own organization or an approved,
 * non-expired project share — service-enforced).
 */
import { withApi } from "@/lib/api/api-utils";
import { apiSuccess, listMeta } from "@/lib/api/api-response";
import { requireUser } from "@/lib/api/api-auth";
import { parseQuery, requireId } from "@/lib/api/api-validation";
import { labTestCalculationsQuery } from "@/lib/api/schemas";
import { listLabTestCalculations } from "@/lib/services/calculations";

export const GET = withApi(async (req, ctx) => {
  const user = await requireUser();
  const { id } = await ctx.params;
  const q = parseQuery(req, labTestCalculationsQuery);
  const result = await listLabTestCalculations(user, requireId(id), {
    ...(q.status !== undefined ? { status: q.status } : {}),
    ...(q.isValid !== undefined && q.isValid !== null ? { isValid: q.isValid } : {}),
    ...(q.moduleId !== undefined ? { moduleId: q.moduleId } : {}),
    ...(q.page !== undefined ? { page: q.page } : {}),
    ...(q.pageSize !== undefined ? { pageSize: q.pageSize } : {}),
  });
  return apiSuccess(result.items, { meta: listMeta(result) });
});
