/**
 * GET /api/lab-tests/registry — the 12-type laboratory test registry
 * (metadata only: codes, labels, standards, units, chart configs and
 * validation notes). Static route segment takes precedence over [id].
 * Consumed by the M5 visualization layer; no tenant data involved.
 */
import { withApi } from "@/lib/api/api-utils";
import { apiSuccess } from "@/lib/api/api-response";
import { requireUser } from "@/lib/api/api-auth";
import { LAB_TEST_REGISTRY, LAB_TEST_TYPES } from "@/lib/lab-tests/registry";

export const GET = withApi(async () => {
  await requireUser();
  const types = LAB_TEST_TYPES.map((code) => {
    const def = LAB_TEST_REGISTRY[code];
    return {
      code: def.code,
      label: def.label,
      description: def.description,
      standard: def.standard,
      category: def.category,
      units: def.units,
      validationNotes: def.validationNotes,
      chart: def.chart,
    };
  });
  return apiSuccess(types, { meta: { total: types.length } });
});
