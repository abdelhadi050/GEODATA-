/**
 * /api/lab-tests — list + create.
 * Creating a test reserves the (sample, testType) slot — one test of
 * each type per sample. Structured results are recorded through the
 * dedicated result endpoint and validated by the registry.
 */
import { withApi } from "@/lib/api/api-utils";
import { apiSuccess, listMeta } from "@/lib/api/api-response";
import { requireUser } from "@/lib/api/api-auth";
import { parseQuery, parseJsonBody } from "@/lib/api/api-validation";
import { labTestsQuery, createLabTestBody } from "@/lib/api/schemas";
import { listLabTests, createLabTest } from "@/lib/services/lab-tests";

export const GET = withApi(async (req) => {
  const user = await requireUser();
  const q = parseQuery(req, labTestsQuery);
  const result = await listLabTests(user, q);
  return apiSuccess(result.items, { meta: listMeta(result) });
});

export const POST = withApi(async (req) => {
  const user = await requireUser();
  const body = await parseJsonBody(req, createLabTestBody);
  const labTest = await createLabTest(user, body);
  return apiSuccess(labTest, { status: 201 });
});
