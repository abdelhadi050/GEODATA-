import { getSessionUser } from "@/lib/auth";
import { apiGet } from "@/lib/server-api";
import { formatDate } from "@/lib/format";
import { PageHeader } from "@/components/shared/page-header";
import { StatusBadge } from "@/components/shared/status-badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { ROLE_LABELS, type Role } from "@/lib/constants";
import type { OrganizationInfo } from "@/lib/api-types";

export default async function SettingsPage() {
  const user = await getSessionUser();
  if (!user) return null;

  const orgRes = await apiGet<OrganizationInfo>("/api/organizations/current");
  const org = orgRes.ok ? orgRes.data : null;

  return (
    <div className="space-y-6">
      <PageHeader
        title="Organization"
        description="Workspace profile and identity. Tenant data is isolated per organization."
      />

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Workspace</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-sm">
            <Row label="Organization" value={org?.name ?? "—"} />
            <Row label="Slug" value={org ? `@${org.slug}` : "—"} />
            <Row label="Created" value={org ? formatDate(org.createdAt) : "—"} />
            <Separator />
            <p className="text-xs text-muted-foreground">
              Organizations cannot be deleted through the API: deletion would
              cascade the entire audit trail. Deactivation/archiving is the
              planned future mechanism (documented in the API design, §7).
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Your identity</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-sm">
            <Row label="Name" value={user.name} />
            <Row label="Email" value={user.email} />
            <Row
              label="Role"
              value={
                <span className="flex items-center gap-2">
                  <StatusBadge value={user.role} />
                  <span className="text-muted-foreground">
                    {ROLE_LABELS[user.role as Role] ?? user.role}
                  </span>
                </span>
              }
            />
            <Separator />
            <p className="text-xs text-muted-foreground">
              Role and active status are re-read from the database on every
              request — role changes and deactivation take effect immediately,
              even mid-session.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function Row({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-4">
      <span className="text-muted-foreground">{label}</span>
      <span className="font-medium">{value}</span>
    </div>
  );
}
