import { getSessionUser } from "@/lib/auth";
import { can, CAPABILITIES } from "@/lib/rbac";
import { apiGet } from "@/lib/server-api";
import { formatDate } from "@/lib/format";
import { PageHeader } from "@/components/shared/page-header";
import { StatusBadge } from "@/components/shared/status-badge";
import { UnauthorizedState, EmptyState } from "@/components/shared/states";
import { ListToolbar } from "@/components/shared/list-toolbar";
import {
  UserRoleSelect,
  UserActiveSwitch,
} from "@/components/users/user-controls";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import type { TeamUser } from "@/lib/api-types";

export default async function UsersPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const user = await getSessionUser();
  if (!user) return null;

  if (!can(user.role, CAPABILITIES.TEAM_VIEW)) {
    return (
      <div className="space-y-6">
        <PageHeader title="Users" description="Team directory and roles." />
        <UnauthorizedState
          title="Team directory not permitted"
          description="Viewing the team directory requires the team:view capability (project managers and admins)."
        />
      </div>
    );
  }

  const sp = await searchParams;
  const search = typeof sp.search === "string" ? sp.search.trim() : undefined;
  const qs = new URLSearchParams();
  if (search) qs.set("search", search);

  const result = await apiGet<TeamUser[]>(`/api/users${qs.size ? `?${qs}` : ""}`);
  if (!result.ok) {
    return (
      <div className="space-y-6">
        <PageHeader title="Users" description="Team directory and roles." />
        <EmptyState
          title="Directory unavailable"
          description="The users endpoint could not be reached. Please retry."
        />
      </div>
    );
  }
  const users = result.data;
  const canManage = can(user.role, CAPABILITIES.TEAM_MANAGE);

  return (
    <div className="space-y-6">
      <PageHeader
        title="Users"
        description={
          canManage
            ? "Team directory. Role changes and activation take effect immediately (DB-fresh sessions)."
            : "Team directory (read-only — only organization admins manage roles and activation)."
        }
      />

      <ListToolbar searchPlaceholder="Search name or email…" />

      {users.length === 0 ? (
        <EmptyState
          title={search ? "No users match your search" : "No users"}
          description={search ? "Try a different search term." : "Invite users to your organization."}
        />
      ) : (
        <div className="overflow-x-auto rounded-lg border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Role</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="hidden md:table-cell">Member since</TableHead>
                {canManage && <TableHead className="text-right">Active</TableHead>}
              </TableRow>
            </TableHeader>
            <TableBody>
              {users.map((u) => {
                const isSelf = u.id === user.id;
                return (
                  <TableRow key={u.id}>
                    <TableCell className="font-medium">
                      {u.name}
                      {isSelf && (
                        <span className="ml-2 rounded bg-accent px-1.5 py-0.5 text-[10px] font-medium text-primary">
                          You
                        </span>
                      )}
                    </TableCell>
                    <TableCell className="text-muted-foreground">{u.email}</TableCell>
                    <TableCell>
                      {canManage ? (
                        <UserRoleSelect user={u} selfId={user.id} disabled={!canManage} />
                      ) : (
                        <StatusBadge value={u.role} />
                      )}
                    </TableCell>
                    <TableCell>
                      <StatusBadge value={u.isActive ? "ACTIVE" : "ARCHIVED"} />
                    </TableCell>
                    <TableCell className="hidden md:table-cell">
                      {formatDate(u.createdAt)}
                    </TableCell>
                    {canManage && (
                      <TableCell className="text-right">
                        <UserActiveSwitch user={u} selfId={user.id} disabled={!canManage} />
                      </TableCell>
                    )}
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      )}

      {canManage && (
        <p className="text-xs text-muted-foreground">
          Your own role and activation cannot be changed here (API-enforced).
          The organization always keeps at least one active administrator.
        </p>
      )}
    </div>
  );
}
