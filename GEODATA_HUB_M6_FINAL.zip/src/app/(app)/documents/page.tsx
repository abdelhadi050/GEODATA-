import Link from "next/link";
import { Download, FileText } from "lucide-react";
import { getSessionUser } from "@/lib/auth";
import { can, CAPABILITIES } from "@/lib/rbac";
import { apiGet, requireData } from "@/lib/server-api";
import { formatDateTime, formatFileSize } from "@/lib/format";
import { PageHeader } from "@/components/shared/page-header";
import { ListToolbar } from "@/components/shared/list-toolbar";
import { PaginationNav } from "@/components/shared/pagination-nav";
import { TypeBadge } from "@/components/shared/status-badge";
import { EmptyState } from "@/components/shared/states";
import { UploadDialog } from "@/components/documents/upload-dialog";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { DOC_TYPES, DOC_TYPE_LABELS } from "@/lib/constants";
import type { DocumentListItem } from "@/lib/api-types";

export default async function DocumentsPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const user = await getSessionUser();
  if (!user) return null;
  const sp = await searchParams;
  const search = typeof sp.search === "string" ? sp.search.trim() : undefined;
  const docType = typeof sp.docType === "string" ? sp.docType : undefined;
  const projectId = typeof sp.projectId === "string" ? sp.projectId : undefined;
  const page = Math.max(1, Number(sp.page ?? 1) || 1);

  const qs = new URLSearchParams();
  if (search) qs.set("search", search);
  if (docType) qs.set("docType", docType);
  if (projectId) qs.set("projectId", projectId);
  qs.set("page", String(page));
  qs.set("pageSize", "15");

  const result = await apiGet<DocumentListItem[]>(`/api/documents?${qs.toString()}`);
  const { data, meta: m } = await requireData(result);
  const meta = { page: m?.page ?? 1, pageSize: m?.pageSize ?? 15, total: m?.total ?? data.length, totalPages: m?.totalPages ?? 1 };

  const canUpload = can(user.role, CAPABILITIES.DOCUMENT_MANAGE);
  const canDownload = can(user.role, CAPABILITIES.DOCUMENT_DOWNLOAD);

  return (
    <div className="space-y-6">
      <PageHeader
        title="Documents"
        description="Project files — reports, drawings, lab data and photos — stored privately with per-project access control."
      >
        {canUpload && <UploadDialog />}
      </PageHeader>

      <ListToolbar
        searchPlaceholder="Search title or filename…"
        filters={[
          {
            key: "docType",
            label: "types",
            options: DOC_TYPES.map((d) => ({ value: d, label: DOC_TYPE_LABELS[d] })),
          },
        ]}
      />

      {data.length === 0 ? (
        <EmptyState
          title={search || docType ? "No documents match your filters" : "No documents yet"}
          description={
            search || docType
              ? "Try clearing the filters."
              : canUpload
                ? "Upload the first report, drawing or lab dataset."
                : "Documents uploaded to your projects will appear here."
          }
        />
      ) : (
        <div className="overflow-x-auto rounded-lg border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Title</TableHead>
                <TableHead>Type</TableHead>
                <TableHead className="hidden md:table-cell">Project</TableHead>
                <TableHead className="hidden lg:table-cell">Borehole</TableHead>
                <TableHead className="hidden sm:table-cell">Size</TableHead>
                <TableHead className="hidden xl:table-cell">Uploaded</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {data.map((d) => (
                <TableRow key={d.id}>
                  <TableCell className="max-w-[260px]">
                    <div className="flex items-center gap-2">
                      <FileText className="h-4 w-4 shrink-0 text-muted-foreground" />
                      <div className="min-w-0">
                        <p className="truncate text-sm font-medium" title={d.title}>
                          {d.title}
                        </p>
                        <p className="truncate text-xs text-muted-foreground" title={d.fileName}>
                          {d.fileName}
                        </p>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <TypeBadge value={d.docType} />
                  </TableCell>
                  <TableCell className="hidden md:table-cell">
                    <Link
                      href={`/projects/${d.project.id}`}
                      className="font-mono text-xs text-primary hover:underline"
                    >
                      {d.project.code}
                    </Link>
                  </TableCell>
                  <TableCell className="hidden font-mono text-xs lg:table-cell">
                    {d.borehole ? (
                      <Link href={`/boreholes/${d.borehole.id}`} className="text-primary hover:underline">
                        {d.borehole.code}
                      </Link>
                    ) : (
                      "—"
                    )}
                  </TableCell>
                  <TableCell className="hidden tabular-nums sm:table-cell">
                    {formatFileSize(d.fileSize)}
                  </TableCell>
                  <TableCell className="hidden xl:table-cell">
                    {formatDateTime(d.createdAt)}
                  </TableCell>
                  <TableCell className="text-right">
                    {canDownload ? (
                      <Button asChild size="sm" variant="outline">
                        {/* Secure streaming endpoint — no storage path is ever exposed. */}
                        <a href={`/api/documents/${d.id}/download`}>
                          <Download className="h-4 w-4" /> Download
                        </a>
                      </Button>
                    ) : (
                      <span className="text-xs text-muted-foreground">No permission</span>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      <PaginationNav
        basePath="/documents"
        params={{ search, docType, projectId }}
        page={meta.page}
        totalPages={meta.totalPages}
        total={meta.total}
      />
    </div>
  );
}
