import Link from "next/link";
import { getSessionUser } from "@/lib/auth";
import { can, CAPABILITIES } from "@/lib/rbac";
import { apiGet, requireData } from "@/lib/server-api";
import { formatDateTime } from "@/lib/format";
import { PageHeader } from "@/components/shared/page-header";
import { ListToolbar } from "@/components/shared/list-toolbar";
import { PaginationNav } from "@/components/shared/pagination-nav";
import { StatusBadge } from "@/components/shared/status-badge";
import { EmptyState } from "@/components/shared/states";
import { ProjectFormDialog } from "@/components/projects/project-form-dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { PROJECT_STATUSES, PROJECT_STATUS_LABELS } from "@/lib/constants";
import type { ProjectListItem } from "@/lib/api-types";

export default async function ProjectsPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const user = await getSessionUser();
  if (!user) return null;
  const sp = await searchParams;
  const search = typeof sp.search === "string" ? sp.search.trim() : undefined;
  const status = typeof sp.status === "string" ? sp.status : undefined;
  const page = Math.max(1, Number(sp.page ?? 1) || 1);

  const qs = new URLSearchParams();
  if (search) qs.set("search", search);
  if (status) qs.set("status", status);
  qs.set("page", String(page));
  qs.set("pageSize", "12");

  const result = await apiGet<ProjectListItem[]>(`/api/projects?${qs.toString()}`);
  const { data, meta: m } = await requireData(result);
  const meta = { page: m?.page ?? 1, pageSize: m?.pageSize ?? 15, total: m?.total ?? data.length, totalPages: m?.totalPages ?? 1 };

  const canCreate = can(user.role, CAPABILITIES.PROJECT_CREATE);

  return (
    <div className="space-y-6">
      <PageHeader
        title="Projects"
        description="Investigation projects owned by your organization, plus projects actively shared with you."
      >
        {canCreate && <ProjectFormDialog variant="create" />}
      </PageHeader>

      <ListToolbar
        searchPlaceholder="Search code, name, client, location…"
        filters={[
          {
            key: "status",
            label: "statuses",
            options: PROJECT_STATUSES.map((s) => ({ value: s, label: PROJECT_STATUS_LABELS[s] })),
          },
        ]}
      />

      {data.length === 0 ? (
        <EmptyState
          title={search || status ? "No projects match your filters" : "No projects yet"}
          description={
            search || status
              ? "Try clearing the search or status filter."
              : canCreate
                ? "Create your first investigation project to start registering boreholes, samples and laboratory tests."
                : "Projects created in your organization will appear here."
          }
        />
      ) : (
        <div className="overflow-x-auto rounded-lg border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Code</TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="hidden md:table-cell">Client</TableHead>
                <TableHead className="hidden lg:table-cell">Location</TableHead>
                <TableHead className="text-right">Boreholes</TableHead>
                <TableHead className="hidden text-right sm:table-cell">Documents</TableHead>
                <TableHead className="hidden xl:table-cell">Created</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {data.map((p) => (
                <TableRow key={p.id}>
                  <TableCell className="font-mono text-xs">
                    <Link
                      href={`/projects/${p.id}`}
                      className="font-medium text-primary hover:underline"
                    >
                      {p.code}
                    </Link>
                    {p.sharedWithYou && (
                      <span className="ml-2 rounded bg-accent px-1.5 py-0.5 text-[10px] font-medium text-primary">
                        Shared
                      </span>
                    )}
                  </TableCell>
                  <TableCell className="max-w-[240px]">
                    <Link
                      href={`/projects/${p.id}`}
                      className="block truncate font-medium hover:underline"
                      title={p.name}
                    >
                      {p.name}
                    </Link>
                  </TableCell>
                  <TableCell>
                    <StatusBadge value={p.status} />
                  </TableCell>
                  <TableCell className="hidden max-w-[160px] truncate md:table-cell">
                    {p.client ?? "—"}
                  </TableCell>
                  <TableCell className="hidden max-w-[160px] truncate lg:table-cell">
                    {p.locationName ?? "—"}
                  </TableCell>
                  <TableCell className="text-right tabular-nums">
                    {p._count.boreholes}
                  </TableCell>
                  <TableCell className="hidden text-right tabular-nums sm:table-cell">
                    {p._count.documents}
                  </TableCell>
                  <TableCell className="hidden xl:table-cell">
                    {formatDateTime(p.createdAt)}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      <PaginationNav
        basePath="/projects"
        params={{ search, status }}
        page={meta.page}
        totalPages={meta.totalPages}
        total={meta.total}
      />
    </div>
  );
}
