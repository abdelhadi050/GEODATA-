import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import {
  Download,
  MapPin,
  Building2,
  CalendarDays,
} from "lucide-react";
import { getSessionUser } from "@/lib/auth";
import { can, CAPABILITIES } from "@/lib/rbac";
import { apiGet } from "@/lib/server-api";
import {
  formatDate,
  formatDateTime,
  formatCoordinate,
  formatDepth,
  pluralize,
} from "@/lib/format";
import { PageHeader } from "@/components/shared/page-header";
import { StatusBadge, TypeBadge } from "@/components/shared/status-badge";
import { PaginationNav } from "@/components/shared/pagination-nav";
import { EmptyState } from "@/components/shared/states";
import {
  CalcStatusBadge,
  InputSourceBadge,
  ValidityBadge,
} from "@/components/lab-tests/calculation-shared";
import { ProjectFormDialog } from "@/components/projects/project-form-dialog";
import { BoreholeFormDialog } from "@/components/boreholes/borehole-form-dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import type { ProjectDetail, CalculationListItemDto } from "@/lib/api-types";

function InfoRow({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-4 py-1.5">
      <span className="shrink-0 text-muted-foreground">{label}</span>
      <span className="text-right font-medium">{value}</span>
    </div>
  );
}

export default async function ProjectDetailPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const { id } = await params;
  const sp = await searchParams;
  const calcPage = Math.max(1, Number(sp.page ?? 1) || 1);
  const user = await getSessionUser();
  if (!user) return null;

  const [result, calcsRes] = await Promise.all([
    apiGet<ProjectDetail>(`/api/projects/${id}`),
    apiGet<CalculationListItemDto[]>(
      `/api/projects/${id}/calculations?page=${calcPage}&pageSize=10`,
    ),
  ]);
  if (!result.ok && result.status === 401) redirect("/login");
  if (!result.ok) notFound();
  const project = result.data;
  const calculations = calcsRes.ok ? calcsRes.data : [];
  const calcMeta =
    calcsRes.ok && calcsRes.meta
      ? {
          page: calcsRes.meta.page ?? 1,
          total: calcsRes.meta.total ?? calculations.length,
          totalPages: calcsRes.meta.totalPages ?? 1,
        }
      : { page: 1, total: calculations.length, totalPages: 1 };

  const ownProject = project.accessSource === "own";
  const canEdit = ownProject && can(user.role, CAPABILITIES.PROJECT_EDIT);
  const canManageBoreholes =
    ownProject && can(user.role, CAPABILITIES.BOREHOLE_MANAGE);
  const canDownload = can(user.role, CAPABILITIES.DOCUMENT_DOWNLOAD);

  return (
    <div className="space-y-6">
      <PageHeader
        title={project.name}
        description={`${project.code} · ${project.organization.name}${project.sharedWithYou ? " · shared with your organization (read-only)" : ""}`}
      >
        {canEdit && <ProjectFormDialog project={project} variant="edit" />}
      </PageHeader>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              Overview
              <StatusBadge value={project.status} />
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm leading-relaxed text-muted-foreground">
              {project.description ?? "No description recorded."}
            </p>
            <dl className="mt-4 grid gap-x-8 gap-y-0 sm:grid-cols-2">
              <div>
                <InfoRow label="Client" value={project.client ?? "—"} />
                <InfoRow label="Location" value={project.locationName ?? "—"} />
                <InfoRow
                  label="Coordinates"
                  value={formatCoordinate(project.latitude, project.longitude)}
                />
                <InfoRow label="Site boundary" value={project.boundary ? "Defined (GeoJSON polygon)" : "Not defined"} />
              </div>
              <div>
                <InfoRow label="Created by" value={project.createdBy.name} />
                <InfoRow label="Created at" value={formatDateTime(project.createdAt)} />
                <InfoRow label="Last update" value={formatDateTime(project.updatedAt)} />
                <InfoRow
                  label="Counts"
                  value={`${pluralize(project.boreholes.length, "borehole")} · ${pluralize(project.documents.length, "document")} · ${pluralize(project.reports.length, "report")}`}
                />
              </div>
            </dl>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">At a glance</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-sm">
            <div className="flex items-center gap-2">
              <Building2 className="h-4 w-4 text-primary" />
              <span>{project.organization.name}</span>
            </div>
            <div className="flex items-center gap-2">
              <MapPin className="h-4 w-4 text-primary" />
              <span>{project.locationName ?? formatCoordinate(project.latitude, project.longitude)}</span>
            </div>
            <div className="flex items-center gap-2">
              <CalendarDays className="h-4 w-4 text-primary" />
              <span>Since {formatDate(project.createdAt)}</span>
            </div>
            {project.sharedWithYou && (
              <p className="rounded-md bg-accent px-3 py-2 text-xs text-primary">
                This project is shared with your organization. Editing,
                borehole management and uploads are only available to the
                owning organization.
              </p>
            )}
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="boreholes">
        <TabsList className="flex-wrap">
          <TabsTrigger value="boreholes">Boreholes ({project.boreholes.length})</TabsTrigger>
          <TabsTrigger value="documents">Documents ({project.documents.length})</TabsTrigger>
          <TabsTrigger value="reports">Reports ({project.reports.length})</TabsTrigger>
          <TabsTrigger value="calculations">Calculations ({calcMeta.total})</TabsTrigger>
          {ownProject && (
            <TabsTrigger value="sharing">Sharing ({project.sharingRequests.length})</TabsTrigger>
          )}
        </TabsList>

        <TabsContent value="boreholes" className="mt-4 space-y-4">
          {canManageBoreholes && (
            <div className="flex justify-end">
              <BoreholeFormDialog projectId={project.id} projectCode={project.code} variant="create" />
            </div>
          )}
          {project.boreholes.length === 0 ? (
            <EmptyState
              title="No boreholes yet"
              description={
                canManageBoreholes
                  ? "Register the first borehole, sounding or trial pit for this project."
                  : "Boreholes registered under this project will appear here."
              }
            />
          ) : (
            <div className="overflow-x-auto rounded-lg border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Code</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="hidden md:table-cell">Depth</TableHead>
                    <TableHead className="hidden lg:table-cell">Coordinates</TableHead>
                    <TableHead className="hidden sm:table-cell">Layers</TableHead>
                    <TableHead className="text-right">Samples</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {project.boreholes.map((b) => (
                    <TableRow key={b.id}>
                      <TableCell className="font-mono text-xs">
                        <Link
                          href={`/boreholes/${b.id}`}
                          className="font-medium text-primary hover:underline"
                        >
                          {b.code}
                        </Link>
                      </TableCell>
                      <TableCell>
                        <TypeBadge value={b.type} />
                      </TableCell>
                      <TableCell>
                        <StatusBadge value={b.status} />
                      </TableCell>
                      <TableCell className="hidden md:table-cell">
                        {formatDepth(b.depth)}
                      </TableCell>
                      <TableCell className="hidden font-mono text-xs lg:table-cell">
                        {formatCoordinate(b.latitude, b.longitude)}
                      </TableCell>
                      <TableCell className="hidden sm:table-cell tabular-nums">
                        {b._count?.layers ?? 0}
                      </TableCell>
                      <TableCell className="text-right tabular-nums">
                        {b._count?.samples ?? 0}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </TabsContent>

        <TabsContent value="documents" className="mt-4">
          {project.documents.length === 0 ? (
            <EmptyState
              title="No documents"
              description="Upload reports, drawings and lab data from the Documents module."
            />
          ) : (
            <ul className="divide-y rounded-lg border">
              {project.documents.map((d) => (
                <li key={d.id} className="flex items-center justify-between gap-3 px-4 py-3">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium">{d.title}</p>
                    <p className="text-xs text-muted-foreground">
                      {d.fileName} · {formatDateTime(d.createdAt)} · {d.uploadedBy.name}
                    </p>
                  </div>
                  <div className="flex shrink-0 items-center gap-2">
                    <TypeBadge value={d.docType} />
                    {canDownload && (
                      <Button asChild size="sm" variant="outline">
                        {/* Secure M3 download endpoint — no storage paths involved. */}
                        <a href={`/api/documents/${d.id}/download`}>
                          <Download className="h-4 w-4" /> Download
                        </a>
                      </Button>
                    )}
                  </div>
                </li>
              ))}
            </ul>
          )}
        </TabsContent>

        <TabsContent value="reports" className="mt-4">
          {project.reports.length === 0 ? (
            <EmptyState
              title="No reports"
              description="Report records generated for this project will appear here."
            />
          ) : (
            <ul className="divide-y rounded-lg border">
              {project.reports.map((r) => (
                <li key={r.id} className="flex items-center justify-between gap-3 px-4 py-3">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium">{r.title}</p>
                    <p className="text-xs text-muted-foreground">
                      {formatDateTime(r.createdAt)} · {r.generatedBy.name}
                    </p>
                  </div>
                  <TypeBadge value={r.reportType} />
                </li>
              ))}
            </ul>
          )}
        </TabsContent>

        <TabsContent value="calculations" className="mt-4 space-y-4">
          {calculations.length === 0 ? (
            <EmptyState
              title="No calculations yet"
              description="Engine-computed results for this project's laboratory tests appear here once calculations are run from a test's page."
            />
          ) : (
            <>
              <div className="overflow-x-auto rounded-lg border" data-testid="project-calculations">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date</TableHead>
                      <TableHead>Test type</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Validity</TableHead>
                      <TableHead className="hidden md:table-cell">Source</TableHead>
                      <TableHead className="hidden lg:table-cell">Method</TableHead>
                      <TableHead className="hidden lg:table-cell">Created by</TableHead>
                      <TableHead />
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {calculations.map((c) => (
                      <TableRow key={c.id}>
                        <TableCell className="whitespace-nowrap text-xs">
                          {formatDateTime(c.createdAt)}
                        </TableCell>
                        <TableCell className="text-sm">{c.testType}</TableCell>
                        <TableCell>
                          <CalcStatusBadge status={c.status} />
                        </TableCell>
                        <TableCell>
                          <ValidityBadge isValid={c.isValid} />
                        </TableCell>
                        <TableCell className="hidden md:table-cell">
                          <InputSourceBadge source={c.inputSource} />
                        </TableCell>
                        <TableCell className="hidden max-w-[180px] truncate lg:table-cell">
                          {c.method ?? "—"}
                        </TableCell>
                        <TableCell className="hidden lg:table-cell">{c.createdBy.name}</TableCell>
                        <TableCell>
                          <Link
                            href={`/calculations/${c.id}`}
                            className="text-xs text-primary hover:underline"
                          >
                            View
                          </Link>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
              <PaginationNav
                basePath={`/projects/${project.id}`}
                params={{}}
                page={calcMeta.page}
                totalPages={calcMeta.totalPages}
                total={calcMeta.total}
              />
            </>
          )}
        </TabsContent>

        {ownProject && (
          <TabsContent value="sharing" className="mt-4">
            {project.sharingRequests.length === 0 ? (
              <EmptyState
                title="Not shared with anyone"
                description="Create sharing requests from the Sharing module to give another organization read access to this project."
              />
            ) : (
              <ul className="divide-y rounded-lg border">
                {project.sharingRequests.map((s) => (
                  <li key={s.id} className="flex items-center justify-between gap-3 px-4 py-3">
                    <div className="min-w-0">
                      <p className="text-sm font-medium">{s.targetOrganization.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {s.permission} permission · requested by {s.requester.name} ·{" "}
                        {formatDateTime(s.createdAt)}
                        {s.expiresAt ? ` · expires ${formatDate(s.expiresAt)}` : ""}
                      </p>
                    </div>
                    <StatusBadge value={s.status} />
                  </li>
                ))}
              </ul>
            )}
          </TabsContent>
        )}
      </Tabs>
    </div>
  );
}
