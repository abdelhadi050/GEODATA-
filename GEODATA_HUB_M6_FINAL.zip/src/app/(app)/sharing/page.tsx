import Link from "next/link";
import { getSessionUser } from "@/lib/auth";
import { can, CAPABILITIES } from "@/lib/rbac";
import { apiGet } from "@/lib/server-api";
import { formatDate, formatDateTime } from "@/lib/format";
import { PageHeader } from "@/components/shared/page-header";
import { StatusBadge } from "@/components/shared/status-badge";
import { UnauthorizedState, EmptyState } from "@/components/shared/states";
import {
  SharingCreateDialog,
  SharingDecision,
  SharingRevoke,
} from "@/components/sharing/sharing-dialogs";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import type { SharingLists, SharingRequestItem } from "@/lib/api-types";

function ShareRow({
  item,
  direction,
  canDecide,
  canRevoke,
}: {
  item: SharingRequestItem;
  direction: "sent" | "inbox";
  canDecide: boolean;
  canRevoke: boolean;
}) {
  const inboxProject = item.project as {
    id: string;
    code: string;
    name: string;
    organization?: { name: string };
  };
  const partner =
    direction === "sent"
      ? item.targetOrganization.name
      : inboxProject.organization?.name ?? "—";
  const pending = item.status === "PENDING";
  const active = item.status === "APPROVED";

  return (
    <li className="flex flex-col gap-2 px-4 py-3 sm:flex-row sm:items-center sm:justify-between">
      <div className="min-w-0">
        <div className="flex flex-wrap items-center gap-2">
          <Link
            href={`/projects/${item.project.id}`}
            className="font-mono text-xs font-medium text-primary hover:underline"
          >
            {item.project.code}
          </Link>
          <StatusBadge value={item.status} />
          <span className="rounded bg-muted px-1.5 py-0.5 text-[10px] font-medium">
            {item.permission}
          </span>
        </div>
        <p className="mt-0.5 truncate text-sm">{item.project.name}</p>
        <p className="text-xs text-muted-foreground">
          {direction === "sent" ? "Shared with" : "Received from"}: {partner} ·
          requested by {item.requester.name} · {formatDateTime(item.createdAt)}
          {item.expiresAt ? ` · expires ${formatDate(item.expiresAt)}` : ""}
          {item.decidedAt && item.decidedBy ? ` · decided by ${item.decidedBy.name}` : ""}
        </p>
        {item.message && (
          <p className="mt-1 rounded bg-muted/60 px-2 py-1 text-xs text-muted-foreground">
            “{item.message}”
          </p>
        )}
      </div>
      <div className="shrink-0">
        {direction === "inbox" && pending && canDecide && (
          <SharingDecision requestId={item.id} projectCode={item.project.code} />
        )}
        {direction === "sent" && (pending || active) && canRevoke && (
          <SharingRevoke requestId={item.id} projectCode={item.project.code} />
        )}
        {direction === "inbox" && pending && !canDecide && (
          <span className="text-xs text-muted-foreground">Waiting for an approver</span>
        )}
      </div>
    </li>
  );
}

export default async function SharingPage() {
  const user = await getSessionUser();
  if (!user) return null;

  // Route guard: the M3 endpoint requires SHARING_MANAGE; mirror it for UX.
  if (!can(user.role, CAPABILITIES.SHARING_MANAGE)) {
    return (
      <div className="space-y-6">
        <PageHeader
          title="Sharing"
          description="Controlled cross-organization project sharing."
        />
        <UnauthorizedState
          title="Sharing requires management permission"
          description="Only project managers and organization admins manage sharing requests. Shared projects still appear in your Projects list once approved."
        />
      </div>
    );
  }

  const result = await apiGet<SharingLists>("/api/sharing/requests");
  if (!result.ok) {
    return (
      <div className="space-y-6">
        <PageHeader title="Sharing" description="Controlled cross-organization project sharing." />
        <EmptyState
          title="Sharing requests unavailable"
          description="The sharing endpoint could not be reached. Please retry."
        />
      </div>
    );
  }
  const { sent, inbox } = result.data;
  const canDecide = can(user.role, CAPABILITIES.SHARING_DECIDE);

  const pendingInbox = inbox.filter((i) => i.status === "PENDING");

  return (
    <div className="space-y-6">
      <PageHeader
        title="Sharing"
        description="Grant and receive read-only project access across organizations. Requests take effect only after approval and stop at expiry or revocation."
      >
        <SharingCreateDialog />
      </PageHeader>

      {pendingInbox.length > 0 && (
        <div className="rounded-md border border-amber-500/40 bg-amber-500/10 px-4 py-3 text-sm text-amber-700 dark:text-amber-300">
          {pendingInbox.length} incoming sharing{" "}
          {pendingInbox.length === 1 ? "request" : "requests"} awaiting your
          decision.
        </div>
      )}

      <Tabs defaultValue="inbox">
        <TabsList>
          <TabsTrigger value="inbox">
            Received ({inbox.length})
            {pendingInbox.length > 0 && (
              <span className="ml-1.5 rounded-full bg-amber-500/80 px-1.5 text-[10px] font-semibold text-white">
                {pendingInbox.length}
              </span>
            )}
          </TabsTrigger>
          <TabsTrigger value="sent">Sent ({sent.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="inbox" className="mt-4">
          <Card>
            <CardContent className="p-0">
              {inbox.length === 0 ? (
                <div className="p-6">
                  <EmptyState
                    title="No incoming requests"
                    description="When another organization shares a project with you, the request appears here for approval."
                  />
                </div>
              ) : (
                <ul className="divide-y">
                  {inbox.map((item) => (
                    <ShareRow
                      key={item.id}
                      item={item}
                      direction="inbox"
                      canDecide={canDecide}
                      canRevoke={false}
                    />
                  ))}
                </ul>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="sent" className="mt-4">
          <Card>
            <CardContent className="p-0">
              {sent.length === 0 ? (
                <div className="p-6">
                  <EmptyState
                    title="No outgoing requests"
                    description="Share one of your projects with a partner organization to start collaborating."
                  />
                </div>
              ) : (
                <ul className="divide-y">
                  {sent.map((item) => (
                    <ShareRow
                      key={item.id}
                      item={item}
                      direction="sent"
                      canDecide={false}
                      canRevoke
                    />
                  ))}
                </ul>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
