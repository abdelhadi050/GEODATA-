import Link from "next/link";
import { getSessionUser } from "@/lib/auth";
import { apiGet, requireData } from "@/lib/server-api";
import { formatDepth, formatDateTime } from "@/lib/format";
import { PageHeader } from "@/components/shared/page-header";
import { ListToolbar } from "@/components/shared/list-toolbar";
import { PaginationNav } from "@/components/shared/pagination-nav";
import { StatusBadge, TypeBadge } from "@/components/shared/status-badge";
import { EmptyState } from "@/components/shared/states";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  BOREHOLE_TYPES,
  BOREHOLE_TYPE_LABELS,
  BOREHOLE_STATUSES,
  BOREHOLE_STATUS_LABELS,
} from "@/lib/constants";
import type { BoreholeListItem } from "@/lib/api-types";

export default async function BoreholesPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  await getSessionUser();
  const sp = await searchParams;
  const search = typeof sp.search === "string" ? sp.search.trim() : undefined;
  const type = typeof sp.type === "string" ? sp.type : undefined;
  const status = typeof sp.status === "string" ? sp.status : undefined;
  const projectId = typeof sp.projectId === "string" ? sp.projectId : undefined;
  const page = Math.max(1, Number(sp.page ?? 1) || 1);

  const qs = new URLSearchParams();
  if (search) qs.set("search", search);
  if (type) qs.set("type", type);
  if (status) qs.set("status", status);
  if (projectId) qs.set("projectId", projectId);
  qs.set("page", String(page));
  qs.set("pageSize", "15");

  const result = await apiGet<BoreholeListItem[]>(`/api/boreholes?${qs.toString()}`);
  const { data, meta: m } = await requireData(result);
  const meta = { page: m?.page ?? 1, pageSize: m?.pageSize ?? 15, total: m?.total ?? data.length, totalPages: m?.totalPages ?? 1 };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Boreholes"
        description="Boreholes, soundings and trial pits across your accessible projects. Stratigraphy is managed on each borehole's page."
      />

      <ListToolbar
        searchPlaceholder="Search code, contractor, notes…"
        filters={[
          {
            key: "type",
            label: "types",
            options: BOREHOLE_TYPES.map((t) => ({ value: t, label: BOREHOLE_TYPE_LABELS[t] })),
          },
          {
            key: "status",
            label: "statuses",
            options: BOREHOLE_STATUSES.map((s) => ({ value: s, label: BOREHOLE_STATUS_LABELS[s] })),
          },
        ]}
      />

      {data.length === 0 ? (
        <EmptyState
          title={search || type || status ? "No boreholes match your filters" : "No boreholes yet"}
          description={
            search || type || status
              ? "Try clearing the filters."
              : "Boreholes are registered from a project's detail page."
          }
          actionLabel="Go to projects"
          actionHref="/projects"
        />
      ) : (
        <div className="overflow-x-auto rounded-lg border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Code</TableHead>
                <TableHead>Project</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="hidden md:table-cell">Depth</TableHead>
                <TableHead className="hidden lg:table-cell">Drilled</TableHead>
                <TableHead className="text-right">Layers</TableHead>
                <TableHead className="text-right">Samples</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {data.map((b) => (
                <TableRow key={b.id}>
                  <TableCell className="font-mono text-xs">
                    <Link
                      href={`/boreholes/${b.id}`}
                      className="font-medium text-primary hover:underline"
                    >
                      {b.code}
                    </Link>
                  </TableCell>
                  <TableCell className="max-w-[200px]">
                    <Link
                      href={`/projects/${b.project.id}`}
                      className="block truncate text-sm hover:underline"
                      title={`${b.project.code} — ${b.project.name}`}
                    >
                      {b.project.code}
                    </Link>
                  </TableCell>
                  <TableCell>
                    <TypeBadge value={b.type} />
                  </TableCell>
                  <TableCell>
                    <StatusBadge value={b.status} />
                  </TableCell>
                  <TableCell className="hidden md:table-cell tabular-nums">
                    {formatDepth(b.depth)}
                  </TableCell>
                  <TableCell className="hidden lg:table-cell">
                    {formatDateTime(b.drillingDate)}
                  </TableCell>
                  <TableCell className="text-right tabular-nums">
                    {b._count.layers}
                  </TableCell>
                  <TableCell className="text-right tabular-nums">
                    {b._count.samples}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      <PaginationNav
        basePath="/boreholes"
        params={{ search, type, status, projectId }}
        page={meta.page}
        totalPages={meta.totalPages}
        total={meta.total}
      />
    </div>
  );
}
