import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import { can, CAPABILITIES } from "@/lib/rbac";
import { apiGet } from "@/lib/server-api";
import {
  formatDate,
  formatDateTime,
  formatCoordinate,
  formatDepth,
  formatDepthRange,
} from "@/lib/format";
import { PageHeader } from "@/components/shared/page-header";
import { StatusBadge, TypeBadge } from "@/components/shared/status-badge";
import { EmptyState } from "@/components/shared/states";
import { StratigraphyColumn } from "@/components/boreholes/stratigraphy-column";
import { BoreholeFormDialog } from "@/components/boreholes/borehole-form-dialog";
import {
  LayerFormDialog,
  LayerDeleteButton,
} from "@/components/layers/layer-form-dialog";
import { SampleFormDialog } from "@/components/samples/sample-form-dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import type { BoreholeDetail } from "@/lib/api-types";

function InfoRow({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-4 py-1.5">
      <span className="shrink-0 text-muted-foreground">{label}</span>
      <span className="text-right font-medium">{value}</span>
    </div>
  );
}

export default async function BoreholeDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const user = await getSessionUser();
  if (!user) return null;

  const result = await apiGet<BoreholeDetail>(`/api/boreholes/${id}`);
  if (!result.ok && result.status === 401) redirect("/login");
  if (!result.ok) notFound();
  const borehole = result.data;

  const own = borehole.accessSource === "own";
  const canManageBorehole = own && can(user.role, CAPABILITIES.BOREHOLE_MANAGE);
  const canManageLayers = own && can(user.role, CAPABILITIES.LAYER_MANAGE);
  const canManageSamples = own && can(user.role, CAPABILITIES.SAMPLE_MANAGE);

  const layerOptions = borehole.layers.map((l) => ({
    id: l.id,
    label: `${l.layerCode ?? "—"} ${l.depthFrom.toFixed(1)}–${l.depthTo.toFixed(1)} m ${l.uscs ?? ""}`.trim(),
  }));

  return (
    <div className="space-y-6">
      <PageHeader
        title={`Borehole ${borehole.code}`}
        description={`Project ${borehole.project.code} — ${borehole.project.name}`}
      >
        {canManageBorehole && (
          <BoreholeFormDialog
            projectId={borehole.projectId}
            projectCode={borehole.project.code}
            borehole={borehole}
            variant="edit"
          />
        )}
      </PageHeader>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex flex-wrap items-center gap-2 text-base">
              Drilling record
              <TypeBadge value={borehole.type} />
              <StatusBadge value={borehole.status} />
            </CardTitle>
          </CardHeader>
          <CardContent>
            <dl className="grid gap-x-8 gap-y-0 sm:grid-cols-2">
              <div>
                <InfoRow label="Coordinates" value={<span className="font-mono text-xs">{formatCoordinate(borehole.latitude, borehole.longitude)}</span>} />
                <InfoRow label="Ground elevation" value={borehole.elevation != null ? `${borehole.elevation.toFixed(2)} m` : "—"} />
                <InfoRow label="Total depth" value={formatDepth(borehole.depth)} />
                <InfoRow label="Drilling date" value={formatDate(borehole.drillingDate)} />
              </div>
              <div>
                <InfoRow label="Drilled by" value={borehole.drilledBy ?? "—"} />
                <InfoRow label="Layers logged" value={borehole.layers.length} />
                <InfoRow label="Samples taken" value={borehole.samples.length} />
                <InfoRow label="Created" value={formatDateTime(borehole.createdAt)} />
              </div>
            </dl>
            {borehole.notes && (
              <p className="mt-3 rounded-md bg-muted/60 px-3 py-2 text-sm text-muted-foreground">
                {borehole.notes}
              </p>
            )}
            {borehole.sharedWithYou && (
              <p className="mt-3 rounded-md bg-accent px-3 py-2 text-xs text-primary">
                Read-only: this borehole belongs to a project shared with your
                organization.
              </p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Stratigraphy</CardTitle>
          </CardHeader>
          <CardContent className="overflow-x-auto">
            {borehole.layers.length === 0 && borehole.samples.length === 0 ? (
              <p className="py-8 text-sm text-muted-foreground">
                No layers or samples logged yet.
              </p>
            ) : (
              <StratigraphyColumn
                layers={borehole.layers}
                samples={borehole.samples}
                boreholeDepth={borehole.depth}
              />
            )}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="flex-row items-center justify-between space-y-0">
          <CardTitle className="text-base">Geological layers ({borehole.layers.length})</CardTitle>
          {canManageLayers && (
            <LayerFormDialog boreholeId={borehole.id} variant="create" />
          )}
        </CardHeader>
        <CardContent>
          {borehole.layers.length === 0 ? (
            <EmptyState
              title="No layers logged"
              description={
                canManageLayers
                  ? "Add geological layers with depth intervals to build the stratigraphic column."
                  : "No stratigraphy has been logged for this borehole yet."
              }
            />
          ) : (
            <div className="overflow-x-auto rounded-lg border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Depth (m)</TableHead>
                    <TableHead>Thickness</TableHead>
                    <TableHead>Material</TableHead>
                    <TableHead className="hidden sm:table-cell">Code</TableHead>
                    <TableHead className="hidden md:table-cell">USCS</TableHead>
                    <TableHead className="hidden lg:table-cell">Consistency</TableHead>
                    <TableHead>Description</TableHead>
                    {canManageLayers && <TableHead className="w-20 text-right">Actions</TableHead>}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {borehole.layers.map((l) => (
                    <TableRow key={l.id}>
                      <TableCell className="whitespace-nowrap font-mono text-xs tabular-nums">
                        {formatDepthRange(l.depthFrom, l.depthTo)}
                      </TableCell>
                      <TableCell className="tabular-nums">
                        {(l.depthTo - l.depthFrom).toFixed(2)} m
                      </TableCell>
                      <TableCell>
                        <TypeBadge value={l.materialType} />
                      </TableCell>
                      <TableCell className="hidden font-mono text-xs sm:table-cell">
                        {l.layerCode ?? "—"}
                      </TableCell>
                      <TableCell className="hidden font-mono text-xs md:table-cell">
                        {l.uscs ?? "—"}
                      </TableCell>
                      <TableCell className="hidden max-w-[140px] truncate lg:table-cell">
                        {l.consistency ?? "—"}
                      </TableCell>
                      <TableCell className="max-w-[280px]">
                        <span className="block truncate text-sm" title={l.description}>
                          {l.description}
                        </span>
                      </TableCell>
                      {canManageLayers && (
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-1">
                            <LayerFormDialog boreholeId={borehole.id} layer={l} variant="edit" />
                            <LayerDeleteButton
                              layerId={l.id}
                              label={l.layerCode ?? formatDepthRange(l.depthFrom, l.depthTo)}
                            />
                          </div>
                        </TableCell>
                      )}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex-row items-center justify-between space-y-0">
          <CardTitle className="text-base">Samples ({borehole.samples.length})</CardTitle>
          {canManageSamples && (
            <SampleFormDialog
              boreholeId={borehole.id}
              boreholeCode={borehole.code}
              layers={layerOptions}
              variant="create"
            />
          )}
        </CardHeader>
        <CardContent>
          {borehole.samples.length === 0 ? (
            <EmptyState
              title="No samples taken"
              description={
                canManageSamples
                  ? "Register samples with their depth interval to prepare laboratory testing."
                  : "No samples have been registered for this borehole."
              }
            />
          ) : (
            <div className="overflow-x-auto rounded-lg border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Code</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Depth (m)</TableHead>
                    <TableHead>Lab status</TableHead>
                    <TableHead className="hidden md:table-cell">Layer</TableHead>
                    <TableHead className="hidden sm:table-cell">Tests</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {borehole.samples.map((s) => (
                    <TableRow key={s.id}>
                      <TableCell className="font-mono text-xs">
                        <Link
                          href={`/samples/${s.id}`}
                          className="font-medium text-primary hover:underline"
                        >
                          {s.code}
                        </Link>
                      </TableCell>
                      <TableCell>
                        <TypeBadge value={s.type} />
                      </TableCell>
                      <TableCell className="whitespace-nowrap font-mono text-xs tabular-nums">
                        {formatDepthRange(s.depthFrom, s.depthTo)}
                      </TableCell>
                      <TableCell>
                        <StatusBadge value={s.labStatus} />
                      </TableCell>
                      <TableCell className="hidden font-mono text-xs md:table-cell">
                        {s.layer?.layerCode ?? s.layer?.uscs ?? "—"}
                      </TableCell>
                      <TableCell className="hidden sm:table-cell">
                        {s.labTests.length === 0 ? (
                          <span className="text-muted-foreground">—</span>
                        ) : (
                          <span className="flex flex-wrap gap-1">
                            {s.labTests.map((t) => (
                              <Link
                                key={t.id}
                                href={`/lab-tests/${t.id}`}
                                title={`${t.testType} — ${t.status}`}
                                className="rounded bg-muted px-1.5 py-0.5 font-mono text-[10px] hover:bg-accent"
                              >
                                {t.testType.slice(0, 4)}
                              </Link>
                            ))}
                          </span>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
