import Link from "next/link";
import {
  ArrowRight,
  FolderKanban,
  Drill,
  TestTube,
  FlaskConical,
  Share2,
} from "lucide-react";
import { getSessionUser } from "@/lib/auth";
import { can, CAPABILITIES } from "@/lib/rbac";
import { apiGet } from "@/lib/server-api";
import { formatDateTime, pluralize } from "@/lib/format";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { PageHeader } from "@/components/shared/page-header";
import { StatCard } from "@/components/shared/stat-card";
import { SignOutButton } from "@/components/layout/sign-out-button";
import { StatusBadge, statusTone } from "@/components/shared/status-badge";
import { EmptyState } from "@/components/shared/states";
import { ActivityFeed } from "@/components/shared/activity-feed";
import {
  PROJECT_STATUSES,
  PROJECT_STATUS_LABELS,
  LAB_TEST_STATUSES,
  LAB_TEST_STATUS_LABELS,
  ROLE_LABELS,
  type Role,
  type ProjectStatus,
  type LabTestStatus,
} from "@/lib/constants";
import type {
  ProjectListItem,
  BoreholeListItem,
  SampleListItem,
  LabTestListItem,
  ActivityItem,
  SharingLists,
} from "@/lib/api-types";

function countBy<T>(items: T[], key: (item: T) => string): Record<string, number> {
  const out: Record<string, number> = {};
  for (const item of items) {
    const k = key(item);
    out[k] = (out[k] ?? 0) + 1;
  }
  return out;
}

function Distribution({
  title,
  data,
  order,
  labels,
  emptyLabel,
}: {
  title: string;
  data: Record<string, number>;
  order: readonly string[];
  labels: Record<string, string>;
  emptyLabel: string;
}) {
  const total = Object.values(data).reduce((a, b) => a + b, 0);
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        {total === 0 ? (
          <p className="text-sm text-muted-foreground">{emptyLabel}</p>
        ) : (
          <ul className="space-y-2.5">
            {order.map((status) => {
              const count = data[status] ?? 0;
              const pct = total > 0 ? Math.round((count / total) * 100) : 0;
              return (
                <li key={status} className="space-y-1">
                  <div className="flex items-center justify-between text-sm">
                    <span>{labels[status]}</span>
                    <span className="tabular-nums text-muted-foreground">
                      {count}
                    </span>
                  </div>
                  <div className="h-1.5 overflow-hidden rounded-full bg-muted">
                    <div
                      className={BAR_TONES[statusTone(status)]}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}

const BAR_TONES: Record<string, string> = {
  emerald: "bg-emerald-600/75 dark:bg-emerald-500/75",
  teal: "bg-teal-600/75 dark:bg-teal-500/75",
  cyan: "bg-cyan-600/75 dark:bg-cyan-500/75",
  amber: "bg-amber-500/75 dark:bg-amber-500/70",
  red: "bg-red-600/75 dark:bg-red-500/75",
  slate: "bg-slate-500/60 dark:bg-slate-400/60",
};

export default async function DashboardPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const user = await getSessionUser();
  if (!user) return null;
  const sp = await searchParams;
  const denied = sp.denied === "1";

  const manageSharing = can(user.role, CAPABILITIES.SHARING_MANAGE);

  // Every number below comes from the real M3 API — no invented metrics.
  const [projectsRes, activeRes, boreholesRes, samplesRes, labTestsRes, activityRes, sharingRes] =
    await Promise.all([
      apiGet<ProjectListItem[]>("/api/projects?pageSize=100&sortBy=createdAt&sortOrder=desc"),
      apiGet<ProjectListItem[]>("/api/projects?status=ACTIVE&pageSize=1"),
      apiGet<BoreholeListItem[]>("/api/boreholes?pageSize=1"),
      apiGet<SampleListItem[]>("/api/samples?pageSize=1"),
      apiGet<LabTestListItem[]>("/api/lab-tests?pageSize=100"),
      apiGet<ActivityItem[]>("/api/activity?limit=8"),
      manageSharing ? apiGet<SharingLists>("/api/sharing/requests") : Promise.resolve(null),
    ]);

  const projectsOk = projectsRes.ok;
  const projects = projectsOk ? projectsRes.data : [];
  const totalProjects = projectsOk ? (projectsRes.meta?.total ?? projects.length) : 0;
  const activeProjects = activeRes.ok ? (activeRes.meta?.total ?? 0) : 0;
  const totalBoreholes = boreholesRes.ok ? (boreholesRes.meta?.total ?? 0) : 0;
  const totalSamples = samplesRes.ok ? (samplesRes.meta?.total ?? 0) : 0;
  const labTestsOk = labTestsRes.ok;
  const totalLabTests = labTestsOk ? (labTestsRes.meta?.total ?? 0) : 0;
  const pendingShares = sharingRes?.ok
    ? sharingRes.data.sent.filter((s) => s.status === "PENDING").length +
      sharingRes.data.inbox.filter((s) => s.status === "PENDING").length
    : null;

  const projectDist = countBy(projects, (p) => p.status);
  const labDist = labTestsOk ? countBy(labTestsRes.data, (t) => t.status) : {};
  const recentProjects = projects.slice(0, 5);
  const activity = activityRes.ok ? activityRes.data : [];

  const firstName = user.name.split(" ")[0];
  const roleLabel = ROLE_LABELS[user.role as Role] ?? user.role;

  return (
    <div className="space-y-6">
      <PageHeader
        title="Dashboard"
        description={`Welcome back, ${firstName} — ${roleLabel}. Live workspace metrics from the GEODATA HUB API.`}
      >
        <SignOutButton />
      </PageHeader>

      {denied && (
        <div className="rounded-md border border-amber-500/40 bg-amber-500/10 px-4 py-3 text-sm text-amber-700 dark:text-amber-300">
          Your role does not permit the page you requested. Ask an organization
          admin if you need additional capabilities.
        </div>
      )}

      {!projectsOk ? (
        <EmptyState
          title="Metrics unavailable"
          description="The projects endpoint could not be reached. Refresh the page or check the health endpoint."
        />
      ) : (
        <>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
            <StatCard label="Projects" value={totalProjects} hint={`${activeProjects} active`} />
            <StatCard
              label="Active projects"
              value={activeProjects}
              hint="Status ACTIVE"
            />
            <StatCard label="Boreholes" value={totalBoreholes} hint="Own + shared projects" />
            <StatCard label="Samples" value={totalSamples} hint="All sample types" />
            <StatCard label="Laboratory tests" value={totalLabTests} hint="12-type registry" />
            {pendingShares !== null ? (
              <StatCard
                label="Pending shares"
                value={pendingShares}
                hint="Incoming + outgoing requests"
              />
            ) : (
              <StatCard label="Pending shares" value="—" hint="Requires sharing permission" />
            )}
          </div>

          <div className="grid gap-4 lg:grid-cols-2">
            <Card className="min-w-0">
              <CardHeader className="flex-row items-center justify-between space-y-0">
                <CardTitle className="text-base">Recent projects</CardTitle>
                <Link
                  href="/projects"
                  className="flex items-center gap-1 text-sm font-medium text-primary hover:underline"
                >
                  All projects <ArrowRight className="h-3.5 w-3.5" />
                </Link>
              </CardHeader>
              <CardContent>
                {recentProjects.length === 0 ? (
                  <EmptyState
                    title="No projects yet"
                    description="Projects created in your organization will appear here."
                    actionLabel="Create a project"
                    actionHref="/projects"
                  />
                ) : (
                  <ul className="divide-y">
                    {recentProjects.map((p) => (
                      <li key={p.id} className="py-2.5 first:pt-0 last:pb-0">
                        <Link
                          href={`/projects/${p.id}`}
                          className="flex items-center justify-between gap-3 rounded-md px-1 py-1 hover:bg-accent/50"
                        >
                          <div className="min-w-0">
                            <div className="flex items-center gap-2">
                              <span className="font-mono text-xs text-muted-foreground">
                                {p.code}
                              </span>
                              {p.sharedWithYou && (
                                <span className="rounded bg-accent px-1.5 py-0.5 text-[10px] font-medium text-primary">
                                  Shared
                                </span>
                              )}
                            </div>
                            <p className="truncate text-sm font-medium">{p.name}</p>
                            <p className="text-xs text-muted-foreground">
                              {pluralize(p._count.boreholes, "borehole")} ·{" "}
                              {formatDateTime(p.createdAt)}
                            </p>
                          </div>
                          <StatusBadge value={p.status} />
                        </Link>
                      </li>
                    ))}
                  </ul>
                )}
              </CardContent>
            </Card>

            <Card className="min-w-0">
              <CardHeader className="flex-row items-center justify-between space-y-0">
                <CardTitle className="text-base">Recent activity</CardTitle>
                <Link
                  href="/activity"
                  className="flex items-center gap-1 text-sm font-medium text-primary hover:underline"
                >
                  Full log <ArrowRight className="h-3.5 w-3.5" />
                </Link>
              </CardHeader>
              <CardContent>
                {activity.length === 0 ? (
                  <EmptyState
                    title="No activity yet"
                    description="Actions performed in your organization are recorded here."
                  />
                ) : (
                  <ActivityFeed items={activity} />
                )}
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-4 lg:grid-cols-2">
            <Distribution
              title="Projects by status"
              data={projectDist}
              order={PROJECT_STATUSES}
              labels={PROJECT_STATUS_LABELS as Record<string, string>}
              emptyLabel="No projects to distribute."
            />
            <Distribution
              title="Laboratory tests by status"
              data={labDist}
              order={LAB_TEST_STATUSES}
              labels={LAB_TEST_STATUS_LABELS as Record<string, string>}
              emptyLabel="No laboratory tests registered yet."
            />
          </div>

          <p className="text-xs text-muted-foreground">
            Metrics are queried live from the API on each page load
            (projects, boreholes, samples, laboratory tests, sharing, activity).
            Distributions cover the first 100 records of each collection.
          </p>
        </>
      )}
    </div>
  );
}
