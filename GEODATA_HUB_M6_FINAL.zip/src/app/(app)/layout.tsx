import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import { apiGet } from "@/lib/server-api";
import { AppShell } from "@/components/layout/app-shell";
import type { OrganizationInfo } from "@/lib/api-types";

export default async function AppLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const user = await getSessionUser();
  if (!user) redirect("/login");

  // Organization display name — via the same API endpoint any client uses.
  // On API hiccup the shell still renders with a neutral fallback.
  const org = await apiGet<OrganizationInfo>("/api/organizations/current");
  const orgName = org.ok ? org.data.name : "GEODATA HUB";

  return (
    <AppShell user={user} orgName={orgName}>
      {children}
    </AppShell>
  );
}
