import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import { apiGet } from "@/lib/server-api";
import { formatDateTime } from "@/lib/format";
import { PageHeader } from "@/components/shared/page-header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CalculationOutput } from "@/components/lab-tests/calculation-output";
import {
  CalcStatusBadge,
  CalculationErrorAlert,
  InputSourceBadge,
  StaleNotice,
  ValidityBadge,
  friendlyKey,
} from "@/components/lab-tests/calculation-shared";
import type { CalculationRecordDto, RegistryEntryDto } from "@/lib/api-types";

/**
 * Calculation record detail (M5.3) — the full immutable snapshot persisted by
 * the M5.2 Calculate API: input snapshot, engine output, warnings or the
 * structured engine failure, provenance (engine/module versions, standard,
 * method), invalidation state and lab-test context. History is never
 * overwritten — stale records stay accessible here, clearly flagged.
 */
export default async function CalculationDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const user = await getSessionUser();
  if (!user) return null;

  const [recordRes, registryRes] = await Promise.all([
    apiGet<CalculationRecordDto>(`/api/calculations/${id}`),
    apiGet<RegistryEntryDto[]>("/api/lab-tests/registry"),
  ]);
  if (!recordRes.ok && recordRes.status === 401) redirect("/login");
  if (!recordRes.ok) notFound();
  const record = recordRes.data;
  const registry = registryRes.ok ? registryRes.data : [];
  const typeLabel = registry.find((r) => r.code === record.testType)?.label ?? record.testType;

  const input = record.inputSnapshot as Record<string, unknown> | null;
  const inputScalars = input
    ? Object.entries(input).filter(([, v]) => !Array.isArray(v) && (v === null || typeof v !== "object"))
    : [];
  const inputArrays = input
    ? Object.entries(input).filter(([, v]) => Array.isArray(v))
    : [];
  const inputNested = input
    ? Object.entries(input).filter(
        ([, v]) => v !== null && typeof v === "object" && !Array.isArray(v),
      )
    : [];

  return (
    <div className="space-y-6">
      <PageHeader
        title={`Calculation — ${typeLabel}`}
        description={`Sample ${record.labTest.sample.code} · Borehole ${record.labTest.sample.borehole.code} · Project ${record.labTest.sample.borehole.project.code} — ${record.labTest.sample.borehole.project.name}`}
      >
        <Link
          href={`/lab-tests/${record.labTest.id}`}
          className="text-sm text-primary hover:underline"
        >
          ← Back to test
        </Link>
      </PageHeader>

      <div className="flex flex-wrap items-center gap-2" data-testid="calculation-record-header">
        <CalcStatusBadge status={record.status} />
        <ValidityBadge isValid={record.isValid} />
        <InputSourceBadge source={record.inputSource} />
        <span className="text-xs text-muted-foreground">
          Record <span className="font-mono">{record.id}</span> · {formatDateTime(record.createdAt)}
        </span>
      </div>

      {!record.isValid && (
        <StaleNotice reason={record.invalidatedReason} invalidatedAt={record.invalidatedAt} />
      )}

      {record.status === "FAILED" && (
        <CalculationErrorAlert
          code={record.errorCode}
          message={record.errorMessage}
          details={record.errorDetails}
        />
      )}

      <div className="grid gap-4 lg:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Provenance</CardTitle>
          </CardHeader>
          <CardContent>
            <dl className="space-y-1.5 text-sm">
              <Row label="Engine module" value={<span className="font-mono text-xs">{record.moduleId}</span>} />
              <Row label="Module version" value={`v${record.moduleVersion}`} />
              <Row label="Engine version" value={`v${record.engineVersion}`} />
              <Row label="Standard" value={record.standard ?? "—"} />
              <Row label="Method" value={record.method ?? "—"} />
              <Row label="Test type" value={typeLabel} />
              <Row label="Created by" value={record.createdBy.name} />
              <Row label="Created at" value={formatDateTime(record.createdAt)} />
              <Row
                label="Input fingerprint"
                value={<span className="font-mono text-[11px]">{record.inputFingerprint.slice(0, 16)}…</span>}
              />
            </dl>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base">Input snapshot (immutable)</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {input === null ? (
              <p className="text-sm text-muted-foreground">
                No input was supplied for this attempt (the engine consumed nothing —
                recorded as a validation failure).
              </p>
            ) : (
              <>
                {inputScalars.length > 0 && (
                  <dl className="grid gap-x-8 gap-y-2 sm:grid-cols-2 lg:grid-cols-3">
                    {inputScalars.map(([key, value]) => (
                      <div key={key} className="flex items-baseline justify-between gap-3 border-b border-dashed py-1">
                        <dt className="text-sm text-muted-foreground">{friendlyKey(key)}</dt>
                        <dd className="font-medium tabular-nums">
                          {typeof value === "boolean" ? (value ? "Yes" : "No") : String(value ?? "—")}
                        </dd>
                      </div>
                    ))}
                  </dl>
                )}
                {inputNested.map(([key, value]) => (
                  <div key={key} className="space-y-1">
                    <p className="text-sm font-medium">{friendlyKey(key)}</p>
                    <pre className="overflow-x-auto rounded-md bg-muted/60 p-2 text-xs">
                      {JSON.stringify(value, null, 2)}
                    </pre>
                  </div>
                ))}
                {inputArrays.map(([key, value]) => {
                  const rows = value as Record<string, unknown>[];
                  const cols = rows.length > 0 ? Object.keys(rows[0]) : [];
                  return (
                    <div key={key} className="space-y-1.5">
                      <p className="text-sm font-medium">
                        {friendlyKey(key)} <span className="text-xs font-normal text-muted-foreground">({rows.length})</span>
                      </p>
                      <div className="overflow-x-auto rounded-md border">
                        <table className="w-full text-sm">
                          <thead className="bg-muted/50">
                            <tr>
                              {cols.map((c) => (
                                <th key={c} className="whitespace-nowrap px-3 py-2 text-left text-xs font-medium text-muted-foreground">
                                  {friendlyKey(c)}
                                </th>
                              ))}
                            </tr>
                          </thead>
                          <tbody>
                            {rows.map((row, i) => (
                              <tr key={i} className="border-t">
                                {cols.map((c) => (
                                  <td key={c} className="whitespace-nowrap px-3 py-1.5 tabular-nums">
                                    {String(row[c] ?? "—")}
                                  </td>
                                ))}
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  );
                })}
                {inputScalars.length === 0 && inputArrays.length === 0 && inputNested.length === 0 && (
                  <p className="text-sm text-muted-foreground">Empty input snapshot.</p>
                )}
              </>
            )}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">
            {record.status === "COMPLETED" ? "Calculated output" : "Engine outcome"}
          </CardTitle>
        </CardHeader>
        <CardContent>
          {record.status === "COMPLETED" ? (
            <CalculationOutput
              moduleId={record.moduleId}
              results={(record.output?.results as Record<string, unknown> | null) ?? null}
              inputSnapshot={record.inputSnapshot}
              warnings={record.warnings}
            />
          ) : (
            <p className="text-sm text-muted-foreground">
              The engine did not produce results for this attempt — the structured failure is
              shown above and persisted verbatim on this record.
            </p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function Row({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-4 py-1">
      <span className="shrink-0 text-muted-foreground">{label}</span>
      <span className="text-right font-medium">{value}</span>
    </div>
  );
}
