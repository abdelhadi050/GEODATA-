import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import { can, CAPABILITIES } from "@/lib/rbac";
import { apiGet } from "@/lib/server-api";
import { formatDateTime, formatDepthRange } from "@/lib/format";
import { PageHeader } from "@/components/shared/page-header";
import { StatusBadge, TypeBadge } from "@/components/shared/status-badge";
import { PaginationNav } from "@/components/shared/pagination-nav";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { TestChart } from "@/components/lab-tests/test-chart";
import { ResultFormDialog } from "@/components/lab-tests/result-form-dialog";
import { TestStatusControl } from "@/components/lab-tests/status-controls";
import { CalculatePanel } from "@/components/lab-tests/calculate-panel";
import { CalculationOutput } from "@/components/lab-tests/calculation-output";
import {
  CalcStatusBadge,
  InputSourceBadge,
  ValidityBadge,
} from "@/components/lab-tests/calculation-shared";
import type {
  LabTestDetail,
  RegistryEntryDto,
  EngineInfoDto,
  LatestCalculationDto,
  CalculationListItemDto,
} from "@/lib/api-types";

const CATEGORY_LABELS: Record<string, string> = {
  INDEX_PROPERTIES: "Index properties",
  COMPACTION: "Compaction",
  MECHANICAL: "Mechanical",
  IN_SITU: "In situ",
};

function friendlyKey(key: string): string {
  return key
    .replace(/([A-Z])/g, " $1")
    .replace(/^./, (c) => c.toUpperCase())
    .replace(/ Kpa/, " (kPa)")
    .replace(/ Mpa/, " (MPa)")
    .replace(/ Percent/, " (%)")
    .replace(/ Mm/, " (mm)")
    .replace(/ Deg/, " (°)")
    .replace(/ G/, " (g)");
}

export default async function LabTestDetailPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const { id } = await params;
  const sp = await searchParams;
  const calcPage = Math.max(1, Number(sp.page ?? 1) || 1);
  const user = await getSessionUser();
  if (!user) return null;

  const [testRes, registryRes, enginesRes, latestRes, historyRes] = await Promise.all([
    apiGet<LabTestDetail>(`/api/lab-tests/${id}`),
    apiGet<RegistryEntryDto[]>("/api/lab-tests/registry"),
    apiGet<EngineInfoDto[]>("/api/calculations/engines"),
    apiGet<LatestCalculationDto>(`/api/lab-tests/${id}/calculations/latest`),
    apiGet<CalculationListItemDto[]>(
      `/api/lab-tests/${id}/calculations?page=${calcPage}&pageSize=10`,
    ),
  ]);
  if (!testRes.ok && testRes.status === 401) redirect("/login");
  if (!testRes.ok) notFound();
  const test = testRes.data;

  const registryEntry = registryRes.ok
    ? registryRes.data.find((r) => r.code === test.testType)
    : undefined;
  const engines = enginesRes.ok ? enginesRes.data : [];
  const engine = engines.find((e) => e.testType === test.testType) ?? null;
  // 404 from the latest endpoint is an expected outcome (no valid calculation
  // yet) — it never hides the page.
  const latest = latestRes.ok ? latestRes.data : null;
  const history = historyRes.ok ? historyRes.data : [];
  const historyMeta = historyRes.ok && historyRes.meta
    ? {
        page: historyRes.meta.page ?? 1,
        total: historyRes.meta.total ?? history.length,
        totalPages: historyRes.meta.totalPages ?? 1,
      }
    : { page: 1, total: history.length, totalPages: 1 };

  const own = test.accessSource === "own";
  const canRecord = own && can(user.role, CAPABILITIES.LAB_TEST_RESULT);
  const canManage = own && can(user.role, CAPABILITIES.LAB_TEST_MANAGE);
  const canCalculate = canRecord; // server enforces the same capability + ownership
  const disabledReason = !own
    ? "Read-only: this test belongs to a project shared with your organization — calculation requires ownership."
    : "Your role does not include permission to run calculations (labtest:result capability required).";

  const result = test.resultData as Record<string, unknown> | null;
  const scalars = result
    ? Object.entries(result).filter(([, v]) => !Array.isArray(v))
    : [];
  const arrays = result
    ? Object.entries(result).filter(([, v]) => Array.isArray(v))
    : [];

  return (
    <div className="space-y-6">
      <PageHeader
        title={registryEntry?.label ?? test.testType}
        description={`Sample ${test.sample.code} · Borehole ${test.sample.borehole.code} · Project ${test.sample.borehole.project.code} — ${test.sample.borehole.project.name}`}
      >
        {canRecord && (
          <ResultFormDialog
            testId={test.id}
            testType={test.testType}
            testLabel={registryEntry?.label ?? test.testType}
            existingResult={result}
            existingSummary={test.summary}
          />
        )}
      </PageHeader>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader className="flex-row flex-wrap items-center justify-between gap-3 space-y-0">
            <CardTitle className="flex flex-wrap items-center gap-2 text-base">
              Test record <StatusBadge value={test.status} />
            </CardTitle>
            {canManage && (
              <TestStatusControl
                testId={test.id}
                status={test.status}
                hasResult={!!result}
              />
            )}
          </CardHeader>
          <CardContent>
            <dl className="grid gap-x-8 gap-y-0 sm:grid-cols-2">
              <div>
                <Row label="Standard" value={registryEntry?.standard ?? "—"} />
                <Row label="Category" value={registryEntry ? CATEGORY_LABELS[registryEntry.category] ?? registryEntry.category : "—"} />
                <Row label="Sample type" value={<TypeBadge value={test.sample.type} />} />
                <Row
                  label="Sample depth"
                  value={<span className="font-mono text-xs">{formatDepthRange(test.sample.depthFrom, test.sample.depthTo)}</span>}
                />
              </div>
              <div>
                <Row
                  label="Sample"
                  value={
                    <Link href={`/samples/${test.sample.id}`} className="font-mono text-xs text-primary hover:underline">
                      {test.sample.code}
                    </Link>
                  }
                />
                <Row
                  label="Borehole"
                  value={
                    <Link href={`/boreholes/${test.sample.borehole.id}`} className="font-mono text-xs text-primary hover:underline">
                      {test.sample.borehole.code}
                    </Link>
                  }
                />
                <Row label="Registered" value={formatDateTime(test.createdAt)} />
                <Row label="Performed" value={formatDateTime(test.performedAt)} />
              </div>
            </dl>
            {test.summary && (
              <p className="mt-3 rounded-md bg-accent/60 px-3 py-2 text-sm">
                <span className="font-medium">Summary:</span> {test.summary}
              </p>
            )}
            {test.notes && (
              <p className="mt-2 text-sm text-muted-foreground">{test.notes}</p>
            )}
            {test.accessSource === "shared" && (
              <p className="mt-3 rounded-md bg-accent px-3 py-2 text-xs text-primary">
                Read-only: this test belongs to a project shared with your organization.
              </p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Registry validation rules</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="mb-3 text-xs text-muted-foreground">
              Results are validated against the {registryEntry?.label ?? test.testType}{" "}
              schema before storage — the same rules run in this form and in the API.
            </p>
            <ul className="space-y-2 text-sm">
              {(test.registry?.validationNotes ?? registryEntry?.validationNotes ?? []).map(
                (note) => (
                  <li key={note} className="flex gap-2">
                    <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
                    <span>{note}</span>
                  </li>
                ),
              )}
            </ul>
          </CardContent>
        </Card>
      </div>

      {result && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Recorded result</CardTitle>
          </CardHeader>
          <CardContent className="space-y-5">
            {scalars.length > 0 && (
              <dl className="grid gap-x-8 gap-y-2 sm:grid-cols-2 lg:grid-cols-3">
                {scalars.map(([key, value]) => (
                  <div
                    key={key}
                    className="flex items-baseline justify-between gap-3 border-b border-dashed py-1"
                  >
                    <dt className="text-sm text-muted-foreground">{friendlyKey(key)}</dt>
                    <dd className="font-medium tabular-nums">
                      {typeof value === "boolean" ? (value ? "Yes" : "No") : String(value)}
                    </dd>
                  </div>
                ))}
              </dl>
            )}

            {arrays.map(([key, value]) => {
              const rows = value as Record<string, unknown>[];
              const cols = rows.length > 0 ? Object.keys(rows[0]) : [];
              return (
                <div key={key} className="space-y-2">
                  <p className="text-sm font-medium">{friendlyKey(key)} ({rows.length})</p>
                  <div className="overflow-x-auto rounded-md border">
                    <table className="w-full text-sm">
                      <thead className="bg-muted/50">
                        <tr>
                          {cols.map((c) => (
                            <th key={c} className="px-3 py-2 text-left text-xs font-medium text-muted-foreground">
                              {friendlyKey(c)}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {rows.map((row, i) => (
                          <tr key={i} className="border-t">
                            {cols.map((c) => (
                              <td key={c} className="px-3 py-1.5 tabular-nums">
                                {typeof row[c] === "boolean"
                                  ? row[c]
                                    ? "Yes"
                                    : "No"
                                    : String(row[c] ?? "—")}
                              </td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              );
            })}

            <div>
              <p className="mb-2 text-sm font-medium">
                {test.registry?.chart && test.registry.chart.kind !== "none"
                  ? "Visualization"
                  : "Visualization unavailable"}
              </p>
              {test.registry && (
                <TestChart chart={test.registry.chart} result={result} />
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {!result && (
        <Card>
          <CardContent className="py-8 text-center text-sm text-muted-foreground">
            No result recorded yet.{" "}
            {canRecord
              ? "Use “Record result” to enter validated values — the chart appears once a result is stored."
              : "A result can be recorded by an engineer, project manager or admin of the owning organization."}
          </CardContent>
        </Card>
      )}

      {/* M5.3 — Calculation: engine-computed results from the M5.2 Calculate
          API. Kept visually separate from the recorded laboratory data above
          so calculated values and user-provided inputs are always
          distinguishable. */}
      <div className="space-y-4" data-testid="calculation-section">
        <Card>
          <CardHeader className="flex-row flex-wrap items-center justify-between gap-3 space-y-0">
            <CardTitle className="flex flex-wrap items-center gap-2 text-base">
              Latest valid calculation
              {latest && <CalcStatusBadge status={latest.status} />}
              {latest && <InputSourceBadge source={latest.inputSource} />}
            </CardTitle>
            {latest && (
              <Link
                href={`/calculations/${latest.id}`}
                className="text-xs text-primary hover:underline"
              >
                View full record →
              </Link>
            )}
          </CardHeader>
          <CardContent className="space-y-4">
            {latest ? (
              <>
                <p className="text-xs text-muted-foreground">
                  Computed {formatDateTime(latest.createdAt)} by {latest.createdBy.name} · engine{" "}
                  <span className="font-mono">{latest.moduleId}</span> v{latest.moduleVersion}
                  {latest.method ? ` · ${latest.method}` : ""}
                  {latest.standard ? ` · ${latest.standard}` : ""} — from the current recorded data.
                </p>
                <CalculationOutput
                  moduleId={latest.moduleId}
                  results={(latest.output?.results as Record<string, unknown> | null) ?? null}
                  inputSnapshot={latest.inputSnapshot}
                  warnings={latest.warnings}
                />
              </>
            ) : (
              <p className="py-4 text-center text-sm text-muted-foreground" data-testid="no-latest-calculation">
                {engine
                  ? "No valid calculation yet — run the engine below; the latest valid result of the current data appears here."
                  : "This test type has no calculation engine — results stay laboratory-entered."}
              </p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Run calculation</CardTitle>
          </CardHeader>
          <CardContent>
            <CalculatePanel
              testId={test.id}
              testType={test.testType}
              testLabel={registryEntry?.label ?? test.testType}
              engine={engine}
              canCalculate={canCalculate}
              hasRecordedResult={!!result}
              recordedResult={result}
              disabledReason={disabledReason}
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex-row flex-wrap items-center justify-between gap-3 space-y-0">
            <CardTitle className="text-base">Calculation history</CardTitle>
            <p className="text-xs text-muted-foreground">
              Immutable snapshots — history is preserved; invalidated records stay flagged, never overwritten.
            </p>
          </CardHeader>
          <CardContent className="space-y-4">
            {history.length === 0 ? (
              <p className="py-4 text-center text-sm text-muted-foreground" data-testid="no-calculation-history">
                No calculations recorded for this test yet.
              </p>
            ) : (
              <>
                <div className="overflow-x-auto rounded-md border" data-testid="calculation-history">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Date</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Validity</TableHead>
                        <TableHead>Source</TableHead>
                        <TableHead className="hidden md:table-cell">Method</TableHead>
                        <TableHead className="hidden lg:table-cell">Warnings</TableHead>
                        <TableHead className="hidden lg:table-cell">Created by</TableHead>
                        <TableHead />
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {history.map((h) => (
                        <TableRow key={h.id} data-testid="calculation-history-row">
                          <TableCell className="whitespace-nowrap text-xs">
                            {formatDateTime(h.createdAt)}
                          </TableCell>
                          <TableCell>
                            <CalcStatusBadge status={h.status} />
                          </TableCell>
                          <TableCell>
                            <ValidityBadge isValid={h.isValid} />
                          </TableCell>
                          <TableCell>
                            <InputSourceBadge source={h.inputSource} />
                          </TableCell>
                          <TableCell className="hidden max-w-[180px] truncate md:table-cell">
                            {h.method ?? "—"}
                          </TableCell>
                          <TableCell className="hidden lg:table-cell">
                            {h.warningCount > 0 ? (
                              <span className="font-medium text-amber-600 dark:text-amber-400">
                                {h.warningCount}
                              </span>
                            ) : (
                              "—"
                            )}
                          </TableCell>
                          <TableCell className="hidden lg:table-cell">{h.createdBy.name}</TableCell>
                          <TableCell>
                            <Link
                              href={`/calculations/${h.id}`}
                              className="text-xs text-primary hover:underline"
                            >
                              View
                            </Link>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
                <PaginationNav
                  basePath={`/lab-tests/${test.id}`}
                  params={{}}
                  page={historyMeta.page}
                  totalPages={historyMeta.totalPages}
                  total={historyMeta.total}
                />
              </>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function Row({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-4 py-1.5">
      <span className="shrink-0 text-muted-foreground">{label}</span>
      <span className="text-right font-medium">{value}</span>
    </div>
  );
}
