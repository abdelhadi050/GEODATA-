import Link from "next/link";
import { getSessionUser } from "@/lib/auth";
import { apiGet, requireData } from "@/lib/server-api";
import { formatDateTime } from "@/lib/format";
import { PageHeader } from "@/components/shared/page-header";
import { ListToolbar } from "@/components/shared/list-toolbar";
import { PaginationNav } from "@/components/shared/pagination-nav";
import { StatusBadge } from "@/components/shared/status-badge";
import { EmptyState } from "@/components/shared/states";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  LAB_TEST_STATUSES,
  LAB_TEST_STATUS_LABELS,
} from "@/lib/constants";
import type { LabTestListItem, RegistryEntryDto } from "@/lib/api-types";

export default async function LabTestsPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  await getSessionUser();
  const sp = await searchParams;
  const search = typeof sp.search === "string" ? sp.search.trim() : undefined;
  const testType = typeof sp.testType === "string" ? sp.testType : undefined;
  const status = typeof sp.status === "string" ? sp.status : undefined;
  const projectId = typeof sp.projectId === "string" ? sp.projectId : undefined;
  const page = Math.max(1, Number(sp.page ?? 1) || 1);

  const qs = new URLSearchParams();
  if (search) qs.set("search", search);
  if (testType) qs.set("testType", testType);
  if (status) qs.set("status", status);
  if (projectId) qs.set("projectId", projectId);
  qs.set("page", String(page));
  qs.set("pageSize", "15");

  const [result, registryRes] = await Promise.all([
    apiGet<LabTestListItem[]>(`/api/lab-tests?${qs.toString()}`),
    apiGet<RegistryEntryDto[]>("/api/lab-tests/registry"),
  ]);
  const { data, meta: m } = await requireData(result);
  const registry = registryRes.ok ? registryRes.data : [];
  const meta = {
    page: m?.page ?? 1,
    pageSize: m?.pageSize ?? 15,
    total: m?.total ?? data.length,
    totalPages: m?.totalPages ?? 1,
  };

  const typeLabel = (code: string) =>
    registry.find((r) => r.code === code)?.label ?? code;

  return (
    <div className="space-y-6">
      <PageHeader
        title="Laboratory Tests"
        description="Tests from the 12-type geotechnical registry, tracked from registration to validated results."
      />

      <ListToolbar
        searchPlaceholder="Search summary or performer…"
        filters={[
          {
            key: "testType",
            label: "test types",
            options: registry.map((r) => ({ value: r.code, label: r.label })),
          },
          {
            key: "status",
            label: "statuses",
            options: LAB_TEST_STATUSES.map((s) => ({ value: s, label: LAB_TEST_STATUS_LABELS[s] })),
          },
        ]}
      />

      {data.length === 0 ? (
        <EmptyState
          title={search || testType || status ? "No tests match your filters" : "No laboratory tests yet"}
          description={
            search || testType || status
              ? "Try clearing the filters."
              : "Tests are registered from a sample's detail page."
          }
          actionLabel="Go to samples"
          actionHref="/samples"
        />
      ) : (
        <div className="overflow-x-auto rounded-lg border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Test type</TableHead>
                <TableHead>Sample</TableHead>
                <TableHead>Borehole</TableHead>
                <TableHead className="hidden lg:table-cell">Project</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="hidden md:table-cell">Summary</TableHead>
                <TableHead className="hidden xl:table-cell">Performed</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {data.map((t) => (
                <TableRow key={t.id}>
                  <TableCell>
                    <Link
                      href={`/lab-tests/${t.id}`}
                      className="font-medium text-primary hover:underline"
                    >
                      {typeLabel(t.testType)}
                    </Link>
                  </TableCell>
                  <TableCell className="font-mono text-xs">
                    <Link href={`/samples/${t.sample.id}`} className="text-primary hover:underline">
                      {t.sample.code}
                    </Link>
                  </TableCell>
                  <TableCell className="font-mono text-xs">
                    <Link href={`/boreholes/${t.sample.borehole.id}`} className="text-primary hover:underline">
                      {t.sample.borehole.code}
                    </Link>
                  </TableCell>
                  <TableCell className="hidden max-w-[160px] truncate lg:table-cell">
                    <Link href={`/projects/${t.sample.borehole.project.id}`} className="hover:underline">
                      {t.sample.borehole.project.code}
                    </Link>
                  </TableCell>
                  <TableCell>
                    <StatusBadge value={t.status} />
                  </TableCell>
                  <TableCell className="hidden max-w-[220px] md:table-cell">
                    <span className="block truncate text-sm" title={t.summary ?? ""}>
                      {t.summary ?? "—"}
                    </span>
                  </TableCell>
                  <TableCell className="hidden xl:table-cell">
                    {formatDateTime(t.performedAt)}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      <PaginationNav
        basePath="/lab-tests"
        params={{ search, testType, status, projectId }}
        page={meta.page}
        totalPages={meta.totalPages}
        total={meta.total}
      />
    </div>
  );
}
