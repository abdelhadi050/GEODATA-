import Link from "next/link";
import { Compass } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function AppNotFound() {
  return (
    <div className="flex flex-col items-center justify-center rounded-lg border border-dashed px-6 py-16 text-center">
      <div className="flex h-12 w-12 items-center justify-center rounded-full bg-accent text-primary">
        <Compass className="h-6 w-6" />
      </div>
      <h2 className="mt-4 text-base font-semibold">Record not found</h2>
      <p className="mt-1.5 max-w-md text-sm text-muted-foreground">
        This record does not exist, or it belongs to another organization and
        is not shared with yours. Cross-tenant records are indistinguishable
        from missing ones by design.
      </p>
      <Button asChild size="sm" variant="outline" className="mt-5">
        <Link href="/dashboard">Back to dashboard</Link>
      </Button>
    </div>
  );
}
