import Link from "next/link";
import { getSessionUser } from "@/lib/auth";
import { apiGet, requireData } from "@/lib/server-api";
import { formatDepthRange } from "@/lib/format";
import { PageHeader } from "@/components/shared/page-header";
import { ListToolbar } from "@/components/shared/list-toolbar";
import { PaginationNav } from "@/components/shared/pagination-nav";
import { StatusBadge, TypeBadge } from "@/components/shared/status-badge";
import { EmptyState } from "@/components/shared/states";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  SAMPLE_TYPES,
  SAMPLE_TYPE_LABELS,
  LAB_STATUSES,
  LAB_STATUS_LABELS,
} from "@/lib/constants";
import type { SampleListItem } from "@/lib/api-types";

export default async function SamplesPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  await getSessionUser();
  const sp = await searchParams;
  const search = typeof sp.search === "string" ? sp.search.trim() : undefined;
  const type = typeof sp.type === "string" ? sp.type : undefined;
  const labStatus = typeof sp.labStatus === "string" ? sp.labStatus : undefined;
  const projectId = typeof sp.projectId === "string" ? sp.projectId : undefined;
  const page = Math.max(1, Number(sp.page ?? 1) || 1);

  const qs = new URLSearchParams();
  if (search) qs.set("search", search);
  if (type) qs.set("type", type);
  if (labStatus) qs.set("labStatus", labStatus);
  if (projectId) qs.set("projectId", projectId);
  qs.set("page", String(page));
  qs.set("pageSize", "15");

  const result = await apiGet<SampleListItem[]>(`/api/samples?${qs.toString()}`);
  const { data, meta: m } = await requireData(result);
  const meta = { page: m?.page ?? 1, pageSize: m?.pageSize ?? 15, total: m?.total ?? data.length, totalPages: m?.totalPages ?? 1 };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Samples"
        description="Physical specimens recovered from boreholes, with laboratory tracking status."
      />

      <ListToolbar
        searchPlaceholder="Search sample code or notes…"
        filters={[
          {
            key: "type",
            label: "types",
            options: SAMPLE_TYPES.map((t) => ({ value: t, label: SAMPLE_TYPE_LABELS[t] })),
          },
          {
            key: "labStatus",
            label: "lab statuses",
            options: LAB_STATUSES.map((s) => ({ value: s, label: LAB_STATUS_LABELS[s] })),
          },
        ]}
      />

      {data.length === 0 ? (
        <EmptyState
          title={search || type || labStatus ? "No samples match your filters" : "No samples yet"}
          description={
            search || type || labStatus
              ? "Try clearing the filters."
              : "Samples are registered from a borehole's detail page."
          }
          actionLabel="Go to boreholes"
          actionHref="/boreholes"
        />
      ) : (
        <div className="overflow-x-auto rounded-lg border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Code</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Depth (m)</TableHead>
                <TableHead>Borehole</TableHead>
                <TableHead className="hidden md:table-cell">Project</TableHead>
                <TableHead>Lab status</TableHead>
                <TableHead className="hidden text-right sm:table-cell">Tests</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {data.map((s) => (
                <TableRow key={s.id}>
                  <TableCell className="font-mono text-xs">
                    <Link
                      href={`/samples/${s.id}`}
                      className="font-medium text-primary hover:underline"
                    >
                      {s.code}
                    </Link>
                  </TableCell>
                  <TableCell>
                    <TypeBadge value={s.type} />
                  </TableCell>
                  <TableCell className="whitespace-nowrap font-mono text-xs tabular-nums">
                    {formatDepthRange(s.depthFrom, s.depthTo)}
                  </TableCell>
                  <TableCell className="font-mono text-xs">
                    <Link
                      href={`/boreholes/${s.borehole.id}`}
                      className="text-primary hover:underline"
                    >
                      {s.borehole.code}
                    </Link>
                  </TableCell>
                  <TableCell className="hidden max-w-[180px] truncate md:table-cell">
                    <Link href={`/projects/${s.borehole.project.id}`} className="hover:underline">
                      {s.borehole.project.code}
                    </Link>
                  </TableCell>
                  <TableCell>
                    <StatusBadge value={s.labStatus} />
                  </TableCell>
                  <TableCell className="hidden text-right tabular-nums sm:table-cell">
                    {s.labTests.length}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      <PaginationNav
        basePath="/samples"
        params={{ search, type, labStatus, projectId }}
        page={meta.page}
        totalPages={meta.totalPages}
        total={meta.total}
      />
    </div>
  );
}
