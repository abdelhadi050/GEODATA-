import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import { can, CAPABILITIES } from "@/lib/rbac";
import { apiGet } from "@/lib/server-api";
import { formatDate, formatDateTime, formatDepthRange } from "@/lib/format";
import { PageHeader } from "@/components/shared/page-header";
import { StatusBadge, TypeBadge } from "@/components/shared/status-badge";
import { EmptyState } from "@/components/shared/states";
import { SampleFormDialog } from "@/components/samples/sample-form-dialog";
import { TestFormDialog } from "@/components/lab-tests/test-form-dialog";
import { ClassificationPanel } from "@/components/classifications/classification-panel";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import type { SampleDetail, RegistryEntryDto } from "@/lib/api-types";

function InfoRow({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-4 py-1.5">
      <span className="shrink-0 text-muted-foreground">{label}</span>
      <span className="text-right font-medium">{value}</span>
    </div>
  );
}

export default async function SampleDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const user = await getSessionUser();
  if (!user) return null;

  const [sampleRes, registryRes] = await Promise.all([
    apiGet<SampleDetail>(`/api/samples/${id}`),
    apiGet<RegistryEntryDto[]>("/api/lab-tests/registry"),
  ]);
  if (!sampleRes.ok && sampleRes.status === 401) redirect("/login");
  if (!sampleRes.ok) notFound();
  const sample = sampleRes.data;
  const registry = registryRes.ok ? registryRes.data : [];

  const own = sample.accessSource === "own";
  const canManageSample = own && can(user.role, CAPABILITIES.SAMPLE_MANAGE);
  const canManageTests = own && can(user.role, CAPABILITIES.LAB_TEST_MANAGE);

  return (
    <div className="space-y-6">
      <PageHeader
        title={`Sample ${sample.code}`}
        description={`Borehole ${sample.borehole.code} · Project ${sample.borehole.project.code} — ${sample.borehole.project.name}`}
      >
        {canManageSample && (
          <SampleFormDialog
            boreholeId={sample.boreholeId}
            boreholeCode={sample.borehole.code}
            sample={sample}
            variant="edit"
          />
        )}
      </PageHeader>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex flex-wrap items-center gap-2 text-base">
              Specimen record
              <TypeBadge value={sample.type} />
              <StatusBadge value={sample.labStatus} />
            </CardTitle>
          </CardHeader>
          <CardContent>
            <dl className="grid gap-x-8 gap-y-0 sm:grid-cols-2">
              <div>
                <InfoRow
                  label="Depth interval"
                  value={
                    <span className="font-mono text-xs">
                      {formatDepthRange(sample.depthFrom, sample.depthTo)}
                    </span>
                  }
                />
                <InfoRow
                  label="Recovery"
                  value={sample.recovery != null ? `${sample.recovery.toFixed(0)} %` : "—"}
                />
                <InfoRow label="Collected on" value={formatDate(sample.collectedAt)} />
                <InfoRow
                  label="Geological layer"
                  value={sample.layer ? `${sample.layer.layerCode ?? ""} ${sample.layer.uscs ?? ""}`.trim() || "Linked" : "—"}
                />
              </div>
              <div>
                <InfoRow
                  label="Borehole"
                  value={
                    <Link href={`/boreholes/${sample.borehole.id}`} className="text-primary hover:underline">
                      {sample.borehole.code}
                    </Link>
                  }
                />
                <InfoRow
                  label="Project"
                  value={
                    <Link
                      href={`/projects/${sample.borehole.project.id}`}
                      className="text-primary hover:underline"
                    >
                      {sample.borehole.project.code}
                    </Link>
                  }
                />
                <InfoRow label="Registered" value={formatDateTime(sample.createdAt)} />
                <InfoRow label="Laboratory tests" value={sample.labTests.length} />
              </div>
            </dl>
            {sample.notes && (
              <p className="mt-3 rounded-md bg-muted/60 px-3 py-2 text-sm text-muted-foreground">
                {sample.notes}
              </p>
            )}
            {sample.accessSource === "shared" && (
              <p className="mt-3 rounded-md bg-accent px-3 py-2 text-xs text-primary">
                Read-only: this sample belongs to a project shared with your organization.
              </p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Laboratory tests</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {canManageTests && (
              <TestFormDialog
                sampleId={sample.id}
                sampleCode={sample.code}
                registry={registry}
                existingTypes={sample.labTests.map((t) => t.testType)}
              />
            )}
            {sample.labTests.length === 0 ? (
              <p className="py-6 text-sm text-muted-foreground">
                No laboratory tests registered for this sample yet.
              </p>
            ) : (
              <ul className="divide-y rounded-md border">
                {sample.labTests.map((t) => (
                  <li key={t.id}>
                    <Link
                      href={`/lab-tests/${t.id}`}
                      className="flex items-center justify-between gap-2 px-3 py-2.5 hover:bg-accent/50"
                    >
                      <div className="min-w-0">
                        <p className="truncate text-sm font-medium">{t.testType}</p>
                        {t.summary && (
                          <p className="truncate text-xs text-muted-foreground">{t.summary}</p>
                        )}
                      </div>
                      <StatusBadge value={t.status} />
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>
      </div>

      {/* M5.4 — Classification panel (USCS + AASHTO) */}
      <ClassificationPanel
        sampleId={sample.id}
        canClassify={own && can(user.role, CAPABILITIES.LAB_TEST_RESULT)}
      />
    </div>
  );
}
