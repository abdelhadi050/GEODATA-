"use client";

import { useEffect } from "react";
import { AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function AppError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error("[ui] page error", error.message);
  }, [error]);

  return (
    <div className="flex flex-col items-center justify-center rounded-lg border border-dashed px-6 py-16 text-center">
      <div className="flex h-12 w-12 items-center justify-center rounded-full bg-accent">
        <AlertTriangle className="h-6 w-6 text-destructive" />
      </div>
      <h2 className="mt-4 text-base font-semibold">This page could not load</h2>
      <p className="mt-1.5 max-w-md text-sm text-muted-foreground">
        The request failed unexpectedly. The error was logged server-side;
        no internal details are exposed here. You can retry or return to the
        dashboard.
      </p>
      <div className="mt-5 flex gap-2">
        <Button size="sm" onClick={reset}>
          Retry
        </Button>
        <Button size="sm" variant="outline" asChild>
          <a href="/dashboard">Back to dashboard</a>
        </Button>
      </div>
    </div>
  );
}
