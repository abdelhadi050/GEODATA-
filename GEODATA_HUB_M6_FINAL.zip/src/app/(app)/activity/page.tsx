import { getSessionUser } from "@/lib/auth";
import { apiGet, requireData } from "@/lib/server-api";
import { PageHeader } from "@/components/shared/page-header";
import { ActivityFeed } from "@/components/shared/activity-feed";
import { EmptyState } from "@/components/shared/states";
import { Card, CardContent } from "@/components/ui/card";
import type { ActivityItem } from "@/lib/api-types";

export default async function ActivityPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  await getSessionUser();
  const sp = await searchParams;
  const limit = Math.min(Math.max(Number(sp.limit ?? 50) || 50, 1), 100);

  const result = await apiGet<ActivityItem[]>(`/api/activity?limit=${limit}`);
  const { data: items } = await requireData(result);

  return (
    <div className="space-y-6">
      <PageHeader
        title="Activity"
        description={`Audit trail of your organization — latest ${items.length} recorded actions (own tenant only).`}
      />
      <Card>
        <CardContent className="p-3 sm:p-4">
          {items.length === 0 ? (
            <EmptyState
              title="No activity recorded"
              description="Actions such as project creation, lab results and sharing decisions will be recorded here."
            />
          ) : (
            <ActivityFeed items={items} />
          )}
        </CardContent>
      </Card>
      {items.length >= 50 && (
        <p className="text-xs text-muted-foreground">
          Showing the latest {items.length} entries (API maximum: 100).
        </p>
      )}
    </div>
  );
}
