"use client";

/**
 * GEODATA HUB — team management controls (M4).
 * Role changes and activation toggles via PATCH endpoints. Self-changes are
 * disabled client-side (the API rejects them too — defense in depth).
 */
import { useState } from "react";
import { useRouter } from "next/navigation";
import { toast } from "@/hooks/use-toast";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { apiPatch, ApiClientError } from "@/lib/api-client";
import { ALL_ROLES, ROLE_LABELS } from "@/lib/constants";
import type { TeamUser } from "@/lib/api-types";

export function UserRoleSelect({
  user,
  selfId,
  disabled,
}: {
  user: TeamUser;
  selfId: string;
  disabled: boolean;
}) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const isSelf = user.id === selfId;

  async function change(role: string) {
    setBusy(true);
    try {
      await apiPatch(`/api/users/${user.id}/role`, { role });
      toast({
        title: "Role updated",
        description: `${user.name} is now ${ROLE_LABELS[role as keyof typeof ROLE_LABELS] ?? role}`,
      });
      router.refresh();
    } catch (e) {
      if (e instanceof ApiClientError) {
        toast({ title: "Role not changed", description: e.message, variant: "destructive" });
      }
    } finally {
      setBusy(false);
    }
  }

  return (
    <Select
      value={user.role}
      onValueChange={change}
      disabled={busy || disabled || isSelf}
    >
      <SelectTrigger size="sm" className="w-[170px]" aria-label={`Role of ${user.name}`}>
        <SelectValue />
      </SelectTrigger>
      <SelectContent>
        {ALL_ROLES.map((r) => (
          <SelectItem key={r} value={r}>
            {ROLE_LABELS[r]}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}

export function UserActiveSwitch({
  user,
  selfId,
  disabled,
}: {
  user: TeamUser;
  selfId: string;
  disabled: boolean;
}) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const isSelf = user.id === selfId;

  async function toggle(next: boolean) {
    setBusy(true);
    try {
      await apiPatch(`/api/users/${user.id}/status`, { isActive: next });
      toast({
        title: next ? "User activated" : "User deactivated",
        description: next
          ? `${user.name} can sign in again.`
          : `${user.name} was signed out immediately (DB-fresh sessions).`,
      });
      router.refresh();
    } catch (e) {
      if (e instanceof ApiClientError) {
        toast({ title: "Status not changed", description: e.message, variant: "destructive" });
      }
      router.refresh();
    } finally {
      setBusy(false);
    }
  }

  return (
    <Switch
      checked={user.isActive}
      onCheckedChange={toggle}
      disabled={busy || disabled || isSelf}
      aria-label={`${user.isActive ? "Deactivate" : "Activate"} ${user.name}`}
    />
  );
}
